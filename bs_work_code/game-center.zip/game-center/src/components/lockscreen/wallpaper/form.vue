<template>
  <div>
    <Form
      :model="insideformScope"
      ref="insideformScope"
      label-position="right"
      :rules="ruleValidate"
      :label-width="100"
      style="margin-right:100px;width: 600px"
      enctype="multipart/form-data"
    >
      <FormItem label="选择游戏组" prop="GroupID">
        <Select
          v-model="insideformScope.GroupID"
          filterable
          remote
          :remote-method="handleTitleSearch"
          placeholder="请选择游戏组"
          clearable
        >
          <Option v-for="item in GameData" :value="item.ID" :key="item.ID">{{ item.Title }}</Option>
        </Select>
      </FormItem>
      <FormItem label="壁纸标题" prop="Title">
        <Input v-model="insideformScope.Title" placeholder="请输入壁纸标题"></Input>
      </FormItem>
      <FormItem label="壁纸描述" prop="Description">
        <Input
          v-model="insideformScope.Description"
          type="textarea"
          :rows="4"
          placeholder="请输入壁纸描述"
        ></Input>
      </FormItem>
      <FormItem label="壁纸上传" prop="WallpaperImg">
        <div class="demo-upload-list" v-if="insideformScope.URL!=''">
          <img id="wallpaper_img" :src="insideformScope.URL">
          <div class="demo-upload-list-cover">
            <Icon type="ios-eye-outline" @click.native="handleView('img')"></Icon>
            <Icon type="ios-trash-outline" @click.native="handleRemove('img')"></Icon>
          </div>
        </div>
        <Upload
          ref="uploadimg"
          :show-upload-list="false"
          :format="['jpg','jpeg','png','mp4','avi','wmv','rmvb','flv']"
          :on-format-error="handleFormatError"
          :before-upload="handleImgBeforeUpload"
          :on-success="handleImgSuccess"
          type="drag"
          :action="uploadurl"
          style="display: inline-block;width:58px;"
        >
          <div style="width: 58px;height:58px;line-height: 58px;">
            <Icon type="ios-camera" size="20"></Icon>
          </div>
        </Upload>
      </FormItem>
      <Divider orientation="left">生效时间</Divider>
      <FormItem label="开始" prop="ExpiredStart">
        <DatePicker type="date" placeholder="开始时间" v-model="insideformScope.ExpiredStart"></DatePicker>
      </FormItem>
      <FormItem label="结束" prop="ExpiredEnd">
        <DatePicker type="date" placeholder="结束时间" v-model="insideformScope.ExpiredEnd"></DatePicker>
      </FormItem>
      <Divider orientation="left">壁纸按钮</Divider>
      <FormItem label="按钮链接" prop="ButtonURL">
        <Input v-model="insideformScope.ButtonURL" placeholder="按钮链接"></Input>
      </FormItem>
      <FormItem label="按钮文案" prop="ButtonText">
        <Input v-model="insideformScope.ButtonText" placeholder="按钮文案"></Input>
      </FormItem>
      <FormItem label="按钮ICON" prop="ButtonIcon">
        <div class="demo-upload-list" v-if="insideformScope.IconURL!=''">
          <img id="wallpaper_icon" :src="insideformScope.IconURL">
          <div class="demo-upload-list-cover">
            <Icon type="ios-eye-outline" @click.native="handleView('button')"></Icon>
            <Icon type="ios-trash-outline" @click.native="handleRemove('button')"></Icon>
          </div>
        </div>
        <Upload
          ref="uploadicon"
          :show-upload-list="false"
          :format="['jpg','jpeg','png']"
          :on-format-error="handleFormatError"
          :before-upload="handleIconBeforeUpload"
          :on-success="handleIconSuccess"
          type="drag"
          multiple
          :action="uploadurl"
          style="display: inline-block;width:58px;"
        >
          <div style="width: 58px;height:58px;line-height: 58px;">
            <Icon type="ios-camera" size="20"></Icon>
          </div>
        </Upload>
      </FormItem>
      <Divider></Divider>
      <FormItem>
        <Button type="primary" @click="handleSubmit">提交</Button>
        <Button @click="handleReset" style="margin-left: 8px">重置</Button>
      </FormItem>
    </Form>
    <Modal title="预览图片" v-model="preview_visible"  width='250px'>
      <video
        id="preview_video"
        v-if="insideformScope.Type==1"
          style="width: 100%;height:100%;"
        controls
        preload
        :src="preview_url"
      />
      <img id="preview_img" v-if="insideformScope.Type==0"   style="width: 100%;height:100%;" :src="preview_url">
    </Modal>
  </div>
</template>
<script>
import Wallpaper from "@/api/lockscreen/wallpaper";
import GameGroup from "@/api/lockscreen/gamegroup";
import minLogo from "@/assets/images/logo-min.png";
import { AssertVideo } from "@/libs/tools";
export default {
  name: "WallpaperForm",
  props: {
    formScope: {
      type: Object
    },
    reset: {
      type: Boolean
    }
  },
  data() {
    return {
      uploadurl: "",
      preview_url: "",
      preview_visible: false,
      insideformScope: {
        Type: 0,
        GroupID: undefined,
        Title: "",
        Description: "",
        ExpiredStart: "",
        ExpiredEnd: "",
        ButtonURL: "",
        ButtonText: "",
        IconURL: "",
        URL: "",
        Validation: ""
      },
      GameData: [],
      loading: false,
      ruleValidate: {
        GroupID: [
          {
            type: "number",
            required: true,
            message: "请选择游戏组",
            trigger: "blur"
          }
        ],
        Title: [
          {
            required: true,
            message: "请输入壁纸标题",
            trigger: "blur"
          }
        ],
        Description: [
          {
            required: true,
            message: "请输入壁纸描述",
            trigger: "blur"
          }
        ],
        ExpiredStart: [
          {
            required: true,
            type: "date",
            message: "请选择生效时间",
            trigger: "blur"
          }
        ],
        ExpiredEnd: [
          {
            required: true,
            type: "date",
            message: "请选择生效时间",
            trigger: "blur"
          }
        ]
      }
    };
  },
  methods: {
    handleTitleSearch(value) {
      GameGroup.LikeTitle({ value }).then(res => {
        this.GameData = res.Data;
      });
    },
    handleFormatError(file) {
      console.log(file);
      this.$Notice.warning({
        title: "图片格式错误",
        desc: file.name + " 格式错误"
      });
    },
    handleImgBeforeUpload(file) {
      const t = AssertVideo(file.name);
      if (t !== "img" && t != "video") {
        this.handleFormatError(file);
        this.$refs.uploadimg.clearFiles();
        return false;
      }
      t == "video"
        ? (this.insideformScope.Type = 1)
        : (this.insideformScope.Type = 0);
      this.$Loading.start();
      return true;
    },
    handleImgSuccess(res, file) {
      this.insideformScope.URL = res.Data.URL;
      this.insideformScope.Validation = res.Data.Validation;
        this.$Loading.finish();
    },
    handleIconBeforeUpload(file) {
      const t = AssertVideo(file.name);
      if (t !== "img") {
        this.handleFormatError(file);
        this.$refs.uploadicon.clearFiles();
        return false;
      }
      this.$Loading.start();
      return true;
    },
    handleIconSuccess(res, file) {
      this.insideformScope.IconURL = res.Data.URL;
      this.$Loading.finish();
    },
    handleView(t) {
      if (t == "img") {
        this.preview_url = this.insideformScope.URL;
      } else {
        this.preview_url = this.insideformScope.IconURL;
      }
      this.preview_visible = true;
    },
    handleRemove(imgsource) {
      console.log(imgsource);
      if (imgsource == "img" || imgsource == "all") {
        this.$refs.uploadimg.clearFiles();
        this.insideformScope.URL='';
      }
      if (imgsource == "button" || imgsource == "all") {
        this.$refs.uploadicon.clearFiles();
         this.insideformScope.IconURL='';
      }
    },
    handleSubmit() {
      this.$refs["insideformScope"].validate(valid => {
        if (valid) {
          // this.$Loading.start();
          // this.loading = true;
          if (this.insideformScope.URL == "") {
            this.$Message.error("请上传壁纸信息!");
            return;
          }
          this.$emit("on-form-submit", this.insideformScope);
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },
    handleReset() {
      this.insideformScope.GroupID = undefined;
      this.GameData = [];
      this.handleRemove("all");
      this.$refs["insideformScope"].resetFields();
    }
  },
  mounted() {
    this.uploadurl = Wallpaper.UploadURL();
    this.handleTitleSearch("");
  },
  watch: {
    formScope(formScope) {
      this.insideformScope = formScope;
      let has = false;
      this.GameData.filter(item => {
        if (item.ID == formScope.GroupID) {
          has = true;
        }
      });
      if (!has) {
        this.GameData.push({
          ID: formScope.GroupID,
          Title: formScope.GroupTitle,
        });
      }
    }
  }
};
</script>

<style>
.demo-upload-list {
  display: inline-block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  border: 1px solid transparent;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
  margin-right: 4px;
}
.demo-upload-list img {
  width: 100%;
  height: 100%;
}
.demo-upload-list-cover {
  display: none;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
  display: block;
}
.demo-upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 2px;
}
</style>