<template>
  <Modal v-model="modal_show" @on-cancel="cancel">
    <p slot="header">
      <Icon type="information-circled"></Icon>
      <span>壁纸审核</span>
    </p>
    <Form
      ref="formScope"
      :model="formScope"
      label-position="right"
      :rules="ruleValidate"
      :label-width="100"
      style="margin-right:100px;"
    >
      <FormItem label="审核结果" prop="Status">
        <Select v-model="formScope.Status">
          <Option v-for="item in statusList" :value="item.value" :key="item.value">{{ item.label }}</Option>
        </Select>
      </FormItem>
      <FormItem label="审核意见" prop="Opinion">
        <Input v-model="formScope.Opinion" type="textarea" :rows="4" placeholder="请输入审核意见"></Input>
      </FormItem>
    </Form>
    <div slot="footer">
      <Row>
        <Col span="6" offset="18">
          <Button type="success" :loading="loading" @click="handleSubmit">审核</Button>
        </Col>
      </Row>
    </div>
  </Modal>
</template>


<script>
import Wallpaper from "@/api/lockscreen/wallpaper";
export default {
  name: "Check",
  data() {
    return {
      modal_show: false,
      loading: false,
      formScope: {
        ID: undefined,
        Status: "",
        Opinion: ""
      },
      statusList: [{ value: 0, label: "未审核" },{ value: 1, label: "审核成功" },{ value: -1, label: "审核失败" }],
      ruleValidate: {
        Status: {
          required: true,
          type: "number",
          message: "请选择审核结果",
          trigger: "blur"
        },
        Opinion: {
          required: true,
          message: "请输入审核意见",
          trigger: "blur"
        },
      }
    };
  },
  methods: {
    show(ID, Status, Opinion) {
      this.formScope.ID = ID;
      this.formScope.Status = Status;
      this.formScope.Opinion = Opinion;
      this.modal_show = true;
    },
    handleSubmit() {
      this.$refs["formScope"].validate(valid => {
        if (valid) {
          this.$Loading.start();
          this.loading = true;
          Wallpaper.CheckStatus(this.formScope.ID, {
            Status: this.formScope.Status,
            Opinion: this.formScope.Opinion
          }).then(res => {
            this.$Loading.finish();
            this.loading = false;
            if (res.error > 0) {
              this.$Message.warning(res.Message);
              return;
            }
            this.modal_show = false;
            this.$Message.success("审核处理成功!");
            this.$refs["formScope"].resetFields();
            this.$emit("onClose");
          });
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },
    cancel() {
      this.$refs["formScope"].resetFields();
      this.$emit("onClose");
    }
  }
};
</script>