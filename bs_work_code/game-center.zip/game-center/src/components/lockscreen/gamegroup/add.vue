<template>
  <Modal v-model="modal_show" @on-cancel="cancel" :mask-closable="false">
    <p slot="header">
      <Icon type="information-circled"></Icon>
      <span>新增游戏组</span>
    </p>
    <Form
      :model="formScope"
      ref="formScope"
      label-position="right"
      :rules="ruleValidate"
      :label-width="100"
      style="margin-right:100px;"
    >
      <FormItem label="游戏组名:" prop="Title">
        <Input v-model="formScope.Title" placeholder="请输入游戏组名"></Input>
      </FormItem>
    </Form>
    <div slot="footer">
      <Row>
        <Col span="6" offset="18">
          <Button type="success" :loading="loading" @click="handleSubmit" style="float: right;">新增</Button>
        </Col>
      </Row>
    </div>
  </Modal>
</template>


<script>
import GameGroup from "@/api/lockscreen/gamegroup";
export default {
  name: "AddGroup",
  data() {
    return {
      formScope: {
        Title: "",
      },
      modal_show: false,
      loading: false,
      ruleValidate: {
        Title: [
          {
            required: true,
            message: "请输入游戏组",
            trigger: "blur"
          }
        ]
      }
    };
  },
  methods: {
    show() {
      this.modal_show = true;
    },
    handleSubmit() {
      this.$refs["formScope"].validate(valid => {
        if (valid) {
          this.$Loading.start();
          this.loading = true;
          GameGroup.Add({Title:this.formScope.Title}).then(res => {
            this.$Loading.finish();
            this.loading = false;
            if (res.error > 0) {
              this.$Message.warning(res.Message);
              return;
            }
            this.modal_show = false;
            this.$Message.success("新增成功!");
            this.$refs["formScope"].resetFields();
            this.$emit("onClose");
          });
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },
    cancel() {
      this.$refs["formScope"].resetFields();
      this.$emit("onClose");
    }
  }
};
</script>
