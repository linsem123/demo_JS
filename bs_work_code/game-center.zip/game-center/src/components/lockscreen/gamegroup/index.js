import Add from './add.vue'
import Edit from './edit.vue'
export default {
  Add,
  Edit
}
