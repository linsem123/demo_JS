<template>
  <Select
    :value="value"
    :clearable="clearable"
    :multiple="multiple"
    :placeholder="placeholder"
    :disabled="disabled"
    @on-change="updateVal"
    :style="'width:' + width + 'px'"
  >
    <Option v-for="j in dataList" :value="j.Id" :key="j.Id">{{
      j.Name
    }}</Option>
  </Select>
</template>
<script>
export default {
  props: {
    value: {
      default: "",
    },
    width: {
      type: Number,
      default: 100,
    },
    multiple: {
      default: false,
    },
    dataList: Array,
    placeholder: {
      type: String,
      default: "请选择",
    },
    clearable: {
      type: Boolean,
      default: true,
    },
    disabled:{
      type: Boolean,
      default: false,
      }
  },
  methods: {
    updateVal(value) {
      this.$emit("input", value);
      this.$emit("on-change", value);
    },
  },
};
</script>
<style lang="less" scoped>
</style>