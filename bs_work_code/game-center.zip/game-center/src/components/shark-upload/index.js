import SharkUpload from './index.vue'
export default SharkUpload
