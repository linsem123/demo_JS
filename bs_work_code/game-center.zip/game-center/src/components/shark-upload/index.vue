<template>
    <div style="font-size: 0; line-height: normal">
        <div class="demo-upload-list" v-for="(item, index) in uploadList" :key="index">
            <template v-if="item.status === 'finished' || !item.status">
                <template v-if="['img','video','pdf'].includes(getfileType(item.url))">
                    <img :src="item.url" v-if="getfileType(item.url) == 'img'" class="img-prev" />

                    <div class="video-prev" v-if="getfileType(item.url) == 'video'">
                        <!--          <img :src="poster" v-if="poster" />-->
                        <Icon type="md-play" size="20" />
                    </div>

                    <img src="@/assets/images/pdficon.png" v-if="getfileType(item.url) == 'pdf'" class="img-prev" />
                </template>
                <!-- 兼容无法判断类型的链接（由服务器解析返回） -->
                <template v-else>
                    <img :src="item.url" v-if="type.indexOf('img')>=0" class="img-prev" />

                    <div class="video-prev" v-if="type.indexOf('video')>=0">
                        <!--          <img :src="poster" v-if="poster" />-->
                        <Icon type="md-play" size="20" />
                    </div>
                </template>

                <div class="demo-upload-list-cover">
                    <Icon type="ios-eye-outline" @click.native="handleView(item)"></Icon>
                    <Icon v-if="!readOnly" type="ios-trash-outline" @click.native="handleRemove(item)"></Icon>
                </div>
            </template>
        </div>
        <Upload
            v-show="uploadList.length < max"
            ref="upload"
            :show-upload-list="false"
            :on-success="handleSuccess"
            :default-file-list="uploadList"
            :format="format"
            :on-format-error="handleFormatError"
            :before-upload="handleBeforeUpload"
            type="drag"
            :disabled="readOnly"
            :action="action"
            style="display: inline-block;width: 58px;"
        >
            <div style="width: 58px;height: 58px;line-height: 58px;">
                <Icon type="ios-camera" size="20"></Icon>
            </div>
        </Upload>

        <div style="font-size: 14px;" v-if="uploadpercent">
            <i-progress :percent="uploadpercent" hide-info></i-progress>
        </div>
        <Modal title="预览" v-model="preview_visible" width="900">
            <img ref="previewImg" style="max-width: 100%; display: block; margin: auto;" :src="preview_url" />
        </Modal>
    </div>
</template>

<script>
import axios from "@/libs/api.request";
import baseurl from "@/api/gamespace/base";
import { getSuffix, AssertVideo, readImg, compressImg } from "@/libs/tools";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";

export default {
    name: "shark-upload",
    model: {
        // 默认返回数据为数组
        prop: "images",
        event: "uploadImage"
    },
    props: {
        images: null,
        readOnly: false,
        // 上传地址
        action: {
            type: String,
            default: "https://jsonplaceholder.typicode.com/posts/"
        },
        format: {
            type: Array,
            default: function () {
                return [];
            }
        },
        module: {
            type: String,
            default: "game"
        },
        // 最大上传数量
        max: {
            type: Number,
            default: 1
        },
        OnSuccess: {
            type: Function,
            default: function () {}
        },
        OnRemove: {
            type: Function,
            default: function () {}
        },
        type: {
            type: String,
            default: "img" // 默认为img，可选，img video,pdf，可能为多类型，由","隔开，如（img,pdf）
        },
        poster: {},

        towebp: {
            // 是否要压缩转换为webp格式，默认不转
            type: Boolean,
            default: false
        },
        compress: {
            // 是否压缩上传，默认原图
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            uploadList: [],
            preview_visible: false,
            preview_url: "",

            uploadpercent: 0,

            base: {
                width: "",
                height: "",
                size: ""
            }
        };
    },
    mounted() {
        // this.uploadList = this.images || []
        this.uploadList = (() => {
            if (this.max === 1) {
                if (this.images) {
                    return [{ url: this.images }];
                } else {
                    return [];
                }
            }
            return this.images || [];
        })();
        // console.log(this.uploadList)
    },
    watch: {
        images() {
            if (this.max == 1) {
                if (this.images) {
                    this.uploadList = [{ url: this.images }];
                } else {
                    this.uploadList = [];
                }
            } else {
                this.uploadList = this.images || [];
            }
        }
    },
    computed: {
        formatInside() {
            let formatRes = [];
            if (this.format.length > 0) {
                formatRes = this.format;
            } else {
                if (this.type.indexOf("video") >= 0) {
                    formatRes = formatRes.concat(["wmv", "avi", "mpeg", "mpg", "rm", "rmvb", "flv", "mp4"]);
                }
                if (this.type.indexOf("img") >= 0) {
                    formatRes = formatRes.concat(["jpg", "JPG", "jpeg", "JPEG", "png", "PNG", "gif", "GIF", "webp", "WebP", "mp3"]);
                }
                if (this.type.indexOf("pdf") >= 0) {
                    formatRes = formatRes.concat(["pdf"]);
                }
            }
            return formatRes;
        }
    },
    methods: {
        GetSts() {
            return axios.request({
                url: baseurl + "game/sts",
                method: "get"
            });
        },
        modelImages(val) {
            console.log("emit", val);
            if (this.max === 1) {
                this.$emit("uploadImage", (val[0] && val[0].url) || "");
            } else {
                this.$emit("uploadImage", val);
            }
        },
        handleSuccess(res, file, fileList) {
            console.log("handleSuccess", fileList);
            this.uploadpercent = 0;
            this.modelImages(fileList);
            this.uploadList = fileList;
            this.OnSuccess(res, file, fileList);
        },
        handleRemove(file) {
            const list = this.$refs.upload.fileList;
            this.$refs.upload.fileList.splice(list.indexOf(file), 1);
            this.uploadList = this.$refs.upload.fileList;
            this.modelImages(this.uploadList);
            this.OnRemove(file, this.uploadList);
        },
        handleView(file) {
            if (this.getfileType(file.url) == "img") {
                this.preview_url = file.url;
                this.preview_visible = true;
                // let $img = this.$refs.previewImg
                //
                // var $img = new Image()
                // $img.src = "https://cdn-market.blackshark.com/game/1595317058969-35f21cf1-be5a-4278-96c1-04160e4d7f79.webp"
                //
                // // var reader = new FileReader();
                // // reader.readAsDataURL(file);
                // //
                // console.log($img)
                // $img.onload = () => {
                //   console.log($img[0])
                //   this.base.width = $img.width
                //   this.base.height = $img.height
                //   this.base.size = $img.size
                // }
            } else if (this.getfileType(file.url) == "video" || this.getfileType(file.url) == "pdf") {
                window.open(file.url, "_blank");
            } else {
                if (this.type.indexOf("img") >= 0) {
                    this.preview_url = file.url;
                    this.preview_visible = true;
                } else {
                    window.open(file.url, "_blank");
                }
            }
        },
        handleFormatError() {
            let format = [
                ...new Set(
                    this.formatInside.map(item => {
                        return item.toLowerCase();
                    })
                )
            ];
            this.$Message.error("文件格式有误，仅支持：" + format.join("，") + "文件");
        },
        getfileType(url) {
            return AssertVideo(url);
        },
        handleCos(filename, blob) {
            let this_ = this;
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    this_.GetSts().then(data => {
                        // console.log(data)
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: filename,
                    Body: blob /* 必须 */,
                    onProgress: function (progressData) {
                        this_.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        // console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        console.error(err);
                        this_.$Message.warning("上传失败");
                        return;
                    }
                    this_.uploadList.push({
                        url: cosconfig.exporturl + "/" + filename
                    });
                    this_.modelImages(this_.uploadList);
                    this_.uploadpercent = 0;
                }
            );
        },
        handleBeforeUpload(file) {
            if (this.format.length > 0) {
                let suffix = getSuffix(file.name);
                console.log(this.format);
                if (!this.format.includes(suffix)) {
                    this.handleFormatError();
                    this.$refs.upload.clearFiles();
                    return false;
                }
            } else {
                const t = AssertVideo(file.name);
                if (this.type.indexOf(t) < 0) {
                    this.handleFormatError();
                    this.$refs.upload.clearFiles();
                    return false;
                }
            }

            // let nameReg = /[`~!@#$^&*()=|{}':;',\\\[\]<>\/?~！@#￥……&*（）——|{}【】'；：""'。，、？%\s]/g; // 去除文件名中特殊字符和空格
            // let key = this.module + "/" + new Date().getTime() + "-" + file.name.replace(nameReg, "");
            let key = this.module + "/" + new Date().getTime();

            if (this.type.indexOf("img") >= 0 && AssertVideo(key) === "img") {
                if (this.compress) {
                    let filename = "";
                    let suffix = getSuffix(file.name);
                    let comType = "image/" + suffix;
                    if (this.towebp) {
                        comType = "image/webp";
                    }
                    readImg(file).then(img => {
                        compressImg(img, comType).then(({ blob }) => {
                            let dotidx = key.lastIndexOf(".");
                            filename = key.substr(0, dotidx) + "." + comType.replace("image/", "");

                            this.handleCos(filename, blob);
                        });
                    });
                } else {
                    this.handleCos(key, file);
                }
            } else {
                this.handleCos(key, file);
            }

            // return false;

            return false;
        }
    }
};
</script>

<style scoped lang="less">
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
    .video-prev {
        display: inline-block;
        text-align: center;
        line-height: 60px;
    }
}
.demo-upload-list img {
    width: 100%;
    height: 100%;
}
.demo-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
    display: block;
}
.demo-upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
}
</style>
