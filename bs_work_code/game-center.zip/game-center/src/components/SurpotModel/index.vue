<template>
  <div>
    <Checkbox
      :indeterminate="indeterminate"
      :value="checkAll"
      @click.prevent.native="handleCheckAll"
      >全选</Checkbox
    >

    <CheckboxGroup :value="value" @on-change="checkAllGroupChange">
      <!-- <Checkbox
        v-for="(m, index) in phoneModel"
        :label="m.value"
        :key="index"
        >{{ m.name }}</Checkbox
      > -->
      <Checkbox v-for="(m, index) in phoneModel" :label="m.Name" :key="index">{{
        m.Name
      }}</Checkbox>
    </CheckboxGroup>
  </div>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
export default {
  name: "SurpotModel",
  props: {
    value: Array,
  },
  data() {
    return {
      // 机型
      phoneModel: [
        // { value: "SKR-A0", name: "SKR-A0" },
        // { value: "AWM-A0", name: "AWM-A0" },
        // { value: "SKW-A0", name: "SKW-A0" },
        // { value: "DLT-A0", name: "DLT-A0" },
        // { value: "SHARK MBU-A0", name: "SHARK MBU-A0" },
        // { value: "SHARK KLE-A0", name: "SHARK KLE-A0" },
        // { value: "SHARK KLE-A1", name: "SHARK KLE-A1" },
        // { value: "SHARK KSR-A0", name: "SHARK KSR-A0" },
        // { value: "SHARK PRS-A0", name: "SHARK PRS-A0" },
      ],
      indeterminate: false,
      checkAll: true,
    };
  },
  async mounted() {
    await this.getPhoneList();
    console.log(1111);
    console.log(this.phoneModel.length);
    if (this.value.length == this.phoneModel.length || this.value.length == 0) {
      this.checkAll = true;
    } else {
      this.checkAll = false;
    }
    if (this.checkAll) {
      let data = this.phoneModel.map((m) => {
        // return m.value;
        return m.Name;
      });
      this.$emit("input", data);
    }
  },
  methods: {
    getPhoneList() {
      return new Promise((resolve) => {
        GameAPI.getPhoneModel().then((res) => {
          if (res.Code == 0) {
            this.phoneModel = res.Data || [];
            resolve();
          }
        });
      });
    },
    checkAllGroupChange(data) {
      this.$emit("input", data);
      if (data.length === this.phoneModel.length) {
        this.indeterminate = false;
        this.checkAll = true;
      } else if (data.length > 0) {
        this.indeterminate = true;
        this.checkAll = false;
      } else {
        this.indeterminate = false;
        this.checkAll = false;
      }
    },
    handleCheckAll() {
      if (this.indeterminate) {
        this.checkAll = false;
      } else {
        this.checkAll = !this.checkAll;
      }
      this.indeterminate = false;

      if (this.checkAll) {
        let data = this.phoneModel.map((m) => {
          // return m.value;
          return m.Name;
        });
        this.$emit("input", data);
      } else {
        // this.formData.SupportModel = [];
        this.$emit("input", []);
      }
    },
  },
};
</script>