<template>
  <Select
    v-model="value"
    filterable
    remote
    clearable
    :placeholder="placeholder"
    :remote-method="getAppList"
    :loading="loading"
    ref="selection"
    @on-clear="valClear"
    @on-change="valChange"
  >
    <Option v-for="item in appList" :value="item.ID" :key="item.ID">{{
      item.Title
    }}</Option>
  </Select>
</template>

<script>
import ActivityAPI from "@/api/gamespace/publicActivity";

export default {
  name: "AppSelect",
  model: {
    prop: "modelValue",
    event: "valueChange",
  },
  props: {
    modelValue: null,
    placeholder: {
      type: String,
      default: "请选择活动",
    },
  },
  data() {
    return {
      value: null,
      loading: false,
      appList: [],
      list: [],
      appTitle: "",
      label: "",
    };
  },
  mounted() {
    this.getAppById(this.modelValue);
  },
  watch: {
    modelValue(v) {
      this.value = v;
      this.getAppById(v);
    },
  },
  methods: {
    getAppList(v) {
      // console.log(v)
      let value = v || this.value;
      if (!value || this.loading) {
        return;
      }
      if (
        this.appList &&
        this.appList.length === 1 &&
        this.appList[0].Title === v
      ) {
        return;
      }
      this.loading = true;
      ActivityAPI.KeyGameLike(value).then((res) => {
        if (res.Code === 0) {
          this.list = res.Data || [];
          this.appList = this.list.filter(
            (item) => item.Title.toLowerCase().indexOf(v.toLowerCase()) > -1
          );
        }
        this.loading = false;
      });
    },

    getAppById(id) {
      console.log(id);
      if (
        this.appList &&
        this.appList.length === 1 &&
        this.appList[0].ID == this.modelValue
      ) {
        return;
      }
      if (!id || id == null) {
        return;
      }
      this.loading = true;
      ActivityAPI.KeyGameTemplate(id).then((res) => {
        this.appList =
          [
            {
              ID: res.Data["ID"],
              Title: res.Data["Title"],
              FeedURL: res.Data["FeedURL"],
            },
          ] || [];

        this.$refs["selection"].setQuery(res.Data["Title"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.$nextTick(() => {
          this.loading = false;
          this.$emit("on-change", { value: this.appList[0] || {}, index: 0 }); // 首次change，index为了防止首次change被回调导致外部默认数据改变
        });
      });
    },

    valChange(v) {
      if (!v) {
        this.$refs["selection"].setQuery(this.appList[0]["Title"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.value = this.appList[0]["ID"];
      }
      this.$emit("valueChange", v);

      this.appList.map((item) => {
        if (v == item.ID) {
          this.$emit("on-change", { value: item, index: 1 });
        }
      });
    },

    valClear() {
      this.$emit("on-change", {});
    },
  },
};
</script>

<style scoped>
</style>
