<template>
  <Select
    v-model="value"
    filterable
    remote
    clearable
    :placeholder="placeholder"
    :remote-method="getActivityList"
    :loading="loading"
    ref="selection"
    @on-clear="valClear"
    @on-change="valChange"
  >
    <Option
      v-for="item in activityList"
      :value="item.value"
      :key="item.value"
      >{{ item.label | filterLabel(item, type) }}</Option
    >
  </Select>
</template>

<script>
import ActivityApi from "@/api/gamespace/activitylist";

export default {
  name: "ActivitySelect",
  model: {
    prop: "modelValue",
    event: "valueChange",
  },
  props: {
    modelValue: null,
    placeholder: {
      type: String,
      default: "请选择活动",
    },
    type: Number, // 图文活动，抽奖活动，论坛帖
  },
  data() {
    return {
      value: null,
      loading: false,
      activityList: [],
      list: [],
      activityTitle: "",
      activityType: null,
    };
  },
  filters: {
    filterLabel(value, item, type) {
      if (item) {
        //type为11展示FeeID+Title
        if (type == 11) return `${item.FeedID} (${item.label})`;
        else return item.label;
      } else {
        return "";
      }
    },
  },
  mounted() {
    this.activityType = this.type;
    if (this.type == 11) this.activityType = 3;
    this.getActivityById(this.modelValue);
  },
  watch: {
    modelValue(v) {
      this.value = v;
      this.getActivityById(v);
    },
    type(v, o) {
      // console.log(v,o)
      this.activityType = v;
      if (this.type == 11) this.activityType = 3;
    },
  },
  methods: {
    getActivityList(v) {
      let str = v || this.value;
      if (!str || this.loading) {
        return;
      }
      if (
        this.activityList &&
        this.activityList.length === 1 &&
        this.activityList[0].Title === v
      ) {
        return;
      }
      this.loading = true;
      ActivityApi.LikeActivity(str, this.activityType).then((res) => {
        // console.log(str,this.activityType)
        if (res.Code === 0) {
          this.list = res.Data || [];
          const list = this.list.map((item) => {
            return {
              value: item.ID,
              label: item.Title,
              ...item,
            };
          });
          this.activityList = list.filter(
            (item) => item.label.toLowerCase().indexOf(v.toLowerCase()) > -1
          );
        }
        this.loading = false;
      });
    },

    getActivityById(id) {
      console.log(id);
      if (
        this.activityList &&
        this.activityList.length === 1 &&
        this.activityList[0].ID == this.modelValue
      ) {
        return;
      }
      if (!id || id == null) {
        return;
      }
      this.loading = true;
      ActivityApi.FeedsInfo(id).then((res) => {
        this.activityList = [
          {
            value: res.Data["ID"],
            label: res.Data["Title"],
            ...res.Data,
          },
        ];
        this.$refs["selection"].setQuery(res.Data["Title"]);
        this.$refs["selection"].toggleMenu(null, false);
        // console.log(this.activityList)
        this.$nextTick(() => {
          this.loading = false;
          this.$emit("on-change", {
            value: this.activityList[0] || {},
            index: 0,
          });
        });
      });
    },

    valChange(v) {
      if (!v) {
        this.$refs["selection"].setQuery(this.activityList[0]["label"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.value = this.activityList[0]["value"];
      }
      this.$emit("valueChange", v);
      this.activityList.forEach((item) => {
        if (v == item.value) {
          this.$emit("on-change", { value: item, index: 1 });
        }
      });
    },

    valClear() {
      this.$emit("on-change", { value: {}, index: 0 });
    },
  },
};
</script>

<style scoped>
</style>
