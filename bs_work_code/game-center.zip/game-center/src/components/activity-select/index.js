import ActivitySelect from './index.vue'
export default ActivitySelect
