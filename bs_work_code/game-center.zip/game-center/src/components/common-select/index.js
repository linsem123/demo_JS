import CommonSelect from './index.vue'
export default CommonSelect
