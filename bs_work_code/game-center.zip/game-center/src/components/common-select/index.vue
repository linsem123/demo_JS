<template>
  <Select
    v-model="value"
    filterable
    remote
    clearable
    :placeholder="placeholder"
    :remote-method="getAppList"
    :loading="loading"
    ref="selection"
    @on-clear="valClear"
    @on-change="valChange"
  >
    <Option v-for="item in appList" :value="item.ID" :label="item.Title" :key="item.ID">{{
        showOptionId ? `${item.ID}（${item.Title}）` : item.Title
    }}</Option>
  </Select>
</template>

<script>
// import ActivityAPI from "@/api/gamespace/publicActivity";
import Api from "@/api/fuzzy";

export default {
  name: "CommonSelect",
  model: {
    prop: "modelValue",
    event: "valueChange",
  },
  props: {
    modelValue: null,
    placeholder: {
      type: String,
      default: "请选择活动",
    },
    serverData: {
      type: Object,
      default: {
        likeUrl: "",
        likeData: {},
        setUrl: "",
        setData: {},
        IdKey: "",
        NameKey: "",
      },
    },

    // 4.11新增，option前是否显示Id
    showOptionId: {
        type: Boolean,
        default: false
    }
  },
  data() {
    return {
      value: null,
      loading: false,
      appList: [],
      list: [],
    };
  },
  mounted() {
    this.getAppById(this.modelValue);
  },
  watch: {
    modelValue(v) {
      this.value = v;
      this.getAppById(v);
    },
  },
  methods: {
    getAppList(v) {
      let value = v || this.value;
      if (!value || this.loading) {
        return;
      }
      if (
        this.appList &&
        this.appList.length === 1 &&
        this.appList[0].Title === v
      ) {
        return;
      }
      this.loading = true;
      Api[this.serverData.likeUrl]({
        like: v,
        ...this.serverData.likeData,
      })
        .then((res) => {
          if (res.Code === 0) {
            this.list = res.Data || [];
            this.list = this.list.map((v) => {
              v.ID = v[this.serverData.IdKey || "ID"];
              v.Title = v[this.serverData.NameKey || "Title"];
              return v;
            });
            this.appList = this.list.filter(
              (item) => item.Title.toLowerCase().indexOf(v.toLowerCase()) > -1
            );
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },

    getAppById(id) {
      if (
        this.appList &&
        this.appList.length === 1 &&
        this.appList[0].ID == this.modelValue
      ) {
        return;
      }
      if (!id || id == null) {
        return;
      }
      this.loading = true;
      Api[this.serverData.setUrl]({
        id,
        ...this.serverData.setData,
      })
        .then((res) => {
          if (res.Code == 0) {
            if (
              (res.Data.Data && Array.isArray(res.Data.Data)) ||
              Array.isArray(res.Data)
            ) {
              if (Array.isArray(res.Data)) {
                this.list = res.Data || [];
              } else {
                this.list = res.Data.Data || [];
              }
              this.appList = this.list.map((v) => {
                v.ID = v[this.serverData.IdKey || "ID"];
                v.Title = v[this.serverData.NameKey || "Title"];
                return v;
              });
            } else {
              this.appList =
                [
                  {
                    ...res.Data,
                    ID: res.Data[this.serverData.IdKey || "ID"],
                    Title: res.Data[this.serverData.NameKey || "Title"],
                  },
                ] || [];
            }
            this.$refs["selection"].setQuery(this.appList[0]["Title"]);
            this.$refs["selection"].toggleMenu(null, false);

            this.$nextTick(() => {
              this.loading = false;
              this.$emit("on-change", {
                value: this.appList[0] || {},
                index: 0,
              }); // 首次change，index为了防止首次change被回调导致外部默认数据改变
            });
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },

    valChange(v) {
      if (!v && this.appList.length > 0) {
        this.$refs["selection"].setQuery(this.appList[0]["Title"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.value = this.appList[0]["ID"];
      }
      this.$emit("valueChange", v);

      this.appList.map((item) => {
        if (v == item.ID) {
          this.$emit("on-change", { value: item, index: 1 });
        }
      });
    },

    valClear() {
      // console.log(111111);
      this.$emit("on-change", {});
    },
    clearText() {
      this.$refs["selection"].clearSingleSelect();
      this.appList = [];
    },
    setQuery({ id, title }) {
      this.$refs["selection"].setQuery(title);
      this.$refs["selection"].toggleMenu(null, false);
    },
  },
};
</script>

<style scoped>
</style>
