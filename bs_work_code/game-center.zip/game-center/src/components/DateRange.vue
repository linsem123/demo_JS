<template>
  <div>
    <DatePicker
      :value="value[0]"
      :type="type"
      :format="format"
      :placeholder="placeholder[0]"
      @on-change="changeStart"
      :style="`width:${width}`"
      :disabled="disabled"
    ></DatePicker>
    <!-- :options="options" -->
    -
    <DatePicker
      :value="value[1]"
      :type="type"
      :format="format"
      :placeholder="placeholder[1]"
      :style="`width:${width}`"
      @on-change="changeEnd"
      :disabled="disabled"
    ></DatePicker>
    <!-- :options="options" -->
  </div>
</template>
<script>
export default {
  name: "DateRange",
  props: {
    type: { type: String, default: "datetime" },
    value: {
      type: Array,
      default: () => ["", ""],
    },
    placeholder: {
      type: Array,
      default: () => ["请选择开始时间", "请选择结束时间"],
    },
    width: {
      type: Number,
      default: 200,
    },
    format: {
      type: String,
      default: "yyyy-MM-dd HH:mm:ss",
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      options: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 86400000;
        },
      },
    };
  },
  methods: {
    changeStart(value) {
      let arr = this.value;
      arr[0] = value;
      this.$emit("input", arr);
      this.$emit("on-change", { start: arr[0], end: arr[1] });
    },
    changeEnd(value) {
      let arr = this.value;
      arr[1] = value;
      this.$emit("input", [this.value[0], value]);
      this.$emit("on-change", { start: arr[0], end: arr[1] });
    },
  },
};
</script>