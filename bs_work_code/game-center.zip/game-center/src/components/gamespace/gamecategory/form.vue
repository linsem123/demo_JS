<template>
  <div>
    <Form
      :model="insideformScope"
      ref="insideformScope"
      label-position="right"
      :rules="ruleValidate"
      :label-width="100"
      style="margin-right:100px;width: 600px"
    >
      <FormItem label="应用类型" prop="AppType">
        <RadioGroup v-model="insideformScope.AppType">
          <Radio :label="0">
            <span>游戏</span>
          </Radio>
          <Radio :label="1">
            <span>应用</span>
          </Radio>
        </RadioGroup>
      </FormItem>
      <FormItem label="分类名称:" prop="Name">
        <Input v-model="insideformScope.Name" placeholder="分类名称"></Input>
      </FormItem>
      <FormItem>
        <Button type="primary" @click="handleSubmit">提交</Button>
        <Button @click="handleReset" style="margin-left: 8px">重置</Button>
      </FormItem>
    </Form>
  </div>
</template>


<script>
export default {
  name: "DeveloperForm",
  props: {
    formScope: {
      type: Object
    }
  },
  data() {
    return {
      loading: false,
      insideformScope: {
        Name: ""
      },
      ruleValidate: {
        Name: [
          {
            required: true,
            message: "请输入分类名称",
            trigger: "blur"
          }
        ],
        AppType: [
          {
            required: true,
            type: 'number',
            message: '请选择应用类型',
            trigger: 'blur'
          }
        ]
      }
    };
  },
  methods: {
    handleSubmit() {
      this.$refs["insideformScope"].validate(valid => {
        if (valid) {
          this.$emit("on-form-submit", this.insideformScope);
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },
    handleReset() {
      this.$refs.insideformScope.resetFields();
    }
  },
  watch: {
    formScope(formScope) {
      this.insideformScope = formScope;
    }
  }
};
</script>
