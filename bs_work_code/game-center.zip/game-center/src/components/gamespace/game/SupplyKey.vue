<template>
  <div>
    <Modal
      v-model="modelShow"
      title="补充礼包码"
      :closable="false"
      :mask-closable="false"
    >
      <Form
        ref="formValidate"
        :model="formValidate"
        label-position="right"
        :label-width="110"
      >
        <FormItem label="礼包标题" prop="Title">
          {{ formValidate.Title }}
        </FormItem>
        <FormItem v-if="!currentGame.ShowType" label="礼包文件" prop="file">
          <div style="float: left; margin-right: 20px">
            <Upload
              action="//jsonplaceholder.typicode.com/posts/"
              :before-upload="handleUpload"
            >
              <Button icon="ios-cloud-upload-outline">选择文件</Button>
            </Upload>
          </div>
          <div style="color: red" v-if="gifFile !== null">
            文件: {{ gifFile.name }} : 礼包数量 {{ gifNum }}
          </div>
        </FormItem>
        <FormItem v-if="!currentGame.ShowType" label="文件提交进度">
          <Progress :percent="uploadpercent" :status="percentSstatus" />
        </FormItem>
      </Form>
      <div slot="footer">
        <Button type="text" size="large" @click="modalCancel">取消</Button>
        <Button
          type="primary"
          size="large"
          @click="addGameGif"
          :loading="loadingStatus"
          >确定</Button
        >
      </div>
    </Modal>
  </div>
</template>
<script>
import GameGifAPI from "@/api/gamespace/gamegif";

export default {
  name: "SupplyGameGif",
  props: {
    currentGame: {
      type: Object,
    },
  },
  data() {
    return {
      modelShow: true,
      loadingStatus: false,
      gifFile: null,
      gifNum: 0,
      formValidate: {},
      CDKey: [],
      uploadpercent: 0, //进度条
      timer: null,
      percentSstatus: "active",
    };
  },
  mounted() {
    this.formValidate = JSON.parse(JSON.stringify(this.currentGame));
  },
  methods: {
    handleUpload(file) {
      if (file.type !== "text/plain" || file.type < 100) {
        this.$Message.error("choose right file");
        this.gifFile = null;
        return false;
      }
      var reader = new FileReader(); // 新建一个FileReader
      reader.readAsText(file, "UTF-8"); // 读取文件
      reader.onload = (evt) => {
        // 读取完文件之后会回来这里
        var fileString = evt.target.result; // 读取文件内容
        this.CDKey = fileString.split("\n");
        var cdkeys = [];
        this.CDKey.forEach(function (item) {
          if (item.match(/^\s*$/)) {
            console.log("空格");
          } else {
            cdkeys.push(item);
          }
        });
        this.CDKey = cdkeys;
        this.gifNum = this.CDKey.length;
      };
      this.gifFile = file;
      return false;
    },
    timeInterval(num, time) {
      this.timer = setInterval(() => {
        if (this.uploadpercent < num) {
          this.uploadpercent += 1;
        } else {
          clearInterval(this.timer);
          this.timer = null;
        }
      }, time);
    },

    addGameGif() {
      if (this.CDKey.length > 0) {
        this.loadingStatus = true;
        clearInterval(this.timer);
        this.timer = null;
        this.uploadpercent = 0;
        this.timeInterval(99, 500);
        GameGifAPI.SupplyGift({ Keys: this.CDKey }, this.formValidate.ID).then(
          (res) => {
            console.log(res);
            if (res.Code === 0) {
              clearInterval(this.timer);
              this.timer = null;
              this.timer = setInterval(() => {
                if (this.uploadpercent < 100) {
                  this.uploadpercent += 1;
                } else {
                  clearInterval(this.timer);
                  this.timer = null;
                  setTimeout(() => {
                    this.$Message.success("Success!");
                    this.loadingStatus = false;
                    this.$emit("on-init");
                  }, 100);
                }
              }, 10);
            } else {
              this.$Message.error(res.Message);
              clearInterval(this.timer);
              this.timer = null;
              this.loadingStatus = false;
            }
          }
        );
      } else {
        this.$Message.error("请上传礼包码");
      }
    },
    modalCancel() {
      this.$emit("on-close-model");
    },
  },
};
</script>

<style>
.demo-upload-list {
  display: inline-block;
  width: 60px;
  height: 60px;
  text-align: center;
  line-height: 60px;
  border: 1px solid transparent;
  border-radius: 4px;
  overflow: hidden;
  background: #fff;
  position: relative;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
  margin-right: 4px;
}
.demo-upload-list img {
  width: 100%;
  height: 100%;
}
.demo-upload-list-cover {
  display: none;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
  display: block;
}
.demo-upload-list-cover i {
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  margin: 0 2px;
}
</style>
