<template>
    <div>
        <Modal
            v-model="modelShow"
            v-if="currentGame"
            :title="
        currentGame.ShowType
          ? '游戏礼包配置:' + currentGame.AppName
          : '绑定礼包文件:' + currentGame.Title
      "
            :closable="false"
            :mask-closable="false"
        >
            <Form ref="formValidate" :model="formValidate" label-position="right" :label-width="120" :rules="ruleValidate">
                <FormItem label="礼包标题" prop="title">
                    <Input v-model="formValidate.title" :disabled="!currentGame.ShowType" placeholder="请输入活动标题"></Input>
                </FormItem>
                <FormItem label="内容介绍" prop="content">
                    <Input
                        v-model="formValidate.content"
                        type="textarea"
                        :autosize="{ minRows: 5, maxRows: 20 }"
                        placeholder="请输入礼包内容"
                        :disabled="!currentGame.ShowType"
                    ></Input>
                </FormItem>
                <FormItem label="使用方法" prop="instruction">
                    <Input
                        v-model="formValidate.instruction"
                        type="textarea"
                        :autosize="{ minRows: 5, maxRows: 20 }"
                        :disabled="!currentGame.ShowType"
                        placeholder="请输入使用方法"
                    ></Input>
                </FormItem>
                <!-- <FormItem label="截止日期" prop="expiredend">
          <DatePicker
            type="date"
            v-model="formValidate.expiredend"
            :disabled="!currentGame.ShowType"
            format="yyyy-MM-dd HH:mm"
            placeholder="请选择截止时间"
            style="width: 200px"
          ></DatePicker>
                </FormItem>-->
                <FormItem label="生效周期：" prop="Expired">
                    <DateRange
                        v-model="formValidate.Expired"
                        @on-change="
              (value) => {
                formValidate.StartTime = value.start;
                formValidate.expiredend = value.end;
              }
            "
                        :disabled="!currentGame.ShowType"
                    />
                </FormItem>
                <FormItem label="礼包类型">
                    <Select v-model="formValidate.GiftType" style="width: 200px" :disabled="!currentGame.ShowType">
                        <Option v-for="item in giftTypeList" :value="item.ID" :key="item.ID">{{ item.Name }}</Option>
                    </Select>
                </FormItem>
                <FormItem label="可领取最低vip等级" v-if="formValidate.GiftType == 6" prop="FilterLevel">
                    <InputNumber :min="0" :max="18" v-model="formValidate.FilterLevel" placeholder="请输入可领取最低vip等级" style="width: 100px"></InputNumber>
                    <span style="padding-left: 6px; font-size: 12px">输入范围：1-18</span>
                </FormItem>
                <FormItem v-if="!currentGame.ShowType" label="礼包文件" prop="file">
                    <div style="float: left; margin-right: 20px">
                        <Upload action="//jsonplaceholder.typicode.com/posts/" :before-upload="handleUpload">
                            <Button icon="ios-cloud-upload-outline">选择文件</Button>
                        </Upload>
                    </div>
                    <div style="color: red" v-if="gifFile !== null">文件: {{ gifFile.name }} : 礼包数量 {{ gifNum }}</div>
                </FormItem>
                <FormItem v-if="!currentGame.ShowType" label="文件提交进度">
                    <Progress :percent="uploadpercent" :status="percentSstatus" />
                </FormItem>
                <FormItem label="单人最大领取数" prop="MaxReceiveCount" v-if="currentGame.ShowType">
                    <InputNumber v-model="formValidate.MaxReceiveCount" :disabled="!currentGame.ShowType" />
                </FormItem>
                <FormItem label="领取范围" v-if="currentGame.ShowType">
                    <CheckboxGroup v-model="formValidate.ReceiveRuleScope">
                        <Checkbox
                            v-for="item in ScopeList"
                            :label="item.ID"
                            :key="item.ID"
                            :disabled="!currentGame.ShowType"
                        >{{ item.Name }}</Checkbox>
                    </CheckboxGroup>
                </FormItem>
                <FormItem label="选择机型" v-if="formValidate.ReceiveRuleScope.includes(1)">
                    <SurpotModel v-model="formValidate.SupportModel" />
                </FormItem>
                <!-- sdk 5.5.0新增 -->
                <FormItem label="剩余不足预警：" v-if="currentGame.ShowType">
                    <Checkbox v-model="formValidate.Conf.IsWarning">启用</Checkbox>
                </FormItem>
                <template v-if="currentGame.ShowType && formValidate.Conf.IsWarning">
                    <FormItem label="预警节点：">
                        <CheckboxGroup v-model="formValidate.Conf.WarningLevel">
                            <Checkbox :label="0.3">30%</Checkbox>
                            <Checkbox :label="0.1">10%</Checkbox>
                            <Checkbox :label="0">0%</Checkbox>
                        </CheckboxGroup>
                    </FormItem>
                    <FormItem label="负责人：">
                        <CheckboxGroup v-model="formValidate.Conf.WarningPerson">
                            <Checkbox v-for="item in personList" :key="item.Id" :label="item.Name">{{ item.Name }}</Checkbox>
                        </CheckboxGroup>
                    </FormItem>
                </template>
            </Form>
            <div slot="footer">
                <Button type="text" size="large" @click="modalCancel">取消</Button>
                <Button type="primary" size="large" @click="addGameGif" :loading="loadingStatus">确定</Button>
            </div>
        </Modal>
    </div>
</template>
<script>
import GameGifAPI from "@/api/gamespace/gamegif";
import SurpotModel from "_c/SurpotModel";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";

export default {
    name: "AddGameGif",
    props: {
        currentGame: {
            type: Object
        },
        personList: {
            type: Array
        }
    },
    components: { SurpotModel, DateRange },
    data() {
        const NumValidate = (rule, value, callback) => {
            if (!value || Number(value) < 1) {
                callback("单人最大领取数必须大于0");
            }
            callback();
        };
        const FilterLevelValidator = (rule, value, callback) => {
            console.log(this.formValidate.FilterLevel);
            if (this.formValidate.FilterLevel > 18 || this.formValidate.FilterLevel < 1) {
                callback("输入范围：1-18");
            }
            callback();
        };
        return {
            gifFile: null,
            gifNum: 0,
            modelShow: true,
            loadingStatus: false,

            giftTypeList: [
                { ID: 1, Name: "预约礼包" },
                { ID: 0, Name: "普通礼包" },
                { ID: 3, Name: "抽奖礼包" },
                { ID: 4, Name: "预约下载礼包" },
                { ID: 5, Name: "新机活动礼包" },
                { ID: 6, Name: "VIP专属礼包" }
            ],
            ScopeList: [{ ID: 1, Name: "指定机型" }],
            formValidate: {
                GiftType: 0,
                title: "",
                content: "",
                expiredend: "",
                instruction: "",
                CDKey: [],
                ReceiveRuleScope: [],
                SupportModel: [],
                MaxReceiveCount: 1,
                Expired: [],
                Conf: {
                    IsWarning: true,
                    WarningLevel: [0.3, 0.1, 0],
                    WarningPerson: []
                }
            },
            ruleValidate: {
                title: [
                    {
                        required: true,
                        message: "礼包标题不能为空",
                        trigger: "blur"
                    }
                ],
                content: [
                    {
                        required: true,
                        message: "内容介绍不能为空",
                        trigger: "blur"
                    }
                ],
                instruction: [
                    {
                        required: true,
                        message: "使用方法不能为空",
                        trigger: "blur"
                    }
                ],
                // expiredend: [
                //   {
                //     required: true,
                //     message: "截止日期不能为空",
                //     type: "date",
                //     trigger: "blur",
                //   },
                // ],
                MaxReceiveCount: [
                    {
                        required: true,
                        validator: NumValidate,
                        trigger: "blur"
                    }
                ],
                Expired: [
                    {
                        validator: checkDateRange,
                        trigger: "change",
                        type: "array"
                    }
                ],
                FilterLevel: [{ validator: FilterLevelValidator, trigger: "change" }]
            },
            uploadpercent: 0, //进度条
            timer: null,
            percentSstatus: "active",
            nowTime: new Date()
        };
    },
    methods: {
        init() {
            this.formValidate.GiftType = this.currentGame.GiftType;
            this.formValidate.expiredend = this.currentGame.ExpiredEnd;
            this.formValidate.title = this.currentGame.Title;
            this.formValidate.content = this.currentGame.Content;
            this.formValidate.instruction = this.currentGame.Instruction;
            this.formValidate.Expired = [formatTimes(this.currentGame.StartTime), formatTimes(this.currentGame.ExpiredEnd)];
            // sdk 5.5.0新增 防止有null的情况
            this.formValidate.Conf && !this.formValidate.Conf.WarningLevel ? (this.formValidate.Conf.WarningLevel = []) : "";
            this.formValidate.Conf && !this.formValidate.Conf.WarningPerson ? (this.formValidate.Conf.WarningPerson = []) : "";
        },
        handleUpload(file) {
            if (file.type !== "text/plain" || file.type < 100) {
                this.$Message.error("choose right file");
                this.gifFile = null;
                return false;
            }
            var reader = new FileReader(); // 新建一个FileReader
            var $this = this;
            reader.readAsText(file, "UTF-8"); // 读取文件
            reader.onload = function (evt) {
                // 读取完文件之后会回来这里
                var fileString = evt.target.result; // 读取文件内容
                $this.formValidate.CDKey = fileString.split("\n");
                console.log($this.formValidate.CDKey);
                var cdkeys = [];
                $this.formValidate.CDKey.forEach(function (item) {
                    if (item.match(/^\s*$/)) {
                        console.log("空格");
                    } else {
                        cdkeys.push(item);
                    }
                });
                $this.formValidate.CDKey = cdkeys;
                $this.gifNum = $this.formValidate.CDKey.length;
            };

            this.gifFile = file;
            return false;
        },
        timeInterval(num, time) {
            this.timer = setInterval(() => {
                if (this.uploadpercent < num) {
                    this.uploadpercent += 1;
                } else {
                    clearInterval(this.timer);
                    this.timer = null;
                }
            }, time);
        },
        upload() {
            this.loadingStatus = true;
            setTimeout(() => {
                this.gifFile = null;
                this.loadingStatus = false;
                this.$Message.success("Success");
            }, 1500);
        },

        addGameGif() {
            if (this.currentGame.ShowType) {
                this.$refs["formValidate"].validate(valid => {
                    if (valid) {
                        if (!this.formValidate.StartTime || !this.formValidate.expiredend) {
                            this.$Modal.confirm({
                                title: "提示",
                                okText: "确认",
                                cancelText: "取消",
                                loading: true,
                                content: "<p>还未设置生效期，是否继续发布？</p>",
                                onOk: () => {
                                    this.submitForm();
                                    this.$Modal.remove();
                                }
                            });
                        } else {
                            this.submitForm();
                        }
                    } else {
                        this.$Message.error("请填写必填信息");
                    }
                });
            }

            if (!this.currentGame.ShowType) {
                var param = {
                    ID: this.currentGame.ID,
                    Title: this.formValidate.title,
                    Content: this.formValidate.content,
                    Instruction: this.formValidate.instruction,
                    CDKey: this.formValidate.CDKey,
                    ExpiredEnd: new Date(this.formValidate.expiredend),
                    StartTime: new Date(this.formValidate.StartTime),
                    GiftType: this.formValidate.GiftType
                };
                this.$refs["formValidate"].validate(valid => {
                    if (valid) {
                        this.loadingStatus = true;
                        clearInterval(this.timer);
                        this.timer = null;
                        this.uploadpercent = 0;
                        this.timeInterval(99, 500);
                        GameGifAPI.Edit(param).then(res => {
                            if (res.Code === 0) {
                                clearInterval(this.timer);
                                this.timer = null;
                                this.timer = setInterval(() => {
                                    if (this.uploadpercent < 100) {
                                        this.uploadpercent += 1;
                                    } else {
                                        // debugger;
                                        clearInterval(this.timer);
                                        this.timer = null;
                                        setTimeout(() => {
                                            this.$Message.success("Success!");
                                            this.$router.push({
                                                name: "gamespace_gift"
                                            });
                                            this.loadingStatus = false;
                                            this.$emit("on-close-model");
                                        }, 100);
                                    }
                                }, 10);
                            } else {
                                this.$Message.error(res.Message);
                                clearInterval(this.timer);
                                this.timer = null;
                                this.loadingStatus = false;
                            }
                        });
                    } else {
                        this.$Message.error("Fail!");
                    }
                });
            }
        },
        submitForm() {
            var param = {
                AppID: this.currentGame.ID,
                Title: this.formValidate.title,
                Content: this.formValidate.content,
                Instruction: this.formValidate.instruction,
                CDKey: this.formValidate.CDKey,
                ExpiredEnd: this.formValidate.expiredend ? new Date(this.formValidate.expiredend) : new Date("2035-01-01 00:00:00"),
                StartTime: this.formValidate.StartTime ? new Date(this.formValidate.StartTime) : this.nowTime,
                GiftType: this.formValidate.GiftType,
                ReceiveRuleScope: this.formValidate.ReceiveRuleScope,
                FilterLevel: this.formValidate.FilterLevel,
                ReceiveRuleExpandInfo: {
                    SupportModel: this.formValidate.SupportModel.join(",")
                },
                MaxReceiveCount: Number(this.formValidate.MaxReceiveCount),
                Conf: {
                    IsWarning: this.formValidate.Conf.IsWarning,
                    WarningLevel: this.formValidate.Conf.IsWarning ? this.formValidate.Conf.WarningLevel : [],
                    WarningPerson: this.formValidate.Conf.IsWarning ? this.formValidate.Conf.WarningPerson : []
                }
            };
            this.loadingStatus = true;
            GameGifAPI.Add(param).then(res => {
                console.log(res);
                if (res.Code === 0) {
                    this.$Message.success("Success!");
                    this.$router.push({
                        name: "gamespace_gift"
                    });
                    this.loadingStatus = false;
                    this.$emit("on-close-model");
                } else {
                    this.loadingStatus = false;
                    this.$Message.error(res.Message);
                }
            });
        },
        modalCancel() {
            this.$emit("on-close-model");
        }
    },
    mounted() {
        this.formValidate.FilterLevel = 0;
        if (!this.currentGame.ShowType) {
            this.init();
        }
        this.formValidate.Conf.WarningPerson = this.personList.map(item => {
            return item.Name;
        });
        console.log("add", this.formValidate);
    }
};
</script>

<style>
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
}
.demo-upload-list img {
    width: 100%;
    height: 100%;
}
.demo-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
    display: block;
}
.demo-upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
}
</style>
