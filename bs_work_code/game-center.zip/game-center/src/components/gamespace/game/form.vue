<template>
    <div>
        <Form
            :model="insideformScope"
            ref="insideformScope"
            label-position="right"
            :rules="ruleValidate"
            :label-width="100"
            style="margin-right: 100px; width: 600px"
            enctype="multipart/form-data"
        >
            <FormItem label="应用类型" prop="AppType">
                <RadioGroup v-model="insideformScope.AppType">
                    <Radio :label="0">
                        <span>游戏</span>
                    </Radio>
                    <Radio :label="1">
                        <span>应用</span>
                    </Radio>
                </RadioGroup>
            </FormItem>
            <FormItem label="是否为广告" prop="IsAd">
                <RadioGroup v-model="insideformScope.IsAd">
                    <Radio
                        :label="1"
                        v-if="
              (pagenema == 'gamemanage' && insideformScope.AppType == 1) ||
              pagenema != 'gamemanage'
            "
                    >是</Radio>

                    <Radio :label="2">否</Radio>
                </RadioGroup>
            </FormItem>

            <FormItem label="选择开发者" prop="DeveloperID">
                <Input v-model="DeveloperName" :disabled="canModify" v-if="DeveloperName" />
                <Select
                    v-model="insideformScope.DeveloperID"
                    filterable
                    remote
                    :remote-method="handleDeveloperSearch"
                    placeholder="请选择开发者"
                    clearable
                    ref="selection"
                    v-else
                >
                    <Option v-for="item in DeveloperData" :value="item.ID" :key="item.ID">{{ item.Name }}</Option>
                </Select>
            </FormItem>
            <FormItem label="选择分类" prop="CategoryName">
                <Select
                    v-model="insideformScope.CategoryName"
                    filterable
                    remote
                    :remote-method="handleCategorySearch"
                    placeholder="请选择分类"
                    clearable
                    :disabled="canModify"
                >
                    <Option v-for="item in CategoryData" :value="item.Name" :key="item.Name">{{ item.Name }}</Option>
                </Select>
            </FormItem>
            <FormItem label="下载源" prop="DownloadSource">
                <RadioGroup v-model="insideformScope.DownloadSource">
                    <Radio :label="0">
                        <span>黑鲨</span>
                    </Radio>
                    <Radio
                        :label="1"
                        v-if="
              (pagenema == 'gamemanage' &&
                (insideformScope.AppType == 0 ||
                  (insideformScope.AppType == 1 &&
                    insideformScope.IsAd != 1))) ||
              pagenema != 'gamemanage'
            "
                    >
                        <span>小米</span>
                    </Radio>
                    <Radio
                        :label="4"
                        v-if="
              (pagenema == 'gamemanage' &&
                (insideformScope.AppType == 0 ||
                  (insideformScope.AppType == 1 &&
                    insideformScope.IsAd != 1))) ||
              pagenema != 'gamemanage'
            "
                    >
                        <span>应用宝</span>
                    </Radio>
                </RadioGroup>
            </FormItem>
            <FormItem label="游戏名称:" prop="AppName">
                <Input v-model="insideformScope.AppName" placeholder="请输入游戏名称"></Input>
            </FormItem>
            <FormItem label="游戏包名:" prop="PkgName">
                <Input v-model="insideformScope.PkgName" placeholder="请输入游戏包名" :disabled="edit"></Input>
            </FormItem>
            <FormItem label="游戏标签:" prop="Tags">
                <Select
                    v-model="insideformScope.Tags"
                    filterable
                    remote
                    :remote-method="handleTagsSearch"
                    placeholder="请选择标签"
                    clearable
                    multiple
                    :disabled="canModify"
                >
                    <Option v-for="(item, index) in TagsData" :value="item.Name" :key="index">{{ item.Name }}</Option>
                </Select>
            </FormItem>
            <FormItem label="开服时间:">
                <DatePicker v-model="insideformScope.FirstLaunchTime" type="datetime" format="yyyy-MM-dd HH:mm" />
            </FormItem>
            <FormItem label="APP图标:" prop="AppIcon">
                <div class="demo-upload-list" v-if="insideformScope.AppIcon != ''">
                    <img :src="insideformScope.AppIcon" />
                    <div class="demo-upload-list-cover">
                        <Icon type="ios-eye-outline" @click.native="handleView()"></Icon>
                        <Icon type="ios-trash-outline" @click.native="handleRemove()"></Icon>
                    </div>
                </div>
                <Upload
                    ref="uploadicon"
                    :show-upload-list="false"
                    :format="['jpg', 'jpeg', 'png','webp']"
                    :on-format-error="handleFormatError"
                    :before-upload="handleIconBeforeUpload"
                    :on-success="handleIconSuccess"
                    type="drag"
                    multiple
                    :action="uploadurl"
                    style="display: inline-block; width: 58px"
                >
                    <div style="width: 58px; height: 58px; line-height: 58px">
                        <Icon type="ios-camera" size="20"></Icon>
                    </div>
                </Upload>
            </FormItem>
            <FormItem>
                <Button type="primary" @click="handleSubmit">提交</Button>
                <Button @click="handleReset" style="margin-left: 8px">重置</Button>
            </FormItem>
        </Form>
        <Modal title="预览" v-model="preview_visible" width="250px">
            <img style="width: 100%; height: 100%" :src="insideformScope.AppIcon" />
        </Modal>
    </div>
</template>
<script>
import DeveloperAPI from "@/api/gamespace/developer";
import GameCategoryAPI from "@/api/gamespace/gamecategory";
import GameAPI from "@/api/gamespace/game";
import GameTagAPI from "@/api/gamespace/gametag";
import { AssertVideo } from "@/libs/tools";
import COS from "cos-js-sdk-v5";
import apkSecretData from "@/libs/apksecret";

import cosconfig from "@/libs/cosconfig";
export default {
    name: "GameForm",
    props: {
        formScope: {
            type: Object
        },
        edit: {
            //true-编辑 faulse-新增
            type: Boolean,
            default: false
        },
        pagenema: String
    },
    data() {
        return {
            preview_visible: false,
            preview_url: "",
            loading: false,
            uploadurl: "",
            DeveloperData: [],
            CategoryData: [],
            TagsData: [],
            insideformScope: {
                AppType: 0,
                ID: undefined,
                IsAd: 2,
                DeveloperID: undefined,
                CategoryName: "",
                From: 0,
                AppName: "",
                PkgName: "",
                AppIcon: "",
                Tags: [],
                DownloadSource: 0,
                FirstLaunchTime: ""
            },
            ruleValidate: {
                DeveloperID: [
                    {
                        required: true,
                        type: "number",
                        message: "请选择开发者",
                        trigger: "blur"
                    }
                ],
                CategoryName: [
                    {
                        required: true,
                        message: "请选择分类",
                        trigger: "blur"
                    }
                ],
                AppName: [
                    {
                        required: true,
                        message: "请输入游戏名称",
                        trigger: "blur"
                    }
                ],
                PkgName: [
                    {
                        required: true,
                        message: "请输入游戏名称",
                        trigger: "blur"
                    }
                ],
                Tags: [
                    {
                        required: true,
                        type: "array",
                        message: "请输入游戏标签",
                        trigger: "blur"
                    }
                ],
                DownloadSource: [
                    {
                        required: true,
                        type: "number",
                        message: "请选择下载源",
                        trigger: "blur"
                    }
                ],
                AppType: [
                    {
                        required: true,
                        type: "number",
                        message: "请选择应用类型",
                        trigger: "blur"
                    }
                ]
            },
            DeveloperName: ""
        };
    },
    computed: {
        canModify() {
            return this.edit && this.insideformScope.AppReporterType == 1;
        }
    },
    methods: {
        handleDeveloperSearch(value) {
            DeveloperAPI.Like({ value }).then(res => {
                this.DeveloperData = res.Data;
            });
        },
        handleTagsSearch(value) {
            GameTagAPI.Like({ value }).then(res => {
                this.TagsData = res.Data;
            });
        },
        handleCategorySearch(value) {
            GameCategoryAPI.Like(value, this.insideformScope.AppType).then(res => {
                this.CategoryData = res.Data;
            });
        },
        handleSubmit() {
            console.log(this.insideformScope);
            this.$refs["insideformScope"].validate(valid => {
                if (valid) {
                    // this.$Loading.start();
                    // this.loading = true;
                    if (this.insideformScope.AppIcon == "") {
                        this.$Message.error("请上传游戏图标信息!");
                        return;
                    }
                    this.$emit("on-form-submit", {
                        ...this.insideformScope,
                        From: this.insideformScope.DownloadSource
                    });
                } else {
                    this.$Message.error("请填写必需信息!");
                }
            });
        },
        handleFormatError(file) {
            console.log(file);
            this.$Notice.warning({
                title: "图片格式错误",
                desc: file.name + " 格式错误"
            });
        },
        handleIconBeforeUpload(file) {
            const t = AssertVideo(file.name);
            if (t != "img") {
                this.handleFormatError(file);
                this.$refs.uploadicon.clearFiles();
                return false;
            }
            if (this.insideformScope.PkgName.length == 0) {
                this.$Notice.warning({
                    title: "请输入包名"
                });
                return;
            }
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        console.log(data);
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            let key = "pkg" + "/" + this.insideformScope.PkgName + "/" + new Date().getTime();
            //   let key = "pkg" + "/" + this.insideformScope.PkgName + "/" + file.name;
            let that = this;
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        that.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        this.$Message.warning(err);
                        return;
                    }
                    console.log(data);
                    that.insideformScope.AppIcon = cosconfig.exporturl + "/" + key;
                }
            );
            return false;
        },
        handleIconSuccess(res, file) {
            this.insideformScope.AppIcon = res.Data.URL;
        },
        handleView(t) {
            this.preview_visible = true;
        },
        handleRemove(imgsource) {
            this.$refs.uploadicon.clearFiles();
            this.insideformScope.AppIcon = "";
        },
        handleReset() {
            this.$refs.insideformScope.resetFields();
            this.insideformScope.AppIcon = "";
        }
    },
    watch: {
        "insideformScope.AppType"(v, o) {
            if (v == 0 && this.pagenema == "gamemanage") {
                this.insideformScope.IsAd = 2;
            }
        },
        "insideformScope.IsAd"(v, o) {
            if (this.pagenema == "gamemanage" && v == 1 && this.insideformScope.AppType == 1) {
                this.insideformScope.From = 0;
            }
        },
        formScope(formScope) {
            // console.log(formScope);
            this.insideformScope = formScope;
            this.insideformScope.FirstLaunchTime = formScope.FirstLaunchTime ? new Date(formScope.FirstLaunchTime) : "";
            DeveloperAPI.Get(formScope.DeveloperID).then(res => {
                this.DeveloperData = [res.Data];
                this.$refs["selection"].setQuery(res.Data["Name"]);
                this.DeveloperName = res.Data["Name"];
                this.$refs["selection"].toggleMenu(null, false);
            });
            this.CategoryData = [{ ID: 0, Name: formScope.CategoryName }];
            // console.log(formScope.Tags);
            if (formScope.Tags && formScope.Tags.length > 0) {
                for (const item of formScope.Tags) {
                    let has = false;
                    this.TagsData.filter(item => {
                        if (item.Name == item) {
                            has = true;
                        }
                    });
                    if (!has) this.TagsData.push({ Name: item });
                }
            }
        }
    },
    mounted() {
        this.uploadurl = GameAPI.UploadURL();
        this.handleTagsSearch("");
    }
};
</script>

<style>
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
}
.demo-upload-list img {
    width: 100%;
    height: 100%;
}
.demo-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
    display: block;
}
.demo-upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
}
</style>
