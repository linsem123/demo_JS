<template>
	<div>
		<Modal
			v-model="modelShow"
			:title="
        currentGame.ShowType
          ? '编辑游戏礼包:' + currentGame.Title
          : '查看游戏礼包:' + currentGame.Title
      "
			:closable="false"
			:mask-closable="false"
		>
			<Form
				ref="formValidate"
				:model="formValidate"
				label-position="right"
				:label-width="110"
				:rules="ruleValidate"
			>
				<FormItem
					label="礼包标题"
					prop="Title"
				>
					<Input
						v-model="formValidate.Title"
						:disabled="!currentGame.ShowType"
						placeholder="请输入活动标题"
					></Input>
				</FormItem>
				<FormItem
					label="内容介绍"
					prop="Content"
				>
					<Input
						v-model="formValidate.Content"
						type="textarea"
						:autosize="{ minRows: 5, maxRows: 20 }"
						placeholder="请输入礼包内容"
						:disabled="!currentGame.ShowType"
					></Input>
				</FormItem>
				<FormItem
					label="使用方法"
					prop="Instruction"
				>
					<Input
						v-model="formValidate.Instruction"
						type="textarea"
						:autosize="{ minRows: 5, maxRows: 20 }"
						:disabled="!currentGame.ShowType"
						placeholder="请输入使用方法"
					></Input>
				</FormItem>
				<FormItem
					label="生效周期："
					prop="Expired"
				>
					<DateRange
						v-model="formValidate.Expired"
						@on-change="
              (value) => {
                formValidate.StartTime = value.start;
                formValidate.ExpiredEnd = value.end;
              }
            "
						:disabled="!currentGame.ShowType"
						format=""
					/>
				</FormItem>
				<FormItem label="礼包类型">
					<Select
						v-model="formValidate.GiftType"
						style="width: 200px"
						:disabled="true"
					>
						<Option
							v-for="item in giftTypeList"
							:value="item.ID"
							:key="item.ID"
						>{{ item.Name }}</Option>
					</Select>
				</FormItem>
				<FormItem
					label="礼包等级"
					v-if="formValidate.GiftType == 6"
				>
					<InputNumber
						:min="0"
						:max="18"
						v-model="formValidate.FilterLevel"
						placeholder="请输入礼包等级"
						style="width: 100px"
						:disabled="true"
					></InputNumber>
				</FormItem>
				<!-- sdk 5.5.0新增 -->
				<FormItem label="剩余不足预警：">
					<Checkbox
						:disabled="!currentGame.ShowType"
						v-model="formValidate.Conf.IsWarning"
					>启用</Checkbox>
				</FormItem>
				<template v-if="formValidate.Conf.IsWarning">
					<FormItem label="预警节点：">
						<CheckboxGroup v-model="formValidate.Conf.WarningLevel">
                            <Checkbox
								:disabled="!currentGame.ShowType"
								:label="0.3"
							>30%</Checkbox>
							<Checkbox
								:disabled="!currentGame.ShowType"
								:label="0.1"
							>10%</Checkbox>
							<Checkbox
								:disabled="!currentGame.ShowType"
								:label="0"
							>0%</Checkbox>
						</CheckboxGroup>
					</FormItem>
					<FormItem label="负责人：">
						<CheckboxGroup v-model="formValidate.Conf.WarningPerson">
							<Checkbox
								v-for="item in personList"
								:key="item.Id"
								:label="item.Name"
                                :disabled="!currentGame.ShowType"
							>{{ item.Name }}</Checkbox>
						</CheckboxGroup>
					</FormItem>
				</template>
			</Form>
			<div slot="footer">
				<Button
					type="text"
					size="large"
					@click="modalCancel"
				>取消</Button>
				<Button
					type="primary"
					size="large"
					@click="addGameGif"
					:loading="loadingStatus"
				>确定</Button>
			</div>
		</Modal>
	</div>
</template>
<script>
import GameGifAPI from '@/api/gamespace/gamegif'
import SurpotModel from '_c/SurpotModel'
import DateRange from '_c/DateRange.vue'
import { checkDateRange } from '@/libs/checkForm.js'

export default {
	name: 'EditGameGif',
	props: {
		currentGame: {
			type: Object,
		},
        personList: {
			type: Array,
		},
	},
	components: { SurpotModel, DateRange },
	data() {
		return {
			modelShow: true,
			loadingStatus: false,

			giftTypeList: [
				{ ID: 1, Name: '预约礼包' },
				{ ID: 0, Name: '普通礼包' },
				{ ID: 3, Name: '抽奖礼包' },
				{ ID: 4, Name: '预约下载礼包' },
				{ ID: 5, Name: '新机活动礼包' },
				{ ID: 6, Name: 'VIP专属礼包' },
			],
			ScopeList: [{ ID: 1, Name: '指定机型' }],
			formValidate: {
				GiftType: 0,
				Title: '',
				Content: '',
				ExpiredEnd: '',
				Instruction: '',
				CDKey: [],
				ReceiveRuleScope: [],
				// SupportModel: [],
				// MaxReceiveCount: 1,
			},
			ruleValidate: {
				Title: [
					{
						required: true,
						message: '礼包标题不能为空',
						trigger: 'blur',
					},
				],
				Content: [
					{
						required: true,
						message: '内容介绍不能为空',
						trigger: 'blur',
					},
				],
				Instruction: [
					{
						required: true,
						message: '使用方法不能为空',
						trigger: 'blur',
					},
				],

				Expired: [
					{
						validator: checkDateRange,
						trigger: 'change',
						type: 'array',
					},
				],
			},
			uploadpercent: 0, //进度条
			timer: null,
			percentSstatus: 'active',
			nowTime: new Date(),
		}
	},
	created() {
		this.formValidate = JSON.parse(JSON.stringify(this.currentGame))
		this.formValidate.Expired = [this.formValidate.StartTime, this.formValidate.ExpiredEnd]
        // sdk 5.5.0新增 防止有null的情况
        !this.formValidate.Conf.WarningLevel ? this.formValidate.Conf.WarningLevel = [] : ''
        !this.formValidate.Conf.WarningPerson ? this.formValidate.Conf.WarningPerson = [] : ''
	},
	methods: {
		addGameGif() {
			if (this.currentGame.ShowType) {
				this.$refs['formValidate'].validate(valid => {
					if (valid) {
						if (!this.formValidate.StartTime || !this.formValidate.ExpiredEnd) {
							this.$Modal.confirm({
								title: '提示',
								okText: '确认',
								cancelText: '取消',
								loading: true,
								content: '<p>还未设置生效期，是否继续发布？</p>',
								onOk: () => {
									this.submitForm()
									this.$Modal.remove()
								},
							})
						} else {
							this.submitForm()
						}
					} else {
						this.$Message.error('请填写必填信息')
					}
				})
			} else {
				this.$emit('on-close-model')
			}
		},
		submitForm() {
			var param = {
				...this.formValidate,
				ExpiredEnd: this.formValidate.ExpiredEnd ? new Date(this.formValidate.ExpiredEnd) : new Date('2035-01-01 00:00:00'),
				StartTime: this.formValidate.StartTime ? new Date(this.formValidate.StartTime) : this.nowTime,
			}
            if (!param.Conf.IsWarning) {
                param.Conf.WarningLevel = []
                param.Conf.WarningPerson = []
            }
			this.loadingStatus = true
			GameGifAPI.EditGift(param)
				.then(res => {
					console.log(res)
					if (res.Code === 0) {
						this.$Message.success('Success!')
						this.$emit('on-init')
					} else {
						this.$Message.error(res.Message)
					}
				})
				.finally(() => {
					this.loadingStatus = false
				})
		},
		modalCancel() {
			this.$emit('on-close-model')
		},
	},
}
</script>