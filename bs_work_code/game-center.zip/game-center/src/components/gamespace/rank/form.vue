<template>
  <div>
    <Form
      :model="insideformScope"
      ref="insideformScope"
      :rules="ruleValidate"
      :label-width="100"
    >
      <FormItem label="请选择游戏:" prop="AppID">
        <Select
          v-model="insideformScope.AppID"
          clearable
          filterable
          remote
          :remote-method="handleGameSearch"
          placeholder="请输入游戏名称"
        >
          <Option v-for="item in apps" :value="item.ID" :key="item.ID">{{ item.AppName }}</Option>
        </Select>
      </FormItem>
    </Form>
  </div>
</template>


<script>
import GameAPI from "@/api/gamespace/game";
import GameRankAPI from "@/api/gamespace/gamerank";
import SearchConApi from '@/api/gamespace/searchconfig'
export default {
  name: "DeveloperForm",
  props: {
    formScope: {
      type: Object
    }
  },
  data() {
    return {
      loading: false,
      insideformScope: {
        RankType: 1,
        AppID: undefined
      },

      apps: [],
      ruleValidate: {
        AppID: [{ required: true, message: "请选择游戏", trigger: "blur", type: "number" }]
      }
    };
  },
  methods: {
    handleGameSearch(value) {
      GameAPI.LikeApp({ value }).then(res => {
        this.apps = res.Data;
      });
    },
    handleSubmit() {
      this.$refs["insideformScope"].validate(valid => {
        if (valid) {
          this.$emit("on-form-submit", this.insideformScope);
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },
    handleReset() {
      this.$refs.insideformScope.resetFields();
    },
  },
  created(){
  },
  watch: {
    formScope(formScope) {
      this.insideformScope = formScope;
    }
  }
};
</script>
