<template>
  <div>
    <Form :model="addRankForm" ref="addRankForm" label-position="right" :rules="ruleValidate" :label-width="100" style="margin-right:100px;width: 600px">
      <FormItem label="榜单标题" prop="RankName">
        <Input v-model="addRankForm.Title" placeholder="请填写标题"></Input>
      </FormItem>
      <FormItem label="榜单描述:" prop="RankDesc">
        <Input v-model="addRankForm.Desc" placeholder="请填写描述"></Input>
      </FormItem>
      <FormItem>
        <Button type="primary" @click="handleSubmit">提交</Button>
      </FormItem>
    </Form>
  </div>
</template>

<script>
    export default {
        name: "addForm",
      props: {
        formScope: {
          type: Object
        }
      },
      data(){
        return {
          addRankForm:{
            Title : "",
            Desc : ""
          },
          ruleValidate: {

          }
        }
      },
      methods:{
        handleSubmit() {
            if (this.addRankForm.Title != undefined) {
              this.$emit("on-form-submit", this.addRankForm);
            } else {
              this.$Message.error("请填写必需信息!");
            }
        },
      },
      watch: {
        formScope(formScope) {
          this.addRankForm = formScope;
        }
      }
    }
</script>

<style scoped>

</style>
