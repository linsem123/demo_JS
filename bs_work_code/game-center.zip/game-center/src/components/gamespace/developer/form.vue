<template>
  <div>
    <Form
      :model="insideformScope"
      ref="insideformScope"
      label-position="right"
      :rules="ruleValidate"
      :label-width="100"
      style="margin-right:100px;width: 600px"
    >
      <FormItem label="开发者名称:" prop="Name">
        <Input v-model="insideformScope.Name" placeholder="开发者名称"></Input>
      </FormItem>
      <FormItem label="开发者简称:" prop="Provider">
        <Input v-model="insideformScope.Provider" placeholder="开发者简称"></Input>
      </FormItem>
      <FormItem>
        <Button type="primary" @click="handleSubmit">提交</Button>
        <Button @click="handleReset" style="margin-left: 8px">重置</Button>
      </FormItem>
    </Form>
  </div>
</template>


<script>
export default {
  name: "DeveloperForm",
  props: {
    formScope: {
      type: Object
    }
  },
  data() {
    return {
      loading: false,
      insideformScope: {
        Name: "",
        Provider:"",
      },
      ruleValidate: {
        Name: [
          {
            required: true,
            message: "请输入开发者信息",
            trigger: "blur"
          }
        ],
        Provider: [
          {
            required: true,
            message: "请输入开发者简称",
            trigger: "blur"
          }
        ]
      }
    };
  },
  methods: {
    handleSubmit() {
      this.$refs["insideformScope"].validate(valid => {
        if (valid) {
          this.$emit("on-form-submit", this.insideformScope);
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },
    handleReset() {
      this.$refs.insideformScope.resetFields();
    }
  },
  watch: {
    formScope(formScope) {
      this.insideformScope = formScope;
    }
  }
};
</script>
