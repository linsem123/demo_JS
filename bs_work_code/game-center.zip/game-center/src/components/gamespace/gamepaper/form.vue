<template>
    <div>
        <Form
            :model="insideformScope"
            ref="insideformScope"
            label-position="right"
            :rules="ruleValidate"
            :label-width="100"
            style="margin-right: 100px; width: 600px"
        >
            <FormItem label="应用" prop="AppID">
                <Select v-model="insideformScope.AppID" filterable remote :remote-method="handleAppSearch" placeholder="请选择应用" clearable>
                    <Option v-for="item in AppData" :value="item.ID" :key="item.ID">
                        {{
                        item.AppName
                        }}
                    </Option>
                </Select>
            </FormItem>
            <FormItem label="跳转按钮标题：">
                <Input v-model="insideformScope.DeepLinkTitle" placeholder="请填写跳转按钮标题"></Input>
            </FormItem>
            <FormItem label="跳转类型：" prop="JumpType">
                <Select v-model="insideformScope.JumpType" clearable style="width: 200px">
                    <Option v-for="item in jumpTypeList" :value="item.id" :key="item.id">{{ item.name }}</Option>
                </Select>
            </FormItem>

            <FormItem v-if="insideformScope.JumpType == 1" label="绑定app：">
                <AppSelect v-model="insideformScope.ResourceID" style="width: 200px" placeholder="请输入App名称" @on-change="appChange"></AppSelect>
            </FormItem>
            <FormItem v-if="insideformScope.JumpType == 2" label="绑定跳转活动：">
                <ActivitySelect
                    v-model="insideformScope.ActivityID"
                    :type="activeParams.type"
                    @on-change="feedChange"
                    placeholder="请输入活动名称"
                    style="width: 200px"
                ></ActivitySelect>
            </FormItem>
            <FormItem v-if="insideformScope.JumpType == 4" label="绑定文章活动：">
                <ActivitySelect
                    v-model="insideformScope.ActivityID"
                    :type="activeParams.paper"
                    @on-change="feedChange"
                    placeholder="请输入活动名称"
                    style="width: 200px"
                ></ActivitySelect>
            </FormItem>
            <template v-if="insideformScope.JumpType == 3">
                <FormItem label="绑定DeepLink包名：">
                    <Input v-model="insideformScope.DeepLinkPkgName" placeholder="请填写包名"></Input>
                </FormItem>
                <FormItem label="绑定DeepLink：">
                    <Input v-model="insideformScope.DeepLink" placeholder="请填写DeepLink"></Input>
                </FormItem>
            </template>

            <!--<template v-if="formData.JumpType == 4 ">-->
            <!--<FormItem label="榜单类型：">-->
            <!--<Select v-model="rankParams.type" clearable>-->
            <!--<Option v-for="item in rankTypeList" :value="item.id" :key="item.id">{{ item.name }}</Option>-->
            <!--</Select>-->
            <!--</FormItem>-->
            <!--<FormItem label="绑定榜单：">-->
            <!--<RankSelect :rankType="rankParams.type" v-model="formData.JumpTypeID" placeholder="请输入榜单名称" style="width: 200px"></RankSelect>-->
            <!--</FormItem>-->
            <!--</template>-->

            <FormItem label="活动标题:" prop="Title">
                <Input v-model="insideformScope.Title" placeholder="请输入活动标题"></Input>
            </FormItem>
            <FormItem label="活动作者:" prop="Author">
                <Input v-model="insideformScope.Author" placeholder="请输入活动作者"></Input>
            </FormItem>
            <FormItem label="活动大图:" prop="BigBg">
                <!-- <Input v-model="insideformScope.BigBg" v-show="false"></Input>
                <div class="demo-upload-list" v-if="insideformScope.BigBg != ''">
                    <img :src="insideformScope.BigBg" />
                    <div class="demo-upload-list-cover">
                        <Icon type="ios-eye-outline" @click.native="handleView('img', insideformScope.BigBg)"></Icon>
                        <Icon type="ios-trash-outline" @click.native="handleRemove('bigbg')"></Icon>
                    </div>
                </div>
                <Upload
                    ref="uploadicon"
                    :show-upload-list="false"
                    :format="['jpg', 'jpeg', 'png']"
                    :on-format-error="handleFormatError"
                    :before-upload="handleBigBgBeforeUpload"
                    :on-success="handleIconSuccess"
                    type="drag"
                    multiple
                    :action="uploadurl"
                    style="display: inline-block; width: 58px"
                >
                    <div style="width: 58px; height: 58px; line-height: 58px">
                        <Icon type="ios-camera" size="20"></Icon>
                    </div>
                </Upload>-->
                <UploadImg v-model="insideformScope.BigBg" style="display: inline-block; width: 58px" />
            </FormItem>
            <FormItem label="活动中图:" prop="MidBg">
                <!-- <Input v-model="insideformScope.MidBg" v-show="false"></Input>
                <div class="demo-upload-list" v-if="insideformScope.MidBg != ''">
                    <img :src="insideformScope.MidBg" />
                    <div class="demo-upload-list-cover">
                        <Icon type="ios-eye-outline" @click.native="handleView('img', insideformScope.MidBg)"></Icon>
                        <Icon type="ios-trash-outline" @click.native="handleRemove('midbg')"></Icon>
                    </div>
                </div>
                <Upload
                    ref="uploadicon"
                    :show-upload-list="false"
                    :format="['jpg', 'jpeg', 'png']"
                    :on-format-error="handleFormatError"
                    :before-upload="handleMidBgBeforeUpload"
                    :on-success="handleIconSuccess"
                    type="drag"
                    multiple
                    :action="uploadurl"
                    style="display: inline-block; width: 58px"
                >
                    <div style="width: 58px; height: 58px; line-height: 58px">
                        <Icon type="ios-camera" size="20"></Icon>
                    </div>
                </Upload>-->
                <UploadImg v-model="insideformScope.MidBg" style="display: inline-block; width: 58px" />
            </FormItem>
            <FormItem label="截止日期" prop="expiredend">
                <DatePicker
                    type="date"
                    v-model="insideformScope.ExpiredEnd"
                    format="yyyy-MM-dd HH:mm"
                    placeholder="请选择截止时间"
                    style="width: 200px"
                ></DatePicker>
            </FormItem>
            <FormItem label="图文内容" prop="Content">
                <quill-editor v-model="insideformScope.Content" ref="quillEditor" :options="editorOption"></quill-editor>
                <Upload
                    ref="uploadpaperimg"
                    :show-upload-list="false"
                    :format="['jpg', 'jpeg', 'png']"
                    :on-format-error="handleFormatError"
                    :before-upload="handlepaperBeforeUpload"
                    :on-success="handleIconSuccess"
                    type="drag"
                    v-show="false"
                    :action="uploadurl"
                    style="display: inline-block; width: 58px"
                >
                    <div style="width: 58px; height: 58px; line-height: 58px">
                        <Icon type="ios-camera" size="20"></Icon>
                    </div>
                </Upload>
            </FormItem>
            <FormItem>
                <Button type="primary" @click="handleSubmit">提交</Button>
                <Button @click="handleReset" style="margin-left: 8px">重置</Button>
            </FormItem>
        </Form>
        <Modal title="预览" v-model="preview_visible" width="250px">
            <video
                id="preview_video"
                v-if="preview_type === 'video'"
                style="width: 100%; height: 100%"
                controls
                preload
                :src="preview_url"
            />
            <img id="preview_img" v-if="preview_type === 'img'" style="width: 100%; height: 100%" :src="preview_url" />
        </Modal>
    </div>
</template>


<script>
import "quill/dist/quill.core.css";
import "quill/dist/quill.snow.css";
import "quill/dist/quill.bubble.css";
import { quillEditor } from "vue-quill-editor";
import GameAPI from "@/api/gamespace/game";
import { AssertVideo } from "@/libs/tools";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";
import AppSelect from "_c/app-select";
import ActivitySelect from "_c/activity-select";
import UploadImg from "_c/shark-upload";
export default {
    components: {
        quillEditor,
        AppSelect,
        ActivitySelect,
        UploadImg
    },
    name: "ViewForm",
    props: {
        formScope: {
            type: Object
        }
    },
    data() {
        return {
            AppData: [],
            preview_visible: false,
            preview_url: "",
            preview_type: "", //video 1, img 0
            uploadurl: "",
            editorOption: {
                modules: {
                    toolbar: [
                        // [{ 'size': ['small', false, 'large'] }],
                        // ['bold', 'italic'],
                        [{ list: "ordered" }, { list: "bullet" }],
                        ["image"]
                    ],
                    history: {
                        delay: 1000,
                        maxStack: 50,
                        userOnly: false
                    }
                    // imageDrop: true,
                    // imageResize: {
                    //   displayStyles: {
                    //     backgroundColor: 'black',
                    //     border: 'none',
                    //     color: 'white'
                    //   },
                    //   modules: [ 'Resize', 'DisplaySize', 'Toolbar' ]
                    // }
                }
            },
            loading: false,
            insideformScope: {
                AppID: undefined,
                Title: "",
                Author: "",
                BigBg: "",
                MidBg: "",
                Content: "",
                JumpType: undefined,
                DeepLinkPkgName: "",
                DeepLinkTitle: "",
                DeepLink: "",
                ResourceID: undefined,
                ActivityID: undefined,
                JumpPkgName: ""
            },
            activeParams: {
                type: 2,
                paper: 1
            },
            jumpTypeList: [
                { id: 1, name: "App详情" },
                { id: 2, name: "H5活动" },
                { id: 3, name: "DeepLink" },
                { id: 4, name: "文章" }
            ],
            ruleValidate: {
                Title: [
                    {
                        required: true,
                        message: "请输入活动主题",
                        trigger: "blur"
                    }
                ],
                Author: [
                    {
                        required: true,
                        message: "请输入活动作者",
                        trigger: "blur"
                    }
                ]
            }
        };
    },
    methods: {
        handleSubmit() {
            console.log(this.$refs.quillEditor.quill.getContents());
            this.$refs["insideformScope"].validate(valid => {
                if (valid) {
                    this.$emit("on-form-submit", this.insideformScope);
                } else {
                    this.$Message.error("请填写必需信息!");
                }
            });
        },
        handleReset() {
            this.$refs.insideformScope.resetFields();
        },
        imageHandler(image, callback) {
            this.$refs.uploadpaperimg.handleClick();
        },
        handleFormatError(file) {
            this.$Notice.warning({
                title: "格式错误",
                desc: file.name + " 格式错误"
            });
        },
        appChange({ value, index }) {
            if (index) this.insideformScope.JumpPkgName = value.PkgName;
        },
        feedChange({ value, index }) {
            if (index) {
                this.insideformScope.DeepLink = value.FeedURL;
                this.insideformScope.ResourceID = value.FeedID;
            }
        },
        // handleBigBgBeforeUpload(file) {
        //     const t = AssertVideo(file.name);
        //     if (t != "img") {
        //         this.handleFormatError(file);
        //         this.$refs.uploadpaperimg.clearFiles();
        //         return false;
        //     }
        //     let cos = new COS({
        //         getAuthorization: function (options, callback) {
        //             GameAPI.GetSts().then(data => {
        //                 console.log(data);
        //                 callback({
        //                     TmpSecretId: data.Data.credentials.tmpSecretId,
        //                     TmpSecretKey: data.Data.credentials.tmpSecretKey,
        //                     XCosSecurityToken: data.Data.credentials.sessionToken,
        //                     ExpiredTime: data.Data.expiredTime
        //                 });
        //             });
        //         }
        //     });
        //     let key = "paper" + "/" + new Date().getTime() + "-" + file.name;
        //     let that = this;
        //     cos.sliceUploadFile(
        //         {
        //             Bucket: cosconfig.bucket /* 必须 */,
        //             Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
        //             Key: key,
        //             Body: file /* 必须 */,
        //             onProgress: function (progressData) {
        //                 that.uploadpercent = progressData.percent * 100;
        //                 /* 非必须 */
        //                 console.log(JSON.stringify(progressData));
        //             }
        //         },
        //         function (err, data) {
        //             if (err) {
        //                 this.$Message.warning(err);
        //                 return;
        //             }
        //             console.log(data);
        //             that.insideformScope.BigBg = cosconfig.exporturl + "/" + key;
        //         }
        //     );
        //     return false;
        // },
        // handleMidBgBeforeUpload(file) {
        //     const t = AssertVideo(file.name);
        //     if (t != "img") {
        //         this.handleFormatError(file);
        //         this.$refs.uploadpaperimg.clearFiles();
        //         return false;
        //     }

        //     let cos = new COS({
        //         getAuthorization: function (options, callback) {
        //             GameAPI.GetSts().then(data => {
        //                 console.log(data);
        //                 callback({
        //                     TmpSecretId: data.Data.credentials.tmpSecretId,
        //                     TmpSecretKey: data.Data.credentials.tmpSecretKey,
        //                     XCosSecurityToken: data.Data.credentials.sessionToken,
        //                     ExpiredTime: data.Data.expiredTime
        //                 });
        //             });
        //         }
        //     });
        //     let key = "paper" + "/" + new Date().getTime() + "-" + file.name;
        //     let that = this;
        //     cos.sliceUploadFile(
        //         {
        //             Bucket: cosconfig.bucket /* 必须 */,
        //             Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
        //             Key: key,
        //             Body: file /* 必须 */,
        //             onProgress: function (progressData) {
        //                 that.uploadpercent = progressData.percent * 100;
        //                 /* 非必须 */
        //                 console.log(JSON.stringify(progressData));
        //             }
        //         },
        //         function (err, data) {
        //             if (err) {
        //                 this.$Message.warning(err);
        //                 return;
        //             }
        //             console.log(data);
        //             that.insideformScope.MidBg = cosconfig.exporturl + "/" + key;
        //         }
        //     );
        //     return false;
        // },
        handleView(t, url) {
            this.preview_type = t;
            this.preview_url = url;
            this.preview_visible = true;
        },
        handleRemove(t) {
            if (t == "bigbg") {
                this.$refs.uploadpaperimg.clearFiles();
                insideformScope.BigBg = "";
                return;
            }
            if (t == "midbg") {
                this.$refs.imgupload.clearFiles();
                insideformScope.MidBg = "";
                return;
            }
        },
        handlepaperBeforeUpload(file) {
            const t = AssertVideo(file.name);
            if (t != "img") {
                this.handleFormatError(file);
                this.$refs.uploadpaperimg.clearFiles();
                return false;
            }
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        console.log(data);
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            let key = "paper" + "/" + new Date().getTime();
            // let key = "paper" + "/" + new Date().getTime() + "-" + file.name;
            let that = this;
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        that.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        this.$Message.warning(err);
                        return;
                    }
                    console.log(data);
                    var quill = that.$refs.quillEditor.quill;
                    let length = quill.getSelection().index;
                    // 插入图片  res.url为服务器返回的图片地址
                    quill.insertEmbed(length + 1, "image", cosconfig.exporturl + "/" + key);
                    // 调整光标到最后
                    quill.setSelection(length + 2);
                }
            );
            return false;
        },
        handleIconSuccess(res, file) {
            console.log(res);
        },
        handleAppSearch(value) {
            GameAPI.LikeApp({ value }).then(res => {
                this.AppData = res.Data;
            });
        }
    },
    watch: {
        formScope(formScope) {
            this.insideformScope = formScope;
            if (this.insideformScope.ID) {
                this.AppData.push({
                    ID: this.insideformScope.AppID,
                    AppName: this.insideformScope.AppName
                });
            }
        }
    },
    mounted() {
        this.uploadurl = GameAPI.UploadURL();
        this.$refs.quillEditor.quill.getModule("toolbar").addHandler("image", this.imageHandler);
    }
};
</script>
<style>
.quill-editor {
    height: 300px;
    width: 800px;
    margin-bottom: 30px;
}
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
}
.demo-upload-list img {
    width: 100%;
    height: 100%;
}
.demo-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
    display: block;
}
.demo-upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
}
</style>

