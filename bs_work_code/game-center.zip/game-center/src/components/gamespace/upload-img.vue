<template>
    <div style="font-size: 0; line-height: normal">
        <div class="demo-upload-list" v-for="item in uploadList" :key="item.url">
            <template v-if="item.status === 'finished' || !item.status">
                <img :src="item.url" alt />
                <div class="demo-upload-list-cover">
                    <Icon type="ios-eye-outline" @click.native="handleView(item)"></Icon>
                    <Icon type="ios-trash-outline" @click.native="handleRemove(item)"></Icon>
                </div>
            </template>
            <template v-else>
                <Progress v-if="item.showProgress" :percent="item.percentage" hide-info></Progress>
            </template>
        </div>
        <Upload
            v-show="uploadList.length < max"
            ref="upload"
            :show-upload-list="false"
            :on-success="handleSuccess"
            :format="format"
            :on-format-error="handleFormatError"
            :before-upload="handleBeforeUpload"
            type="drag"
            :action="action"
            style="display: inline-block;width: 58px;"
        >
            <div style="width: 58px;height: 58px;line-height: 58px;">
                <Icon type="ios-camera" size="20"></Icon>
            </div>
        </Upload>

        <Modal title="预览" v-model="preview_visible" width="400px">
            <img id="preview_img" style="width: 100%;height:100%;" :src="preview_url" />
        </Modal>
    </div>
</template>

<script>
import axios from "@/libs/api.request";
import baseurl from "@/api/gamespace/base";
import { AssertVideo } from "@/libs/tools";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";

export default {
    name: "UploadImg",
    model: {
        // 默认返回数据为数组
        prop: "images",
        event: "uploadImage"
    },
    props: {
        images: null,
        // 上传地址
        action: {
            type: String,
            default: "https://jsonplaceholder.typicode.com/posts/"
        },
        format: {
            type: Array,
            default: function () {
                return ["jpg", "JPG", "jpeg", "JPEG", "png", "PNG", "gif", "GIF"];
            }
        },
        module: {
            type: String,
            default: "game"
        },
        // 最大上传数量
        max: {
            type: Number,
            default: 1
        },
        OnSuccess: {
            type: Function,
            default: function () {}
        },
        OnRemove: {
            type: Function,
            default: function () {}
        }
    },
    data() {
        return {
            uploadList: [],
            preview_visible: false,
            preview_url: ""
        };
    },
    mounted() {
        this.uploadList = this.images;
    },
    watch: {
        images() {
            this.uploadList = this.images;
        }
    },
    methods: {
        GetSts() {
            return axios.request({
                url: baseurl + "game/sts",
                method: "get"
            });
        },
        modelImages(val) {
            console.log("emit");
            this.$emit("uploadImage", val);
        },
        handleSuccess(res, file, fileList) {
            console.log(fileList);
            this.modelImages(fileList);
            this.uploadList = fileList;
            this.OnSuccess(res, file, fileList);
        },
        handleRemove(file) {
            const list = this.$refs.upload.fileList;
            this.$refs.upload.fileList.splice(list.indexOf(file), 1);
            this.uploadList = this.$refs.upload.fileList;
            this.modelImages(this.uploadList);
            this.OnRemove(file, this.uploadList);
        },
        handleView(file) {
            this.preview_url = file.url;
            this.preview_visible = true;
        },
        handleFormatError() {
            let format = [
                ...new Set(
                    this.format.map(item => {
                        return item.toLowerCase();
                    })
                )
            ];
            this.$Message.error("文件格式有误，仅支持：" + format.join("，") + "图片");
        },
        handleBeforeUpload(file) {
            let that = this;
            const t = AssertVideo(file.name);
            if (t !== "img") {
                this.handleFormatError(file);
                this.$refs.upload.clearFiles();
                return false;
            }
            let this_ = this;
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    this_.GetSts().then(data => {
                        // console.log(data)
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            //   let key = this.module + "/" + new Date().getTime() + "-" + file.name;
            let key = this.module + "/" + new Date().getTime();
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        that.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        // console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        console.error(err);
                        that.$Message.warning("上传失败");
                        return;
                    }
                    // console.log(data);
                    that.uploadList.push({
                        url: cosconfig.exporturl + "/" + key
                    });
                }
            );
            return false;
        }
    }
};
</script>

<style scoped>
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
}
.demo-upload-list img {
    width: 100%;
    height: 100%;
}
.demo-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
    display: block;
}
.demo-upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
}
</style>
