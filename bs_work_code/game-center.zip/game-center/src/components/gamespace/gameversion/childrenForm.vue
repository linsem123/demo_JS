<template>
  <div class="childrenFrom">
         
          <Col span="12" >

      
                  <Form
      :model="formData"
      ref="formData"
      label-position="right"
      :rules="ruleValidate"
      :label-width="100"
      style="margin-right:100px;width: 600px;padding:20px 0;border-bottom:1px solid #eee;"
      enctype="multipart/formData-data"
    >
            <!-- <FormItem label="上传游戏包:">
          <Upload ref="uploadpkg" action="/" :disabled="isupload" :before-upload="handlepackageBeforeUpload">
            <Button icon="ios-cloud-upload-outline">点击上传</Button>
          </Upload>
          <Progress :percent="uploadpercent" status="active" />
        </FormItem> -->
        <FormItem label="apk_md5:">
            <Input
              v-model="formData.apk_md5"
              :disabled="apkHashdisabled"
              placeholder="apk_md5"
            ></Input>
          </FormItem>
          <FormItem label="下载地址:" prop="source_url">
            <Input v-model="formData.source_url" :disabled="isupload"  placeholder="下载地址"></Input>
          </FormItem>
          <Row>
            <Col span="8">
          <FormItem label="版本号:" prop="version_code">
            <InputNumber v-model="formData.version_code" :disabled="apkHashdisabled"></InputNumber>
          </FormItem>
          </Col>
            <Col span="8">
          <FormItem label="大小:" prop="apk_size">
            <InputNumber v-model="formData.apk_size" :disabled="apkHashdisabled"></InputNumber>
          </FormItem>
          </Col>

            <Col span="8">
                    <FormItem label="ChannelId:" prop="channel_code">
            <InputNumber v-model="formData.channel_code" :disabled="apkHashdisabled"></InputNumber>
          </FormItem>
 </Col>
                      <Col span="12">
          <FormItem label="版本名称:" prop="version_name" >
            <Input v-model="formData.version_name" :disabled="apkHashdisabled"></Input>
          </FormItem>
            </Col>

 <Col span="12" align="right">
 <Button :disabled="!isupload"  v-if="formData.ID&&formData.ID>0" style="margin-right:5px" type="primary" @click="edit">编辑</Button>
  <Button :disabled="isvisibel" type="primary" @click="submit">保存</Button>
  </Col>
  </Row>
                  </Form>
           </Col>
   

  </div>
</template>

<script>
import GameAPI from "@/api/gamespace/game";
import GameVersionAPI from "@/api/gamespace/gameversion";

import AppInfoParser from "app-info-parser";
import COS from "cos-js-sdk-v5";
import SparkMD5 from "spark-md5";
import cosconfig from "@/libs/cosconfig";
export default {
    data(){
        return{
            uploadpercent:0,
            formData:{},
            apkHashdisabled: true,
            showversion:false,
            ruleValidate:{},
            isvisibel:true,
            isupload:true
        }
    },
    props:["form"],
    watch: {
        form:{
            handler(v,o){
                console.log(v)
                if(v){
                   this.formData=v
                   console.log(!(v.ID&&v.ID>0))
                   if(!(v.ID&&v.ID>0)){
                     this.isupload=false
                   }
                }
             
            },immediate:true  
        },
        'formData.source_url'(v,o){
          if(!v){
            this.isvisibel = true
          }else{
            this.isvisibel = false
          }
        }

    },
methods: {
    //     handlepackageBeforeUpload(file) {
    //   const parser = new AppInfoParser(file);
    //   parser
    //     .parse()
    //     .then((result) => {
    //       console.log(result);
    //       console.log(this.formData)

    //       this.formData['version_name'] = result.versionName;
    //     //   this.formData.version_code = result.versionCode;
    //       this.formData.apk_size = parser.file.size;
    //       if(result.versionCode!=this.formData.version_code){
    //           this.$Message.warning({content: '版本号不一致'})
    //         return;
    //       }
    //       if (result.package != this.formData.package_name) {
    //         this.$refs.uploadpkg.clearFiles();
    //         this.$Message.warning({content: '包名不相符合'})
    //         return;
    //       }
    //       let fileReader = new FileReader();
    //       let validation = "";
    //       fileReader.onloadend = function (e) {
    //         console.log(e);
    //         let spark = new SparkMD5.ArrayBuffer();
    //         spark.append(e.target.result);
    //         validation = spark.end();
    //         console.log(validation);
    //       };
    //       fileReader.readAsArrayBuffer(file);
    //       this.showversion = true;
    //       let cos = new COS({
    //         getAuthorization: function (options, callback) {
    //           GameAPI.GetSts().then((data) => {
    //             console.log(data);
    //             callback({
    //               TmpSecretId: data.Data.credentials.tmpSecretId,
    //               TmpSecretKey: data.Data.credentials.tmpSecretKey,
    //               XCosSecurityToken: data.Data.credentials.sessionToken,
    //               ExpiredTime: data.Data.expiredTime,
    //             });
    //           });
    //         },
    //       });
    //     //   console.log(this.formData)
    //       let key =
    //         "pkg" +
    //         "/" +
    //         this.formData.package_name +
    //         "/" +
    //         new Date().getTime() +
    //         "-" +
    //         this.formData.version_name;
    //       "/" + parser.file.name;
    //       console.log(key)
    //       let that = this;
    //       cos.sliceUploadFile(
    //         {
    //           Bucket: cosconfig.bucket /* 必须 */,
    //           Region:
    //             cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
    //           Key: key,
    //           Body: file /* 必须 */,
    //           onProgress: function (progressData) {
    //             let percent = progressData.percent * 100;
    //             that.uploadpercent= percent
    //             // console.log(percent);
    //             // console.log(that.uploadpercent);
    //             if (that.uploadpercent == 100) {
    //                  that.isvisibel =false
    //               //  that.uploadpercent = percent == 100 ? 99 : percent;
    //               // return;
    //             }
    //             // that.uploadpercent = percent == 100 ? 99 : percent;
    //             // that.uploadpercent = progressData.percent * 100
    //             /* 非必须 */
    //             // console.log(JSON.stringify(progressData));
    //           },
    //         },
    //         function (err, data) {
    //           if (err) {
    //             this.$Message.warning(err);
    //             return;
    //           }
    //           console.log(data);
    //           that.formData.Validation = validation;
    //           that.formData.source_url =
    //             cosconfig.exporturl + "/" + key;
    //           console.log(that.formData.source_url)
    //           // that.getChannelId( that.formData.source_url,that.formData.package_name)    //获取channelId的过程
    //         }
    //       );
    //     })
    //     .catch((err) => {
    //       console.log(err);
    //       this.$Message.warning(err);
    //     });
    //   let that = this;
    //   var reader = new FileReader(); //新建一个FileReader
    //   reader.readAsArrayBuffer(file); //读取文件
    //   reader.onload = function (evt) {
    //     //读取完文件之后会回来这里
    //     let spark = new SparkMD5.ArrayBuffer();
    //     spark.append(evt.target.result);
    //     that.formData.apk_md5 = spark.end();
    //   };
    //   this.apkHashdisabled = true;
    //   return false;
    // },
    // getChannelId(url,pkg){
    //     const params = new URLSearchParams();
    //     params.append("url", url);
    //     params.append("pkg_name", pkg);
    //     GameVersionAPI.getChannelId(params).then(res=>{
    //         if(res.Code==0){
    //             this.formData.channel_code= Number(res.Data.ChannelId)
    //             this.isvisibel =false
    //             this.uploadpercent = 100;

    //         }else{
    //             this.$Message.error(res.Message)
    //         }
    //     })
    // },
    submit(){
        GameVersionAPI.saveChannelMinor(this.formData).then(res=>{
            if(res.Code == 0){
                this.$Message.success("保存成功")
                 this.isvisibel = true
                 this.isupload=false
                this.$parent.$parent.$parent.getlist()
                this.$emit("getisAdd",true)
            }else{
                this.$Message.error(res.Message)
            }
        })
    },
    edit(){
      this.isupload= false
      this.isvisibel = false
      this.formData.channel_code =0
    }
},

}
</script>

<style lang="less" scoped>

</style>
