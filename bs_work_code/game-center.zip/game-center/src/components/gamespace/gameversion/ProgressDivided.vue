<template>
  <div>
    <span
      v-for="(item, index) of dataList"
      :key="index"
      :style="'width:' + 100 / dataList.length + '%'"
      class="step-box"
    >
      {{ getData(item, index).label }}
      <span
        class="step"
        :style="'background-color:' + getData(item, index).color"
      ></span>
    </span>
  </div>
</template>
<script>
export default {
  name: "ProgressDivided",
  props: {
    dataList: Array,
    // data: Number, // 4.11 修改
    data: Object,
    hasChannel: Boolean,
    channelID: String,
  },
  methods: {
    getData(list, index) {
        // 4.11 修改
        let findData = { label: list[0].label, color: "gray" };
        if (index == 0) {
            for (let i = 0; i < list.length; i++) {
                let item = list[i];
                if (item.value == this.data.DownloadStatus) {
                    findData = item;
                    return findData;
                }
            }
        }
        if (this.data.DownloadStatus == 2 && index == 1) {
            //下载状态为成功时
            for (let i = 0; i < list.length; i++) {
                let item = list[i];
                if (item.value == this.data.ParseStatus) {
                    findData = item;
                    return findData;
                }
            }
        }
        //当apk解析成功时
        if (this.data.ParseStatus == 1 && index == 2) {
            for (let i = 0; i < list.length; i++) {
                let item = list[i];
                if (item.value == this.data.MoveFileStatus) {
                    findData = item;
                    return findData;
                }
            }
        }
        return findData;

        // let findData = { label: list[0].label, color: "gray" };
        // for (let i = 0; i < list.length; i++) {
        //     let item = list[i];
        //     let regx =
        //     (typeof item.value == "number" && item.value == this.data) ||
        //     (typeof item.value == "function" &&
        //         item.value(this.data, this.hasChannel, this.channelID)) ||
        //     (typeof item.value == "object" && item.value.includes(this.data));
        //     if (regx) {
        //     findData = item;
        //     if (i == 3 && this.data == 5) {
        //         console.log(index, i, findData, this.data);
        //     }
        //     return findData;
        //     }
        // }
        // return findData;
    },
  },
};
</script>
<style lang="less" scoped>
.step-box {
  display: inline-block;
}
.step {
  display: inline-block;
  width: 98%;
  height: 8px;
  box-sizing: border-box;
  border-radius: 4px;
}
</style>