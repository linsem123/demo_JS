<template>
    <div>
        <Form
            :model="insideformScope"
            ref="insideformScope"
            label-position="right"
            :rules="ruleValidate"
            :label-width="100"
            style="margin-right: 100px; width: 600px"
            enctype="multipart/form-data"
        >
            <FormItem label="下载源:" prop="DownloadSource">
                <RadioGroup v-model="insideformScope.DownloadSource">
                    <Radio :label="0">
                        <span>黑鲨</span>
                    </Radio>
                    <Radio :label="1">
                        <span>小米</span>
                    </Radio>
                    <Radio :label="2">
                        <span>应用宝</span>
                    </Radio>
                </RadioGroup>
            </FormItem>
            <FormItem label="版本类型:" prop="AppVersionType">
                <RadioGroup v-model="insideformScope.AppVersionType">
                    <Radio :label="1" :disabled="disablesub || upByUrlData.loading ">
                        <span>预约</span>
                    </Radio>
                    <Radio :label="0" :disabled="upByUrlData.loading">
                        <span>上线</span>
                    </Radio>
                </RadioGroup>
            </FormItem>
            <FormItem label="内测类型:">
                <RadioGroup v-model="insideformScope.ReleaseType">
                    <Radio :label="0" :disabled="!insideformScope.isAdd">
                        <span>正式</span>
                    </Radio>
                    <Radio :label="1" :disabled="!insideformScope.isAdd">
                        <span>内测</span>
                    </Radio>
                </RadioGroup>
            </FormItem>
            <FormItem v-show="insideformScope.ReleaseType == 1" label="发布描述:">
                <Input v-model="insideformScope.ReleaseTypeDesc" placeholder="发布描述"></Input>
            </FormItem>
            <FormItem v-if="insideformScope.ReleaseType == 1" label="时间范围描述:">
                <Input v-model="insideformScope.ReleasePeriodDesc" placeholder="时间范围描述"></Input>
            </FormItem>

            <template v-if="
          insideformScope.AppVersionType == 1 ||
          insideformScope.ReleaseType == 1
        ">
                <FormItem label="预约人数:">
                    <Input v-model="insideformScope.Reservations" placeholder="预约人数"></Input>
                </FormItem>
                <FormItem label="预计上线时间文本:">
                    <Input v-model="insideformScope.OnlineTimeDesc"></Input>
                </FormItem>
                <FormItem label="预计上线时间:" v-show="insideformScope.AppVersionType == 1">
                    <DatePicker type="datetime" v-model="insideformScope.OnlineTime" format="yyyy-MM-dd HH:mm" placeholder="请选择上线时间"></DatePicker>
                </FormItem>
            </template>
            <FormItem label="CDN:">
                <Select v-model="insideformScope.CDNType" style="width: 100px" :disabled="upByUrlData.loading">
                    <Option :value="2">金山CDN</Option>
                    <Option :value="1">腾讯CDN</Option>
                </Select>
            </FormItem>
            <FormItem label="是否以获取Apk包:" v-show="isShow && insideformScope.AppVersionType == 0">
                <Checkbox v-model="insideformScope.HasApk" :disabled="upByUrlData.loading">以获取</Checkbox>
            </FormItem>

            <template v-if="insideformScope.AppVersionType == 0 && insideformScope.HasApk">
                <FormItem label="上传游戏包:">
                    <Upload ref="uploadpkg" action="/" :before-upload="handlepackageBeforeUpload">
                        <Button icon="ios-cloud-upload-outline">点击上传</Button>
                    </Upload>
                    <Progress :percent="uploadpercent" status="active" />
                </FormItem>
            </template>
            <template v-if="insideformScope.AppVersionType == 0">
                <template v-if="insideformScope.HasApk">
                    <FormItem label="ApkHash:">
                        <Input v-model="insideformScope.ApkHash" :disabled="apkHashdisabled || isEdit" placeholder="ApkHash"></Input>
                    </FormItem>
                    <FormItem label="下载地址:">
                        <Input v-model="insideformScope.DownloadURL" placeholder="下载地址" :disabled="isEdit"></Input>
                    </FormItem>
                    <FormItem label="版本名称:" prop="VersionName">
                        <Input v-model="insideformScope.VersionName" :disabled="isEdit"></Input>
                    </FormItem>
                    <FormItem label="版本号:" prop="VersionCode">
                        <InputNumber v-model="insideformScope.VersionCode" :disabled="isEdit"></InputNumber>
                    </FormItem>
                    <FormItem label="大小:" prop="Size">
                        <InputNumber v-model="insideformScope.Size" :disabled="isEdit"></InputNumber>
                    </FormItem>
                </template>

                <template v-if="!insideformScope.HasApk">
                    <!-- 4.11新增 -->
                    <FormItem label="是否首发版本:">
                        <Checkbox v-model="insideformScope.IsFirstPublish" :disabled="upByUrlData.loading"></Checkbox>
                    </FormItem>
                    
                    <FormItem label="是否需要解析ChannelID:">
                        <Checkbox v-model="insideformScope.ParseChannelID" :disabled="upByUrlData.loading">解析</Checkbox>
                    </FormItem>
                    <FormItem label="Apk包下载地址:">
                        <Input
                            v-model="insideformScope.ApkDownloadURL"
                            placeholder="下载地址"
                            style="width: 80%"
                            :readonly="upByUrlData.loading"
                        ></Input>
                        <Button type="primary" @click="handleUpByUrl" style="margin-left: 5px" :disabled="upByUrlData.loading">立即上传</Button>
                        <div v-if="upByUrlData.loading">
                            <span style="display: inline-block; width: 80%">
                                <ProgressDivided
                                    :dataList="stateList"
                                    :data="upByUrlData.stateCode"
                                    :hasChannel="insideformScope.ParseChannelID"
                                    :channelID="insideformScope.ChannelId"
                                />
                            </span>
                            <Button type="error" @click="handleDelTask" style="margin-left: 5px">删除</Button>
                            <p style="color: red" v-show="upByUrlData.upErrorMsg">报错原因：{{ upByUrlData.upErrorMsg }}</p>
                        </div>
                    </FormItem>
                </template>
                <template v-if="!insideformScope.HasApk && upByUrlData.stateCode.TaskStatus == 2">
                    <Button
                        type="info"
                        @click="handleUpdate"
                        style="left: 520px; position: absolute; z-index: 2"
                        v-show="this.upByUrlData.showUpdateBtn"
                    >刷新</Button>
                    <FormItem label="ChannelID:" v-if="insideformScope.ParseChannelID">
                        <Input placeholder="解析完展示" v-model="insideformScope.ChannelId" style="width: 200px" />
                    </FormItem>
                    <FormItem label="下载地址:">
                        <Input placeholder="解析完展示" v-model="insideformScope.DownloadUrl" style="width: 400px" />
                    </FormItem>
                    <FormItem label="版本名称:">
                        <Input placeholder="解析完展示" v-model="insideformScope.VersionName" style="width: 200px" />
                    </FormItem>
                    <FormItem label="版本号:">
                        <Input placeholder="解析完展示" v-model="insideformScope.VersionCode" style="width: 200px" />
                    </FormItem>
                    <FormItem label="大小:">
                        <Input placeholder="解析完展示" v-model="insideformScope.Size" style="width: 200px" />
                    </FormItem>
                </template>
            </template>
            <FormItem label="选择开发者:" prop="DeveloperID">
                <Select v-model="readonlyformScope.DeveloperID" disabled>
                    <Option v-for="item in DeveloperData" :value="item.ID" :key="item.ID">{{ item.Name }}</Option>
                </Select>
            </FormItem>
            <FormItem label="游戏名称:" prop="AppName">
                <Input v-model="readonlyformScope.AppName" placeholder="请输入游戏名称" disabled></Input>
            </FormItem>
            <FormItem label="游戏包名:" prop="PkgName">
                <Input v-model="readonlyformScope.PkgName" placeholder="请输入游戏包名" disabled></Input>
            </FormItem>
            <FormItem label="选择分类:" prop="CategoryName">
                <!-- <Select v-model="insideformScope.CategoryName" :disabled="canModify">
                    <Option v-for="item in CategoryData" :value="item.Name" :key="item.Name" :disabled="canModify">{{ item.Name }}</Option>
                </Select> -->
                <Select
                    v-model="insideformScope.CategoryName"
                    filterable
                    remote
                    :remote-method="handleCategorySearch"
                    placeholder="请选择分类"
                    clearable
                    :disabled="canModify"
                >
                    <Option v-for="item in CategoryData" :value="item.Name" :key="item.Name" :disabled="canModify">{{ item.Name }}</Option>
                </Select>
            </FormItem>
            <FormItem label="游戏标签:" prop="Tags">
                <Select
                    v-model="insideformScope.Tags"
                    filterable
                    remote
                    :remote-method="handleTagsSearch"
                    placeholder="请选择标签"
                    clearable
                    multiple
                    :disabled="canModify"
                >
                    <Option v-for="item in TagsData" :value="item.Name" :key="item.Name" :disabled="canModify">{{ item.Name }}</Option>
                </Select>
            </FormItem>
            <FormItem label="APP图标:" prop="AppIcon">
                <SharkUpload v-model="insideformScope.AppIcon" :format="['jpg', 'jpeg', 'png', 'gif','webp']" module="game"></SharkUpload>
            </FormItem>
            <FormItem label="一句话介绍:" prop="Title">
                <Input v-model="insideformScope.Title" placeholder="一句话介绍游戏"></Input>
            </FormItem>
            <FormItem label="游戏介绍:" prop="Content">
                <Input v-model="insideformScope.Content" type="textarea" :rows="4" placeholder="请输入游戏介绍"></Input>
            </FormItem>
            <FormItem label="更新内容:" prop="UpdateContent">
                <Input v-model="insideformScope.UpdateContent" type="textarea" :rows="4" placeholder="请输入更新内容"></Input>
            </FormItem>
            <FormItem label="游戏截图:" prop="ImgSource">
                <SharkUpload
                    v-model="insideformScope.ImgSource"
                    module="game"
                    :format="['jpg', 'jpeg', 'png','webp']"
                    compress
                    towebp
                    :max="12"
                ></SharkUpload>
            </FormItem>
            <FormItem label="视频截图:" prop="VideoBg">
                <Input v-model="insideformScope.VideoBg" v-show="false"></Input>
                <div class="demo-upload-list" v-if="insideformScope.VideoBg != ''">
                    <img :src="insideformScope.VideoBg" />
                    <div class="demo-upload-list-cover">
                        <Icon type="ios-eye-outline" @click.native="handleView('img', insideformScope.VideoBg)"></Icon>
                        <Icon type="ios-trash-outline" @click.native="handleRemove('bg')"></Icon>
                    </div>
                </div>
                <Upload
                    ref="bgupload"
                    :show-upload-list="false"
                    :format="['jpg', 'jpeg', 'png','webp']"
                    :on-format-error="handleFormatError"
                    :before-upload="handlebgBeforeUpload"
                    :on-success="handleVideoBgSuccess"
                    type="drag"
                    multiple
                    :action="uploadurl"
                    style="display: inline-block; width: 58px"
                >
                    <div style="width: 58px; height: 58px; line-height: 58px">
                        <Icon type="ios-camera" size="20"></Icon>
                    </div>
                </Upload>
            </FormItem>
            <FormItem label="视频时长:">
                <Input v-model="insideformScope.VideoDuration" placeholder="视频时长"></Input>
            </FormItem>
            <FormItem label="游戏视频:">
                <Input v-model="insideformScope.VideoURL" v-show="false"></Input>
                <div class="demo-upload-list" v-if="insideformScope.VideoURL != ''">
                    <img :src="insideformScope.VideoBg" />
                    <div class="demo-upload-list-cover">
                        <Icon type="ios-eye-outline" @click.native="handleView('video', insideformScope.VideoURL)"></Icon>
                        <Icon type="ios-trash-outline" @click.native="handleRemove('video')"></Icon>
                    </div>
                </div>
                <Upload
                    ref="videoupload"
                    :show-upload-list="false"
                    :format="['mp4', 'avi', 'wmv', 'rmvb', 'flv']"
                    :on-format-error="handleFormatError"
                    :before-upload="handlevideoBeforeUpload"
                    :on-success="handlevideoSuccess"
                    type="drag"
                    multiple
                    :action="uploadurl"
                    style="display: inline-block; width: 58px"
                >
                    <div style="width: 58px; height: 58px; line-height: 58px">
                        <Icon type="ios-camera" size="20"></Icon>
                    </div>
                </Upload>
            </FormItem>
            <FormItem label="隐私协议链接:">
                <Input v-model="insideformScope.PrivacyAgreement" placeholder="请输入隐私协议链接" />
            </FormItem>
            <FormItem label="发布类型:">
                <RadioGroup v-model="insideformScope.PublishType">
                    <Radio :label="0">
                        <span>立即发布</span>
                    </Radio>
                    <Radio :label="1">
                        <span>定时发布</span>
                    </Radio>
                </RadioGroup>
            </FormItem>
            <FormItem label="发布时间:" v-show="insideformScope.PublishType == 1">
                <DatePicker type="datetime" v-model="insideformScope.PublishTime" placeholder="请选择发布时间" style="width: 200px"></DatePicker>
            </FormItem>
            <FormItem>
                <Button type="primary" @click="handleSubmit">提交</Button>
                <Button @click="handleReset" style="margin-left: 8px">重置</Button>
            </FormItem>
        </Form>
        <Modal title="预览" v-model="preview_visible" width="250px">
            <video
                id="preview_video"
                v-if="preview_type === 'video'"
                style="width: 100%; height: 100%"
                controls
                preload
                :src="preview_url"
            />
            <img id="preview_img" v-if="preview_type === 'img'" style="width: 100%; height: 100%" :src="preview_url" />
        </Modal>
    </div>
</template>
<script>
import DeveloperAPI from "@/api/gamespace/developer";
import GameCategoryAPI from "@/api/gamespace/gamecategory";
import GameAPI from "@/api/gamespace/game";
import GameTagAPI from "@/api/gamespace/gametag";
import SharkUpload from "_c/shark-upload";

import GameVersionAPI from "@/api/gamespace/gameversion";
import { AssertVideo } from "@/libs/tools";
import AppInfoParser from "app-info-parser";
import COS from "cos-js-sdk-v5";
import SparkMD5 from "spark-md5";
import cosconfig from "@/libs/cosconfig";
import ProgressDivided from "./ProgressDivided.vue";
export default {
    name: "GameVersionForm",
    components: { SharkUpload, ProgressDivided },
    props: {
        isEdit: {
            type: Boolean,
            default: false
        },
        formScope: {
            ID: undefined,
            AppType: 0,
            DeveloperID: undefined,
            CategoryName: undefined,
            AppName: "",
            PkgName: "",
            VersionName: "",
            VersionCode: 0,
            AppIcon: "",
            Title: "",
            Content: "",
            UpdateContent: "",
            Tags: [],
            ImgSource: []
        }
    },
    data() {
        return {
            isShow: false,
            apkHashdisabled: false,
            readonlyformScope: {
                ID: undefined,
                DeveloperID: undefined,
                CategoryName: "",
                AppName: "",
                PkgName: ""
            },
            disablesub: false,
            preview_visible: false,
            preview_url: "",
            preview_type: "", //video 1, img 0
            loading: false,
            uploadurl: "",
            uploadpercent: 0,
            DeveloperData: [],
            CategoryData: [],
            TagsData: [],
            showversion: false,
            insideformScope: {
                ID: undefined,
                AppIcon: "",
                Title: "",
                Content: "",
                UpdateContent: "",
                Tags: [],
                ImgSource: [],
                CategoryName: "",
                VideoURL: "",
                VideoBg: "",
                VideoDuration: "",
                DownloadURL: "",
                ApkDownloadURL: "",
                VersionName: "",
                VersionCode: 0,
                Size: 0,
                DownloadSource: 0,
                AppVersionType: 0,
                Reservations: 0, //预约人数
                PublishType: 0, //发布类型
                ReleaseType: 0,
                PublishTime: undefined, //定时发布时间
                ApkHash: "",
                OnlineTimeDesc: "",
                OnlineTime: undefined,
                HasApk: true,
                IsFirstPublish: false, // 4.11迭代新增
                ParseChannelID: false,
                CDNType: 2,
                PrivacyAgreement: "", //4,7迭代新增
                Permission: "" //4,9迭代新增权限列表
            },
            ruleValidate: {
                AppVersionType: [
                    {
                        required: true,
                        type: "number",
                        message: "请选择发布类型",
                        trigger: "blur"
                    }
                ],
                DownloadSource: [
                    {
                        required: true,
                        type: "number",
                        message: "请选择下载来源",
                        trigger: "blur"
                    }
                ],
                Tags: [
                    {
                        required: true,
                        type: "array",
                        message: "请输入游戏标签",
                        trigger: "blur"
                    }
                ],
                AppIcon: [
                    {
                        required: true,
                        message: "app图标不能为空",
                        trigger: "blur"
                    }
                ],
                Title: [
                    {
                        required: true,
                        message: "文案不能为空",
                        trigger: "blur"
                    }
                ],
                Content: [
                    {
                        required: true,
                        message: "游戏介绍不能为空",
                        trigger: "blur"
                    }
                ],
                UpdateContent: [
                    {
                        required: true,
                        message: "更新内容不能为空",
                        trigger: "blur"
                    }
                ],
                ImgSource: [
                    {
                        required: true,
                        type: "array",
                        message: "请上传游戏截图",
                        trigger: "blur"
                    }
                ],
                VideoBg: [
                    {
                        required: true,
                        message: "请上传视频截图",
                        trigger: "blur"
                    }
                ]
            },
            uploading: false, //是否上传中
            upByUrlData: {
                loading: false, //据apk链接获取akp包是否上传中
                upStatusMap: [
                    "暂无状态",
                    "开始下载",
                    "下载失败",
                    "合并成功",
                    "合并失败",
                    "解析apk成功",
                    "解析apk失败",
                    "解析channelId成功",
                    "channelId解析失败",
                    "移动文件成功",
                    "文件移动失败",
                    "成功"
                ],
                timer: null, //定时器
                upErrorMsg: "", //上传错误原因
                // stateCode: 0, //状态码
                stateCode: {}, // 4.11 状态对象
                logID: 0, //上传任务ID
                showUpdateBtn: false
            },

            // stateList: [
            //     [
            //         { value: 1, label: "开始下载且合并", color: "#2d8cf0" },
            //         { value: 2, label: "下载失败", color: "#ed4014" },
            //         { value: 4, label: "合并失败", color: "#ed4014" },
            //         {
            //             value: function (state) {
            //                 return state == 3 || state > 4;
            //             },
            //             label: "合并成功",
            //             color: "#19be6b"
            //         }
            //     ],
            //     [
            //         { value: 3, label: "开始解析apk", color: "#2d8cf0" },
            //         {
            //             value: function (state, hasChannel, channelID) {
            //                 console.log(channelID);
            //                 return state == 6 || state == 8 || (state > 8 && hasChannel && !channelID);
            //             },
            //             label: "解析apk失败",
            //             color: "#ed4014"
            //         },
            //         {
            //             value: function (state, hasChannel, channelID) {
            //                 if (hasChannel) {
            //                     return state == 7 || (state > 8 && channelID);
            //                 }
            //                 return state == 5 || state > 6;
            //             },
            //             label: "解析成功",
            //             color: "#19be6b"
            //         }
            //     ],
            //     [
            //         {
            //             value: function (state, hasChannel) {
            //                 if (hasChannel) {
            //                     return state == 7;
            //                 }
            //                 return state == 5;
            //             },
            //             label: "开始移动文件",
            //             color: "#2d8cf0"
            //         },
            //         { value: 10, label: "移动文件失败", color: "#ed4014" },
            //         {
            //             value: function (state) {
            //                 return state > 8;
            //             },
            //             label: "成功",
            //             color: "#19be6b"
            //         }
            //     ]
            // ],

            // 4.11
            stateList: [
                [
                    { value: 0, label: "开始下载且合并", color: "gray" },
                    { value: 1, label: "下载中", color: "#2d8cf0" },
                    { value: 2, label: "合并成功", color: "#19be6b" },
                    { value: 3, label: "合并失败", color: "#ed4014" }
                ],
                [
                    { value: 0, label: "开始解析apk", color: "#2d8cf0" },
                    { value: 1, label: "解析成功", color: "#19be6b" },
                    { value: 2, label: "解析apk失败", color: "#ed4014" }
                ],
                [
                    { value: 0, label: "开始移动文件", color: "#2d8cf0" },
                    { value: 1, label: "成功", color: "#19be6b" },
                    { value: 2, label: "移动文件失败", color: "#ed4014" }
                ]
            ],
            canModify: false
        };
    },
    // computed: {
    //     canModify() {
    //         return this.isEdit && this.insideformScope.AppReporterType == 1;
    //     }
    // },
    methods: {
        //根据apk链接获取akp包上传
        async handleUpByUrl() {
            if (!this.insideformScope.ApkDownloadURL) {
                this.$Message.error("请先填写Apk包下载地址！");
                return;
            }
            this.upByUrlData.loading = true;
            //页面监听闭窗口/关闭浏览器/刷新，弹窗提示
            window.onbeforeunload = function () {
                return "您确定退出吗？";
            };
            let actLogData = await GameVersionAPI.upByUrlAct({
                DownloadUrl: this.insideformScope.ApkDownloadURL,
                IsFirstPublish: this.insideformScope.IsFirstPublish, // 4.11
                ParseChannelId: this.insideformScope.ParseChannelID,
                CdnType: this.insideformScope.CDNType,
                PkgName: this.readonlyformScope.PkgName
            });
            if (actLogData.Code == 0) {
                this.upByUrlData.logId = actLogData.Data;
                this.upByUrlServer(actLogData.Data);
            } else {
                this.$Message.error(actLogData.Message || "上传失败");
                this.upByUrlData.loading = false;
                window.onbeforeunload = null;
                return;
            }
        },
        //获取任务进度
        async upByUrlServer(logId) {
            let res = await GameVersionAPI.getActProgress(logId);
            if (res.Code == 0) {
                // 4.11迭代修改
                let data = res.Data;
                //判断哪个步骤了
                this.upByUrlData.stateCode = data;
                // 0 初始化状态，1 下载中，2 成功，3 失败
                if (data.TaskStatus == 3) {
                    //失败
                    this.clearTimers();
                    this.$Message.error(data.FailedReason);
                    this.upByUrlData.upErrorMsg = data.FailedReason;
                    return;
                }
                if (data.TaskStatus == 2) {
                    //任务最终状态
                    //解析成功
                    this.insideformScope = {
                        ...this.insideformScope,
                        Size: data.Size,
                        DownloadUrl: data.DownloadUrl,
                        VersionCode: data.VersionCode,
                        VersionName: data.VersionName,
                        ChannelId: data.TencentChannelId || "",
                        Permission: data.UsesPermission
                    };
                    this.insideformScope = Object.assign({}, this.insideformScope);
                    this.upByUrlData.showUpdateBtn = true;
                    this.clearTimers();
                    return;
                }

                // let data = res.Data;
                // this.upByUrlData.stateCode = data.State;
                // this.stateName = this.upByUrlData.upStatusMap[data.State];
                // if ([2, 4, 6, 10].includes(data.State)) {
                //     //失败
                //     this.clearTimers();
                //     this.$Message.error(data.FailedReason || this.upByUrlData.upStatusMap[data.State]);
                //     this.upByUrlData.upErrorMsg = data.FailedReason;
                //     return;
                // }
                //channelID解析失败展示报错原因但不终止
                // if (data.State == 8) {
                //     this.upByUrlData.upErrorMsg = data.FailedReason;
                // }
                // if (data.State == 5 || data.State > 6) {
                //     //解析成功
                //     this.insideformScope = {
                //         ...this.insideformScope,
                //         Size: data.ApkSize,
                //         DownloadUrl: data.DownloadUrl,
                //         VersionCode: data.VersionCode,
                //         VersionName: data.VersionName,
                //         ChannelId: data.ChannelId || "",
                //         Permission: data.Permission
                //     };
                //     this.insideformScope = Object.assign({}, this.insideformScope);
                //     this.upByUrlData.showUpdateBtn = true;
                // }
                // if (data.State == 11) {
                //     if (!this.insideformScope.ChannelId && this.insideformScope.ParseChannelID && !this.upByUrlData.upErrorMsg) {
                //         this.upByUrlData.upErrorMsg = "ChannelId解析失败";
                //     }
                //     this.clearTimers();
                //     return;
                // }
            } else {
                this.$Message.error(res.Message || "任务失败");
                return;
            }
            this.upByUrlData.timer = setTimeout(() => {
                this.upByUrlServer(logId);
            }, 5000);
        },
        //删除上传任务
        handleDelTask() {
            this.$Modal.confirm({
                title: "提示",
                content: "<p>是否删除当前上传任务</p>",
                onOk: () => {
                    this.delTaskServer();
                    this.$Modal.remove();
                }
            });
        },
        //删除任务接口调用
        delTaskServer() {
            GameVersionAPI.delActProgress(this.upByUrlData.logId).then(res => {
                if (res.Code == 0) {
                    this.$Message.success("删除任务成功");
                    //删除任务成功需-清空定时器/上传状态改为false/上传状态码重置/解析数据重置/报错信息重置/取消监听关闭浏览器行为
                    this.clearTimers();
                    this.upByUrlData.loading = false;
                    // this.upByUrlData.stateCode = 0;
                    this.upByUrlData.stateCode = {}; // 4.11
                    this.upByUrlData.upErrorMsg = "";
                    window.onbeforeunload = null;
                    this.insideformScope = {
                        ...this.insideformScope,
                        Size: "",
                        DownloadUrl: "",
                        VersionCode: "",
                        VersionName: "",
                        ChannelId: "",
                        Permission: "",
                        ApkDownloadURL: ""
                    };
                } else {
                    this.$Message.error(res.Message || "删除任务失败");
                }
            });
        },

        //清空定时器
        clearTimers() {
            if (this.upByUrlData.timer) {
                clearTimeout(this.upByUrlData.timer);
                this.upByUrlData.timer = null;
            }
        },
        //刷新，重新获取数据
        handleUpdate() {
            GameVersionAPI.getActProgress(this.upByUrlData.logId)
                .then(res => {
                    if (res.Code == 0) {
                        //调用接口成功
                        this.insideformScope = {
                            ...this.insideformScope,
                            Size: data.Size,
                            DownloadUrl: data.DownloadUrl,
                            VersionCode: data.VersionCode,
                            VersionName: data.VersionName,
                            ChannelId: data.TencentChannelId || ""
                        };
                        this.insideformScope = Object.assign({}, this.insideformScope);
                    }
                })
                .finally(() => {
                    this.upByUrlData.showUpdateBtn = false;
                });
        },
        handleDeveloperSearch(value) {
            DeveloperAPI.Like({ value }).then(res => {
                this.DeveloperData = res.Data;
            });
        },
        handleTagsSearch(value) {
            GameTagAPI.Like({ value }).then(res => {
                this.TagsData = res.Data;
            });
        },
        handleCategorySearch(value) {
            GameCategoryAPI.Like(value, this.insideformScope.AppType).then(res => {
                this.CategoryData = res.Data;
            });
        },
        handleSubmit() {
            this.$refs["insideformScope"].validate(valid => {
                if (valid) {
                    if (this.uploading && this.uploadpercent < 100) {
                        this.$Message.error("请等待游戏包上传完成!");
                        return;
                    }
                    if (
                        this.insideformScope.DownloadURL == "" &&
                        this.insideformScope.AppVersionType == 0 &&
                        this.insideformScope.DownloadSource == 0 &&
                        this.insideformScope.ApkHash
                    ) {
                        this.$Message.error("请上传游戏包!");
                        return;
                    }
                    if (!this.isShow && this.insideformScope.AppVersionType == 0 && this.insideformScope.DownloadURL.trim() == "") {
                        this.$Message.error("请上传apk!");
                        return;
                    }

                    if (this.upByUrlData.loading) {
                        // 4.11
                        if (this.upByUrlData.stateCode.TaskStatus == 3) {
                            this.$Message.error("上传任务失败，请重新上传");
                            return;
                        } else if (this.upByUrlData.stateCode.TaskStatus != 2) {
                            this.$Message.error("上传任务未完成，请稍等");
                            return;
                        }
                        // if ([2, 4, 6, 8, 10].includes(this.upByUrlData.stateCode)) {
                        //     this.$Message.error("上传任务失败，请重新上传");
                        //     return;
                        // } else if (this.upByUrlData.stateCode < 11) {
                        //     this.$Message.error("上传任务未完成，请稍等");
                        //     return;
                        // }
                    }
                    if (this.insideformScope.PublishType == 1 && !this.insideformScope.PublishTime) {
                        this.$Message.error("请选择发布时间!");
                        return;
                    } else if (
                        this.insideformScope.PublishType == 1 &&
                        new Date().getTime() > new Date(this.insideformScope.PublishTime).getTime()
                    ) {
                        this.$Message.error("定时上线时间不得早于当前时间");
                        return;
                    }
                    this.insideformScope.Reservations = parseInt(this.insideformScope.Reservations);
                    this.insideformScope.ApkHash = "";
                    this.$emit("on-form-submit", this.insideformScope);
                } else {
                    this.$Message.error("请填写必需信息!");
                }
            });
        },
        handleFormatError(file) {
            this.$Notice.warning({
                title: "格式错误",
                desc: file.name + " 格式错误"
            });
        },
        handleImgBeforeUpload(file) {
            const t = AssertVideo(file.name);
            if (t != "img") {
                this.handleFormatError(file);
                this.$refs.uploadicon.clearFiles();
                return false;
            }

            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        console.log(data);
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            let key = "pkg" + "/" + this.readonlyformScope.PkgName + "/" + new Date().getTime() + "-" + file.name;
            let that = this;
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        let percent = progressData.percent * 100;
                        if (that.uploadpercent == 100) {
                            return;
                        }
                        that.uploadpercent = percent == 100 ? 99 : percent;
                        /* 非必须 */
                        console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        this.$Message.warning(err);
                        return;
                    }
                    console.log(data);
                    that.insideformScope.ImgSource.push(cosconfig.exporturl + "/" + key);
                    that.uploadpercent = 100;
                }
            );
            return false;
        },
        handlebgBeforeUpload(file) {
            const t = AssertVideo(file.name);
            if (t != "img") {
                this.handleFormatError(file);
                this.$refs.uploadicon.clearFiles();
                return false;
            }
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        console.log(data);
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            let key = "pkg" + "/" + this.readonlyformScope.PkgName + "/" + new Date().getTime();
            // let key = "pkg" + "/" + this.readonlyformScope.PkgName + "/" + file.name;
            let that = this;
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        that.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        this.$Message.warning(err);
                        return;
                    }
                    console.log(data);
                    that.insideformScope.VideoBg = cosconfig.exporturl + "/" + key;
                }
            );
            return false;
        },
        handleIconBeforeUpload(file) {
            const t = AssertVideo(file.name);
            if (t != "img") {
                this.handleFormatError(file);
                this.$refs.uploadicon.clearFiles();
                return false;
            }
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            let key = "pkg" + "/" + this.readonlyformScope.PkgName + "/" + file.name;
            let that = this;
            cos.putObject(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */
                    // ContentType: 'image/png',
                    // onProgress: function(progressData) {
                    //   that.uploadpercent = progressData.percent * 100;
                    //   /* 非必须 */
                    //   console.log(JSON.stringify(progressData));
                    // }
                },
                function (err, data) {
                    if (err) {
                        this.$Message.warning(err);
                        return;
                    }
                    console.log(data);
                    that.insideformScope.AppIcon = cosconfig.exporturl + "/" + key;
                }
            );
            return false;
        },
        handlevideoBeforeUpload(file) {
            console.log(file);
            const t = AssertVideo(file.name);
            console.log(t);
            if (t != "video") {
                this.handleFormatError(file);
                this.$refs.videoupload.clearFiles();
                return false;
            }
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        console.log(data);
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });

            let key = "pkg" + "/" + this.readonlyformScope.PkgName + "/" + new Date().getTime();
            // let key = "pkg" + "/" + this.readonlyformScope.PkgName + "/" + file.name;
            let that = this;
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        that.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        this.$Message.warning(err);
                        return;
                    }
                    console.log(data);
                    that.insideformScope.VideoURL = cosconfig.exporturl + "/" + key;
                }
            );
            return false;
        },
        //上传游戏包
        handlepackageBeforeUpload(file) {
            this.uploading = true;
            const parser = new AppInfoParser(file);
            parser
                .parse()
                .then(result => {
                    console.log(result);

                    this.insideformScope.VersionName = result.versionName;
                    this.insideformScope.VersionCode = result.versionCode;
                    this.insideformScope.Size = parser.file.size;
                    if (result.package != this.readonlyformScope.PkgName) {
                        console.log(result.package);
                        this.$refs.uploadpkg.clearFiles();
                        this.$Message.warning("包名不相符合");
                        this.uploading = false;
                        return;
                    }
                    //获取权限列表，以‘,’分隔
                    this.insideformScope.Permission = result.usesPermissions.map(v => v.name).join(",");
                    let fileReader = new FileReader();
                    let validation = "";
                    fileReader.onloadend = function (e) {
                        console.log(e);
                        let spark = new SparkMD5.ArrayBuffer();
                        spark.append(e.target.result);
                        validation = spark.end();
                        console.log(validation);
                    };
                    fileReader.readAsArrayBuffer(file);
                    this.showversion = true;
                    let cos = new COS({
                        getAuthorization: function (options, callback) {
                            GameAPI.GetSts().then(data => {
                                console.log(11111111111111);
                                console.log(data);
                                callback({
                                    TmpSecretId: data.Data.credentials.tmpSecretId,
                                    TmpSecretKey: data.Data.credentials.tmpSecretKey,
                                    XCosSecurityToken: data.Data.credentials.sessionToken,
                                    ExpiredTime: data.Data.expiredTime
                                });
                            });
                        }
                    });
                    let key =
                        "pkg" + "/" + this.readonlyformScope.PkgName + "/" + new Date().getTime() + "-" + this.insideformScope.VersionName;
                    "/" + parser.file.name;
                    let that = this;
                    cos.sliceUploadFile(
                        {
                            Bucket: cosconfig.bucket /* 必须 */,
                            Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                            Key: key,
                            Body: file /* 必须 */,
                            onProgress: function (progressData) {
                                let percent = progressData.percent * 100;
                                console.log(percent);
                                console.log(that.uploadpercent);
                                if (that.uploadpercent == 100) {
                                    that.uploading = false;
                                    return;
                                }
                                that.uploadpercent = percent == 100 ? 99 : percent;
                                // that.uploadpercent = progressData.percent * 100
                                /* 非必须 */
                                console.log(22222222222222);
                                console.log(JSON.stringify(progressData));
                            }
                        },
                        function (err, data) {
                            if (err) {
                                that.$Message.warning(err);
                                that.uploading = false;
                                return;
                            }
                            console.log(data);
                            that.insideformScope.Validation = validation;
                            that.insideformScope.DownloadURL = `${
                                that.insideformScope.CDNType == 2 ? cosconfig.exporturl : cosconfig.tencentExporturl
                            }/${key}`;
                            console.log(that.insideformScope.DownloadURL);
                            that.uploadpercent = 100;
                            that.uploading = false;
                        }
                    );
                })
                .catch(err => {
                    console.log(err);
                    this.$Message.warning(err);
                    this.uploading = false;
                });
            let that = this;
            var reader = new FileReader(); //新建一个FileReader
            reader.readAsArrayBuffer(file); //读取文件
            reader.onload = function (evt) {
                //读取完文件之后会回来这里
                let spark = new SparkMD5.ArrayBuffer();
                spark.append(evt.target.result);
                that.insideformScope.ApkHash = spark.end();
            };
            this.apkHashdisabled = true;
            return false;
        },
        handleIconSuccess(res, file) {
            this.insideformScope.AppIcon = res.Data.URL;
        },
        handleImgSuccess(res, file) {
            this.insideformScope.ImgSource.push(res.Data.URL);
        },
        handlevideoSuccess(res, file) {
            this.insideformScope.VideoURL = res.Data.URL;
        },
        handleVideoBgSuccess(res, file) {
            this.insideformScope.VideoBg = res.Data.URL;
        },
        handleView(t, url) {
            console.log(t, url);
            this.preview_type = t;
            this.preview_url = url;
            this.preview_visible = true;
        },
        handleRemove(t, item) {
            if (t == "icon") {
                this.$refs.uploadicon.clearFiles();
                this.insideformScope.AppIcon = "";
                return;
            }
            if (t == "img") {
                this.$refs.imgupload.clearFiles();
                this.insideformScope.ImgSource.remove(item);
                return;
            }
            if (t == "bg") {
                this.$refs.bgupload.clearFiles();
                this.insideformScope.VideoBg = "";
                return;
            }
            if (t == "video") {
                this.$refs.videoupload.clearFiles();
                this.insideformScope.VideoURL = "";
                return;
            }
        },
        handleReset() {
            this.$refs.insideformScope.resetFields();
            this.insideformScope.AppIcon = "";
            if (this.upByUrlData.loading) {
                //正在上传中，提示弹窗确认删除任务
                this.handleDelTask();
            }
        }
    },
    mounted() {
        this.uploadurl = GameAPI.UploadURL();
    },
    watch: {
        formScope(formScope) {
            console.log(formScope);
            this.isShow = formScope.IsShow;
            this.readonlyformScope.DeveloperID = formScope.DeveloperID;
            this.insideformScope.DownloadSource = formScope.DownloadSource;
            this.readonlyformScope.AppName = formScope.AppName;
            this.readonlyformScope.PkgName = formScope.PkgName;
            this.insideformScope.AppID = formScope.AppID;
            this.insideformScope.CategoryName = formScope.CategoryName;
            this.insideformScope.Tags = formScope.Tags;
            this.insideformScope.ReleaseType = formScope.ReleaseType || 0;
            this.insideformScope.ReleaseTypeDesc = formScope.ReleaseTypeDesc;
            this.insideformScope.ReleasePeriodDesc = formScope.ReleasePeriodDesc;
            this.insideformScope.isAdd = formScope.isAdd || false;
            if (formScope.Tags && formScope.Tags.length > 0) {
                for (const item of formScope.Tags) {
                    let has = false;
                    this.TagsData.filter(item => {
                        if (item.Name == item) {
                            has = true;
                        }
                    });
                    if (!has) this.TagsData.push({ Name: item });
                }
            }
            this.insideformScope.AppIcon = formScope.AppIcon;
            this.insideformScope.Title = formScope.Title;
            this.insideformScope.Content = formScope.Content;
            this.insideformScope.UpdateContent = formScope.UpdateContent;
            this.insideformScope.PublishType = formScope.PublishType || 0;
            if (this.insideformScope.PublishType == 0) {
                let nowDate = new Date().getFullYear() + "/" + (new Date().getMonth() + 1) + "/" + new Date().getDate();
                this.insideformScope.PublishTime = new Date(nowDate);
            } else {
                this.insideformScope.PublishTime = formScope.PublishTime;
            }
            this.insideformScope.VideoBg = formScope.VideoBg || "";
            this.insideformScope.VideoURL = formScope.VideoURL || "";
            this.insideformScope.VideoDuration = formScope.VideoDuration || "";
            if (formScope.ImgSource.length == 1 && formScope.ImgSource[0] == "") {
                formScope.ImgSource = [];
            }
            this.insideformScope.ImgSource = formScope.ImgSource || [];
            this.insideformScope.Title = formScope.Title;
            this.insideformScope.Content = formScope.Content;
            this.insideformScope.VideoDuration = formScope.VideoDuration;
            this.insideformScope.VersionName = formScope.VersionName;
            this.insideformScope.VersionCode = formScope.VersionCode;
            this.insideformScope.DownloadURL = formScope.DownloadURL;
            this.insideformScope.AppVersionType = formScope.AppVersionType || 0;
            if (formScope.DownloadURL != "") {
                this.showversion = true;
            }
            this.insideformScope.Size = parseInt(formScope.Size);
            this.insideformScope.ID = formScope.ID;
            this.insideformScope.AppType = formScope.AppType;
            this.insideformScope.ApkHash = formScope.ApkHash;
            this.insideformScope.OnlineTime = formScope.OnlineTime;
            this.insideformScope.OnlineTimeDesc = formScope.OnlineTimeDesc;
            this.insideformScope.Reservations = formScope.Reservations;
            this.insideformScope.PrivacyAgreement = formScope.PrivacyAgreement; //4.7迭代增加
            this.insideformScope.AppReporterType = formScope.AppReporterType; //4.10迭代增加

            // this.insideformScope.SubType = formScope.SubType;
            DeveloperAPI.Get(formScope.DeveloperID).then(res => {
                this.DeveloperData = [res.Data];
            });
            this.CategoryData = [
                {
                    ID: 0,
                    Name: formScope.CategoryName
                }
            ];
            this.canModify = this.isEdit && this.insideformScope.AppReporterType == 1;
            // console.log(, this.isEdit, this.insideformScope.AppReporterType == 1);
        }
    },
    destroyed() {
        //页面销毁，清空定时器
        this.clearTimers();
        window.onbeforeunload = null;
    }
};
</script>

<style>
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
}
.demo-upload-list img {
    width: 100%;
    height: 100%;
}
.demo-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
    display: block;
}
.demo-upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
}
</style>
