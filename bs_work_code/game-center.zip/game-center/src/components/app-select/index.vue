<template>
    <Select
        v-model="value"
        filterable
        remote
        clearable
        :placeholder="placeholder"
        :remote-method="getAppList"
        :loading="loading"
        ref="selection"
        @on-clear="valClear"
        @on-change="valChange"
        :disabled="gameDisabled"
    >
        <Option v-for="item in appList" :value="item.value" :key="item.value">{{ item.label }}</Option>
    </Select>
</template>

<script>
import GameAPI from "@/api/gamespace/game";

export default {
    name: "AppSelect",
    model: {
        prop: "modelValue",
        event: "valueChange"
    },
    props: {
        modelValue: null,
        placeholder: {
            type: String,
            default: "请选择App"
        },
        disabled: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            value: null,
            loading: false,
            appList: [],
            list: [],
            appTitle: "",
            label: "",
            gameDisabled: false
        };
    },
    mounted() {
        this.getAppById(this.modelValue);
    },
    watch: {
        modelValue(v) {
            this.gameDisabled = this.disabled;
            this.value = v;
            this.getAppById(v);
        }
    },
    methods: {
        getAppList(v) {
            // console.log(v)
            let value = v || this.value;
            if (!value || this.loading) {
                return;
            }
            if (this.appList && this.appList.length === 1 && this.appList[0].label === v) {
                return;
            }
            this.loading = true;
            GameAPI.LikeApp({ value }).then(res => {
                if (res.Code === 0) {
                    this.list = res.Data || [];
                    const list = this.list.map(item => {
                        item.value = item.ID;
                        item.label = item.AppName;
                        // return {
                        //   value: item.ID,
                        //   label: item.AppName,
                        //   Title: item.Title,
                        //   PkgName: item.PkgName,
                        //   AppIcon: item.AppIcon,
                        //   Content: item.Content,
                        //   AppStatus: item.AppStatus,
                        // };
                        return item;
                    });
                    this.appList = list.filter(item => item.label.toLowerCase().indexOf(v.toLowerCase()) > -1);
                }
                this.loading = false;
            });
        },

        getAppById(id) {
            if (this.appList && this.appList.length === 1 && this.appList[0].value == this.modelValue) {
                this.gameDisabled = this.disabled;
                return;
            }
            if (!id || id == null) {
                this.gameDisabled = this.disabled;
                return;
            }
            this.loading = true;
            GameAPI.Get(id).then(res => {
                this.appList = [{ value: res.Data["ID"], label: res.Data["AppName"], ...res.Data }] || [];

                // this.value = this.appList[0]["value"]
                this.$refs["selection"].setQuery(res.Data["AppName"]);
                this.$refs["selection"].toggleMenu(null, false);
                this.$nextTick(() => {
                    this.gameDisabled = this.disabled;
                    this.loading = false;
                    this.$emit("on-change", { value: this.appList[0] || {}, index: 0 }); // 首次change，index为了防止首次change被回调导致外部默认数据改变
                });
            });
        },

        valChange(v) {
            if (!v) {
                this.$refs["selection"].setQuery(this.appList[0]["label"]);
                this.$refs["selection"].toggleMenu(null, false);
                this.value = this.appList[0]["value"];
            }
            this.$emit("valueChange", v);

            this.appList.map(item => {
                // console.log(item)
                if (v == item.value) {
                    this.$emit("on-change", { value: item, index: 1 });
                }
            });
        },

        valClear() {
            this.$emit("on-change", {});
        }
    }
};
</script>

<style scoped>
</style>
