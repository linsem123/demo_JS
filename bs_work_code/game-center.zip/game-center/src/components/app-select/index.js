import AppSelect from './index.vue'
export default AppSelect
