import RankSelect from './index.vue'
export default RankSelect
