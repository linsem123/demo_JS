<template>
  <Select
    v-model="value"
    filterable
    remote
    clearable
    :placeholder="placeholder"
    :remote-method="getRankList"
    :loading="loading"
    ref="selection"
    @on-clear="valClear"
    @on-change="valChange"
  >
    <Option v-for="(item, i) in ranktypes" :value="item.value" :key="i">{{
      item.label
    }}</Option>
  </Select>
</template>

<script>
import HomeModuleApi from "@/api/gamespace/homemodule";

export default {
  name: "RankSelect",
  model: {
    prop: "modelValue",
    event: "valueChange",
  },
  props: {
    rankType: 0,
    modelValue: null,
    placeholder: {
      type: String,
      default: "请选择榜单",
    },
  },
  data() {
    return {
      value: null,
      loading: false,
      ranktypes: [],
      list: [],
      rankTitle: "",
      gameRankType: undefined,
    };
  },
  mounted() {
    this.getRankById(this.modelValue);
  },
  watch: {
    modelValue(v) {
      this.value = v;
      this.getRankById(v);
    },
    rankType(v) {
      this.gameRankType = v;
    },
  },
  methods: {
    getRankList(v) {
      let str = v || this.value;
      if (!str || this.loading) {
        return;
      }
      if (
        this.ranktypes &&
        this.ranktypes.length === 1 &&
        this.ranktypes[0].Title === v
      ) {
        return;
      }
      this.loading = true;
      this.gameRankType = this.rankType;
      HomeModuleApi.LikeRank(str, this.gameRankType).then((res) => {
        if (res.Code === 0) {
          this.list = res.Data || [];
          const list = this.list.map((item) => {
            return {
              value: item.ID,
              label: item.Title,
              from: item.From,
              Desc: item.Desc,
              RankType: item.RankType,
            };
          });
          this.ranktypes = list.filter(
            (item) => item.label.toLowerCase().indexOf(v.toLowerCase()) > -1
          );
        }
        this.loading = false;
      });
    },

    getRankById(id) {
      if (
        this.ranktypes &&
        this.ranktypes.length === 1 &&
        this.ranktypes[0].ID == this.modelValue
      ) {
        return;
      }
      if (!id || id == null) {
        return;
      }
      this.loading = true;
      HomeModuleApi.GetRankById(id).then((res) => {
        this.ranktypes = [
          {
            value: res.Data["ID"],
            label: res.Data["Title"],
            from: res.Data.From,
            Desc: res.Data.Desc,
            RankType: res.Data.RankType,
          },
        ];
        // this.value = this.ranktypes[0]["value"]
        this.$refs["selection"].setQuery(res.Data["Title"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.$nextTick(() => {
          this.loading = false;
          this.$emit("on-change", { value: this.ranktypes[0] || {}, index: 0 });
        });
      });
    },

    valChange(v) {
      if (!v) {
        this.$refs["selection"].setQuery(this.ranktypes[0]["label"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.value = this.ranktypes[0]["value"];
      }
      this.$emit("valueChange", v);
      this.ranktypes.forEach((item) => {
        if (v == item.ID) {
          this.$emit("on-change", { value: item, index: 1 });
        }
      });
    },

    valClear() {
      this.$emit("on-change", {});
    },
  },
};
</script>

<style scoped>
</style>
