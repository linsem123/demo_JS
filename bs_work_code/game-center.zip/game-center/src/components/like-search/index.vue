<template>
  <Select
    v-model="value"
    filterable
    remote
    clearable
    :placeholder="placeholder"
    :remote-method="getAppList"
    :loading="loading"
    ref="selection"
    @on-clear="valClear"
    @on-change="valChange"
  >
    <Option v-for="item in appList" :value="item.ID" :key="item.ID">{{
      item.Title
    }}</Option>
  </Select>
</template>

<script>
import Api from "@/api/fuzzy";

export default {
  name: "LikeSearch",
  model: {
    prop: "modelValue",
    event: "valueChange",
  },
  props: {
    modelValue: null,
    placeholder: {
      type: String,
      default: "请选择",
    },
    serverData: {
      type: Object,
      default: {
        likeUrl: "",
        likeData: {},
        IdKey: "",
        NameKey: "",
      },
    },
  },
  data() {
    return {
      value: null,
      loading: false,
      appList: [],
      list: [],
    };
  },
  methods: {
    getAppList(v) {
      let value = v || this.value;
      if (!value || this.loading) {
        return;
      }
      if (
        this.appList &&
        this.appList.length === 1 &&
        this.appList[0].Title === v
      ) {
        return;
      }
      this.loading = true;
      Api[this.serverData.likeUrl]({
        like: v,
        ...this.serverData.likeData,
      })
        .then((res) => {
          if (res.Code === 0) {
            if (this.serverData.listName) {
              this.list = res.Data[this.serverData.listName] || [];
            } else {
              this.list = res.Data || [];
            }
            this.list = this.list.map((v) => {
              v.ID = v[this.serverData.IdKey || "ID"];
              v.Title = v[this.serverData.NameKey || "Title"];
              return v;
            });
            this.appList = this.list.filter(
              (item) => item.Title.toLowerCase().indexOf(v.toLowerCase()) > -1
            );
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    valChange(v) {
      if (!v) {
        this.$refs["selection"].setQuery(this.appList[0]["Title"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.value = this.appList[0]["ID"];
      }
      this.$emit("valueChange", v);
      this.appList.map((item) => {
        if (v == item.ID) {
          this.$emit("on-change", item);
        }
      });
    },

    valClear() {
      this.$emit("on-change", "");
    },
    clearText() {
      this.$refs.selection.clearSingleSelect();
      this.appList = [];
    },
    setQuery({ id, title }) {
      this.$refs["selection"].setQuery(title);
      this.$refs["selection"].toggleMenu(null, false);
    },
  },
};
</script>

<style scoped>
</style>
