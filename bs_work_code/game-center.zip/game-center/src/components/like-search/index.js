import LikeSearch from './index.vue'
export default LikeSearch
