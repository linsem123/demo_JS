<template>
  <Select
    :value="value"
    filterable
    remote
    clearable
    :placeholder="placeholder"
    :loading="loading"
    ref="selection"
    @on-clear="valClear"
    @on-change="valChange"
    :style="'width:' + width + 'px'"
  >
    <Option v-for="item in phoneList" :value="item.ID" :key="item.ID">{{
      item.Name
    }}</Option>
  </Select>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
export default {
  name: "PhoneSelect",
  //   model: {
  //     prop: "value",
  //     event: "valueChange",
  //   },
  props: {
    value: { default: undefined },
    placeholder: {
      type: String,
      default: "请选择机型",
    },
    width: {
      type: Number,
      default: 100,
    },
  },
  data() {
    return {
      loading: false,
      phoneList: [],
    };
  },
  mounted() {
    this.getPhoneList();
  },
  methods: {
    valClear() {},
    valChange(v) {
      this.$emit("input", v);
    },
    getPhoneList() {
      GameAPI.getPhoneModel().then((res) => {
        if (res.Code == 0) {
          this.phoneList = res.Data;
          this.phoneList.push({
            ID: 0,
            Name: "其他",
          });
        }
      });
    },
  },
};
</script>