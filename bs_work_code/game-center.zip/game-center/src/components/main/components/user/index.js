import User from './user.vue'
export default User
