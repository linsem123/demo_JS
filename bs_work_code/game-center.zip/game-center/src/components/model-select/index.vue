<template>
  <Select
    v-model="value"
    filterable
    remote
    clearable
    :placeholder="placeholder"
    :remote-method="getModelList"
    :loading="loading"
    ref="selection"
    @on-clear="valClear"
    @on-change="valChange"
  >
    <Option v-for="item in modelList" :value="item.value" :key="item.value"
      >({{ item.value }}){{ item.label }}</Option
    >
  </Select>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";

export default {
  name: "ModelSelect",
  model: {
    prop: "modelValue",
    event: "modelChange",
  },
  props: {
    modelValue: null,
    placeholder: {
      type: String,
      default: "请输入模块名称",
    },
  },
  data() {
    return {
      value: null,
      loading: false,
      modelList: [],
      list: [],
    };
  },
  mounted() {
    this.getModelById(this.modelValue);
  },
  watch: {
    modelValue(v) {
      this.value = v;
    },
  },
  methods: {
    getModelList(v) {
      let value = v || this.value;
      if (!value || this.loading) {
        return;
      }
      if (
        this.modelList &&
        this.modelList.length === 1 &&
        this.modelList[0].label === v
      ) {
        return;
      }
      this.loading = true;
      HomeModuleAPI.ModelLike(value).then((res) => {
        if (res.Code === 0) {
          this.list = res.Data || [];
          const list = this.list.map((item) => {
            return {
              value: item.ID,
              label: item.Name,
            };
          });

          this.modelList = list.filter(
            (item) => item.label.toLowerCase().indexOf(v.toLowerCase()) > -1
          );
        }
        this.loading = false;
      });
    },

    getModelById(id) {
      if (
        this.modelList &&
        this.modelList.length === 1 &&
        this.modelList[0].value == this.modelValue
      ) {
        return;
      }
      if (!id || id == null) {
        return;
      }
      this.loading = true;
      HomeModuleAPI.ModelById(id).then((res) => {
        this.modelList = [
          {
            value: res.Data.ID,
            label: res.Data.Name,
          },
        ];
        this.$refs["selection"].setQuery(res.Data["Name"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.$nextTick(() => {
          this.loading = false;
          this.$emit("on-change", { value: this.modelList[0] || {}, index: 0 }); // 首次change，index为了防止首次change被回调导致外部默认数据改变
        });
      });
    },

    valChange(v) {
      if (!v && this.modelList[0]) {
        this.$refs["selection"].setQuery(this.modelList[0]["label"]);
        this.$refs["selection"].toggleMenu(null, false);
        this.value = this.modelList[0]["value"];
      }
      this.$emit("modelChange", v);

      this.modelList.map((item) => {
        if (v == item.value) {
          this.$emit("on-change", { value: item, index: 1 });
        }
      });
    },

    valClear() {
      this.$emit("on-change", {});
    },
  },
};
</script>

<style scoped>
</style>
