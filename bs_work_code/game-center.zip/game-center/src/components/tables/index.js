import Tables from './tables.vue'
import RenderColumns from './render'
export default {
    Tables,
    RenderColumns,
}
