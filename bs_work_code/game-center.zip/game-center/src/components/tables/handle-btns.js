const btns = {
  edit: (h, param, vm) => {
    return h(
      "Button", {
        props: {
          type: "primary",
          size: "small"
        },
        style: {
          marginRight: "5px",
        },
        on: {
          click: () => {
            vm.$emit('on-edit',param)
          }
        }
      }, '编辑');
  },
  delete: (h, param, vm) => {
    return h('Poptip', {
      props: {
        confirm: true,
        title: '你确定要删除吗?',
      },
      on: {
        'on-ok': () => {
          vm.$emit('on-delete', param)
        }
      }
    }, [
      h('Button', {
        props: {
          type: 'error',
          size: 'small',
          // ghost: true
        },
        style: {
          marginRight: "5px"
        }
      }, '删除')
    ])
  }
}


export default btns;
