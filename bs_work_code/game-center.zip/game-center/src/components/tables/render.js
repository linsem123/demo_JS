import {
  formatTime
} from "@/libs/tools"
import handleBtns from './handle-btns'


const renders = {
  enable: (item, vm) => {
    item.render = (h, param) => {
      return h('Poptip', {
        props: {
          confirm: true,
          title: param.row[param.column.key] ? '你确定要禁用吗?' : '你确定要启用吗?',
        },
        on: {
          'on-ok': () => {
            vm.$emit('on-enable', param)
          }
        }
      }, [
        h('Button', {
          props: {
            type: param.row[param.column.key] ? 'success' : 'error',
            size: 'small',
            // ghost: true
          },
          style: {
            marginRight: "5px"
          }
        }, param.row[param.column.key] ? '已启用' : '已禁用')
      ])
    }
    return item
  },
  formatTime: (item, index) => {
    item.render = (h, params) => {
      return h(
        "p",
        formatTime(params.row[params.column.key])
      );
    };
    return item;
  },
  handleBtn: (item, vm) => {
    let options = item.options || [];
    let insideBtns = [];
    options.forEach(item => {
      if (handleBtns[item]) insideBtns.push(handleBtns[item]);
    });
    let btns = item.button ? [].concat(insideBtns, item.button) : insideBtns;
    item.render = (h, param) => {
      return h("div", btns.map(item => item(h, param, vm)));
    };
    return item;
  }
}
const renderColumns = (columns, vm) => {
  return columns.map((item, index) => {
    let res = item;
    if (res.timeformat) res = renders.formatTime(res, index);
    if (res.enable) res = renders.enable(res, vm);
    if (res.key === "handle") res = renders.handleBtn(res, vm);
    return res
  })
};

export default renderColumns;
