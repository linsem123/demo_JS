<template>
  <Form :label-width="100" :model="formData" ref="formData" :rules="rules">
    <FormItem label="事件ID：" prop="EventId">
      <InputNumber v-model="formData.EventId" style="width: 100px" />
    </FormItem>
    <FormItem label="关联游戏：" prop="AppId">
      <AppSelect
        v-model="formData.AppId"
        style="width: 200px"
        placeholder="请输入游戏名称"
        @on-change="changeApp"
      />
    </FormItem>

    <FormItem label="来源类型：" prop="ResourceType">
      <Selection
        v-model="formData.ResourceType"
        :dataList="list"
        :clearable="false"
      />
    </FormItem>
    <FormItem label="约束条件：" prop="Constraints">
      <Button @click="handleAdd()">添加</Button>
      <div v-show="formData.Constraints.length > 0">
        <span class="set_width">key</span>
        <span class="set_width">value</span>
      </div>
      <div
        v-for="(item, index) in formData.Constraints"
        :key="index"
        style="padding-bottom: 5px"
      >
        <span class="set_width">
          <Input v-model="item.key" />
        </span>
        <span class="set_width">
          <Input v-model="item.value" />
        </span>
        <Icon
          type="md-trash"
          color="rgb(56, 135, 240)"
          :size="24"
          @click="handleDel(index)"
        />
      </div>
    </FormItem>
    <!-- <FormItem label="绑定关系：" prop="Status">
      <InputNumber
        v-model="formData.Status"
        style="width: 100px"
        :disabled="true"
      />
    </FormItem> -->
  </Form>
</template>
<script>
import AppSelect from "_c/app-select";
import Selection from "_c/Selection.vue";
import ConfigApi from "@/api/gameIntegral/taskConfig";

export default {
  name: "FormPage",
  components: { Selection, AppSelect },
  props: ["editForm", "isAdd", "list"],
  data() {
    const EventIdValidate = (rule, value, callback) => {
      console.log(value);
      if (!value) {
        callback("请输入事件ID");
      }
      callback();
    };
    return {
      formData: {},
      rules: {
        EventId: [
          {
            required: true,
            type: "number",
            validator: EventIdValidate,
            trigger: "change",
          },
        ],
      },
    };
  },
  watch: {
    editForm: {
      immediate: true,
      handler: function () {
        this.formData = JSON.parse(JSON.stringify(this.editForm));
        if (this.formData.AppIds) {
          this.getAppById(this.formData.AppIds);
        }
      },
    },
  },
  methods: {
    changeApp({ value, index }) {
      if (value.PkgName) {
        this.formData.PkgName = value.PkgName;
        console.log(value.PkgName);
      }
    },
    handleDel(index) {
      this.formData.Constraints.splice(index, 1);
    },
    handleAdd() {
      let index = this.formData.Constraints.length;
      this.formData.Constraints.splice(index + 1, 0, {
        key: "",
        value: "",
      });
    },
    server() {
      this.$refs["formData"].validate((valid) => {
        if (valid) {
          let flag = this.formData.Constraints.some(
            (v) => v.key.trim() == "" || v.value.trim() == ""
          );
          if (flag) {
            this.$Message.error("约束条件有未填内容");
            return;
          }

          let params = JSON.parse(JSON.stringify(this.formData));
          //   let delArr = [
          //     "ActName",
          //     "DistributeName",
          //     "RateName",
          //     "ResultName",
          //     "ScopeName",
          //     "Time",
          //     "_index",
          //     "_rowKey",
          //   ];
          //   delArr.forEach((name) => {
          //     delete params[name];
          //   });
          let obj = {};
          params.Constraints.forEach((v) => {
            obj[v.key.trim()] = v.value.trim();
          });
          params.Constraints = JSON.stringify(obj);
          if (this.isAdd) {
            ConfigApi.AddConfig(params).then((res) => {
              if (res.Code == 0) {
                this.$emit("update-list");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            ConfigApi.EditConfig(params.ID, params).then((res) => {
              if (res.Code == 0) {
                this.$emit("update-list");
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
  },
};
</script>
<style lang="less" scoped>
.set_width {
  display: inline-block;
  width: 40%;
  padding-right: 10px;
}
</style>
