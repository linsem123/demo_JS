<template>
  <div>
    <Card>
      <Form
        ref="formValidate"
        :model="formData"
        :rules="ruleValidate"
        :inline="true"
        style="position: relative"
      >
        <FormItem prop="AppName">
          <Select
            v-model="formData.AppId"
            clearable
            filterable
            remote
            :remote-method="handleGameSearch"
            placeholder="请输入游戏名称"
            ref="AppName"
          >
            <Option v-for="item in gameList" :value="item.ID" :key="item.ID">{{
              item.AppName
            }}</Option>
          </Select>
        </FormItem>
        <FormItem label="事件ID" prop="EventId" :label-width="60">
          <Input type="number" v-model="formData.EventId" />
        </FormItem>

        <Button type="primary" @click="toSearch" style="margin-right: 15px"
          >查询</Button
        >
      </Form>
      <Table
        border
        highlight-row
        ref="currentRowTable"
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :max-height="600"
      >
        <template slot-scope="{ row }" slot="ResourceType">
          <span v-if="row.ResourceType == 1">下载</span>
          <span v-if="row.ResourceType == 2">评论</span>
          <span v-if="row.ResourceType == 3">预约</span>
          <span v-if="row.ResourceType == 4">帖子</span>
        </template>
        <template slot="Status" slot-scope="{ row }">
          <span v-if="row.Status == 1">绑定</span>
          <span v-else>解绑</span>
        </template>
        <template slot-scope="{ row }" slot="action">
          <Button
            @click="edit(row)"
            type="primary"
            size="small"
            style="margin-right: 10px"
            >编辑</Button
          >
          <Button
            @click="bind(row.ID, 1)"
            type="success"
            size="small"
            v-if="row.Status == 2"
            >绑定</Button
          >
          <Button
            @click="bind(row.ID, 2)"
            type="error"
            size="small"
            v-if="row.Status == 1"
            >解绑</Button
          >
        </template>
      </Table>
      <Row style="margin-top: 10px">
        <Col :span="6">
          <Button @click="edit()" type="info" shape="circle" icon="md-add"
            >新增</Button
          >
        </Col>
        <Col :span="18" align="right">
          <Page
            show-sizer
            :total="total"
            show-total
            :page-size="pageSize"
            :current="pageIndex"
            @on-change="changePage"
            @on-page-size-change="changePageSize"
          />
        </Col>
      </Row>
    </Card>
    <Modal v-model="showModal" :title="isAdd ? '新增' : '修改'" :width="600">
      <FormPage
        ref="formpage"
        :editForm="editForm"
        v-if="showModal"
        :isAdd="isAdd"
        :list="StatusList"
        @update-list="updateList"
      />
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button @click="handleCommit" type="primary">确认</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import GameAPI from "@/api/gamespace/game";
import ConfigApi from "@/api/gameIntegral/taskConfig";
import FormPage from "./form";
// import common from "@/view/gameCircle/pubFunc/common.js";
export default {
  components: { FormPage },
  data() {
    return {
      formData: {
        AppId: undefined,
        EventId: "",
      },
      ruleValidate: {},
      columns: [
        {
          title: "ID",
          key: "ID",
          align: "center",
          minWidth: 80,
        },
        {
          title: "游戏名称",
          key: "AppName",
          align: "center",
          minWidth: 200,
        },
        {
          title: "游戏包名",
          key: "PkgName",
          minWidth: 200,
          align: "center",
        },
        {
          title: "事件ID",
          key: "EventId",
          align: "center",
          minWidth: 80,
        },
        {
          title: "约束条件",
          key: "Constraints",
          align: "center",
          minWidth: 200,
        },
        {
          title: "来源",
          slot: "ResourceType",
          align: "center",
          minWidth: 80,
        },
        {
          title: "状态",
          slot: "Status",
          align: "center",
          minWidth: 80,
        },
        {
          title: "操作",
          slot: "action",
          align: "center",
          minWidth: 150,
        },
      ],
      tableData: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      loading: false,
      gameList: [],
      editForm: {},
      showModal: false,
      isAdd: true,
      StatusList: [
        { Id: 1, Name: "下载" },
        { Id: 2, Name: "评论" },
        { Id: 3, Name: "预约" },
        { Id: 4, Name: "帖子" },
      ],
    };
  },
  mounted() {
    this.searchServer();
  },
  methods: {
    bind(id, status) {
      console.log(id);
      ConfigApi.BindConfig(id, status).then((res) => {
        if (res.Code == 0) {
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    edit(val) {
      if (val) {
        this.isAdd = false;
        this.editForm = JSON.parse(JSON.stringify(val));
        let obj = JSON.parse(this.editForm.Constraints);
        let arr = [];
        for (let key in obj) {
          let item = {};
          item.key = key;
          item.value = obj[key];
          arr.push(item);
        }
        this.editForm.Constraints = arr;
      } else {
        this.isAdd = true;
        this.editForm = {
          AppId: undefined,
          EventId: 1,
          Constraints: [],
          PkgName: "",
          ResourceType: 1,
          Status: 1,
        };
      }
      this.showModal = true;
    },
    updateList() {
      this.showModal = false;
      this.searchServer();
    },
    handleCommit() {
      this.$refs["formpage"].server();
    },
    //查询游戏名称
    handleGameSearch(value) {
      GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },

    //查询
    toSearch() {
      this.pageIndex = 1;
      this.searchServer();
    },
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.searchServer();
    },
    searchServer() {
      this.formData.EventId = this.formData.EventId
        ? Number(this.formData.EventId)
        : undefined;
      ConfigApi.GetList({
        Limit: this.pageSize,
        Page: this.pageIndex,
        Params: this.formData,
      }).then((res) => {
        if (res.Code == 0) {
          this.total = res.Data.Count;
          this.tableData = res.Data.Data || [];
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>
