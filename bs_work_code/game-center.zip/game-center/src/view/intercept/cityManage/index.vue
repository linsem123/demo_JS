<template>
  <Card title="城市列表">
    <Collapse simple v-model="panelName">
      <Panel v-for="(item, key, index) in cityObj" :name="key" :key="index">
        {{ key }}
        <Row slot="content">
          <Col span="6" v-for="num of 4" :key="num">
            <Table
              :show-header="false"
              :columns="columns"
              :data="item[num - 1]"
              style="margin-right: 20px"
              v-show="item[num - 1]"
            ></Table>
          </Col>
        </Row>
      </Panel>
    </Collapse>
  </Card>
</template>
<script>
import CityApi from "@/api/intercept/cityManage";
export default {
  name: "CityManage",
  data() {
    return {
      cityObj: {},
      columns: [{ title: "省份", key: "Name", align: "center" }],
      panelName: [],
    };
  },
  mounted() {
    this.getList();
  },
  methods: {
    getList() {
      CityApi.cityList().then((res) => {
        if (res.Code == 0) {
          for (let key in res.Data) {
            this.cityObj[key] = this.getData(res.Data[key]);
            this.panelName.push(key);
          }
        }
      });
    },
    getData(item) {
      var arr = [];
      let step = Math.ceil(item.length / 4);
      for (var i = 0; i < item.length; i += step) {
        arr.push(item.slice(i, i + step));
      }
      return arr;
    },
  },
};
</script>