<template>
  <Form :label-width="100" :model="formData" :rules="rules" ref="formData">
    <FormItem label="平台名称：" prop="Name">
      <Input
        placeholder="请输入平台名称"
        style="width: 350px"
        v-model.trim="formData.Name"
      />
    </FormItem>
    <FormItem label="是否启用：" prop="IsEnable">
      <RadioGroup v-model="formData.IsEnable">
        <Radio :label="1" :disabled="!!platformID">启用</Radio>
        <Radio :label="2" :disabled="!!platformID">禁用</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="是否白名单：" prop="IsWhite">
      <RadioGroup v-model="formData.IsWhite">
        <Radio :label="1" :disabled="!!platformID">是</Radio>
        <Radio :label="2" :disabled="!!platformID">否</Radio>
      </RadioGroup>
    </FormItem>
  </Form>
</template>
<script>
import platformAPI from "@/api/intercept/platformList";
export default {
  name: "FormPage",
  props: {
    platformID: Number,
    checkData: Object,
  },
  data() {
    return {
      formData: {
        Name: "",
        IsEnable: 1,
        IsWhite: 1,
      },
      rules: {
        Name: [{ required: true, message: "请输入分组名", trigger: "blur" }],
        IsEnable: [
          {
            required: true,
            message: "请选择是否启用",
            trigger: "blur",
            type: "number",
          },
        ],
        IsWhite: [
          {
            required: true,
            message: "请选择是否白名单",
            trigger: "blur",
            type: "number",
          },
        ],
      },
    };
  },
  watch: {
    platformID(val) {
      if (val) {
        this.formData = JSON.parse(JSON.stringify(this.checkData));
      } else {
        this.formData = {
          Name: "",
          IsEnable: 1,
          IsWhite: 1,
        };
      }
    },
  },
  methods: {
    submit() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          this.$emit("hadleSuccess");
          if (this.platformID) {
            //编辑
            platformAPI.Edit(this.formData, this.platformID).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            //新增
            platformAPI.Add(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    clear() {
      this.$refs.formData.resetFields();
    },
  },
};
</script>
<style lang="less" scoped>
</style>