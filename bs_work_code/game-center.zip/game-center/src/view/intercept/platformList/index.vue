<template>
  <Card>
    <Form :model="searchData" :inline="true" style="position: relative">
      <FormItem prop="Id">
        <LikeSearch
          v-model="searchData.Id"
          placeholder="请输入平台名"
          :serverData="postServerData"
          style="width: 200px"
          clearable
        />
      </FormItem>
      <FormItem label="是否白名单" prop="IsWhite" :label-width="90">
        <!-- <Checkbox v-model="searchData.IsWhite" /> -->
        <Selection
          v-model="searchData.IsWhite"
          :dataList="dataList"
          :clearable="true"
        />
      </FormItem>
      <Button type="primary" @click="search" style="margin-right: 50px"
        >查询</Button
      >
    </Form>
    <Table :columns="columns" :data="tableData" border>
      <template slot="Status" slot-scope="{ row, index }">
        <i-switch
          v-model="tableData[index].IsEnable"
          size="large"
          :true-value="1"
          :false-value="2"
          @on-change="(val) => updateIsEnable(val, row.Id)"
        >
          <span slot="open">启用</span>
          <span slot="close">禁用</span>
        </i-switch>
      </template>
      <template slot="IsWhite" slot-scope="{ row, index }">
        <i-switch
          v-model="tableData[index].IsWhite"
          size="large"
          :true-value="1"
          :false-value="2"
          @on-change="(val) => updateIsWhite(val, row.Id)"
        >
          <span slot="open">是</span>
          <span slot="close">否</span>
        </i-switch>
      </template>
      <template slot="action" slot-scope="{ row }">
        <Button
          style="margin-right: 10px"
          type="primary"
          @click="handleEdit(row)"
          size="small"
          >编辑</Button
        >
      </template>
    </Table>
    <div style="margin: 10px 0; overflow: hidden">
      <div style="float: left">
        <Button type="info" shape="circle" icon="md-add" @click="createGroup"
          >新增平台</Button
        >
      </div>
      <div style="float: right">
        <Page
          :total="total"
          :current="page.Page"
          :page-size="page.Limit"
          :page-size-opts="[10, 20, 40, 80, 100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>
    </div>
    <Modal
      v-model="showForm"
      :title="platformID ? '编辑城市分组' : '新增城市分组'"
    >
      <FormPage
        :checkData="checkData"
        :platformID="platformID"
        ref="FormPage"
        @hadleSuccess="hadleSuccess"
      />
      <template slot="footer">
        <Button @click="showForm = false">取消</Button>
        <Button @click="handleSubmit" type="primary">确定</Button>
      </template>
    </Modal>
  </Card>
</template>
<script>
import platformAPI from "@/api/intercept/platformList";
import LikeSearch from "_c/like-search";
import FormPage from "./Form.vue";
import Selection from "_c/Selection";
export default {
  name: "PlatformList",
  components: { FormPage, LikeSearch, Selection },
  data() {
    return {
      columns: [
        {
          title: "平台名称",
          key: "Name",
        },
        { title: "当前状态", slot: "Status" },
        { title: "是否白名单", slot: "IsWhite" },
        { title: "操作", slot: "action" },
      ],
      tableData: [],
      page: {
        Page: 1,
        Limit: 10,
      },
      searchData: {
        Id: undefined,
        IsWhite: undefined,
      },
      total: 0,
      showForm: false,
      platformID: 0,
      checkData: {},
      postServerData: {
        likeUrl: "platformLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "Name",
      },
      dataList: [
        { Id: 1, Name: "是" },
        { Id: 2, Name: "否" },
      ],
    };
  },
  mounted() {
    this.server();
  },
  methods: {
    //新增/编辑成功
    hadleSuccess() {
      this.showForm = false;
      this.server();
    },
    createGroup() {
      //新增
      this.$refs.FormPage.clear();
      this.showForm = true;
      this.platformID = 0;
    },
    handleEdit(row) {
      // 编辑
      this.showForm = true;
      this.platformID = row.Id;
      this.checkData = row;
    },
    //更新状态
    updateIsEnable(val, Id) {
      platformAPI
        .Update({ IsEnable: val }, Id)
        .then((res) => {
          if (res.Code != 0) {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.server();
        });
    },
    updateIsWhite(val, Id) {
      platformAPI
        .Update({ IsWhite: val }, Id)
        .then((res) => {
          if (res.Code != 0) {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.server();
        });
    },
    handleSubmit() {
      this.$refs.FormPage.submit();
    },
    onPageChange(page) {
      this.page.Page = page;
      this.server();
    },
    onPageSizechange(size) {
      this.page.Page = 1;
      this.page.Limit = size;
      this.server();
    },
    search() {
      this.page.Page = 1;
      this.server();
    },
    server() {
      platformAPI
        .getList({ ...this.page, Params: this.searchData })
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.Data || [];
            this.total = res.Data.Count;
          }
        });
    },
  },
};
</script>