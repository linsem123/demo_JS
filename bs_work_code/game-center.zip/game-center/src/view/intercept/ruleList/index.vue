<template>
  <Card>
    <Table :columns="columns" :data="tableData" border>
      <template slot="Status" slot-scope="{ row, index }">
        <i-switch
          v-model="tableData[index].IsEnable"
          size="large"
          :true-value="1"
          :false-value="2"
          @on-change="(val) => updateIsEnable(val, row.Id)"
        >
          <span slot="open">启用</span>
          <span slot="close">禁用</span>
        </i-switch>
      </template>

      <template slot="action" slot-scope="{ row }">
        <Button
          style="margin-right: 10px"
          type="primary"
          @click="handleEdit(row)"
          size="small"
          >编辑</Button
        >
      </template>
    </Table>
    <div style="margin: 10px 0; overflow: hidden">
      <div style="float: left">
        <Button type="info" shape="circle" icon="md-add" @click="createGroup"
          >新增规则</Button
        >
      </div>
      <div style="float: right">
        <Page
          :total="total"
          :current="page.Page"
          :page-size="page.Limit"
          :page-size-opts="[10, 20, 40, 80, 100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>
    </div>
    <Modal v-model="showForm" :title="ruleID ? '编辑规则' : '新增规则'">
      <FormPage
        :checkData="checkData"
        :ruleID="ruleID"
        ref="FormPage"
        @hadleSuccess="hadleSuccess"
      />
      <template slot="footer">
        <Button @click="showForm = false">取消</Button>
        <Button @click="handleSubmit" type="primary">确定</Button>
      </template>
    </Modal>
  </Card>
</template>
<script>
import ruleAPI from "@/api/intercept/ruleList";
// import LikeSearch from "_c/like-search";
import FormPage from "./Form.vue";
export default {
  name: "RuleList",
  components: { FormPage },
  data() {
    return {
      columns: [
        {
          title: "规则名称",
          key: "RuleName",
        },
        {
          title: "规则等级",
          key: "RuleLevel",
        },
        {
          title: "规则描述",
          key: "Description",
        },
        { title: "当前状态", slot: "Status" },
        { title: "操作", slot: "action" },
      ],
      tableData: [{ RuleName: "11", Id: 1, IsEnable: 1, RuleLevel: 3 }],
      page: {
        Page: 1,
        Limit: 10,
        Params: {},
      },
      total: 0,
      showForm: false,
      ruleID: 0,
      checkData: {},
    };
  },
  mounted() {
    this.server();
  },
  methods: {
    //新增/编辑成功
    hadleSuccess() {
      this.showForm = false;
      this.server();
    },
    createGroup() {
      //新增
      this.$refs.FormPage.clear();
      this.showForm = true;
      this.ruleID = 0;
    },
    handleEdit(row) {
      // 编辑
      this.showForm = true;
      this.ruleID = row.Id;
      this.checkData = row;
    },
    updateIsEnable(val, Id) {
      ruleAPI
        .Update({ IsEnable: val }, Id)
        .then((res) => {
          if (res.Code != 0) {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.server();
        });
    },
    handleSubmit() {
      this.$refs.FormPage.submit();
    },
    onPageChange(page) {
      this.page.Page = page;
      this.server();
    },
    onPageSizechange(size) {
      this.page.Page = 1;
      this.page.Limit = size;
      this.server();
    },
    server() {
      ruleAPI.getList({ ...this.page }).then((res) => {
        if (res.Code == 0) {
          this.tableData = res.Data.Data || [];
          this.total = res.Data.Count;
        }
      });
    },
  },
};
</script>