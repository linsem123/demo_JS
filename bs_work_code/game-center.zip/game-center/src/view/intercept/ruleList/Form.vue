<template>
  <Form :label-width="100" :model="formData" :rules="rules" ref="formData">
    <FormItem label="规则名称：" prop="RuleName">
      <Input
        placeholder="请输入规则名称"
        style="width: 350px"
        v-model.trim="formData.RuleName"
      />
    </FormItem>
    <FormItem label="规则等级：" prop="RuleLevel">
      <InputNumber
        placeholder="请输入规则等级"
        style="width: 350px"
        v-model="formData.RuleLevel"
        :precision="0"
      />
    </FormItem>
    <FormItem label="规则描述：" prop="Description">
      <Input
        placeholder="请输入规则描述"
        style="width: 350px"
        v-model.trim="formData.Description"
      />
    </FormItem>
    <FormItem label="是否启用：" prop="IsEnable">
      <RadioGroup v-model="formData.IsEnable">
        <Radio :label="1">启用</Radio>
        <Radio :label="2">禁用</Radio>
      </RadioGroup>
    </FormItem>
  </Form>
</template>
<script>
import ruleAPI from "@/api/intercept/ruleList";
export default {
  name: "FormPage",
  props: {
    ruleID: Number,
    checkData: Object,
  },
  data() {
    const checkZero = (rule, value, callback) => {
      if (Number(value) <= 0) {
        callback("请填写0以上的整数");
      }
      callback();
    };
    return {
      formData: {
        RuleName: "",
        Description: "",
        RuleLevel: "",
        IsEnable: 1,
      },
      rules: {
        RuleName: [
          { required: true, message: "请输入规则名称", trigger: "blur" },
        ],
        RuleLevel: [
          {
            required: true,
            message: "请输入规则等级",
            trigger: "blur",
            type: "number",
          },
          {
            validator: checkZero,
            trigger: "blur",
          },
        ],
        IsEnable: [
          {
            required: true,
            message: "请选择是否启用",
            trigger: "blur",
            type: "number",
          },
        ],
      },
    };
  },
  watch: {
    ruleID(val) {
      if (val) {
        this.formData = JSON.parse(JSON.stringify(this.checkData));
      } else {
        this.formData = {
          RuleName: "",
          Description: "",
          RuleLevel: "",
          IsEnable: 1,
        };
      }
    },
  },
  methods: {
    submit() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          this.$emit("hadleSuccess");
          if (this.ruleID) {
            //编辑
            ruleAPI.Edit(this.formData, this.ruleID).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            //新增
            ruleAPI.Add(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    clear() {
      this.$refs.formData.resetFields();
    },
  },
};
</script>
<style lang="less" scoped>
</style>