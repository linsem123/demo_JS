<template>
  <Card>
    <Row style="margin: 10px 0">
      <LikeSearch
        v-model="page.Params.Id"
        placeholder="请输入城市名"
        :serverData="postServerData"
        style="width: 200px"
        clearable
      />
      <Button style="margin-left: 10px" type="primary" @click="search"
        >查询</Button
      >
    </Row>
    <Table :columns="columns" :data="tableData" border>
      <template slot="Status" slot-scope="{ row, index }">
        <i-switch
          v-model="tableData[index].IsEnable"
          size="large"
          :true-value="1"
          :false-value="2"
          @on-change="(val) => updateIsEnable(val, row.Id)"
        >
          <span slot="open">启用</span>
          <span slot="close">禁用</span>
        </i-switch>
      </template>
      <template slot="action" slot-scope="{ row }">
        <Button
          style="margin-right: 10px"
          type="info"
          @click="handleCheck(row)"
          size="small"
          >查看</Button
        >
        <Button
          style="margin-right: 10px"
          type="primary"
          @click="handleEdit(row)"
          size="small"
          >编辑</Button
        >
      </template>
    </Table>
    <div style="margin: 10px 0; overflow: hidden">
      <div style="float: left">
        <Button type="info" shape="circle" icon="md-add" @click="createGroup"
          >新增分组</Button
        >
      </div>
      <div style="float: right">
        <Page
          :total="total"
          :current="page.Page"
          :page-size="page.Limit"
          :page-size-opts="[10, 20, 40, 80, 100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>
    </div>
    <Modal
      v-model="showForm"
      :title="groupID ? '编辑城市分组' : '新增城市分组'"
      :width="700"
    >
      <FormPage
        :allCity="allCity"
        :groupID="groupID"
        :cityData="cityData"
        ref="FormPage"
        @hadleSuccess="hadleSuccess"
      />
      <template slot="footer">
        <Button @click="showForm = false">取消</Button>
        <Button @click="handleSubmit" type="primary">确定</Button>
      </template>
    </Modal>
    <Modal v-model="showCheck" title="查看城市分组" :hide-fotter="true">
      <CheckPage :groupID="groupID" :cityData="cityData" />
    </Modal>
  </Card>
</template>
<script>
import groupAPI from "@/api/intercept/cityGroup";
import FormPage from "./Form.vue";
import CheckPage from "./Check.vue";
import LikeSearch from "_c/like-search";
export default {
  name: "CityGroup",
  components: { FormPage, CheckPage, LikeSearch },
  data() {
    return {
      columns: [
        {
          title: "城市分组名",
          key: "Name",
        },
        { title: "当前状态", slot: "Status" },
        { title: "操作", slot: "action" },
      ],
      tableData: [],
      page: {
        Page: 1,
        Limit: 10,
        Params: {
          Id: undefined,
        },
      },
      total: 0,
      showForm: false,
      showCheck: false,
      groupID: 0,
      allCity: [],
      cityData: {},
      postServerData: {
        likeUrl: "cityLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "Name",
      },
    };
  },
  mounted() {
    this.getCitylist();
    this.server();
  },
  methods: {
    //新增/编辑成功
    hadleSuccess() {
      this.showForm = false;
      this.server();
    },
    createGroup() {
      //新增
      this.showForm = true;
      this.groupID = 0;
      this.$refs.FormPage.clear();
    },
    handleEdit(row) {
      // 编辑
      this.showForm = true;
      this.groupID = row.Id;
      this.getCityListServer();
    },
    handleCheck(row) {
      //查看
      this.showCheck = true;
      this.groupID = row.Id;
      this.getCityListServer();
    },
    getCityListServer() {
      groupAPI
        .groupCityList({
          Page: 0,
          Limit: 0,
          Params: { Id: this.groupID },
        })
        .then((res) => {
          if (res.Code == 0) {
            this.cityData = res.Data.Data;
          }
        });
    },
    handleSubmit() {
      this.$refs.FormPage.submit();
    },
    //更改状态
    updateIsEnable(val, Id) {
      groupAPI
        .Update({ IsEnable: val }, Id)
        .then((res) => {
          if (res.Code != 0) {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.server();
        });
    },
    onPageChange(page) {
      this.page.Page = page;
      this.server();
    },
    onPageSizechange(size) {
      this.page.Page = 1;
      this.page.Limit = size;
      this.server();
    },
    search() {
      this.page.Page = 1;
      this.server();
    },
    server() {
      groupAPI.getList({ ...this.page }).then((res) => {
        if (res.Code == 0) {
          this.tableData = res.Data.Data || [];
          this.total = res.Data.Count;
        }
      });
    },
    getCitylist() {
      groupAPI.cityList().then((res) => {
        if (res.Code == 0) {
          let list = res.Data || [];
          this.allCity = list.map((v) => {
            v.key = v.Id;
            return v;
          });
        }
      });
    },
  },
};
</script>