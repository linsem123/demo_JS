<template>
  <Form :label-width="90" :model="formData" :rules="rules" ref="formData">
    <FormItem label="城市分组：" prop="Name">
      <Input
        placeholder="请输入分组名"
        style="width: 400px"
        v-model.trim="formData.Name"
      />
    </FormItem>
    <FormItem label="是否启用：" prop="IsEnable">
      <RadioGroup v-model="formData.IsEnable">
        <Radio :label="1" :disabled="!!groupID">启用</Radio>
        <Radio :label="2" :disabled="!!groupID">禁用</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="">
      <Transfer
        :data="allCity"
        :target-keys="targetKeys"
        :render-format="render"
        filterable
        :filter-method="filterMethod"
        :titles="['城市列表', '已选城市']"
        @on-change="handleChange"
      ></Transfer>
    </FormItem>
  </Form>
</template>
<script>
import groupAPI from "@/api/intercept/cityGroup";
export default {
  name: "FormPage",
  props: {
    allCity: Array,
    groupID: Number,
    cityData: Object,
  },
  data() {
    return {
      formData: {
        Name: "",
        Cities: [],
        IsEnable: 1,
      },
      rules: {
        Name: [{ required: true, message: "请输入分组名", trigger: "blur" }],
      },
      targetKeys: [],
    };
  },
  watch: {
    cityData(val) {
      if (val) {
        this.formData = JSON.parse(JSON.stringify(this.cityData));
        this.targetKeys = this.formData.Cities.map((v) => v.Id);
      } else {
        this.formData.IsEnable = 1;
        this.targetKeys = [];
      }
    },
    groupID(val) {
      if (!val) {
        this.formData.IsEnable = 1;
        this.targetKeys = [];
      }
    },
  },
  methods: {
    render(item) {
      return item.Name;
    },
    handleChange(newTargetKeys) {
      this.targetKeys = newTargetKeys;
    },
    filterMethod(data, query) {
      return data.Name.indexOf(query) > -1;
    },
    submit() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          let Params = JSON.parse(JSON.stringify(this.formData));
          Params.Cities = this.allCity.filter((v) => {
            return this.targetKeys.includes(v.Id);
          });
          if (this.groupID) {
            //编辑
            groupAPI.Edit(Params, this.groupID).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            //新增
            groupAPI.Add(Params).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    clear() {
      this.$refs.formData.resetFields();
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-form-item-content .ivu-transfer .ivu-transfer-list {
  width: 220px;
  height: 300px;
}
</style>