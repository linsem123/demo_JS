<template>
  <Form :label-width="90" :model="formData">
    <FormItem label="城市分组：">
      {{ formData.Name }}
    </FormItem>
    <FormItem label="是否启用：" prop="IsEnable">
      <RadioGroup v-model="formData.IsEnable">
        <Radio :label="1" disabled>启用</Radio>
        <Radio :label="2" disabled>禁用</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="">
      <Table
        boder
        :columns="columns"
        :data="formData.Cities"
        :max-height="400"
        :width="300"
        :loading="loading"
      ></Table>
    </FormItem>
  </Form>
</template>
<script>
import groupAPI from "@/api/intercept/cityGroup";
export default {
  name: "FormPage",
  props: {
    groupID: Number,
    cityData: Object,
  },
  data() {
    return {
      formData: {
        Name: "",
        Cities: [],
        IsEnable: 0,
      },
      Count: 0,
      Page: 0,
      Limit: 0,
      loading: false,
      isEnd: false,
      columns: [{ title: "城市名称", key: "Name", align: "center" }],
    };
  },
  watch: {
    cityData(val) {
      if (val) {
        this.formData = JSON.parse(JSON.stringify(this.cityData));
      } else {
        this.formData.IsEnable = 1;
      }
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-form-item-content .ivu-transfer .ivu-transfer-list {
  width: 220px;
  height: 300px;
}

/deep/ .ivu-scroll-container {
  width: 300px;
}
.scroll_box {
  overflow: auto;
  max-height: 300px;
}
li {
  list-style: none;
  margin: 10px;
  line-height: 25px;
}
ul {
  width: 250px;
}
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>