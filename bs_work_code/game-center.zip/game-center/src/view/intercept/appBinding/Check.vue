<template>
  <div>
    <Table :columns="columns" :data="tableData" border></Table>
    <Page
      :total="Count"
      :current="Page"
      :page-size="10"
      @on-change="onPageChange"
      show-total
      style="margin-top: 10px; display: flex; justify-content: center"
    ></Page>
  </div>
</template>
<script>
import bindAPI from "@/api/intercept/appBinding";
export default {
  name: "FormPage",
  props: {
    bindID: Number,
  },
  data() {
    return {
      formData: {
        Name: "",
        Cities: [],
        IsEnable: 0,
      },
      Count: 0,
      Page: 1,
      columns: [
        { title: "绑定包名", key: "BindPkgName" },
        { title: "绑定平台", key: "PlatformName" },
      ],
      tableData: [],
    };
  },
  watch: {
    bindID(val) {
      if (val) {
        this.getList();
      }
    },
  },

  methods: {
    onPageChange(page) {
      this.Page = page;
      this.getList();
    },
    getList() {
      bindAPI
        .getBindList({
          Page: this.Page,
          Limit: 10,
          Params: { Id: this.bindID },
        })
        .then((res) => {
          if (res.Code == 0) {
            this.Count = res.Data.Counr;
            this.tableData = res.Data.Data || [];
          }
        });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-form-item-content .ivu-transfer .ivu-transfer-list {
  width: 220px;
  height: 300px;
}

/deep/ .ivu-scroll-container {
  width: 300px;
}
</style>