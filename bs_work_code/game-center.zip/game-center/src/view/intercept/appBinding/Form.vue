<template>
  <Form :label-width="120" :model="formData" :rules="rules" ref="formData">
    <FormItem label="应用名：" prop="StandardAppName">
      <Input
        placeholder="请输入应用名"
        style="width: 350px"
        v-model.trim="formData.StandardAppName"
      />
    </FormItem>
    <FormItem label="标准包名：" prop="StandardPkgName">
      <Input
        placeholder="请输入标准包名"
        style="width: 350px"
        v-model.trim="formData.StandardPkgName"
      />
    </FormItem>
    <FormItem label="应用类型：" prop="StandardAppType">
      <RadioGroup v-model="formData.StandardAppType">
        <Radio :label="1">游戏</Radio>
        <Radio :label="2">应用</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="平台名：" prop="Description">
      <LikeSearch
        v-model="formData.PlatformId"
        placeholder="请输入平台名"
        :serverData="postServerData"
        style="width: 200px"
        clearable
        @on-change="changeApp"
      />
    </FormItem>
    <FormItem label="是否启用：" prop="IsEnable">
      <RadioGroup v-model="formData.IsEnable">
        <Radio :label="1">启用</Radio>
        <Radio :label="2">禁用</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="绑定包名和平台：" prop="BindApp">
      <Button type="info" shape="circle" icon="md-add" @click="addBindMessage"
        >添加</Button
      >
    </FormItem>
    <ul>
      <li v-for="(item, index) of formData.BindApp" :key="index">
        <Input
          placeholder="请输入绑定包名"
          style="width: 200px"
          v-model.trim="formData.BindApp[index].bind_pkg_name"
        />
        <LikeSearch
          v-model="formData.BindApp[index].PlatformId"
          placeholder="请输入平台名"
          :serverData="postServerData"
          style="width: 200px; margin-left: 10px"
          clearable
        />

        <Icon
          type="md-trash"
          color="rgb(56, 135, 240)"
          :size="24"
          @click="handleDel(index)"
        />
      </li>
    </ul>
  </Form>
</template>
<script>
import bindAPI from "@/api/intercept/appBinding";
import LikeSearch from "_c/like-search";
export default {
  name: "FormPage",
  props: {
    bindID: Number,
    checkData: Object,
  },
  components: { LikeSearch },
  data() {
    return {
      formData: {
        StandardPkgName: "",
        StandardAppName: "",
        StandardAppType: 1,
        PlatformName: "",
        PlatformId: undefined,
        IsEnable: 1,
        BindApp: [],
      },
      rules: {
        StandardAppName: [
          { required: true, message: "请输入应用名", trigger: "blur" },
        ],
        StandardPkgName: [
          {
            required: true,
            message: "请输入标准包名",
            trigger: "blur",
          },
        ],
        IsEnable: [
          {
            required: true,
            message: "请选择是否启用",
            trigger: "blur",
            type: "number",
          },
        ],
      },
      postServerData: {
        likeUrl: "platformLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "PlatformName",
      },
    };
  },
  watch: {
    bindID(val) {
      if (val) {
        this.formData = JSON.parse(JSON.stringify(this.checkData));
      } else {
        this.formData = {
          StandardPkgName: "",
          StandardAppName: "",
          StandardAppType: 1,
          PlatformName: "",
          PlatformId: undefined,
          IsEnable: 1,
          BindApp: [],
        };
      }
    },
  },
  methods: {
    //新增
    addBindMessage() {
      this.formData.BindApp.push({
        bind_pkg_name: "",
        PlatformId: "",
      });
    },
    // 删除
    handleDel(index) {
      this.formData.BindApp.splice(index, 1);
    },
    changeApp(val) {
      if (val) {
        this.formData.PlatformName = val.PlatformName;
      } else {
        this.formData.PlatformName = "";
        this.formData.PlatformId = undefined;
      }
    },
    submit() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          this.$emit("hadleSuccess");
          if (this.bindID) {
            //编辑
            bindAPI.Edit(this.formData, this.bindID).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            //新增
            bindAPI.Add(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    clear() {
      this.$refs.formData.resetFields();
    },
  },
};
</script>
<style lang="less" scoped>
li {
  list-style: none;
  margin: 10px;
}
</style>