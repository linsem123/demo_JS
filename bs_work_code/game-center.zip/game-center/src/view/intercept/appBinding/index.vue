<template>
  <Card>
    <Row style="margin: 10px 0">
      <Select
        v-model="page.Params.Id"
        placeholder="请输入应用名"
        filterable
        remote
        :remote-method="handleAppLike"
        clearable
        @on-change="changeApp"
        style="width: 200px"
        label-in-value
      >
        <Option v-for="item in applist" :value="item.Id" :key="item.Id">{{
          item.StandardAppName
        }}</Option>
      </Select>
      <Select
        v-model="page.Params.Id"
        placeholder="请输入标准包名"
        filterable
        remote
        :remote-method="handlePkgNameLike"
        clearable
        @on-change="changeApp"
        style="width: 200px; margin-left: 10px"
        label-in-value
      >
        <Option v-for="item in applist" :value="item.Id" :key="item.Id">{{
          item.StandardPkgName
        }}</Option>
      </Select>

      <Button style="margin-left: 10px" type="primary" @click="search"
        >查询</Button
      >
    </Row>
    <Table :columns="columns" :data="tableData" border>
      <template slot="StandardAppType" slot-scope="{ row }">
        {{ row.StandardAppType == 1 ? "游戏" : "应用" }}
      </template>
      <template slot="Status" slot-scope="{ row, index }">
        <i-switch
          v-model="tableData[index].IsEnable"
          size="large"
          :true-value="1"
          :false-value="2"
          @on-change="(val) => updateIsEnable(val, row.Id)"
        >
          <span slot="open">启用</span>
          <span slot="close">禁用</span>
        </i-switch>
      </template>

      <template slot="action" slot-scope="{ row }">
        <Button
          style="margin-right: 10px"
          type="info"
          @click="handleCheck(row)"
          size="small"
          >查看</Button
        >
        <Button type="primary" @click="handleEdit(row)" size="small"
          >编辑</Button
        >
      </template>
    </Table>
    <div style="margin: 10px 0; overflow: hidden">
      <div style="float: left">
        <Button type="info" shape="circle" icon="md-add" @click="createGroup"
          >新增应用绑定</Button
        >
      </div>
      <div style="float: right">
        <Page
          :total="total"
          :current="page.Page"
          :page-size="page.Limit"
          :page-size-opts="[10, 20, 40, 80, 100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>
    </div>
    <Modal v-model="showForm" :title="bindID ? '编辑应用绑定' : '新增应用绑定'">
      <FormPage
        :checkData="checkData"
        :bindID="bindID"
        ref="FormPage"
        @hadleSuccess="hadleSuccess"
      />
      <template slot="footer">
        <Button @click="showForm = false">取消</Button>
        <Button @click="handleSubmit" type="primary">确定</Button>
      </template>
    </Modal>
    <Modal v-model="showCheck" title="查看" hide-footer>
      <CheckPage :bindID="bindID" />
    </Modal>
  </Card>
</template>
<script>
import bindAPI from "@/api/intercept/appBinding";
import LikeSearch from "_c/like-search";
import FormPage from "./Form.vue";
import CheckPage from "./Check.vue";
export default {
  name: "AppBinding",
  components: { FormPage, CheckPage, LikeSearch },
  data() {
    return {
      columns: [
        {
          title: "应用名",
          key: "StandardAppName",
        },
        {
          title: "标准包名",
          key: "StandardPkgName",
        },
        {
          title: "应用类型",
          key: "StandardAppType",
        },
        {
          title: "平台名",
          key: "PlatformName",
        },
        { title: "当前状态", slot: "Status" },
        { title: "操作", slot: "action" },
      ],
      tableData: [{ StandardPkgName: "11", Id: 1, IsEnable: 1 }],
      page: {
        Page: 1,
        Limit: 10,
        Params: {
          StandardPkgName: "",
          Id: undefined,
        },
      },
      total: 0,
      showForm: false,
      showCheck: false,
      bindID: 0,
      checkData: {},
      applist: [],
    };
  },
  mounted() {
    this.server();
  },
  methods: {
    //模糊查询
    handleAppLike(val) {
      this.doLikeSearch(val, "appBindingLike");
    },
    handlePkgNameLike(val) {
      this.doLikeSearch(val, "pkgNameLike");
    },
    doLikeSearch(val, serveName) {
      bindAPI[serveName](val).then((res) => {
        if (res.Code === 0) {
          let list = res.Data || [];
          this.appList = list.filter(
            (item) => item.Title.toLowerCase().indexOf(v.toLowerCase()) > -1
          );
        }
      });
    },
    changeApp(val) {
      if (val) {
        this.page.Params.StandardPkgName = val.StandardPkgName;
      } else {
        this.page.Params.StandardPkgName = "";
        this.page.Params.Id = undefined;
      }
    },
    //新增/编辑成功
    hadleSuccess() {
      this.showForm = false;
      this.server();
    },
    createGroup() {
      //新增
      this.$refs.FormPage.clear();
      this.showForm = true;
      this.bindID = 0;
    },
    handleEdit(row) {
      // 编辑
      this.showForm = true;
      this.bindID = row.Id;
      this.checkData = row;
    },
    //查看
    handleCheck(row) {
      this.showCheck = true;
      this.bindID = row.Id;
    },
    updateIsEnable(val, Id) {
      bindAPI
        .Update({ IsEnable: val }, Id)
        .then((res) => {
          if (res.Code != 0) {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.server();
        });
    },
    handleSubmit() {
      this.$refs.FormPage.submit();
    },
    onPageChange(page) {
      this.page.Page = page;
      this.server();
    },
    onPageSizechange(size) {
      this.page.Page = 1;
      this.page.Limit = size;
      this.server();
    },
    search() {
      this.page.Page = 1;
      this.server();
    },
    server() {
      bindAPI.getList({ ...this.page }).then((res) => {
        if (res.Code == 0) {
          this.tableData = res.Data.Data || [];
          this.total = res.Data.Count;
        }
      });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-modal-body {
  max-height: 450px;
  overflow: auto;
}
</style>