<template>
  <div style="display: flex; justify-content: center">
    <div class="left_box">
      <div class="title">标准包列表</div>

      <div style="padding: 6px 10px">
        <!-- <Checkbox
          :indeterminate="indeterminate"
          :value="checkAll"
          @click.prevent.native="handleCheckAll"
          >全选</Checkbox
        > -->
        <Input
          icon="ios-search"
          placeholder="Enter text"
          style="width: auto"
          v-model.trim="query"
          type="text"
          @on-click="handleSearch"
          @on-enter="handleSearch"
        />
      </div>
      <div class="scroll_box" @scroll.stop="listenScroll">
        <CheckboxGroup v-model="checkAllGroup">
          <!-- @on-change="checkAllGroupChange" -->
          <Checkbox
            v-for="(item, index) of pkgNameList"
            :label="item"
            :key="index"
            style="display: block"
            ><span
              style="
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: inline-block;
                width: 180px;
                vertical-align: middle;
              "
              :title="item"
              >{{ item }}</span
            ></Checkbox
          >
        </CheckboxGroup>
      </div>
    </div>
    <div class="right_box">
      <div class="title">
        已选包名
        <Icon
          type="ios-close"
          size="24"
          title="全部取消选择"
          style="float: right; line-height: 40px; cursor: pointer"
          @click="handelCancel"
        />
      </div>

      <div style="padding: 6px 10px">
        <Input
          icon="ios-search"
          placeholder="Enter text"
          style="width: auto"
          v-model.trim="checkQuery"
          type="text"
        />
        <!-- @on-click="handleCheckSearch"
          @on-enter="handleCheckSearch" -->
      </div>
      <ul class="scroll_box">
        <li v-for="(item, index) of allCheckList" :key="index">
          <span
            style="
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
              display: inline-block;
              width: 180px;
              vertical-align: middle;
            "
            :title="item"
            >{{ item }}</span
          >
          <Icon
            type="ios-close"
            size="24"
            title="取消选择"
            style="float: right; cursor: pointer"
            @click="handelSingleCancel(index)"
          />
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import RuleAPI from "@/api/intercept/ruleBinding";
import appBindAPI from "@/api/intercept/appBinding";
import LikeSearch from "_c/like-search";
export default {
  name: "FormPage",
  props: {
    bindID: Number,
    checkData: Object,
  },
  components: { LikeSearch },
  data() {
    return {
      indeterminate: true,
      checkAll: false,
      checkAllGroup: [],
      pkgNameList: [
        "香蕉",
        "西瓜",
        "苹果",
        "11",
        "22s",
        "33",
        "44",
        "55",
        "66",
        "ss",
        "ee",
        "tt",
        "rr",
      ],
      allPkgNameList: [],
      Page: 1,
      Count: 0,
      pageSize: 10,
      query: "",
      checkQuery: "",
      loading: false,
    };
  },
  watch: {
    bindID(val) {
      if (val) {
        this.getListServer();
      }
    },
  },
  computed: {
    allCheckList() {
      if (this.checkQuery) {
        return this.checkAllGroup.filter(
          (data) => data.indexOf(this.checkQuery) > -1
        );
      }
      return this.checkAllGroup;
    },
  },
  methods: {
    //全部取消选择
    handelCancel() {
      this.checkAllGroup = [];
    },
    handelSingleCancel(index) {
      this.checkAllGroup.splice(index, 1);
    },

    //监听滚动
    listenScroll(e) {
      let ele = e.srcElement ? e.srcElement : e.target;
      if (
        ele.scrollTop + ele.offsetHeight >= ele.scrollHeight &&
        !this.loading
      ) {
        console.log(this.Page);
        if (this.Page < this.Count / this.Limit) {
          this.Page++;
          this.loading = true;
          this.getListServer();
          // if (this.checkAll) {
          //   //全选
          //   this.checkAllGroup = this.pkgNameList;
          // }
        }
      }
    },
    //搜索
    handleSearch() {
      console.log(this.query);
      if (this.query) {
        appBindAPI.pkgNameLike(this.query);
      } else {
        this.pkgNameList = JSON.parse(JSON.stringify(this.allPkgNameList));
      }
    },
    // handleCheckSearch() {},
    getListServer() {
      RuleAPI.getBindList({
        Page: this.Page,
        Limit: this.pageSize,
        Params: { Id: this.bindID },
      }).then((res) => {
        if (res.Code == 0) {
          this.Count = res.Data.Count;
          let list = res.Data.Data || [];
          this.pkgNameList = this.pkgNameList.concat(list);
          this.allPkgNameList = JSON.parse(JSON.stringify(this.pkgNameList));
        }
      });
    },
    //全选
    // handleCheckAll() {
    //   if (this.indeterminate) {
    //     this.checkAll = false;
    //   } else {
    //     this.checkAll = !this.checkAll;
    //   }
    //   this.indeterminate = false;

    //   if (this.checkAll) {
    //     this.checkAllGroup = this.pkgNameList;
    //   } else {
    //     this.checkAllGroup = [];
    //   }
    // },
    // checkAllGroupChange(data) {
    //   if (data.length === this.pkgNameList.length) {
    //     this.indeterminate = false;
    //     this.checkAll = true;
    //   } else if (data.length > 0) {
    //     this.indeterminate = true;
    //     this.checkAll = false;
    //   } else {
    //     this.indeterminate = false;
    //     this.checkAll = false;
    //   }
    // },
  },
};
</script>
<style lang="less" scoped>
li {
  list-style: none;
  height: 24px;
}
.left_box,
.right_box {
  width: 250px;
  margin: 10px;
  border: 1px solid #eee;
  .scroll_box {
    overflow: auto;
    min-height: 200px;
    max-height: 250px;
    padding: 0 10px;
  }
}
/deep/ .ivu-checkbox-group .ivu-checkbox-group-item {
  height: 25px;
}
.title {
  background-color: #f5f7fa;
  line-height: 40px;
  padding: 0 10px;
}
</style>