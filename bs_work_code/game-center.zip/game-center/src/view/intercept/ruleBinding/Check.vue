<template>
  <div>
    <ul class="scroll_box" @scroll.stop="listenScroll">
      <li
        v-for="(item, index) of tableData"
        :key="index"
        style="
          padding: 5px 0;
          margin: 5px 0;
          border: 1px solid #eee;
          text-align: center;
        "
      >
        {{ item }}
      </li>
    </ul>
    <!-- <Page
      :total="Count"
      :current="Page"
      :page-size="10"
      @on-change="onPageChange"
      show-total
      style="margin-top: 10px; display: flex; justify-content: center"
    ></Page> -->
  </div>
</template>
<script>
import bindAPI from "@/api/intercept/ruleBinding";
export default {
  name: "FormPage",
  props: {
    bindID: Number,
  },
  data() {
    return {
      Count: 30,
      Page: 1,
      Limit: 20,
      // columns: [{ title: "绑定包名", key: "BindPkgName" }],
      tableData: [
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
        "com.www.wwww",
      ],
      isEnd: false,
    };
  },
  watch: {
    bindID(val) {
      if (val) {
        this.getList();
      }
    },
  },

  methods: {
    listenScroll(e) {
      let ele = e.srcElement ? e.srcElement : e.target;
      if (
        ele.scrollTop + ele.offsetHeight >= ele.scrollHeight &&
        !this.loading &&
        !this.isEnd
      ) {
        this.Page++;
        console.log(this.Page);
        if (this.Page <= Math.ceil(this.Count / this.Limit)) {
          this.loading = true;
          this.getList();
        } else {
          this.isEnd = true;
        }
      }
    },

    getList() {
      bindAPI
        .getBindList({
          Page: this.Page,
          Limit: this.Limit,
          Params: { Id: this.bindID },
        })
        .then((res) => {
          if (res.Code == 0) {
            this.Count = res.Data.Counr;
            let list = res.Data.Data || [];
            this.tableData = this.tableData.concat(list);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    // onPageChange(page) {
    //   this.Page = page;
    //   this.getList();
    // },
  },
};
</script>
<style lang="less" scoped>
// /deep/ .ivu-form-item-content .ivu-transfer .ivu-transfer-list {
//   width: 220px;
//   height: 300px;
// }

// /deep/ .ivu-scroll-container {
//   width: 300px;
// }
.scroll_box {
  overflow: auto;
  max-height: 380px;
}
li {
  list-style: none;
  margin: 10px;
  line-height: 25px;
}
ul {
  width: 300px;
  margin: auto;
}
.demo-spin-icon-load {
  animation: ani-demo-spin 1s linear infinite;
}
@keyframes ani-demo-spin {
  from {
    transform: rotate(0deg);
  }
  50% {
    transform: rotate(180deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>