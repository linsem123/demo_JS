<template>
  <Form :label-width="120" :model="formData" :rules="rules" ref="formData">
    <FormItem label="规则名称：" prop="RuleId">
      <LikeSearch
        v-model="formData.RuleId"
        placeholder="请输入规则名称"
        :serverData="ruleLikeData"
        style="width: 200px"
        clearable
      />
    </FormItem>
    <FormItem label="城市分组：" prop="GroupCityId">
      <LikeSearch
        v-model="formData.GroupCityId"
        placeholder="请输入城市分组名"
        :serverData="cityGropData"
        style="width: 200px; margin: 5px"
        clearable
      />
    </FormItem>
    <FormItem label="选择标准包名：" prop="IsAll">
      <RadioGroup v-model="formData.IsAll">
        <Radio :label="1">全选</Radio>
        <Radio :label="2">部分</Radio>
      </RadioGroup>
    </FormItem>
    <List :bindID="bindID" v-show="formData.IsAll == 2" />
  </Form>
</template>
<script>
// import RuleAPI from "@/api/intercept/ruleBinding";
import LikeSearch from "_c/like-search";
import List from "./list.vue";
export default {
  name: "FormPage",
  props: {
    bindID: Number,
    checkData: Object,
  },
  components: { LikeSearch, List },
  data() {
    return {
      formData: {
        RuleId: undefined,
        GroupCityId: undefined,
        IsAll: 2,
      },
      rules: {
        RuleId: [
          { required: true, message: "请输入规则名称", trigger: "change" },
        ],
        GroupCityId: [
          {
            required: true,
            message: "请输入城市分组名",
            trigger: "blur",
          },
        ],
      },
      cityGropData: {
        likeUrl: "cityGropLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "GroupCityName",
      },
      ruleLikeData: {
        likeUrl: "ruleLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "RuleName",
      },
    };
  },
  watch: {
    bindID(val) {
      if (val) {
        this.formData = JSON.parse(JSON.stringify(this.checkData));
      } else {
        this.formData = {
          RuleId: undefined,
          GroupCityId: undefined,
          IsAll: 2,
        };
      }
    },
  },
  methods: {
    submit() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          this.$emit("hadleSuccess");
          if (this.bindID) {
            //编辑
            bindAPI.Edit(this.formData, this.bindID).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            //新增
            bindAPI.Add(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("成功");
                this.$emit("hadleSuccess");
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    clear() {
      this.$refs.formData.resetFields();
    },
  },
};
</script>
<style lang="less" scoped>
li {
  list-style: none;
  margin: 10px;
}
</style>