<template>
  <Card>
    <Form :model="searchData" :inline="true" style="position: relative">
      <FormItem>
        <Input
          placeholder="请输入IMEI"
          style="width: 200px"
          v-model.trim="searchData.IMEI"
          clearable
        />
      </FormItem>
      <FormItem>
        <Input
          placeholder="请输入版本号"
          style="width: 200px"
          v-model.trim="searchData.VersionName"
          clearable
        />
      </FormItem>
      <FormItem>
        <Input
          placeholder="请输入手机型号"
          style="width: 200px"
          v-model.trim="searchData.Model"
          clearable
        />
      </FormItem>
      <FormItem>
        <Input
          placeholder="请输入应用包名"
          style="width: 200px"
          v-model.trim="searchData.PkgName"
          clearable
        />
      </FormItem>
      <FormItem>
        <LikeSearch
          v-model="searchData.PlatformId"
          placeholder="请输入平台名"
          :serverData="postServerData"
          style="width: 200px"
          clearable
        />
      </FormItem>
      <FormItem>
        <LikeSearch
          v-model="searchData.CityId"
          placeholder="请输入城市名"
          :serverData="cityLikeData"
          style="width: 200px"
          clearable
        />
      </FormItem>
      <Button type="primary" @click="search" style="margin-right: 50px"
        >查询</Button
      >
    </Form>
    <Table :columns="columns" :data="tableData" border> </Table>
  </Card>
</template>
<script>
import ruleAPI from "@/api/intercept/ruleList";
import LikeSearch from "_c/like-search";
export default {
  name: "RuleList",
  components: { LikeSearch },
  data() {
    return {
      columns: [
        {
          title: "规则等级",
          key: "RuleLevel",
        },
      ],
      tableData: [{ RuleName: "11", Id: 1, IsEnable: 1, RuleLevel: 3 }],
      searchData: {
        IMEI: "",
        VersionName: "",
        Model: "",
        PkgName: "",
        PlatformId: undefined,
        CityId: "",
      },
      showForm: false,
      ruleID: 0,
      postServerData: {
        likeUrl: "platformLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "PlatformName",
      },
      cityLikeData: {
        likeUrl: "CityLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "Name",
      },
    };
  },
  methods: {
    search() {
      let Params = JSON.parse(JSON.stringify(this.searchData));
      for (let key in Params) {
        if (Params[key] == "") {
          Params[key] = undefined;
        }
      }
      ruleAPI.getList(Params).then((res) => {
        if (res.Code == 0) {
          this.tableData = [res.Data.Data] || [];
        }
      });
    },
  },
};
</script>