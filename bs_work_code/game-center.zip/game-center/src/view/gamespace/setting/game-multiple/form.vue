<template>
  <Form
    ref="settingData"
    :model="settingData"
    :rules="rules"
    :label-width="100"
  >
    <FormItem label="图片上传：" prop="ImgURLs">
      <UploadImg v-model="settingData.ImgURLs" :max="2"></UploadImg>
    </FormItem>
    <FormItem label="标题：" prop="Title">
      <Input
        type="text"
        v-model="settingData.Title"
        placeholder="请填写标题"
      ></Input>
    </FormItem>
    <FormItem label="信息类型：" prop="FeedType">
      <Select
        v-model="settingData.FeedType"
        @on-change="typeChange"
        placeholder="请选择信息类型"
      >
        <Option v-for="type in typeList" :value="type.id" :key="type.id">{{
          type.value
        }}</Option>
      </Select>
    </FormItem>
    <FormItem v-if="showFeedId" label="目标信息：" prop="FeedId">
      <AppSelect
        v-model="settingData.FeedId"
        placeholder="搜索游戏名称"
        v-if="showPkgName"
        @on-change="APPchange"
      />
      <Select
        v-else
        v-model="settingData.FeedId"
        filterable
        remote
        label-in-value
        ref="FeedIdSelect"
        :remote-method="remoteMethod"
        :loading="selecting"
        placeholder="请设置目标信息"
        @on-change="FeedIdChange"
      >
        <Option
          v-for="(item, index) in idsList"
          :key="index"
          :value="item.id"
          >{{ item.value }}</Option
        >
      </Select>
    </FormItem>

    <FormItem label="生效周期：" prop="Expired">
      <DateRange
        v-model="settingData.Expired"
        @on-change="
          (value) => {
            settingData.StartTime = value.start;
            settingData.EndTime = value.end;
          }
        "
      />
    </FormItem>
  </Form>
</template>
<script>
import SettingApi from "@/api/gamespace/setting";
import UploadImg from "_c/gamespace/upload-img";
import AppSelect from "_c/app-select";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";
export default {
  name: "FormPage",
  components: { UploadImg, AppSelect, DateRange },
  props: ["editForm", "isAdd"],
  data() {
    return {
      selecting: false,
      settingData: {
        // 表单
        ImgURLs: [],
        FeedType: 1,
        Title: "",
        FeedId: undefined,
        PkgName: "",
        Expired: [],
      },
      typeList: [
        { id: 1, value: "公告活动" },
        { id: 2, value: "抽奖活动" },
        { id: 3, value: "APP详情" },
        { id: 4, value: "游戏专题" },
        { id: 5, value: "福利社主页" },
        { id: 6, value: "礼包详情" },
      ],
      idsList: [],
      rules: {
        ImgURLs: [
          {
            required: true,
            type: "array",
            message: "请上传图片",
            trigger: "blur",
          },
        ],
        Title: [{ required: true, message: "请填写标题", trigger: "blur" }],
        FeedType: [
          {
            required: true,
            type: "number",
            message: "请选择信息类型",
            trigger: "blur",
          },
        ],
        FeedId: [
          {
            required: true,
            type: "number",
            message: "请设置目标信息",
            trigger: "blur",
          },
        ],
        Expired: [
          {
            validator: checkDateRange,
            trigger: "change",
            type: "array",
          },
        ],
      },
    };
  },
  mounted() {
    if (this.settingData.FeedId && this.$refs["FeedIdSelect"]) {
      this.$refs["FeedIdSelect"].setQuery(this.editForm.FeedTitle);
      this.$refs["FeedIdSelect"].toggleMenu(null, false);
    }
  },
  watch: {
    editForm: {
      immediate: true,
      handler: function () {
        this.settingData = JSON.parse(JSON.stringify(this.editForm));
      },
    },
  },
  computed: {
    showFeedId() {
      return this.settingData.FeedType != 5 ? true : false;
    },
    showPkgName() {
      return this.settingData.FeedType == 3 || this.settingData.FeedType == 6;
    },
    nowTime() {
      return formatTimes(new Date());
    },
  },
  methods: {
    remoteMethod(value) {
      this.selecting = true;
      let type = this.settingData.FeedType;
      SettingApi.GetFeedIds(type, value).then((res) => {
        if (res.Code === 0) {
          let list = res.Data || [];
          this.idsList = list.map((l) => {
            return { id: l.ID, value: l.Title || l.AppName || "" };
          });
          this.selecting = false;
        }
      });
    },
    // 手动设置
    FeedIdChange(val) {
      if (val && val.label) {
        this.settingData.FeedTitle = val.label;
      }
    },
    typeChange(val) {
      if (val === 5) {
        this.settingData.FeedId = 0;
        this.settingData.FeedTitle = "";
      }
    },
    handleCommit() {
      this.$refs["settingData"].validate((valid) => {
        if (valid) {
          if (this.settingData.ImgURLs.length < 2) {
            this.$Message.error("请上传两张图片");
            return;
          }
          if (!this.settingData.StartTime || !this.settingData.EndTime) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitcheck();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitcheck();
          }
        }
      });
    },
    submitcheck() {
      let params = JSON.parse(JSON.stringify(this.settingData));
      params.KaiserImgUrl = params.ImgURLs[1].url;
      params.ImgURL = params.ImgURLs[0].url;
      params.StartTime = params.StartTime || this.nowTime;
      params.EndTime = params.EndTime || "2099-01-01 00:00:00";
      if (this.isAdd) {
        SettingApi.addMulGame(params).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("success!");
            this.$emit("getServe");
          }
        });
      } else {
        SettingApi.editMulGame(params.Id, params).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("success!");
            this.$emit("getServe");
          }
        });
      }
    },
    APPchange(val) {
      console.log(val);
      if (val && val.value && val.value.PkgName) {
        this.settingData.PkgName = val.value.PkgName;
      }
    },
  },
};
</script>