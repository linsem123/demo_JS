<template>
  <Card>
    <Row style="margin-bottom: 10px">
      <Col :span="6">
        <Button @click="handleModal()" type="info" shape="circle" icon="md-add"
          >新增</Button
        >
      </Col>
    </Row>
    <Table :data="tableData" :columns="columns" :loading="loading" border>
      <template slot-scope="{ row }" slot="Status">
        {{ row.Status | filterStatus }}
      </template>
      <template slot-scope="{ row }" slot="FeedType">
        {{ filterFeedType(row.FeedType) }}
      </template>
      <template slot-scope="{ row }" slot="ImgURL">
        <img :src="row.ImgURL" style="width: 50px; height: 50px" />
      </template>
      <template slot-scope="{ row }" slot="KaiserImgUrl">
        <img :src="row.KaiserImgUrl" style="width: 50px; height: 50px" />
      </template>
      <template slot-scope="{ row }" slot="Expired">
        <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">
          {{ row.StartTime }}~{{ row.EndTime }}
        </span>
      </template>
      <template slot-scope="{ row }" slot="action">
        <Button
          type="success"
          @click="changeStatus(row.Id, 1)"
          size="small"
          style="margin-right: 5px"
          v-show="row.Status != 1"
          >上架</Button
        >
        <Button
          type="error"
          @click="changeStatus(row.Id, 2)"
          size="small"
          style="margin-right: 5px"
          v-show="row.Status == 1"
          >下架</Button
        >
        <Button
          type="primary"
          @click="handleEdit(row)"
          size="small"
          style="margin-right: 5px"
          >编辑</Button
        >
        <Button type="success" @click="handleTop(row.Id)" size="small"
          >置顶</Button
        >
      </template>
    </Table>

    <Modal v-model="showModal" :title="isAdd ? '新增' : '修改'" :width="530">
      <FormPage
        :editForm="editForm"
        :isAdd="isAdd"
        ref="formPage"
        @getServe="getServe"
        v-if="showModal"
      />
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button @click="handleCommit" type="primary">确认</Button>
      </template></Modal
    ></Card
  >
</template>
<script>
import SettingApi from "@/api/gamespace/setting";
import FormPage from "./form";
export default {
  name: "GameMultiple",
  components: { FormPage },
  data() {
    return {
      tableData: [],
      columns: [
        { key: "Id", title: "ID", width: 60 },
        { key: "Title", title: "标题", minWidth: 150 },
        { slot: "ImgURL", title: "图片1", width: 100 },
        { slot: "KaiserImgUrl", title: "图片2", width: 100 },
        { slot: "FeedType", title: "跳转类型", width: 150 },
        { slot: "Status", title: "状态", width: 80 },
        { title: "生效周期", slot: "Expired", minWidth: 270 },
        { slot: "action", title: "操作", width: 170, fixed: "right" },
      ],
      loading: false,
      showModal: false,
      isAdd: true,

      typeList: [
        { id: 1, value: "公告活动" },
        { id: 2, value: "抽奖活动" },
        { id: 3, value: "APP详情" },
        { id: 4, value: "游戏专题" },
        { id: 5, value: "福利社主页" },
        { id: 6, value: "礼包详情" },
      ],
      editForm: {
        // 表单
        ImgURLs: [],
        FeedType: 1,
        Title: "",
        FeedID: undefined,
        PkgName: "",
        // FeedURL: "",
      },
    };
  },
  mounted() {
    this.searchServer();
  },
  filters: {
    filterStatus(value) {
      let arr = ["初始化", "上线", "下线", "待上线"];
      return arr[value];
    },
  },
  methods: {
    filterFeedType(id) {
      return this.typeList.filter((v) => v.id == id)[0].value;
    },
    handleModal() {
      this.showModal = true;
      this.isAdd = true;
      this.editForm = {
        ImgURLs: [],
        Title: "",
        FeedType: 1,
        FeedId: undefined,
        // FeedURL: "",
        PkgName: "",
        FeedTitle: "",
        Expired: [],
      };
    },

    handleTop(id) {
      SettingApi.topMulGame(id).then((res) => {
        if (res.Code == 0) {
          this.searchServer();
          this.$Message.success("success!");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    handleEdit(row) {
      this.showModal = true;
      this.isAdd = false;
      this.editForm = {
        ...row,
      };
      this.editForm.Expired = [this.editForm.StartTime, this.editForm.EndTime]; //4.7迭代增加生效周期
    },
    changeStatus(id, status) {
      SettingApi.updateMulGame(id, status).then((res) => {
        if (res.Code == 0) {
          this.searchServer();
          this.$Message.success("success!");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    searchServer() {
      this.loading = true;
      SettingApi.getMulGame()
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data || [];
            this.tableData = this.tableData.map((val) => {
              val.ImgURLs = [{ url: val.ImgURL }, { url: val.KaiserImgUrl }];
              return val;
            });
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    handleCommit() {
      this.$refs["formPage"].handleCommit();
    },
    getServe() {
      this.showModal = false;
      this.searchServer();
    },
    //校验生效周期状态
    getStatus(row) {
      const now = new Date().getTime();
      const start = new Date(row.StartTime).getTime();
      const end = new Date(row.EndTime).getTime();
      return row.Status == 1 && now > start && now < end;
    },
  },
};
</script>