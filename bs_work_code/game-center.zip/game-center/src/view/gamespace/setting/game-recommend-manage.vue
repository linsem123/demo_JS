<template>
  <div>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">下载页面游戏推荐列表设置</p>
          <Form ref="formData" :model="form" :label-width="150">
            <FormItem label="榜单类型：">
              <Select v-model="rankParams.type" clearable style="width: 200px">
                <Option
                  v-for="item in rankTypeList"
                  :value="item.id"
                  :key="item.id"
                  >{{ item.name }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="绑定榜单：">
              <RankSelect
                :rankType="rankParams.type"
                v-model="form.rankID"
                placeholder="请输入榜单名称"
                style="width: 200px"
              ></RankSelect>
            </FormItem>
            <FormItem>
              <Button type="primary" @click="handleCommonSubmit">提交</Button>
            </FormItem>
          </Form>
        </Card>
      </Col>
    </Row>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">游戏详情页推荐模块设置</p>
          <Form ref="formData" :model="gameForm" :label-width="150">
            <FormItem label="绑定模块合辑：">
              <Select
                v-model="gameForm.ResourceID"
                ref="selection"
                clearable
                filterable
                remote
                :remote-method="getModulesList"
                placeholder="请输入合辑名称"
                style="width: 200px"
              >
                <Option v-for="m in modulesList" :value="m.ID" :key="m.ID">{{
                  m.Name
                }}</Option>
              </Select>
            </FormItem>
            <FormItem>
              <Button type="primary" @click="GameDetailSubmit">提交</Button>
            </FormItem>
          </Form>
        </Card>
      </Col>
    </Row>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">游戏空间推荐游戏列表设置</p>
          <Form ref="formData" :model="gamespaceGameForm" :label-width="150">
            <FormItem label="榜单类型：">
              <Select
                v-model="gamespaceRankParams.type"
                clearable
                style="width: 200px"
              >
                <Option
                  v-for="item in rankTypeList"
                  :value="item.id"
                  :key="item.id"
                  >{{ item.name }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="绑定榜单：">
              <RankSelect
                :rankType="gamespaceRankParams.type"
                v-model="gamespaceGameForm.rankID"
                @on-change="getrank"
                placeholder="请输入榜单名称"
                style="width: 200px"
              ></RankSelect>
            </FormItem>
            <FormItem>
              <Button type="primary" @click="gamespaceSubmit">提交</Button>
            </FormItem>
          </Form>
        </Card>
      </Col>
    </Row>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">更新页面游戏推荐列表设置</p>
          <Form ref="formData" :model="updateForm" :label-width="150">
            <FormItem label="榜单类型：">
              <Select v-model="updateForm.type" clearable style="width: 200px">
                <Option
                  v-for="item in rankTypeList"
                  :value="item.id"
                  :key="item.id"
                  >{{ item.name }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="绑定榜单：">
              <RankSelect
                :rankType="updateForm.type"
                v-model="updateForm.rankID"
                placeholder="请输入榜单名称"
                style="width: 200px"
              ></RankSelect>
            </FormItem>
            <FormItem>
              <Button
                type="primary"
                @click="commitSubmit(updateForm.rankID, 4, updateForm.type)"
                >提交</Button
              >
            </FormItem>
          </Form>
        </Card>
      </Col>
    </Row>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">搜索页面游戏推荐列表设置</p>
          <Form ref="formData" :model="searchForm" :label-width="150">
            <FormItem label="榜单类型：">
              <Select v-model="searchForm.type" clearable style="width: 200px">
                <Option
                  v-for="item in rankTypeList"
                  :value="item.id"
                  :key="item.id"
                  >{{ item.name }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="绑定榜单：">
              <RankSelect
                :rankType="searchForm.type"
                v-model="searchForm.rankID"
                placeholder="请输入榜单名称"
                style="width: 200px"
              ></RankSelect>
            </FormItem>
            <FormItem>
              <Button
                type="primary"
                @click="commitSubmit(searchForm.rankID, 5, searchForm.type)"
                >提交</Button
              >
            </FormItem>
          </Form>
        </Card>
      </Col>
    </Row>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">搜索无结果/少结果游戏推荐列表设置</p>
          <Form ref="formData" :model="supplySearchForm" :label-width="150">
            <FormItem label="榜单类型：">
              <Select
                v-model="supplySearchForm.type"
                clearable
                style="width: 200px"
              >
                <Option
                  v-for="item in rankTypeList"
                  :value="item.id"
                  :key="item.id"
                  >{{ item.name }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="绑定榜单：">
              <RankSelect
                :rankType="supplySearchForm.type"
                v-model="supplySearchForm.rankID"
                placeholder="请输入榜单名称"
                style="width: 200px"
              ></RankSelect>
            </FormItem>
            <FormItem>
              <Button
                type="primary"
                @click="
                  commitSubmit(
                    supplySearchForm.rankID,
                    6,
                    supplySearchForm.type
                  )
                "
                >提交</Button
              >
            </FormItem>
          </Form>
        </Card>
      </Col>
    </Row>
  </div>
</template>

<script>
import RankSelect from "_c/rank-select";
import SettingApi from "@/api/gamespace/setting";
import HomeModuleAPI from "@/api/gamespace/homemodule";
export default {
  name: "game-recommend-manager",
  components: { RankSelect },
  data() {
    return {
      rankParams: {
        type: undefined,
      },
      gamespaceRankParams: {
        type: undefined,
      },
      rankTypeList: [
        { id: 1, name: "普通榜单" },
        { id: 2, name: "排行榜单" },
        { id: 3, name: "预约榜单" },
        { id: 4, name: "分类榜单" },
        { id: 5, name: "标签榜单" },
        { id: 6, name: "飙升榜单" },
      ],
      modulesList: [],
      form: {
        rankID: undefined,
      },
      gameForm: {
        ResourceID: undefined,
      },
      gamespaceGameForm: {
        rankID: undefined,
      },
      searchForm: {
        rankID: undefined,
        type: undefined,
      },
      updateForm: {
        rankID: undefined,
        type: undefined,
      },
      supplySearchForm: {
        rankID: undefined,
        type: undefined,
      },
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    getrank({ value, index }) {
      if (index == 0) this.gamespaceRankParams.type = value.RankType;
    },
    init() {
      SettingApi.GetGameRecommendData().then((res) => {
        let len = Object.keys(res.Data).length;
        this.form.rankID = res.Data[1].RankID;
        this.rankParams.type = res.Data[1].RankType;
        this.gameForm.ResourceID = res.Data[2].RankID;
        this.gamespaceGameForm.rankID = res.Data[3].RankID;
        this.gamespaceRankParams.type = res.Data[3].RankType;
        this.searchForm.rankID = res.Data[5].RankID;
        this.searchForm.type = res.Data[5].RankType;
        this.updateForm.rankID = res.Data[4].RankID;
        this.updateForm.type = res.Data[4].RankType;
        this.supplySearchForm.rankID = len > 5 ? res.Data[6].RankID : null;
        this.supplySearchForm.type = len > 5 ? res.Data[6].RankType : null;
        HomeModuleAPI.collectionInfo(this.gameForm.ResourceID).then((res) => {
          this.modulesList = [res.Data || {}];
          this.$refs["selection"].setQuery(res.Data["Name"]);
          this.$refs["selection"].toggleMenu(null, false);
        });
      });
    },
    handleCommonSubmit() {
      SettingApi.ChangeRank(this.form.rankID, 1, this.rankParams.type).then(
        (res) => {
          if (res.error > 0) {
            this.$Message.warning(res.Message);
            return;
          }
          this.$Message.success("修改成功!");
        }
      );
    },
    commitSubmit(ID, number, type) {
      //搜索页面猜你喜欢配置提交-number:1;
      //更新页面猜你喜欢配置提交-number:1;
      SettingApi.ChangeRank(ID, number, type).then((res) => {
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Message.success("修改成功!");
      });
    },
    gamespaceSubmit() {
      SettingApi.ChangeRank(
        this.gamespaceGameForm.rankID,
        3,
        this.gamespaceRankParams.type
      ).then((res) => {
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Message.success("修改成功!");
      });
    },

    GameDetailSubmit() {
      SettingApi.ChangeRank(this.gameForm.ResourceID, 2, 0).then((res) => {
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Message.success("修改成功!");
      });
    },
    getModulesList(name) {
      if (!name || this.gameForm.ResourceID) return;
      HomeModuleAPI.moduleTypes(name, 1).then((res) => {
        if (res.Code === 0) {
          this.modulesList = res.Data || [];
        }
      });
    },
  },
};
</script>

<style scoped>
</style>
