<!--游戏精选设置-->
<template>
  <div>
    <Row :gutter="20">
      <Col :span="12">
        <Card>
          <div v-if="!hasData" class="no-data-box">
            <p>暂无精选配置</p>
            <Button @click="hasData = true" type="info" size="small"
              >立即配置<Icon type="ios-arrow-forward"
            /></Button>
          </div>
          <div v-else>
            <!---->
            <h4 class="block-title">
              游戏精选设置
              <Button
                v-if="!isEditSet"
                @click="editSet(1)"
                size="small"
                type="success"
                class="full-right"
                icon="md-create"
                >编辑</Button
              >
              <Button
                v-else
                @click="editSet(0)"
                size="small"
                type="default"
                class="full-right"
                icon="md-return-left"
                >取消</Button
              >
            </h4>
            <!---->
            <Row>
              <Col :span="21">
                <!--编辑表单-->
                <div v-show="isEditSet">
                  <Form
                    ref="settingData"
                    :model="settingData"
                    :rules="rules"
                    :label-width="150"
                  >
                    <FormItem label="图片上传：" prop="ImgURL">
                      <UploadImg
                        v-model="settingData.ImgURL"
                        :max="2"
                      ></UploadImg>
                    </FormItem>
                    <FormItem label="标题：" prop="Title">
                      <Input
                        type="text"
                        v-model="settingData.Title"
                        placeholder="请填写标题"
                      ></Input>
                    </FormItem>
                    <FormItem label="信息类型：" prop="FeedType">
                      <Select
                        v-model="settingData.FeedType"
                        @on-change="typeChange"
                        placeholder="请选择信息类型"
                      >
                        <Option
                          v-for="type in typeList"
                          :value="type.id"
                          :key="type.id"
                          >{{ type.value }}</Option
                        >
                      </Select>
                    </FormItem>
                    <FormItem
                      v-if="showFeedId"
                      label="目标信息："
                      prop="FeedID"
                    >
                      <AppSelect
                        v-model="settingData.FeedID"
                        placeholder="搜索游戏名称"
                        v-if="settingData.FeedType == 3"
                      />
                      <Select
                        v-else
                        v-model="settingData.FeedID"
                        filterable
                        remote
                        label-in-value
                        ref="feedIdSelect"
                        @on-change="feedIdChange"
                        :remote-method="remoteMethod"
                        :loading="loading"
                        placeholder="请设置目标信息"
                      >
                        <Option
                          v-for="(item, index) in idsList"
                          :key="index"
                          :value="item.id"
                          >{{ item.value }}</Option
                        >
                      </Select>
                    </FormItem>
                    <FormItem align="center">
                      <Button type="primary" @click="submitsettingData()"
                        >提 交</Button
                      >
                    </FormItem>
                  </Form>
                </div>

                <!--数据详情查看-->
                <div v-show="!isEditSet" class="detail-box">
                  <Form :label-width="150">
                    <FormItem label="图片：">
                      <img :src="detailData.ImgURL" alt="" />
                      <img
                        :src="detailData.KaiserImgUrl"
                        alt=""
                        style="margin-top: 10px"
                      />
                    </FormItem>
                    <FormItem label="标题：">
                      {{ detailData.Title }}
                    </FormItem>
                    <FormItem label="信息类型：">
                      {{ feedTypeFilter(detailData.FeedType) }}
                    </FormItem>
                    <FormItem v-if="showFeedId" label="目标信息：">
                      {{ detailData.FeedTitle }}（{{ detailData.FeedID }}）
                    </FormItem>
                  </Form>
                </div>
              </Col>
            </Row>
          </div>
        </Card>
      </Col>

      <!---------------启动设置---------------->
      <Col :span="12">
        <Card>
          <h4 class="block-title">
            启动设置
            <Button
              v-if="!isEditStart"
              @click="editStart(1)"
              size="small"
              type="success"
              class="full-right"
              icon="md-create"
              >编辑</Button
            >
            <Button
              v-else
              @click="editStart(0)"
              size="small"
              type="default"
              class="full-right"
              icon="md-return-left"
              >取消</Button
            >
          </h4>
          <Row>
            <Col :span="21">
              <!--编辑表单-->
              <div v-show="isEditStart">
                <Form
                  ref="startData"
                  :model="startData"
                  :rules="startRules"
                  :label-width="150"
                >
                  <FormItem label="按钮文字：" prop="ButtonTxt">
                    <Input
                      type="text"
                      v-model="startData.ButtonTxt"
                      placeholder="请输入按钮文字"
                    ></Input>
                  </FormItem>
                  <FormItem label="链接地址：" prop="ButtonURL">
                    <Input
                      type="text"
                      v-model="startData.ButtonURL"
                      placeholder="请输入链接地址"
                    ></Input>
                  </FormItem>
                  <FormItem align="center">
                    <Button @click="submitStartData()" type="primary"
                      >提 交</Button
                    >
                  </FormItem>
                </Form>
              </div>

              <!--数据详情查看-->
              <div v-show="!isEditStart" class="detail-box">
                <Form :label-width="150">
                  <FormItem label="按钮文字：">
                    {{ startDataDetail.ButtonTxt }}
                  </FormItem>
                  <FormItem label="链接地址：">
                    <p class="link-address">{{ startDataDetail.ButtonURL }}</p>
                  </FormItem>
                </Form>
              </div>
            </Col>
          </Row>
        </Card>
      </Col>
    </Row>
  </div>
</template>

<script>
import SettingApi from "@/api/gamespace/setting";
import UploadImg from "_c/gamespace/upload-img";
import AppSelect from "_c/app-select";

export default {
  name: "",
  components: { UploadImg, AppSelect },
  data() {
    return {
      hasData: false,
      isEditSet: false,
      // 类型列表
      typeList: [
        { id: 1, value: "公告活动" },
        { id: 2, value: "抽奖活动" },
        { id: 3, value: "APP详情" },
        { id: 4, value: "游戏专题" },
        { id: 5, value: "福利社主页" },
        { id: 6, value: "礼包详情" },
      ],

      detailData: {}, // 详情
      settingData: {
        // 表单
        ImgURL: [],
      },
      settingData_copy: {},
      showFeedId: true,
      rules: {
        ImgURL: [
          {
            required: true,
            type: "array",
            message: "请上传图片",
            trigger: "blur",
          },
        ],
        Title: [{ required: true, message: "请填写标题", trigger: "blur" }],
        FeedType: [
          {
            required: true,
            type: "number",
            message: "请选择信息类型",
            trigger: "blur",
          },
        ],
        FeedID: [
          {
            required: true,
            type: "number",
            message: "请设置目标信息",
            trigger: "blur",
          },
        ],
      },
      loading: false,
      idsList: [],

      //=============启动设置
      isEditStart: false,
      startData: {},
      startDataDetail: {},
      startRules: {
        ButtonTxt: [
          { required: true, message: "请输入按钮文字", trigger: "blur" },
        ],
        // ButtonURL: [{required: true, message: '请输入链接地址', trigger: 'blur'}]
      },
    };
  },
  mounted() {
    this.initData();
    this.initStartData();
  },
  watch: {
    settingData: {
      deep: true,
      immediate: true,
      handler() {
        if (this.settingData.FeedType === 5) {
          this.showFeedId = false;
        } else {
          this.showFeedId = true;
        }
      },
    },
  },
  methods: {
    // 初始化查询数据
    initData() {
      SettingApi.GetSettingData().then((res) => {
        if (res.Code === 0) {
          if (res.Data) {
            this.hasData = true;
            let data = res.Data || {};
            this.detailData = JSON.parse(JSON.stringify(data));
            let settingData = JSON.parse(JSON.stringify(data));
            settingData.ImgURL = [{ url: settingData.ImgURL }];
            if (settingData.KaiserImgUrl) {
              settingData.ImgURL.push({ url: settingData.KaiserImgUrl });
            }
            this.settingData = settingData;
            this.settingData_copy = JSON.parse(JSON.stringify(data));
          }
        }
      });
    },
    // 信息类型改变
    typeChange(val) {
      if (this.settingData.FeedType == this.settingData_copy.FeedType) {
        this.settingData.FeedID = this.settingData_copy.FeedID;
      } else {
        this.settingData.FeedID = "";
      }
      if (val === 5) {
        this.settingData.FeedID = 0;
        this.settingData.FeedTitle = "";
      }
    },

    // 点击编辑精选设置 切换状态。。。
    editSet(bl) {
      this.isEditSet = !!bl;
      if (!!bl) {
        if (this.$refs.feedIdSelect)
          this.$refs.feedIdSelect.setQuery(this.settingData.FeedTitle);
      }
    },

    // 手动设置
    feedIdChange(val) {
      this.settingData.FeedTitle = val.label;
    },

    // 远程搜索
    remoteMethod(str) {
      this.loading = true;
      let title = str;
      let type = this.settingData.FeedType;
      SettingApi.GetFeedIds(type, title).then((res) => {
        if (res.Code === 0) {
          let list = res.Data || [];
          this.idsList = list.map((l) => {
            return { id: l.ID, value: l.Title || l.AppName || "" };
          });
          this.loading = false;
        }
      });
    },
    // 提交精选设置表单
    submitsettingData() {
      this.$refs["settingData"].validate((valid) => {
        if (valid) {
          let params = JSON.parse(JSON.stringify(this.settingData));
          params.KaiserImgUrl = params.ImgURL[1].url;
          params.ImgURL = params.ImgURL[0].url;
          delete params.FeedURL;
          SettingApi.EditSettingData(params).then((res) => {
            if (res.Code === 0) {
              this.$Message.success("操作成功");
              this.initData();
              this.isEditSet = false;
            } else {
              this.$Message.error(res.Message);
            }
          });
        }
      });
    },

    //
    feedTypeFilter(id) {
      return this.typeList.filter((tp) => tp.id === id)[0].value || "未知类型";
    },

    //===============
    editStart(bl) {
      this.isEditStart = !!bl;
    },
    initStartData() {
      SettingApi.GetStartData().then((res) => {
        if (res.Code === 0) {
          this.startData = JSON.parse(JSON.stringify(res.Data || {}));
          this.startDataDetail = JSON.parse(JSON.stringify(res.Data || {}));
        }
      });
    },
    submitStartData() {
      this.$refs["startData"].validate((valid) => {
        if (valid) {
          let params = this.startData;
          SettingApi.EditStartData(params).then((res) => {
            if (res.Code === 0) {
              this.initStartData();
              this.isEditStart = false;
              this.$Message.success("操作成功");
            }
          });
        }
      });
    },
  },
};
</script>

<style scoped lang="less">
.no-data-box {
  min-height: 80px;
  text-align: center;
  display: block;
  width: 100%;
  line-height: 80px;
  color: #999;
}

.block-title {
  font-size: 14px;
  margin-bottom: 20px;
  display: block;
  padding-bottom: 13px;
  border-bottom: 1px solid #f0f0f0;
}

.detail-box {
  img {
    max-width: 300px;
    max-height: 300px;
    display: block;
    width: 100%;
  }
}

.full-right {
  float: right;
}
.link-address {
  word-break: break-all;
  line-height: 2em;
}
</style>
