<template>
  <Card>
    <Form
      :model="searchForm"
      ref="formValidate"
      :inline="true"
      style="position: relative"
    >
      <FormItem>
        <AppSelect
          v-model="searchForm.params.appId"
          placeholder="搜索游戏名称"
        />
      </FormItem>
      <FormItem>
        <Button type="primary" @click="handleSearch">查询</Button>
      </FormItem>
    </Form>

    <Table :data="tableData" :columns="columns" :loading="loading" border>
      <template slot-scope="{ row }" slot="Status">
        {{ row.Status | filterStatus }}
      </template>
      <template slot-scope="{ row }" slot="JumpType">
        {{ filterJumpType(row.JumpType) }}
      </template>
      <template slot-scope="{ row }" slot="JumpFloorPageType">
        {{ row.JumpFloorPageType | filterJumpFloorPageType }}
      </template>
      <template slot-scope="{ row }" slot="Expired">
        <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">
          {{ row.StartTime }}~{{ row.EndTime }}</span
        >
      </template>
      <template slot-scope="{ row }" slot="action">
        <Button
          type="success"
          @click="changeStatus(row.Id, 1)"
          size="small"
          style="margin-right: 5px"
          v-show="row.Status == 0 || row.Status == 2"
          >上架</Button
        >
        <Button
          type="error"
          @click="changeStatus(row.Id, 2)"
          size="small"
          style="margin-right: 5px"
          v-show="row.Status == 1"
          >下架</Button
        >
        <Button
          type="primary"
          @click="handleEdit(row)"
          size="small"
          style="margin-right: 5px"
          >编辑</Button
        >
        <Button type="success" @click="handleTop(row.Id)" size="small"
          >置顶</Button
        >
      </template>
    </Table>
    <Row style="margin-top: 10px">
      <Col :span="6">
        <Button @click="handleModal()" type="info" shape="circle" icon="md-add"
          >新增</Button
        >
      </Col>
      <Col :span="18" align="right">
        <Page
          show-sizer
          :total="searchForm.total"
          show-total
          :page-size="searchForm.limit"
          :current="searchForm.page"
          @on-change="changePage"
          @on-page-size-change="changePageSize"
        />
      </Col>
    </Row>
    <Modal v-model="showModal" :title="isAdd ? '新增' : '修改'" :width="530">
      <FormPage
        :editForm="editForm"
        :isAdd="isAdd"
        ref="formPage"
        @getServe="getServe"
        v-if="showModal"
      />
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button @click="handleCommit" type="primary">确认</Button>
      </template></Modal
    ></Card
  >
</template>
<script>
import SettingApi from "@/api/gamespace/setting";
import FormPage from "./form";
import AppSelect from "_c/app-select";
export default {
  name: "Recommend",
  components: { FormPage, AppSelect },
  data() {
    return {
      tableData: [],
      columns: [
        { key: "Id", title: "ID", width: 60 },
        { key: "Title", title: "标题", width: 150 },
        { key: "AppName", title: "游戏名称", minWidth: 150 },
        { slot: "JumpType", title: "跳转类型", minWidth: 100 },
        { slot: "Status", title: "状态", minWidth: 80 },
        { slot: "JumpFloorPageType", title: "落地页类型", minWidth: 100 },
        { key: "JumpRankTitle", title: "榜单标题", minWidth: 100 },
        { title: "生效周期", slot: "Expired", minWidth: 270 },
        { slot: "action", title: "操作", width: 180, fixed: "right" },
      ],
      loading: false,
      showModal: false,
      isAdd: true,
      typeList: [
        { id: 1, value: "文章详情页" },
        { id: 2, value: "抽奖页" },
        { id: 3, value: "APP详情" },
        { id: 4, value: "榜单落地页" },
        { id: 5, value: "积分任务" },
        { id: 6, value: "论坛贴" },
        { id: 7, value: "H5" },
        { id: 8, value: "积分商城" },
        { id: 9, value: "普通deeplink" },
      ],
      editForm: {
        // 表单
      },
      searchForm: {
        page: 1,
        total: 0,
        limit: 10,
        params: {
          appId: undefined,
        },
      },
    };
  },
  mounted() {
    this.searchServer();
  },
  filters: {
    filterStatus(value) {
      let arr = ["初始化", "上线", "下线", "待上线"];
      return arr[value];
    },
    filterJumpFloorPageType(value) {
      let arr = [
        {
          Id: 3,
          Name: "竖版默认落地⻚",
        },
        {
          Id: 4,
          Name: "视频列表落地⻚",
        },
        {
          Id: 5,
          Name: "专题落地⻚",
        },
        {
          Id: 6,
          Name: "新游落地⻚",
        },
      ];
      let index = arr.findIndex((v) => v.Id == value);
      return index > -1 ? arr[index].Name : "--";
    },
  },
  methods: {
    filterJumpType(id) {
      return this.typeList.filter((v) => v.id == id)[0].value;
    },
    handleModal() {
      this.showModal = true;
      this.isAdd = true;
      this.editForm = {
        Title: "",
        AppId: undefined,
        PkgName: "",
        JumpType: 1,
        JumpFeedId: undefined,
        JumpFeedTitle: "",
        JumpPkgName: "",
        JumpFloorPageType: undefined,
        JumpRankTitle: "",
        JumpH5Url: "",
        DeepLink: "",
        DeepLinkPkgName: "",
        Expired: [],
      };
    },

    handleTop(id) {
      SettingApi.topActGame(id).then((res) => {
        if (res.Code == 0) {
          this.searchServer();
          this.$Message.success("success!");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    handleEdit(row) {
      this.showModal = true;
      this.isAdd = false;

      this.editForm = row;
      this.editForm.Expired = [this.editForm.StartTime, this.editForm.EndTime]; //4.7迭代增加生效周期
      // {
      //   Id,
      //   Title,
      //   AppId,
      //   PkgName,
      //   JumpType,
      //   JumpFeedId,
      //   JumpFeedTitle,
      //   JumpH5Url,
      //   JumpPkgName,
      //   JumpFloorPageType,
      //   JumpRankTitle,
      //   DeepLink,
      //   DeepLinkPkgName,
      // };
    },
    changeStatus(id, status) {
      SettingApi.updateActGame(id, status).then((res) => {
        if (res.Code == 0) {
          this.searchServer();
          this.$Message.success("success!");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    handleSearch() {
      this.searchForm.page = 1;
      this.searchServer();
    },
    //改页数
    changePage(page) {
      this.searchForm.page = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(limit) {
      this.searchForm.limit = limit;
      this.searchForm.page = 1;
      this.searchServer();
    },
    searchServer() {
      this.loading = true;
      SettingApi.getActGame(this.searchForm)
        .then((res) => {
          if (res.Code == 0) {
            this.searchForm.total = res.Data.Count;
            this.tableData = res.Data.Data || [];
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    handleCommit() {
      this.$refs["formPage"].handleCommit();
    },
    getServe() {
      this.showModal = false;
      this.searchServer();
    },
    //校验生效周期状态
    getStatus(row) {
      const now = new Date().getTime();
      const start = new Date(row.StartTime).getTime();
      const end = new Date(row.EndTime).getTime();
      return row.Status == 1 && now > start && now < end;
    },
  },
};
</script>