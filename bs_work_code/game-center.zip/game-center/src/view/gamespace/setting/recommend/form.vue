<template>
  <Form
    ref="settingData"
    :model="settingData"
    :rules="rules"
    :label-width="100"
  >
    <FormItem label="标题：" prop="Title">
      <Input
        type="text"
        v-model="settingData.Title"
        placeholder="请填写标题"
      ></Input>
    </FormItem>
    <FormItem label="游戏名称：" prop="Title">
      <AppSelect
        v-model="settingData.AppId"
        placeholder="搜索游戏名称"
        @on-change="changeAppId"
      />
    </FormItem>
    <FormItem label="信息类型：" prop="JumpType">
      <Select
        v-model="settingData.JumpType"
        @on-change="typeChange"
        placeholder="请选择信息类型"
        style="width: 200px"
      >
        <Option v-for="type in typeList" :value="type.id" :key="type.id">{{
          type.value
        }}</Option>
      </Select>
    </FormItem>
    <FormItem v-if="showFeedId" label="目标信息：" prop="JumpFeedId">
      <Select
        v-model="settingData.JumpFeedId"
        filterable
        remote
        label-in-value
        ref="FeedIdSelect"
        :remote-method="remoteMethod"
        :loading="selecting"
        placeholder="请设置目标信息"
        @on-change="FeedIdChange"
      >
        <Option
          v-for="(item, index) in idsList"
          :key="index"
          :value="item.id"
          >{{ item.value }}</Option
        >
      </Select>
    </FormItem>
    <!-- <FormItem v-if="showPkgName" label="游戏包名：" prop="PkgName">
      <Input v-model="settingData.PkgName" placeholder="请输入游戏包名" />
    </FormItem> -->
    <FormItem v-if="showJumpH5Url" label="URL：" prop="JumpH5Url">
      <Input v-model="settingData.JumpH5Url" placeholder="请输入URL" />
    </FormItem>
    <template v-if="showFloorPageType">
      <FormItem label="榜单标题：" prop="JumpRankTitle">
        <Input
          v-model="settingData.JumpRankTitle"
          placeholder="请输入榜单标题"
        />
      </FormItem>
      <FormItem label="落地⻚类型：" prop="JumpFloorPageType">
        <Selection
          v-model="settingData.JumpFloorPageType"
          :dataList="FloorPageList"
          :width="200"
        />
      </FormItem>
    </template>
    <template v-if="showDeepLink">
      <FormItem label="DeepLink" prop="DeepLink">
        <Input v-model="settingData.DeepLink" placeholder="请输入DeepLink" />
      </FormItem>
      <FormItem label="DeepLink包名：" prop="DeepLinkPkgName">
        <Input
          v-model="settingData.DeepLinkPkgName"
          placeholder="请输入DeepLink包名"
        />
      </FormItem>
    </template>
    <FormItem label="生效周期：" prop="Expired">
      <DateRange
        v-model="settingData.Expired"
        @on-change="
          (value) => {
            settingData.StartTime = value.start;
            settingData.EndTime = value.end;
          }
        "
      />
    </FormItem>
  </Form>
</template>
<script>
import SettingApi from "@/api/gamespace/setting";
import UploadImg from "_c/gamespace/upload-img";
import AppSelect from "_c/app-select";
import Selection from "_c/Selection";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";
export default {
  name: "FormPage",
  components: { UploadImg, AppSelect, Selection, DateRange },
  props: ["editForm", "isAdd"],
  data() {
    const validateNum = (rule, value, callback) => {
      // 模拟异步验证效果
      if (!Number.isInteger(value)) {
        callback(new Error("请选择落地页类型"));
      } else {
        callback();
      }
    };

    return {
      selecting: false,
      settingData: {
        // 表单
        Title: "",
        AppId: undefined,
        PkgName: "",
        JumpType: 1,
        JumpFeedId: undefined,
        JumpFeedTitle: "",
        JumpPkgName: "",
        JumpFloorPageType: undefined,
        JumpRankTitle: "",
        JumpH5Url: "",
        DeepLink: "",
        DeepLinkPkgName: "",
      },
      typeList: [
        { id: 1, value: "文章详情页" },
        { id: 2, value: "抽奖页" },
        { id: 3, value: "APP详情" },
        { id: 4, value: "榜单落地页" },
        // { id: 5, value: "积分任务" },//4.5.0迭代注释
        { id: 6, value: "论坛贴" },
        { id: 7, value: "H5" },
        // { id: 8, value: "积分商城" },//4.5.0迭代注释
        { id: 9, value: "普通deeplink" },
      ],
      FloorPageList: [
        {
          Id: 3,
          Name: "竖版默认落地⻚",
        },
        {
          Id: 4,
          Name: "视频列表落地⻚",
        },
        {
          Id: 5,
          Name: "专题落地⻚",
        },
        {
          Id: 6,
          Name: "新游落地⻚",
        },
      ],
      idsList: [],
      rules: {
        Title: [{ required: true, message: "请填写标题", trigger: "blur" }],
        JumpType: [
          {
            required: true,
            type: "number",
            message: "请选择信息类型",
            trigger: "blur",
          },
        ],
        JumpFeedId: [
          {
            required: true,
            type: "number",
            message: "请设置目标信息",
            trigger: "blur",
            // validator: validateFeed,
          },
        ],
        JumpFloorPageType: [
          {
            required: true,
            type: "number",
            message: "请选择落地页类型",
            trigger: "change",
            validator: validateNum,
          },
        ],
        JumpRankTitle: [
          { required: true, message: "请填写榜单标题", trigger: "blur" },
        ],
        DeepLink: [
          { required: true, message: "请填写DeepLink", trigger: "blur" },
        ],
        DeepLinkPkgName: [
          { required: true, message: "请填写DeepLink包名", trigger: "blur" },
        ],
        JumpH5Url: [{ required: true, message: "请填写URl", trigger: "blur" }],
        Expired: [
          {
            validator: checkDateRange,
            trigger: "change",
            type: "array",
          },
        ],
      },
    };
  },
  mounted() {
    if (this.settingData.JumpFeedId && this.$refs["FeedIdSelect"]) {
      this.$refs["FeedIdSelect"].setQuery(this.editForm.JumpFeedTitle);
      this.$refs["FeedIdSelect"].toggleMenu(null, false);
    }
  },
  watch: {
    editForm: {
      immediate: true,
      handler: function () {
        this.settingData = JSON.parse(JSON.stringify(this.editForm));
      },
    },
  },
  computed: {
    showFeedId() {
      return [1, 2, 3, 4, 6].includes(this.settingData.JumpType);
    },
    showJumpH5Url() {
      return this.settingData.JumpType == 7;
    },
    showFloorPageType() {
      return this.settingData.JumpType == 4;
    },
    showDeepLink() {
      return this.settingData.JumpType == 9;
    },
    nowTime() {
      return formatTimes(new Date());
    },
  },
  methods: {
    remoteMethod(value) {
      this.selecting = true;
      let type = this.settingData.JumpType;
      SettingApi.ActGameLick(type, value).then((res) => {
        if (res.Code === 0) {
          let list = res.Data || [];
          this.idsList = list.map((item) => {
            item.id = item.ID || item.Id;
            item.value = item.Title || item.AppName || "";
            return item;
          });
          this.selecting = false;
        }
      });
    },
    // 手动设置
    FeedIdChange(val) {
      if (val && val.label) {
        this.settingData.JumpFeedTitle = val.label;
        if (val.PkgName) {
          this.settingData.JumpPkgName = val.PkgName;
        }
      }
    },
    changeAppId(val) {
      if (val && val.value) {
        this.settingData.PkgName = val.value.PkgName;
      }
    },
    typeChange(val) {
      if (val != this.editForm.JumpType) {
        this.settingData.JumpFeedId = 0;
        this.settingData.JumpFeedTitle = "";
      }
    },
    handleCommit() {
      this.$refs["settingData"].validate((valid) => {
        if (valid) {
          if (!this.settingData.StartTime || !this.settingData.EndTime) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitcheck();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitcheck();
          }
        }
      });
    },
    submitcheck() {
      let params = JSON.parse(JSON.stringify(this.settingData));
      params.StartTime = params.StartTime || this.nowTime;
      params.EndTime = params.EndTime || "2099-01-01 00:00:00";
      if (this.isAdd) {
        SettingApi.addActGame(params).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("success!");
            this.$emit("getServe");
          } else {
            this.$Message.error(res.Message);
          }
        });
      } else {
        SettingApi.editActGame(params.Id, params).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("success!");
            this.$emit("getServe");
          } else {
            this.$Message.error(res.Message);
          }
        });
      }
    },
  },
};
</script>