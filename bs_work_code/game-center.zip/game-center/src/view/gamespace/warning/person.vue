<template>
	<Card>
		<Table
			border
			:columns="personColumns"
			:data="personList"
		>
			<template
				slot="opt"
				slot-scope="{ row, index }"
			>
				<Poptip
					confirm
					transfer
					title="确定要删除吗？"
					@on-ok="delPerson(row)"
				>
					<Button
						type="error"
						size="small"
					>删除</Button>
				</Poptip>
			</template>
		</Table>
        <div style="margin: 10px 0; overflow: hidden">
				<div style="float: left">
					<Button
						type="info"
						shape="circle"
						icon="md-add"
						@click="addPerson"
					>新增</Button>
				</div>
				<div style="float: right">
					<Page
                        show-sizer
                        :total="total"
                        show-total
                        :page-size="pageSize"
                        :current="page"
                        @on-change="changePage"
                        @on-page-size-change="changePageSize"
                    />
				</div>
			</div>
		<Modal
			v-model="editVisible"
			title="新增"
			:mask-closable="false"
		>
            <Form
                ref="form"
                :model="formData"
                :rules="rules"
                :label-width="140"
            >
                <form-item
                    label="负责人企微："
                    prop="WxAccount"
                >
                    <Input
                        class="inputStyle"
                        v-model="formData.WxAccount"
                        placeholder="请输入负责人企微"
                    ></Input>
                </form-item>
                <form-item
                    label="名字："
                    prop="Name"
                >
                    <Input
                        class="inputStyle"
                        v-model="formData.Name"
                        placeholder="请输入负责人名字"
                    ></Input>
                </form-item>
                
            </Form>
            <div slot="footer">
				<Button type="text" size="large" @click="editVisible = false">取消</Button>
				<Button type="primary" size="large" @click="handleSubmit">确定</Button>
			</div>
        </Modal>
	</Card>
</template>

<script>
import commentApi from '@/api/gamespace/comment'
export default {
	name: 'gamespace_warning_person',
	data() {
		return {
			personColumns: [
				{ title: '负责人企微', key: 'WxAccount', minWidth: 85 },
				{ title: '名字', key: 'Name', minWidth: 85 },
				{
					title: '操作',
					slot: 'opt',
					fixed: 'right',
					align: 'center',
					width: 100,
				},
			],
			personList: [],
			total: 0,
			pageSize: 10,
			page: 1,
			formData: {
				WxAccount: '',
				Name: '',
			},
			rules: {
				WxAccount: [{ required: true, message: '请填写负责人企微', trigger: 'blur' }],
				Name: [{ required: true, message: '请填写负责人名字', trigger: 'blur' }],
			},
			editVisible: false,
		}
	},
	mounted() {
		this.getPersonList()
	},
	methods: {
		async getPersonList() {
			let params = {
				Page: this.page,
				PageSize: this.pageSize,
			}
			await commentApi.GetPersonList(params).then(res => {
				if (res.Code == 0) {
					this.total = res.Data.Total
					this.personList = res.Data.List
				}
			})
		},
		delPerson(row) {
			commentApi.DelPerson({Id: row.Id}).then(res => {
				if (res.Code == 0) {
					this.$Message.success('删除成功')
					this.getPersonList()
				} else {
					this.$Message.success('删除失败')
				}
			})
		},
		// 新增预警人
		addPerson() {
			this.$refs.form.resetFields()
			this.editVisible = true
		},
        handleSubmit () {
            this.$refs.form.validate(valid => {
				if (valid) {
					commentApi.AddPerson(this.formData).then(async res => {
						if (res.Code == 0) {
							this.$Message.success('新增成功')
							await this.getPersonList()
							this.editVisible = false
						}
					})
				}
			})
        },
		//改页数
		changePage(page) {
			this.page = page
			this.getPersonList()
		},
		//改分页条数
		changePageSize(pageSize) {
			this.pageSize = pageSize
			this.page = 1
			this.getPersonList()
		},
	},
}
</script>

<style>
.inputStyle {
	width: 250px;
}
</style>