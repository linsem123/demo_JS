<template>
  <Card title="">
    <Form
      ref="formValidate"
      :model="formData"
      :rules="ruleValidate"
      :inline="true"
    >
      <FormItem prop="AppId">
        <gameNameSelect
          v-model="formData.AppId"
          :multiple="false"
          :width="250"
        />
      </FormItem>
      <FormItem label="状态" :label-width="50">
        <Selection v-model="formData.Status" :dataList="statusList" />
      </FormItem>
      <FormItem label="来源" :label-width="50">
        <Selection v-model="formData.Place" :dataList="PlaceList" />
      </FormItem>
      <Button
        type="success"
        shape="circle"
        icon="ios-search"
        @click="handlesearch"
        >搜索</Button
      >
    </Form>
    <Table
      border
      highlight-row
      ref="currentRowTable"
      :columns="columns"
      :data="tableData"
      :loading="loading"
      :max-height="600"
    >
      <template slot="Status" slot-scope="{ row }">
        <span v-if="row.Status == 1">成功</span>
        <span v-else-if="row.Status == 2">失败</span>
        <span v-else>未知类型</span></template
      >
      <template slot="Place" slot-scope="{ row }">
        <span v-if="row.Place == 1">发现好游戏</span>
        <span v-else-if="row.Place == 2">应用商店</span>
        <span v-else>--</span></template
      >
      <template slot="Time" slot-scope="{ row }">
        {{ row.CreatedAt | format }}</template
      >
    </Table>
    <Page
      show-sizer
      :total="total"
      show-total
      :page-size="pageSize"
      :current="pageIndex"
      @on-change="changePage"
      @on-page-size-change="changePageSize"
    />
  </Card>
</template>
<script>
import OrderDirect from "@/api/gamespace/orderDirect";
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect";
import Selection from "_c/Selection.vue";
import common from "@/view/gameCircle/pubFunc/common";
export default {
  components: {
    gameNameSelect,
    Selection,
  },
  data() {
    const isEmpty = (rule, value, callback) => {
      if (value.trim() == "") {
        return callback(new Error("请输入预约指令"));
      } else {
        callback();
      }
    };
    return {
      formData: {
        AppId: undefined,
        Status: undefined,
        Place: undefined,
      },
      ruleValidate: { direct: [{ validator: isEmpty, trigger: "change" }] },
      tableData: [],
      columns: [
        {
          title: "ID",
          key: "Id",
          align: "center",
          minWidth: 100,
        },
        {
          title: "游戏名称",
          key: "AppName",
          align: "center",
          minWidth: 100,
        },
        {
          title: "游戏包名",
          key: "PkgName",
          align: "center",
          minWidth: 200,
        },
        {
          title: "来源",
          slot: "Place",
          align: "center",
          minWidth: 100,
        },
        {
          title: "状态",
          slot: "Status",
          align: "center",
          minWidth: 100,
        },
        {
          title: "MsgId",
          key: "MsgId",
          align: "center",
          minWidth: 200,
        },
        {
          title: "时间",
          slot: "Time",
          align: "center",
          minWidth: 150,
        },
        {
          title: "返回结果",
          key: "Result",
          align: "center",
          minWidth: 100,
        },
      ],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      loading: false,
      statusList: [
        {
          Id: 1,
          Name: "成功",
        },
        {
          Id: 2,
          Name: "失败",
        },
      ],
      PlaceList: [
        {
          Id: 1,
          Name: "发现好游戏",
        },
        {
          Id: 2,
          Name: "应用商店",
        },
      ],
    };
  },
  mounted() {
    this.search();
  },
  filters: {
    format(v) {
      return common.formatDate(v, true);
    },
  },
  methods: {
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.search();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.search();
    },
    handlesearch() {
      this.pageIndex = 1;
      this.search();
    },
    search() {
      this.loading = true;
      OrderDirect.getList({
        limit: this.pageSize,
        page: this.pageIndex,
        params: this.formData,
      })
        .then((res) => {
          if (res.Code == 0) {
            this.total = res.Data.Count;
            this.tableData = res.Data.Data || [];
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>