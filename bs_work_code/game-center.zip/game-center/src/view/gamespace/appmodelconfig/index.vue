<template>
  <Card>
    <Table :columns="columns" :data="tableData" border :loading="loading">
      <template slot="action" slot-scope="{ row }">
        <Button type="primary" size="small" @click="handleConfig(row)"
          >编辑</Button
        >
      </template>
    </Table>
    <Row style="margin-top: 10px">
      <Col :span="6">
        <Button
          @click="handleConfig(0)"
          type="info"
          shape="circle"
          icon="md-add"
          >新增</Button
        >
      </Col>
      <Col :span="18" align="right">
        <Page
          show-sizer
          :total="searchData.total"
          show-total
          :page-size="searchData.limit"
          :current="searchData.page"
          @on-change="changePage"
          @on-page-size-change="changePageSize"
        />
      </Col>
    </Row>
    <Modal v-model="show" :title="isAdd ? '新增' : '编辑'">
      <Form
        :model="formData"
        :label-width="80"
        ref="formData"
        :rules="rules"
        v-if="show"
      >
        <FormItem label="模块：" prop="ModelId">
          <ModelSelect
            v-model="formData.ModelId"
            :Name="formData.Name"
            @on-change="changeModel"
            style="width: 300px"
          />
        </FormItem>
        <FormItem label="游戏：" prop="AppId">
          <AppSelect v-model="formData.AppId" style="width: 300px" />
        </FormItem>
        <FormItem label="评分：" prop="Scope">
          <Input v-model="formData.Scope" style="width: 300px" />
        </FormItem>
        <FormItem label="人数：" prop="Count">
          <InputNumber v-model="formData.Count" />
        </FormItem>
      </Form>
      <template slot="footer">
        <Button size="large" type="text" @click="show = false">取消</Button>
        <Button size="large" type="primary" @click="submit">确定</Button>
      </template>
    </Modal>
  </Card>
</template>
<script>
import appmodelAPI from "@/api/gamespace/appmodelconfig.js";
import ModelSelect from "_c/model-select/index";
import AppSelect from "_c/app-select";
// import HomeModuleAPI from "@/api/gamespace/homemodule";

export default {
  name: "AppModelConfig",
  components: { ModelSelect, AppSelect },
  data() {
    // const CountCheck = (rule, value, callback) => {
    //   if (!value || Number(value) < 1) {
    //     callback("人数必须大于0");
    //   }
    //   callback();
    // };
    return {
      searchData: {
        total: 0,
        limit: 10,
        page: 1,
        params: {},
      },

      columns: [
        {
          key: "ID",
          title: "ID",
        },
        {
          key: "AppName",
          title: "游戏名称",
        },
        {
          key: "Name",
          title: "模块名称",
        },
        {
          key: "Scope",
          title: "评分",
        },
        {
          key: "Count",
          title: "人数",
        },
        {
          slot: "action",
          title: "操作",
        },
      ],
      tableData: [],
      show: false,
      isAdd: true,
      loading: false,
      formData: {
        Name: "",
        AppId: undefined,
        ModelId: undefined,
        Scope: "",
        Count: 0,
        Comment: "",
      },
      rules: {
        // Count: [
        //   {
        //     required: true,
        //     validator: CountCheck,
        //     trigger: "blur",
        //   },
        // ],
        ModelId: [
          {
            required: true,
            message: "请输入模块名称",
            type: "number",
            trigger: "blur",
          },
        ],
        AppId: [
          {
            required: true,
            message: "请输入游戏名称",
            type: "number",
            trigger: "blur",
          },
        ],
        // Scope: [
        //   {
        //     required: true,
        //     message: "请输入评分",
        //     trigger: "change",
        //   },
        // ],
      },
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    handleConfig(row) {
      this.show = true;
      if (row) {
        this.isAdd = false;
        this.formData = { ...row };
      } else {
        this.isAdd = true;
        this.formData = Object.assign(
          {},
          {
            Name: "",
            AppId: undefined,
            ModelId: undefined,
            Scope: "",
            Count: 0,
            Comment: "",
          }
        );
      }
    },
    //保存修改/新增
    submit() {
      this.$refs["formData"].validate((validate) => {
        if (validate) {
          if (this.isAdd) {
            appmodelAPI.Add(this.formData).then((res) => {
              if (res.Code == 0) {
                this.init();
                this.show = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            appmodelAPI.Edit(this.formData.ID, this.formData).then((res) => {
              if (res.Code == 0) {
                this.init();
                this.show = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    changeModel(val) {
      if (val.value) {
        this.formData.Name = val.value.label;
      } else {
        this.formData.Name = "";
        this.formData.ModelId = undefined;
      }
    },
    //改页数
    changePage(page) {
      this.searchData.page = page;
      this.init();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.searchData.limit = pageSize;
      this.searchData.page = 1;
      this.init();
    },
    init() {
      this.loading = true;
      appmodelAPI
        .GetList(this.searchData)
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.Data;
            this.searchData.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
