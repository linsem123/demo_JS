<template>
  <div>
    <Card title="游戏下载人数看板">
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="3">
            <Select
              v-model="search.params.appID"
              :loading="search.loading"
              clearable
              filterable
              remote
              :remote-method="handleGameSearch"
              placeholder="请输入游戏名称"
              ref="AppName"
              @on-change="changeAppName"
            >
              <Option
                v-for="item in gameList"
                :value="item.ID"
                :key="item.ID"
                >{{ item.AppName }}</Option
              >
            </Select>
          </Col>
          <Col span="3">
            <Select
              v-model="search.params.appID"
              :loading="search.loading"
              clearable
              filterable
              remote
              :remote-method="handleGamePkgNameSearch"
              placeholder="请输入游戏包名"
              ref="packageName"
              @on-change="changeValue"
            >
              <Option
                v-for="item in gameList"
                :value="item.ID"
                :key="item.ID"
                >{{ item.PkgName }}</Option
              >
            </Select>
          </Col>
          <Col span="3">
            <Input
              v-model="search.params.versionCode"
              clearable
              placeholder="请输入游戏版本号"
            ></Input>
          </Col>
          <Col span="3">
            <Select
              v-model="search.params.appVersionCode"
              :loading="search.appLoading"
              clearable
              filterable
              remote
              :remote-method="handleFindGameVersionSearch"
              placeholder="请输入发现好游戏版本名称"
            >
              <Option
                v-for="item in appVersionList"
                :value="item.VersionCode"
                :key="item.ID"
                >{{ item.VersionName }}</Option
              >
            </Select>
          </Col>
          <Col span="3" :xxl="5">
            <DatePicker
              v-model="search.params.daterange"
              type="daterange"
              placeholder="开始日期 - 结束日期"
              style="width: 100%"
            ></DatePicker>
          </Col>
          <Col span="4">
            <Checkbox v-model="search.params.IsAggregation" size="large"
              >&nbsp;聚合</Checkbox
            >
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </Col>
          <Col span="3" align="right">
            <Button @click="handleDownload" type="primary" icon="md-download"
              >导出</Button
            >
          </Col>
        </Row>
      </div>
      <Table
        :columns="table.columns"
        :data="table.data"
        ref="selection"
        @on-selection-change="selectionChange"
      >
        <template slot-scope="{ row, index }" slot="VersionCode">
          <span v-if="row.VersionCode == 0">-</span>
          <span v-else>{{ row.VersionCode }}</span>
        </template>
        <template slot-scope="{ row, index }" slot="AppVersionCode">
          <span v-if="row.AppVersionCode == 0">-</span>
          <span v-else>{{ row.AppVersionCode }}</span>
        </template>
      </Table>
      <div style="margin: 10px 0; overflow: hidden">
        <div style="float: right">
          <Page
            :total="page.total"
            :current="page.current"
            :page-size="page.size"
            :page-size-opts="[10, 20, 40, 80, 100, 500]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>
  </div>
</template>

<script>
import { formatDate } from "@/libs/tools";
import VersionAPI from "@/api/gamespace/gameversion";
import GameAPI from "@/api/gamespace/game";
import config from "@/config/index";
export default {
  name: "download-info",
  data() {
    return {
      table: {
        data: [],
        columns: [
          { type: "selection", width: 50 },
          { title: "游戏名称", key: "AppName" },
          { title: "游戏包名", key: "PkgName" },
          { title: "游戏版本号", slot: "VersionCode" },
          { title: "发现好游戏版本号", slot: "AppVersionCode" },
          { title: "下载完成次数", key: "InstallNum" },
          { title: "下载完成人数", key: "DistinctInstallNum" },
          { title: "静默下载人数", key: "SilentInstallNum" },
          { title: "主动下载人数", key: "ActiveInstallNum" },
          { title: "下载安装", key: "DownLoadInstallNum" },
          { title: "更新安装", key: "UpdateInstallNum" },
          { title: "未上报安装类型", key: "OtherInstallNum" },
        ],
      },
      page: {
        current: 1,
        size: 10,
        total: 0,
      },
      gameList: [],
      appVersionList: [],
      search: {
        loading: false,
        appLoading: false,
        params: {
          appID: undefined,
          versionCode: undefined,
          IsAggregation: false,
          appVersionCode: undefined,
          daterange: [],
        },
        selection: [],
      },
    };
  },
  methods: {
    init() {
      this.downloadInfo();
    },
    onPageChange(value) {
      this.page.current = value;
      this.downloadInfo();
    },
    onPageSizechange(value) {
      this.page.size = value;
      this.downloadInfo();
    },
    downloadInfo() {
      let params = {
        Limit: this.page.size,
        Page: this.page.current,
        Params: {
          IsAggregation: this.search.params.IsAggregation,
          AppID: this.search.params.appID,
          AppVersionCode: this.search.params.appVersionCode,
        },
      };
      if (this.search.params.versionCode != "") {
        params.Params.VersionCode = this.search.params.versionCode;
      }
      if (
        this.search.params.daterange[0] &&
        this.search.params.daterange[0] != ""
      ) {
        params.Params.Start = formatDate(this.search.params.daterange[0]);
      }
      if (
        this.search.params.daterange[1] &&
        this.search.params.daterange[1] != ""
      ) {
        params.Params.End = formatDate(this.search.params.daterange[1]);
      }
      VersionAPI.DownloadInfo(params).then((res) => {
        this.table.data = res.Data.Data || [];
        this.page.total = res.Data.Count;
      });
    },
    //游戏名
    changeAppName(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["packageName"].setQuery(item[0].PkgName);
        this.$refs["packageName"].toggleMenu(null, false);
      }
    },
    //包名
    changeValue(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["AppName"].setQuery(item[0].AppName);
        this.$refs["AppName"].toggleMenu(null, false);
      }
    },
    handleGameSearch(value) {
      GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    handleGamePkgNameSearch(value) {
      GameAPI.LikeAppByParams({ params: { PkgName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    handleFindGameVersionSearch(value) {
      GameAPI.LikeGameVersion({
        params: { VersionName: value, AppID: 107 },
      }).then((res) => {
        this.appVersionList = res.Data;
      });
    },
    selectionChange(sel) {
      this.selection = sel;
      console.log(this.selection);
    },
    handleDownload() {
      if (this.selection.length === 0) {
        this.$Message.error("请勾选要导出的数据");
      } else {
        VersionAPI.exportDownloadList({ Data: this.selection }).then((res) => {
          if (res.Code === 0) {
            let url = res.Data;
            url = url.replace(".", "");
            window.location.href = config.fileBaseUrl + url;
          } else {
            this.$Message.error(res.Message);
          }
        });
      }
    },
  },
  mounted() {
    this.init();
  },
};
</script>

<style scoped>
</style>
