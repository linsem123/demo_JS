<template>
  <div>
    <Card title="游戏真实预约人数看板">
      <div style="margin: 10px">
        <Form
          ref="formValidate"
          :model="search.params"
          :inline="true"
          style="position: relative"
        >
          <FormItem>
            <Select
              v-model="search.params.appID"
              :loading="search.loading"
              clearable
              filterable
              remote
              :remote-method="handleGameSearch"
              placeholder="请输入游戏名称"
              ref="AppName"
              @on-change="changeAppName"
            >
              <Option
                v-for="item in gameList"
                :value="item.ID"
                :key="item.ID"
                >{{ item.AppName }}</Option
              >
            </Select>
          </FormItem>
          <FormItem>
            <Select
              v-model="search.params.appID"
              :loading="search.loading"
              clearable
              filterable
              remote
              :remote-method="handleGamePkgNameSearch"
              placeholder="请输入游戏包名"
              ref="packageName"
              @on-change="changeValue"
            >
              <Option
                v-for="item in gameList"
                :value="item.ID"
                :key="item.ID"
                >{{ item.PkgName }}</Option
              >
            </Select>
          </FormItem>
          <FormItem>
            <!-- <DatePicker
              v-model="search.params.daterange"
              type="daterange"
              placeholder="开始日期 - 结束日期"
              style="width: 200px"
            ></DatePicker> -->
          </FormItem>
          <FormItem>
            <DatePicker
              v-model="search.params.Start"
              type="date"
              format="yyyy-MM-dd"
              placeholder="开始日期"
              style="width: 120px"
              @on-change="(v) => changeDate(v, 'Start')"
            ></DatePicker>
            -
            <DatePicker
              v-model="search.params.End"
              type="date"
              format="yyyy-MM-dd"
              placeholder="结束日期"
              style="width: 120px"
              @on-change="(v) => changeDate(v, 'End')"
            ></DatePicker>
          </FormItem>
          <FormItem label="机型" :label-width="40">
            <PhoneSelect v-model="search.params.model_id" :width="150" />
          </FormItem>
          <FormItem label="来源" :label-width="40">
            <Selection v-model="search.params.place" :dataList="sourceList" />
          </FormItem>
          <FormItem>
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </FormItem>
          <FormItem span="4" align="right">
            <Button @click="handleDownload" type="primary" icon="md-download"
              >导出</Button
            >
          </FormItem>
        </Form>
      </div>
      <Table
        :columns="table.columns"
        :data="table.data"
        ref="selection"
        @on-selection-change="selectionChange"
      >
        <template slot="SubPlace" slot-scope="{ row }">
          {{ row.SubPlace | SubPlaceFilter }}
        </template>
      </Table>
      <!-- <div style="margin: 10px 0; overflow: hidden">
        <div style="float: right">
          <Page
            :total="page.total"
            :current="page.current"
            :page-size="page.size"
            :page-size-opts="[10, 20, 40, 80, 100]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div> -->
    </Card>
  </div>
</template>

<script>
import VersionAPI from "@/api/gamespace/gameversion";
import GameAPI from "@/api/gamespace/game";
import Selection from "_c/Selection.vue";
import PhoneSelect from "_c/phone-select";
import common from "@/view/gameCircle/pubFunc/common";
import config from "@/config/index";
export default {
  name: "sub-count",
  components: { Selection, PhoneSelect },
  data() {
    return {
      table: {
        data: [],
        columns: [
          { type: "selection", width: 50 },
          { title: "游戏包名", key: "PkgName" },
          { title: "游戏名称", key: "AppName" },
          { title: "预约机型", key: "ModelName" },
          { title: "预约来源", slot: "SubPlace" },
          { title: "预约人数", key: "SubCount" },
          { title: "真实预约人数", key: "SubRealCount" },
          { title: "预约上报IMEI去重数", key: "ImeiCount" },
          { title: "预约机型推送IMEI数", key: "MatchImeiCount" },
          { title: "非预约机型推送IMEI数", key: "MismatchImeiCount" },
          // { title: "预约IMEI数", key: "UnionIMeiCount" },
        ],
      },
      page: {
        current: 1,
        size: 10,
        total: 0,
      },
      gameList: [],
      search: {
        loading: false,
        params: {
          appID: undefined,
          // daterange: ['2016-01-01', '2016-02-15'],
          place: undefined,
          model_id: undefined,
          Start: "",
          End: "",
        },
      },
      selection: [],
      sourceList: [
        {
          Id: 0,
          Name: "游戏中心",
        },
        {
          Id: 1,
          Name: "应用商店",
        },
      ],
    };
  },
  filters: {
    SubPlaceFilter(value) {
      return ["游戏中心", "应用商店"][value];
    },
  },
  methods: {
    init() {
      this.subCount();
    },
    //游戏名
    changeAppName(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["packageName"].setQuery(item[0].PkgName);
        this.$refs["packageName"].toggleMenu(null, false);
      }
    },
    //包名
    changeValue(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["AppName"].setQuery(item[0].AppName);
        this.$refs["AppName"].toggleMenu(null, false);
      }
    },
    changeDate(date, type) {
      let start = new Date(this.search.params.Start).getTime();
      let end = new Date(this.search.params.End).getTime();
      if (start > end) {
        this.search.params[type] = "";
        this.$Message.error("开始时间不得大于结束时间");
        return;
      }
    },
    onPageChange(value) {
      this.page.current = value;
      this.subCount();
    },
    onPageSizechange(value) {
      this.page.size = value;
      this.subCount();
    },
    subCount() {
      if (!this.search.params.appID) {
        this.$Message.error("请输入游戏名称或游戏安装包");
        return;
      }

      let params = {
        Limit: this.page.size,
        Page: this.page.current,
        Params: {
          AppID: this.search.params.appID,
          place: this.search.params.place,
          model_id: this.search.params.model_id,
          Start: this.search.params.Start
            ? common.formatDate(this.search.params.Start)
            : undefined,
          End: this.search.params.End
            ? common.formatDate(this.search.params.End)
            : undefined,
        },
      };
      // if (
      //   this.search.params.daterange[0] &&
      //   this.search.params.daterange[0] != ""
      // ) {
      //   params.Params.Start = formatDate(this.search.params.daterange[0]);
      // }
      // if (
      //   this.search.params.daterange[1] &&
      //   this.search.params.daterange[1] != ""
      // ) {
      //   params.Params.End = formatDate(this.search.params.daterange[1]);
      // }
      VersionAPI.SubCount(params).then((res) => {
        // this.table.data = res.Data.Data || [];
        this.table.data = res.Data || [];
        // this.page.total = res.Data.Count;
      });
    },
    handleGameSearch(value) {
      GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    handleGamePkgNameSearch(value) {
      GameAPI.LikeAppByParams({ params: { PkgName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    selectionChange(sel) {
      this.selection = sel;
      console.log(this.selection);
    },
    handleDownload() {
      if (this.selection.length === 0) {
        this.$Message.error("请勾选要导出的数据");
      } else {
        VersionAPI.exportList({ Data: this.selection }).then((res) => {
          if (res.Code === 0) {
            let url = res.Data;
            url = url.replace(".", "");
            window.location.href = config.fileBaseUrl + url;
          } else {
            this.$Message.error(res.Message);
          }
        });
      }
    },
  },
  mounted() {
    // this.init();
  },
};
</script>

<style scoped>
</style>
