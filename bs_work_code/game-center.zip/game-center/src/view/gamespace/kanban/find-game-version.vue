<template>
    <div>
      <Card title="发现好游戏升级数据看板">
        <Table :columns="table.columns" :data="table.data"></Table>

        <div style="margin: 10px 0;overflow: hidden">
          <div style="float: right">
            <Page
              :total="page.total"
              :current="page.current"
              :page-size="page.size"
              :page-size-opts="[10,20,40,80,100]"
              @on-change="onPageChange"
              @on-page-size-change="onPageSizechange"
              show-sizer
              show-total
            ></Page>
          </div>
        </div>
      </Card>
    </div>
</template>

<script>
  import VersionAPI from "@/api/gamespace/gameversion";
    export default {
        name: "find-game-version",
      data() {
          return {
            table: {
              data: [],
              columns: [
                {title: '版本号', key: 'VersionCode'},
                {title: '上报版本人数', key: 'ReportVersionCount'},
                {title: '触发开始下载人数', key: 'StartDownLoadCount'},
                {title: '下载完成人数', key: 'EndDownLoadCount'},
              ]
            },
            page: {
              current: 1,
              size: 10,
              total: 0
            }
          }
      },
      methods:{
        onPageChange(value) {
          this.page.current = value;
          this.versionCount();
        },
        onPageSizechange(value) {
          this.page.size = value;
          this.versionCount();
        },
        init() {
          this.versionCount()
        },
        versionCount(){
          VersionAPI.VersionCount({Limit: this.page.size, Page: this.page.current}).then(res=>{
            this.table.data = res.Data.Data||[]
            this.page.total = res.Data.Count
          })
        }
      },
      mounted() {
        this.init();
      },
    }
</script>

<style scoped>

</style>
