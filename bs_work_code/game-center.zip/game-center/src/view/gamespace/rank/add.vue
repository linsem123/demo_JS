<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>榜单绑定游戏
    </p>
    <view-form @on-form-submit="handleSubmit"></view-form>
  </Card>
</template>
<script>
import GameRankAPI from "@/api/gamespace/gamerank";
import ViewForm from "_c/gamespace/rank/form";
import { mapMutations} from 'vuex'
export default {
  name: "Add",
  components: {
      ViewForm,
  },
  data() {
    return {

    }
  },
  methods: {
    ...mapMutations([
      'closeTag'
    ]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      GameRankAPI.Bind(formScope.RankType,formScope.AppID).then(res => {
        this.$Loading.finish();
        this.loading = false;
        if (res.Code > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "绑定成功!"
        });
        // this.closeTag(this.$route);
        // this.$emit("on-close", undefined, undefined, this.$route);
        // this.$router.push({
        //   name: "gamespace_rank"
        // });
      });
    }
  }
};
</script>
