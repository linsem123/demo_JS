<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.appname.loading"
              clearable
              filterable
              remote
              :remote-method="handleGameSearch"
              placeholder="请输入游戏名称"
            >
              <Option
                v-for="item in searchform.appname.data"
                :value="item.ID"
                :key="item.ID"
                >{{ item.AppName }}</Option
              >
            </Select>
          </Col>
          <Col span="6">
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </Col>
          <i-col :span="12" align="right">
            <b v-if="$route.query.type == 1">普通榜单</b>
            <b v-if="$route.query.type == 2">排行榜单</b>
            <b v-if="$route.query.type == 3">预约榜单</b>
            <b v-if="$route.query.type == 6">飙升榜单</b>
            <b v-if="$route.query.type == 4">分类榜单</b>
            <b v-if="$route.query.type == 5">标签榜单</b>
            <b v-if="$route.query.type == 9">7天预约榜</b>
          </i-col>
        </Row>
      </div>

      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      >
        <template slot="game" slot-scope="{ row }">
          <Avatar
            shape="square"
            :src="row.AppIcon"
            size="small"
            style="margin-right: 5px"
          ></Avatar>
          <Tag>{{ row.AppName }}</Tag>
        </template>

        <template slot="opt" slot-scope="{ row }">
          <Button
            @click="up(row)"
            type="primary"
            size="small"
            style="margin-right: 6px"
            >置顶</Button
          >

          <template v-if="option === 'button'">
            <Poptip
              confirm
              transfer
              title="你确定要解绑吗？"
              @on-ok="unbind(row)"
            >
              <Button type="error" size="small">解绑</Button>
            </Poptip>
          </template>

          <template v-if="option === 'switch'">
            <i-switch
              size="large"
              :value="row.HideStatus"
              :true-value="false"
              :false-value="true"
              @on-change="changeStatus(row)"
            >
              <span slot="open">显示</span>
              <span slot="close">隐藏</span>
            </i-switch>
          </template>
        </template>
      </Table>

      <div style="margin: 10px; overflow: hidden">
        <div style="float: left">
          <Button
            v-if="option === 'button'"
            type="info"
            style="margin-right: 15px"
            shape="circle"
            icon="md-add"
            @click="openAdd"
            >绑定游戏</Button
          >
          <Button type="default" shape="circle" @click="toRankManage"
            >返回榜单管理</Button
          >
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>

    <!--绑定游戏弹窗-->
    <Modal
      v-model="visible"
      title="绑定游戏"
      :loading="loading"
      @on-ok="handleSubmit"
    >
      <Form
        :model="insideformScope"
        ref="insideformScope"
        :rules="ruleValidate"
        :label-width="130"
      >
        <FormItem label="请选择游戏:" prop="AppID">
          <Select
            v-model="insideformScope.AppID"
            clearable
            filterable
            remote
            :remote-method="handleGameSearch2"
            placeholder="请输入游戏名称"
            @on-change="selectAction"
          >
            <Option v-for="item in apps" :value="item.ID" :key="item.ID">{{
              item.AppName
            }}</Option>
          </Select>
        </FormItem>
        <FormItem label="app包名：">
          {{ pkgName }}
        </FormItem>
      </Form>
    </Modal>
  </div>
</template>

<script>
import GameAPI from "@/api/gamespace/game";
import GameRankAPI from "@/api/gamespace/gamerank";
import SearchConApi from "@/api/gamespace/searchconfig";

import Tables from "_c/tables";
export default {
  name: "game",
  data() {
    return {
      searchform: {
        params: {
          id: undefined,
          PoolID: parseInt(this.$route.params.id),
        },
        page: {
          total: 100,
          current: 1,
          size: 10,
        },
        appname: {
          loading: false,
          data: [],
        },
      },
      table: {
        loading: false,
        data: [],
        columns: [
          { title: "游戏名称", fixed: "left", width: 200, slot: "game" },
          {
            title: "游戏包名",
            width: 250,
            render: (h, params) => {
              return h("Tag", { props: {} }, params.row.PkgName);
            },
          },
          {
            title: "游戏分类",
            width: 200,
            render: (h, params) => {
              return h("Tag", { props: {} }, params.row.CategoryName);
            },
          },
          {
            title: "下载源",
            align: "center",
            fixed: "left",
            width: 100,
            key: "Status",
            render: (h, params) => {
              if (params.row.DownloadSource == 0) {
                return h("Tag", { props: { color: "default" } }, "黑鲨");
              }
              if (params.row.DownloadSource == 1) {
                return h("Tag", { props: { color: "default" } }, "小米");
              }
              if (params.row.DownloadSource == 2) {
                return h("Tag", { props: { color: "default" } }, "应用商店");
              }
            },
          },
          {
            title: "游戏状态",
            align: "center",
            fixed: "left",
            width: 100,
            key: "Status",
            render: (h, params) => {
              if (params.row.Status == 0) {
                return h("Tag", { props: { color: "warning" } }, "待处理");
              }
              if (params.row.Status == 1) {
                return h("Tag", { props: { color: "success" } }, "上架");
              }
              if (params.row.Status == 2) {
                return h("Tag", { props: { color: "error" } }, "下架");
              }
              if (params.row.Status == 3) {
                return h("Tag", { props: { color: "primary" } }, "预约");
              }
            },
          },
          {
            title: "游戏标签",
            width: 200,
            key: "Tags",
            render: (h, params) => {
              let div = [];
              if (params.row.Tags) {
                for (const item of params.row.Tags) {
                  div.push(h("Tag", {}, item));
                }
              }
              return h("div", div);
            },
          },
          {
            title: "版本信息",
            width: 200,
            align: "center",
            render: (h, params) => {
              if (params.row.VersionID == "") {
                return h("Tag", { props: { color: "error" } }, "暂无版本");
              }
              if (params.row.SubType == 0) {
                return h("Tag", { props: { color: "warning" } }, "游戏预约");
              }
              return h("div", [
                h("Tag", {}, params.row.VersionName),
                h("Tag", {}, params.row.VersionCode),
              ]);
            },
          },
          { title: "开发者", width: 200, key: "Provider" },
          {
            title: "操作",
            fixed: "right",
            width: 150,
            slot: "opt",
          },
        ],
        columns1: [
          { title: "游戏名称", width: 200, slot: "game" },
          {
            title: "游戏包名",
            // width: 250,
            render: (h, params) => {
              return h("Tag", { props: {} }, params.row.PkgName);
            },
          },
          {
            title: "游戏状态",
            align: "center",
            width: 100,
            key: "Status",
            render: (h, params) => {
              if (params.row.Status == 0) {
                return h("Tag", { props: { color: "warning" } }, "待处理");
              }
              if (params.row.Status == 1) {
                return h("Tag", { props: { color: "success" } }, "上架");
              }
              if (params.row.Status == 2) {
                return h("Tag", { props: { color: "error" } }, "下架");
              }
              if (params.row.Status == 3) {
                return h("Tag", { props: { color: "primary" } }, "预约");
              }
            },
          },

          { title: "开发者", key: "Provider" },
        ],
      },

      visible: false,
      loading: true,
      insideformScope: {
        RankType: 1,
        AppID: undefined,
      },
      apps: [],
      ruleValidate: {
        AppID: [
          {
            required: true,
            message: "请选择游戏",
            trigger: "blur",
            type: "number",
          },
        ],
      },

      option: "button", // switch: '开关'，button: '按钮执行'
      pkgName: "",
    };
  },
  methods: {
    handleGameSearch(value) {
      GameAPI.LikeApp({ value }).then((res) => {
        this.searchform.appname.data = res.Data;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    openAdd() {
      this.visible = true;
    },
    closeAdd() {
      this.init();
    },
    // 选择app
    selectAction(value) {
      this.pkgName = "";
      this.apps.forEach((item) => {
        if (item.ID == value) {
          this.pkgName = item.PkgName;
        }
      });
    },
    up(params) {
      let poolID = parseInt(this.$route.params.id);
      let type = this.$route.query.type;
      let id;
      if (type == 4 || type == 5) {
        let catrgoryType = type == 4 ? 1 : type == 5 ? 2 : undefined;
        GameRankAPI.Upswitch(params.CategoryID, catrgoryType).then((res) => {
          if (res.Code === 0) {
            this.$Message.success("置顶成功");
          }
          this.init();
        });
      } else {
        if (type == 1) id = params.RankID;
        if (type == 2) id = params.GameRankID;
        if (type == 3) id = params.SubID;
        if (type == 6) id = params.WeekID;
        GameRankAPI.Up(poolID, id).then((res) => {
          if (res.Code === 0) {
            this.$Message.success("置顶成功");
          }
          this.init();
        });
      }
    },
    unbind(params) {
      let poolID = parseInt(this.$route.params.id);
      let type = this.$route.query.type;
      let id;
      if (type == 1) id = params.RankID;
      if (type == 2) id = params.GameRankID;
      if (type == 3) id = params.SubID;
      if (type == 6) id = params.WeekID;
      if (type == 4 || type == 5) id = params.CategoryID;
      GameRankAPI.UnBind(poolID, id).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("解绑成功");
          this.init();
        }
        this.searchform.params.id = undefined;
      });
    },
    init() {
      GameRankAPI.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then((res) => {
        if (res.Code === 0) {
          this.table.data = res.Data.Data || [];
          this.searchform.page.total = res.Data.Count;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },

    toRankManage() {
      this.$router.push({
        name: "gamespace_rankmanage",
        query: {
          type: this.$route.query.type || 1,
        },
      });
    },

    handleGameSearch2(value) {
      GameAPI.LikeApp({ value }).then((res) => {
        this.apps = res.Data;
      });
    },
    handleSubmit() {
      this.$refs["insideformScope"].validate((valid) => {
        if (valid) {
          GameRankAPI.Bind(
            this.$route.params.id,
            this.insideformScope.AppID
          ).then((res) => {
            if (res.Code === 0) {
              // this.visible = false
              this.insideformScope.AppID = undefined;
              this.$Message.success("绑定成功");
              this.init();
              this.loading = false;
              this.$nextTick(() => (this.loading = true));
            } else {
              this.$Message.error(res.Message);
              this.loading = false;
              this.$nextTick(() => (this.loading = true));
            }
          });
        } else {
          this.loading = false;
          this.$nextTick(() => (this.loading = true));
        }
      });
    },

    changeStatus(row) {
      let type = this.$route.query.type;
      let catrgoryType = type == 4 ? 1 : type == 5 ? 2 : undefined;
      let status = !row.HideStatus;
      GameRankAPI.SwitchGamesStatus(row.CategoryID, catrgoryType, status).then(
        (res) => {
          if (res.Code === 0) {
            this.$Message.success("操作成功");
            this.init();
          } else {
            this.$Message.error(res.Message);
          }
        }
      );
    },
  },
  mounted() {
    // this.table.columns = Tables.RenderColumns(this.table.columns, this);
    this.init();
    //注册监听事件
    this.option = this.$route.query.option || "button";
    if (this.$route.query.type == 9) {
      this.table.columns = this.table.columns1;
    }
  },
};
</script>
