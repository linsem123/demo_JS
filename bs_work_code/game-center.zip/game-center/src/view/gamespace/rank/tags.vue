<!--分类榜单的标签管理-->
<template>
    <Card dis-hover="">
      <Row style="margin-bottom: 15px;">
        <Button type="default" shape="circle" @click="back">返回榜单</Button>
      </Row>

      <Table border :data="tagsList" :columns="columns">


        <template slot="opt" slot-scope="{row}">
          <Button @click="showTagGames(row)" type="primary" size="small">标签游戏</Button>

          <Button @click="up(row)" type="info" size="small" style="margin: 0 8px;">置顶</Button>

          <i-switch size="large" :value="row.HideStatus" :true-value="false" :false-value="true"
                    @on-change="changeStatus(row)">
            <span slot="open">显示</span>
            <span slot="close">隐藏</span>
          </i-switch>
        </template>

      </Table>

      <!--<Row style="margin-top: 10px;">
        <Col :span="24" align="right">
          <Page
            :total="page.total"
            :current="page.current"
            :page-size="page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </Col>
      </Row>
-->
    </Card>
</template>

<script>
  import GameRankAPI from "@/api/gamespace/gamerank";

  export default {
    name: '',
    data () {
      return {
        tagsList: [
        ],
        columns: [
          {title: 'ID', key: 'ID'},
          {title: '标签ID', key: 'TagID'},
          {title: '标签名称', key: 'Name'},
          {title: '操作', slot: 'opt'},
        ],
      }
    },
    mounted () {
      this.getList()
    },
    methods: {
      onPageChange(value) {
        this.page.current = value;
        this.getList();
      },
      onPageSizechange(value) {
        this.page.size = value;
        this.getList();
      },

      getList(){
        let id = this.$route.params.id
        GameRankAPI.GetRankTags(id).then(res=>{
          if (res.Code === 0) {
            this.tagsList = res.Data || [];
          } else {
            this.$Message.error(res.Message);
          }
        })
      },

      showTagGames(row) {
        this.$router.push({
          name: 'gamespace_taggames',
          params: {
            CategoryID: this.$route.params.id,
            TagID: row.ID
          },
          query: {
            type: this.$route.query.type
          }
        })
      },

      back () {
        this.$router.push({
          name: 'gamespace_rankmanage',
          query: {
            type: this.$route.query.type || 1
          }
        })
      },

      up (row) {
        GameRankAPI.TagsUp(row.TagID).then(res => {
          if (res.Code === 0) {
            this.$Message.success('置顶成功')
            this.getList()
          } else {
            this.$Message.error(res.Message)
          }
        })
      },

      changeStatus(row) {
        GameRankAPI.TagsStatus(row.TagID, !row.HideStatus).then(res => {
          if (res.Code === 0) {
            this.$Message.success('操作成功')
          }
          this.getList()
        })
      }

    }
  }
</script>

<style scoped>

</style>
