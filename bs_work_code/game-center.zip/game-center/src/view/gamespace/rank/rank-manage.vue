<template>
    <div>
        <Card dis-hover>
            <Row style="margin-bottom: 15px">
                榜单类型：
                <RadioGroup v-model="search.PoolType" type="button" @on-change="getRankListChange">
                    <Radio v-for="item in typeList" :label="item.value" :key="item.value">{{ item.name }}</Radio>
                </RadioGroup>
            </Row>

            <Row
                :gutter="10"
                style="margin-bottom: 15px"
                v-if="
          search.PoolType == 1 || search.PoolType == 4 || search.PoolType == 5
        "
            >
                <i-col :span="5" :xxl="4">
                    <RankSelect v-model="search.RankID"></RankSelect>
                </i-col>
                <Col :span="5" :xxl="4">
                    <Button type="success" shape="circle" icon="ios-search" @click="getRankList">搜索</Button>
                </Col>
            </Row>

            <Table :data="tableData" :columns="columns" border :loading="tableLoading">
                <template slot-scope="{ row, index }" slot="Status">
                    <!--<template v-if="search.PoolType == 4">
              <i-switch :value="row.Status" @on-change="updateStatus(row,$event)" size="large" :true-value="1" :false-value="2">
                <span slot="open">显示</span>
                <span slot="close">隐藏</span>
              </i-switch>
          </template>
          <template v-else>
            <Tag color="success" v-if="row.Status == 1">上架</Tag>
            <Tag color="error" v-else-if="row.Status == 2">下架</Tag>
            <Tag color="warning" v-else>未处理</Tag>
                    </template>-->
                    <Tag color="success" v-if="row.Status == 1">上架</Tag>
                    <Tag color="error" v-else-if="row.Status == 2">下架</Tag>
                    <Tag color="warning" v-else>未处理</Tag>
                </template>
                <template slot-scope="{ row, index }" slot="Opt">
                    <!-- <template v-if="search.PoolType == 4"> -->
                    <Button v-show="search.PoolType == 4" @click="toTags(row)" type="default" size="small" style="margin-right: 10px">分类标签</Button>
                    <!-- </template> -->
                    <Button @click="editTheRank(row)" type="primary" size="small" style="margin-right: 10px">编辑</Button>
                    <Button v-if="row.Status !== 1" @click="updateStatus(row, 1)" type="success" size="small">上架</Button>
                    <Button v-else @click="updateStatus(row, 2)" type="error" size="small">下架</Button>
                    <Button @click="togame(row)" type="info" size="small" style="margin-left: 10px">榜单游戏</Button>
                </template>
            </Table>

            <Row style="margin-top: 10px">
                <Col :span="6">
                    <Button v-if="search.PoolType === 1" @click="editTheRank()" type="info" shape="circle" icon="md-add">新增榜单</Button>
                    <span v-else>&nbsp;</span>
                </Col>
                <Col :span="18" align="right">
                    <Page
                        :total="page.total"
                        :current="page.current"
                        :page-size="page.size"
                        @on-change="onPageChange"
                        @on-page-size-change="onPageSizechange"
                        show-sizer
                        show-total
                    ></Page>
                </Col>
            </Row>
        </Card>

        <Modal v-model="visible" :title="formData.ID ? '编辑' : '新增'">
            <Row>
                <Col :span="21">
                    <Form :model="formData" :rules="rules" :label-width="120" ref="formData">
                        <FormItem label="榜单名称：" prop="Title">
                            <Input v-model="formData.Title" placeholder="请输入榜单名称"></Input>
                        </FormItem>
                        <FormItem label="横版图片:" prop="ImgUrl">
                            <UploadImg v-model="formData.ImgUrl" module="rank"></UploadImg>
                        </FormItem>
                        <FormItem label="竖版图片:" prop="VerticalImgUrl">
                            <UploadImg v-model="formData.VerticalImgUrl" module="rank"></UploadImg>
                        </FormItem>
                        <FormItem label="描述：" prop="Desc">
                            <Input type="textarea" :rows="2" v-model="formData.Desc" placeholder="请输入描述信息"></Input>
                        </FormItem>
                    </Form>
                </Col>
            </Row>
            <template slot="footer">
                <Button @click="visible = false" type="text" size="large">取消</Button>
                <Button @click="submitForm" type="primary" size="large">确定</Button>
            </template>
        </Modal>
    </div>
</template>

<script>
import GameRankAPI from "@/api/gamespace/gamerank";
import SearchConApi from "@/api/gamespace/searchconfig";
import UploadImg from "_c/shark-upload/index";
import RankSelect from "_c/rank-select";

export default {
    name: "",
    components: { UploadImg, RankSelect },
    data() {
        return {
            search: {
                PoolType: parseInt(this.$route.query.type) || 1,
                RankID: undefined
            },
            typeList: [
                { name: "普通榜单", value: 1 },
                { name: "排行榜单", value: 2 },
                { name: "预约榜单", value: 3 },
                { name: "飙升榜单", value: 6 },
                { name: "分类榜单", value: 4 },
                { name: "标签榜单", value: 5 },
                { name: "7天预约榜", value: 9 }
            ],
            page: {
                total: 100,
                current: 1,
                size: 10
            },

            tableData: [],
            columns: [
                { title: "榜单ID", key: "ID", minWidth: 85 },
                { title: "榜单名称", key: "Title", minWidth: 150 },
                { title: "描述信息", key: "Desc", minWidth: 120 },
                { title: "状态", slot: "Status", minWidth: 80 },
                {
                    title: "操作",
                    slot: "Opt",
                    minWidth: 200,
                    align: "center",
                    fixed: "right"
                }
            ],
            tableLoading: false,

            visible: false,
            formData: {},
            rules: {
                Title: [{ required: true, message: "请输入榜单名称", trigger: "blur" }]
            }
        };
    },
    mounted() {
        this.getRankList();
    },
    methods: {
        onPageChange(value) {
            this.page.current = value;
            this.getRankList();
        },
        onPageSizechange(value) {
            this.page.size = value;
            this.getRankList();
        },
        getRankListChange() {
            this.search.RankID = undefined;
            this.getRankList();
        },
        getRankList() {
            let params = {
                Limit: this.page.size,
                Page: this.page.current,
                Params: {
                    PoolType: this.search.PoolType,
                    ID: this.search.RankID
                }
            };
            this.tableLoading = true;
            SearchConApi.GetRankList(params).then(res => {
                if (res.Code === 0) {
                    this.page.total = res.Data.Count;
                    this.tableData = res.Data.Data || [];
                    this.$nextTick(() => {
                        setTimeout(() => {
                            this.tableLoading = false;
                        });
                    });
                }
            });
        },

        editTheRank(item) {
            if (!item) {
                this.formData = {};
            } else {
                this.formData = JSON.parse(JSON.stringify(item));
            }
            this.visible = true;
        },

        submitForm() {
            this.$refs.formData.validate(valid => {
                if (valid) {
                    let params = JSON.parse(JSON.stringify(this.formData));
                    // params.ImgUrl = params.ImgUrl[0] ? params.ImgUrl[0].url : ""
                    console.log(params);
                    this.rankApi(params).then(res => {
                        if (res.Code === 0) {
                            this.visible = false;
                            this.getRankList();
                            this.$Message.success("操作成功");
                            this.formData = {};
                        } else {
                            this.$Message.error(res.Message);
                        }
                    });
                }
            });
        },

        rankApi(params) {
            if (this.formData.ID) {
                return GameRankAPI.EditRank(params);
            } else {
                return GameRankAPI.AddRank(params);
            }
        },

        updateStatus(row, status) {
            GameRankAPI.UpdateRankStatus(row.ID, status).then(res => {
                if (res.Code === 0) {
                    this.getRankList();
                    this.$Message.success("状态更新成功");
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        togame(row) {
            let option = "button";
            if (this.search.PoolType === 4 || this.search.PoolType === 5 || this.search.PoolType === 9) {
                option = "switch";
            }
            this.$router.push({
                name: "gamespace_rank",
                params: {
                    id: row.ID
                },
                query: {
                    option: option,
                    type: this.search.PoolType
                }
            });
        },
        toTags(row) {
            this.$router.push({
                name: "gamespace_ranktag",
                params: {
                    id: row.ResourceID
                },
                query: {
                    type: this.search.PoolType
                }
            });
        }
    }
};
</script>

<style scoped lang="less">
.ivu-radio-group-button .ivu-radio-wrapper-checked {
    /*background: #2d8cf0;*/
    /*color: #fff;*/
}
</style>
