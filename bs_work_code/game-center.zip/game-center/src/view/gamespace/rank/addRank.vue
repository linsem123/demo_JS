<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>添加游戏榜单
    </p>
    <view-form @on-form-submit="handleSubmit"></view-form>
  </Card>
</template>
<script>
  import GameRankAPI from "@/api/gamespace/gamerank";
  import ViewForm from "_c/gamespace/rank/addForm";
  import { mapMutations} from 'vuex'
  export default {
    name: "AddRank",
    components: {
      ViewForm,
    },
    data() {
      return {

      }
    },
    methods: {
      ...mapMutations([
        'closeTag'
      ]),
      handleSubmit(formScope) {
        this.$Loading.start();
        this.loading = true;
        GameRankAPI.AddRank(formScope.Title,formScope.Desc).then(res => {
          this.$Loading.finish();
          this.loading = false;
          if (res.Code > 0) {
            this.$Message.warning(res.Message);
            return;
          }
          this.$Notice.success({
            title: "榜单添加成功!"
          });
          this.closeTag(this.$route);
          this.$router.push({
            name: "gamespace_rank"
          });
        });
      }
    }
  };
</script>
