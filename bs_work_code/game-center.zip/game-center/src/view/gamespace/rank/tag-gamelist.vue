<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.appname.loading"
              clearable
              filterable
              remote
              :remote-method="handleGameSearch"
              placeholder="请输入游戏名称"
            >
              <Option
                v-for="item in searchform.appname.data"
                :value="item.ID"
                :key="item.ID"
              >{{ item.AppName }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
          <i-col :span="12" align="right">
            <b>分类榜单</b>
          </i-col>
        </Row>
      </div>


      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      >

        <template slot="opt" slot-scope="{row}">
          <Button @click="up(row)" type="primary" size="small" style="margin-right: 6px">置顶</Button>

          <i-switch size="large" :value="row.HideStatus" :true-value="false" :false-value="true"
                    @on-change="changeStatus(row)">
            <span slot="open">显示</span>
            <span slot="close">隐藏</span>
          </i-switch>
        </template>


      </Table>


      <div style="margin: 10px;overflow: hidden">
        <div style="float: left">
<!--          <Button type="info" shape="circle" icon="md-add" @click="openAdd">绑定游戏</Button>-->
          <Button type="default" style="margin-left: 15px;" shape="circle" @click="toTagsPage">返回游戏标签</Button>
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>

    <!--绑定游戏弹窗-->
    <Modal v-model="visible" title="绑定游戏" :loading="loading" @on-ok="handleSubmit">
      <Form
        :model="insideformScope"
        ref="insideformScope"
        :rules="ruleValidate"
        :label-width="130"
      >
        <FormItem label="请选择游戏:" prop="AppID">
          <Select
            v-model="insideformScope.AppID"
            clearable
            filterable
            remote
            :remote-method="handleGameSearch2"
            placeholder="请输入游戏名称"
          >
            <Option v-for="item in apps" :value="item.ID" :key="item.ID">{{ item.AppName }}</Option>
          </Select>
        </FormItem>
      </Form>
    </Modal>

  </div>
</template>

<script>
  import GameAPI from "@/api/gamespace/game";
  import GameRankAPI from "@/api/gamespace/gamerank";
  import SearchConApi from '@/api/gamespace/searchconfig'

  import Tables from "_c/tables";
  export default {
    name: "game",
    data() {
      return {
        searchform: {
          params: {
            id: undefined,
            PoolID: parseInt(this.$route.params.id)
          },
          page: {
            total: 0,
            current: 1,
            size: 10
          },
          appname: {
            loading: false,
            data: []
          }
        },
        table: {
          loading: false,
          data: [],
          columns: [
            {
              title: "游戏名称",
              fixed: "left",
              width: 200,
              render: (h, params) => {
                const div = [];
                if (params.row.IconURL != "") {
                  let icon = h("Avatar", {
                    props: {
                      shape: "square",
                      src: params.row.AppIcon,
                      size: "small"
                    },
                    style: {
                      marginRight: "5px"
                    }
                  });
                  div.push(icon);
                }
                if (params.row.ButtonText != "") {
                  let tag = h("Tag", { props: {} }, params.row.AppName);
                  div.push(tag);
                }
                return h("div", div);
              }
            },
            {
              title: "游戏包名",
              width: 250,
              render: (h, params) => {
                return h("Tag", { props: {} }, params.row.PkgName);
              }
            },
            {
              title: "游戏分类",
              width: 200,
              render: (h, params) => {
                return h("Tag", { props: {} }, params.row.CategoryName);
              }
            },
            {
              title: "下载源",
              align: "center",
              fixed: "left",
              width: 100,
              key: "Status",
              render: (h, params) => {
                if (params.row.DownloadSource == 0) {
                  return h("Tag", { props: { color: "default" } }, "黑鲨");
                }
                if (params.row.DownloadSource == 1) {
                  return h("Tag", { props: { color: "default" } }, "小米");
                }
              }
            },
            {
              title: "游戏状态",
              align: "center",
              fixed: "left",
              width: 100,
              key: "Status",
              render: (h, params) => {
                if (params.row.Status == 0) {
                  return h("Tag", { props: { color: "warning" } }, "待处理");
                }
                if (params.row.Status == 1) {
                  return h("Tag", { props: { color: "success" } }, "上架");
                }
                if (params.row.Status == 2) {
                  return h("Tag", { props: { color: "error" } }, "下架");
                }
                if (params.row.Status == 3) {
                  return h("Tag", { props: { color: "primary" } }, "预约");
                }
              }
            },
            {
              title: "游戏标签",
              width: 200,
              key: "Tags",
              render: (h, params) => {
                let div = [];
                if (params.row.Tags) {
                  for (const item of params.row.Tags) {
                    div.push(h("Tag", {}, item));
                  }
                }
                return h("div", div);
              }
            },
            {
              title: "版本信息",
              width: 200,
              align: "center",
              render: (h, params) => {
                if (params.row.VersionID == "") {
                  return h("Tag", { props: { color: "error" } }, "暂无版本");
                }
                if (params.row.SubType == 0) {
                  return h("Tag", { props: { color: "warning" } }, "游戏预约");
                }
                return h("div", [
                  h("Tag", {}, params.row.VersionName),
                  h("Tag", {}, params.row.VersionCode)
                ]);
              }
            },
            { title: "开发者", width: 200, key: "Provider" },
            {
              title: "操作",
              fixed: "right",
              width: 150,
              slot: "opt"
            }
          ]
        },

        visible: false,
        loading: true,
        insideformScope: {
          RankType: 1,
          AppID: undefined
        },
        apps: [],
        ruleValidate: {
          AppID: [{ required: true, message: "请选择游戏", trigger: "blur", type: "number" }]
        }

      };
    },
    methods: {
      handleGameSearch(value) {
        GameAPI.LikeApp({ value }).then(res => {
          this.searchform.appname.data = res.Data;
        });
      },
      onPageChange(value) {
        this.searchform.page.current = value;
        this.init();
      },
      onPageSizechange(value) {
        this.searchform.page.size = value;
        this.init();
      },
      openAdd() {
        this.visible = true
      },
      closeAdd() {
        this.init();
      },
      up(row) {
        GameRankAPI.Upswitch(row.CategoryID, 3).then(res => {
          if (res.Code === 0) {
            this.$Message.success('置顶成功')
          }
          this.init();
        });
      },
      unbind(params) {
        GameRankAPI.UnBind(params.row.RankID).then(res => {
          if (res.Code === 0) {
            this.$Message.success('解绑成功')
            this.init();
          }
          this.searchform.params.id = undefined
        });
      },
      init() {
        GameRankAPI.GetRankTagsGames({
          Limit: this.searchform.page.size,
          Page:  this.searchform.page.current,
          Params: {
            CategoryID: parseInt(this.$route.params.CategoryID),
            TagID: parseInt(this.$route.params.TagID)
          }
        }).then(res => {
          if (res.Code === 0) {
            this.table.data = res.Data.Data || [];
            this.searchform.page.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message)
          }
        });
      },

      toRankManage () {
        this.$router.push({
          name: 'gamespace_rankmanage'
        })
      },


      handleGameSearch2(value) {
        GameAPI.LikeApp({ value }).then(res => {
          this.apps = res.Data;
        });
      },
      handleSubmit() {
        this.$refs["insideformScope"].validate(valid => {
          if (valid) {
            GameRankAPI.Bind(this.$route.params.id,this.insideformScope.AppID).then(res => {
              if (res.Code === 0) {
                this.visible = false
                this.$Message.success('绑定成功')
                this.init()
              } else {
                this.$Message.error(res.Message)
                this.loading = false
                this.$nextTick(()=> this.loading = true)
              }
            });
          } else {
            this.loading = false
            this.$nextTick(()=> this.loading = true)
          }
        });
      },

      toTagsPage () {
        this.$router.push({
          name: 'gamespace_ranktag',
          params: {
            id: this.$route.params.CategoryID
          },
          query: {
            type: this.$route.query.type
          }
        })
      },

      changeStatus(row) {
        let status = !row.HideStatus
        GameRankAPI.SwitchGamesStatus(row.CategoryID,3,status).then(res => {
          if (res.Code === 0) {
            this.$Message.success('操作成功')
            this.init()
          } else {
            this.$Message.error(res.Message)
          }
        })
      }


    },
    mounted() {
      this.table.columns = Tables.RenderColumns(this.table.columns, this);
      this.init();
      //注册监听事件
    },
  };
</script>


