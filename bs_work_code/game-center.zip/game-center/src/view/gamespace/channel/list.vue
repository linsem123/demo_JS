<template>
  <div>
      <Card >
    <div style="margin-bottom: 10px">
         
      <Row :gutter="10">
        <Col span="5">
          <Input v-model="search.models" clearable placeholder="请输入机型"></Input>
        </Col>
                <Col span="5">
          <Input v-model="search.platforms" clearable placeholder="请输入平台"></Input>
        </Col>

                <Col span="5">
          <Input v-model="search.model_ids" clearable placeholder="请输入模块ID"  ></Input>
        </Col>
        <Col span="5">
            <Input v-model="search.channel_code" clearable placeholder="请输入渠道ID"  ></Input>
        </Col>

        <Col span="2">
          <Button type="success" shape="circle" icon="ios-search" @click="getList">搜索</Button>
        </Col>
        <Col span="2" align="right">
          <Button type="primary" icon="ios-search" @click="edit">新增</Button>
        </Col>
      </Row>
    </div>

    <Table :loading="loading" border ref="selection" :columns="columns" :data="tableList">
      <template slot="source_type" slot-scope="{row,index}">
       <div v-for="(item,i) in typeList" :key="i">
           <span  v-if="item.val ==row.source_type">{{item.label}}</span>
       </div>
      </template>
      <template slot="opt" slot-scope="{row,index}">
        <div>
          <Button type="primary" size="small" @click="edit(row)">编辑</Button>
          <Button type="error" size="small" style="margin-left:10px" @click="del(row)">删除</Button>
          <!-- <Button :type="row.source_type==1?'warning':'success'" size="small" style="margin-left:10px" @click="changeStatus(row)">{{row.source_type==1?'下架':'上架'}}</Button> -->

        </div>
      </template>
    </Table>
    <Page
      :total="page.total"
      :current="page.current"
      :page-size="page.size"
      :page-size-opts="[10,20,40,80,100]"
      @on-change="onPageChange"
      @on-page-size-change="onPageSizechange"
      show-sizer
      show-total
    ></Page>
      </Card>
        <Modal v-model="visible" :title="isEdit?'编辑':'新增'" width="800" :loading="loading">
        <!-- <div v-for="(item,i) in params" :key="i"> -->
            <Edit ref="form"  :edit="params"  @form="getform" ></Edit>
        <!-- </div> -->
   
          <template slot="footer">
        <div>
          <Button @click="cancel">取消</Button>
          <Button type="primary" @click="submitModal">确定</Button>
        </div>
      </template>
    </Modal>

  </div>
</template>

<script>
import channelApi from "@/api/gamespace/channelApi";
import Edit from "./edit"
export default {
  data() {
    return {
      loading: false,
      isEdit: false,
      visible: false,
      params:{channel_code:0,min_version:0,max_version:0,priority:0},
      columns: [
         {title:"渠道ID",key:"channel_code"},
        { title: "机型", key: "models", minWidth: 100 },
        { title: "平台", key: "platforms", minWidth: 100 },
 {title:"min_version",key:"min_version"},
  {title:"max_version",key:"max_version"},

        { title: "模块ID", key: "model_ids", minWidth: 100 },
       
        { title: "优先级", key: "priority", minWidth: 120 },
        { title: "操作", slot: "opt", width: 160 },
      ],
      tableList: [],
      typeList:[{val:0,label:"未知"},{val:1,label:"腾讯游戏"},{val:2,label:"小米联运"},{val:3,label:"黑鲨联运"},{val:4,label:"全部"},],
      search: {},
      page: {
        current: 1,
        size: 10,
        total: 0,
      },

    };
  },
  mounted() {
    this.getList();
  },
  watch: {
      search:{
          handler(v,o){
           if(v.channel_code||v.models||v.platforms||v.model_ids){
               this.page.current=1
           }
           if(v.channel_code){
             this.search.channel_code=Number(v.channel_code)
           }
          },immediate:true
      },
      visible(v,o){
         if(!v){
             this.params = {channel_code:0,min_version:0,max_version:0,priority:0}
         }
      }
  },
  components:{
      Edit
  },
  methods: {
    onPageChange(value) {
      this.page.current = value;
      this.getList();
    },
    onPageSizechange(value) {
      this.page.size = value;
      this.page.current = 1
      this.getList();
    },
    edit(row){
         this.isEdit= false
          // this.params={}
     if(row.ID){
                for(var k in row){
                      if(k=="models" ||k=="platforms"){
                        this.params[k]=row[k].split(",")
                        }
                     else{
                      
                       this.params[k] = row[k]
                     }
                     this.isEdit = true
       }
       console.log(this.params)
        
     

         
     }
     this.visible=true
    },
    del(row){
      console.log(row)
              let _this=this
            this.$Modal.confirm({title:"删除提醒",content:"您确定要删除渠道ID为 <span style='color:red'>"+row.channel_code+"</span> 的渠道吗？",okText:"删除",
                cancelText:"再考虑",onOk(){
                channelApi.deletes(row.ID).then(res=>{
                        if (res.Code == 0) {
                            this.$Message.success("删除成功")
                            _this.getList()
                        }
                })
            }})
    },
    getform(row){
      console.log(row.form)
        this.params= row.form

         

    },
    cancel(){
        this.visible= false
    },
    submitModal() {
        // this.$refs.form.$refs.formData.validate((valid) => {
        // if (valid) {
        //     this.params.source_type=Number(this.params.source_type)
       let params ={}
       for(var k in this.params){
                      if(k=="models" ||k=="platforms"){
                        console.log(this.params[k])
                        params[k]=this.params[k].join(",")
                        }else if(k=="model_ids"){params[k] = this.params[k].replace(/，/g,",")}
                     else{
                       params[k] = this.params[k]
                     }
       }
        console.log()
          if (this.isEdit) {
            //   params[""]
            
            channelApi.Edit(params).then((res) => {
              if (res.Code == 0) {
                this.visible = false;
                this.getList();
                this.$Message.success("编辑"+res.Message);
              }else{
                  this.$Message.error(res.Message);
              } 
            });
          } else {
              
            channelApi.add(params).then((res) => {
              if (res.Code == 0) {
                this.visible = false;
                this.getList();
                this.$Message.success("新增"+res.Message);
              }else{
                   this.$Message.error(res.Message);
              }
            });
          }
        // } else {
        //   this.visible = true;
        // }
    //   });
    },
    getList() {
        const params = new URLSearchParams();
        for(var k in this.search){
           if(k=="source_type"){
              params.append(k, this.search[k]||4);
           }else{
           params.append(k, this.search[k]||"");
           }
        }
            params.append('page', this.page.current);
            params.append('limit', this.page.size);

      channelApi.List(params).then((res) => {
        if (res.Code == 0) {
          this.tableList = res.Data.channels;
          this.page.total = res.Data.size;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>

 <style lang="less" scoped>
.icon {
  width: 36px;
  display: block;
  margin: 0 auto;
}
</style>
