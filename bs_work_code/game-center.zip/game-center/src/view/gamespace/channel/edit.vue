<template>
      <Form ref="formData" :model="formData"  :label-width="80">
        <Row  > 
          <Col span="12">
            <FormItem label="机型：" prop="models">
             <Select v-model="formData['models']" multiple >
               <Option value="*">全部</Option>
                <Option v-for="(item,i) in modelList" :value="item" :key="i">{{ item }}</Option>
             </Select>
            </FormItem>
          </Col>

          <Col span="12">
            <FormItem label="平台：" prop="platforms">
                           <Select v-model="formData['platforms']" multiple >
                             <Option value="*"  >全部</Option>
                <Option v-for="(item,i) in platforms" :value="item" :key="i" >{{ item }}</Option>
             </Select>

            </FormItem>
          </Col>
           </Row>
           <Row  > 
                    <Col span="12">
            <FormItem label="模块ID：" prop="model_ids">
               <Input v-model="formData['model_ids']" placeholder="请输入模块ID"></Input>
                           <!-- <Select v-model="formData['platforms']" multiple >
                             <Option value="*"  >全部</Option>
                <Option v-for="(item,i) in platforms" :value="item" :key="i" >{{ item }}</Option>
             </Select> -->

            </FormItem>
          </Col>
                    <Col span="12">
            <FormItem label="渠道ID：" prop="channel_code">
              <InputNumber v-model="formData['channel_code']" placeholder="请输入渠道ID"></InputNumber>
            </FormItem>
          </Col>
 </Row>
           <Row  > 
                    <Col span="8">
            <FormItem label="最小版本：" prop="min_version">
              <InputNumber v-model="formData['min_version']" placeholder="请输入最小版本"></InputNumber>
            </FormItem>
          </Col>
                    <Col span="8">
            <FormItem label="最大版本：" prop="max_version">
              <InputNumber v-model="formData['max_version']" placeholder="请输入最大版本"></InputNumber>
            </FormItem>
          </Col>
                    <Col span="8">
            <FormItem label="优先级：" prop="priority">
              <InputNumber v-model="formData['priority']" placeholder="请输入优先级"></InputNumber>
            </FormItem>
          </Col>
        </Row>
      </Form>
</template>

<script>
import channelApi from "@/api/gamespace/channelApi";

export default {
    data() {
        return {
          modelList:[],
          platforms:[],
            formData:{},

            // rules: {
            //     pkg_name: [{ required: true, message: "请输入包名", trigger: "blur" }],
            //     app_name: [{ required: true, message: "请输入应用名", trigger: "blur" }],
            // },
    
        }
    },
    props:["edit","index"],
    watch: {
        formData:{
            handler(v,o){
              console.log(v)
                if(v){
                  this.$emit("form",{index:this.index,form:v})
                  this.formData =v
                }
            
            },
            immediate: true,
        },
        edit:{
            handler(v,o){
                if(v){
                    this.formData=v
                }
                
            },
            immediate: true,
        }
    },
    mounted() {
      this.getConfig()
    },
    methods: {
      getConfig(){
        channelApi.getconfig().then(res=>{
          console.log(res)
          if(res.Code==0){
             this.modelList= res.Data.models
             this.platforms = res.Data.platforms
          }
           
        })
      },
    },
}
</script>

<style lang="less" scoped>
.icon{
    font-size: 22px;
    line-height: 33px;
    color: red;
}
    .ios-add-circle-outline{
        color: #00c030;
    }

</style>
