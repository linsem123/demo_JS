<!--优惠券任务-->
<template>
  <div>
    <Card>
      <Row style="margin: 10px 0 15px;" :gutter="10">
        <Col span="4">
          <Input v-model="search.id" placeholder="请输入优惠券ID"></Input>
        </Col>
        <Col span="4">
          <Input v-model="search.title" placeholder="请输入优惠券名称"></Input>
        </Col>

        <Col span="16">
          <Button type="primary" @click="onSearch()">查询</Button>
        </Col>
      </Row>

      <Table border :columns="columns" :data="tableData">
        <template slot="ActType" slot-scope="{row, index}">
          <div v-for="(item,i) in actType" :key="i">
            <span v-if="row.ActType == item.value">{{item.label}}</span>
          </div>
        </template>
        <template slot="EndTime" slot-scope="{row, index}">
          <div>{{timeFormat(row.EndTime)}}</div>
        </template>
        <template slot="StartTime" slot-scope="{row, index}">
          <div>{{timeFormat(row.StartTime)}}</div>
        </template>
        <template slot="opt" slot-scope="{row, index}"></template>
      </Table>

      <div style="margin: 10px 0;overflow: hidden">
        <div style="float: left">
          <Button type="info" shape="circle" icon="md-add" @click="createCoupon">新增优惠券任务</Button>
        </div>
        <div style="float: right">
          <Page
            :total="page.total"
            :current="page.current"
            :page-size="page.size"
            :page-size-opts="[10,20,40,80,100]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>

    <!-- 新增，编辑弹窗   -->
    <Modal
      v-model="editVisible"
      :title="editFormData.ID ? '编辑' :  '新增'"
      :loading="editFormLoading"
      @on-ok="submitFormData"
      :mask-closable="false"
      width="600px"
    >
      <Row>
        <Col :span="21">
          <TaskForm ref="editForm" v-model="editFormData"></TaskForm>
        </Col>
      </Row>
    </Modal>
  </div>
</template>

<script>
import TaskForm from "./task-form";
import expandRow from "./table-expand.vue";
import { formatTime } from "@/libs/tools";
import couponApi from "@/api/gamespace/coupon";

export default {
  name: "",
  data() {
    return {
      search: {},
      page: {
        current: 1,
        size: 10,
        total: 0,
      },
      actType: [
        { value: 1, label: "首次登陆-优惠券" },
        { value: 2, label: "累计登陆-优惠券" },
        { value: 4, label: "充值指定金额-优惠券" },
        { value: 6, label: "首次登陆-礼包" },
        { value: 7, label: "累计登陆-礼包" },
        { value: 9, label: "充值指定金额-礼包" },
        { value: 11, label: "充值包含优惠券送礼包" },
        { value: 12, label: "vip赠送" },
        { value: 13, label: "vip升级赠送" },
      ],
      columns: [
        {
          type: "expand",
          title: "规则",
          minWidth: 30,
          render: (h, params) => {
            return h(expandRow, {
              props: {
                row: params.row,
              },
            });
          },
        },
        { title: "任务ID", key: "ID", minWidth: 70 },
        { title: "AppId", key: "AppId", minWidth: 85 },
        { title: "任务名称", key: "Title", minWidth: 120 },
        { title: "任务类型", slot: "ActType", minWidth: 150 },
        { title: "开始时间", slot: "StartTime", minWidth: 100 },
        { title: "结束时间", slot: "EndTime", minWidth: 100 },
        //   {title: '操作', slot: 'opt', fixed: 'right', align: 'left', width: 220},
      ],
      tableData: [],

      // 新增编辑的表单数据
      editVisible: false,
      editFormLoading: true,
      editFormData: {},
    };
  },
  components: { TaskForm },
  mounted() {
    this.init();
  },
  methods: {
    timeFormat(date) {
      return formatTime(date);
    },
    onPageChange(value) {
      this.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.page.size = value;
      this.init();
    },

    init() {
      let pm = Object.assign(
        {},
        {
          Params: {
            id: this.search.id || null,
            title: this.search.title || null,
          },
        },
        { Limit: this.page.size, Page: this.page.current }
      );
      couponApi.CouponTaskList(pm).then((res) => {
        if (res.Code === 0) {
          this.page.total = res.Data.Count;
          this.tableData = res.Data.Data || [];
        } else {
          this.$Message.error(res.Message);
        }
      });
    },

    onSearch() {
      this.page.current = 1;
      this.init();
    },

    editRow(row) {
      this.editVisible = true;
      this.editFormData = JSON.parse(JSON.stringify(row));
    },

    /*提交编辑或新增*/
    submitFormData() {
      console.log(this.editFormData);

      this.$refs.editForm.$refs.form.validate((valid) => {
        console.log(valid);
        if (valid) {
          let params = this.editFormData;

          if (params.ID) {
            // this.subEdit()
            console.log(JSON.parse(JSON.stringify(params)));
            couponApi.EditCoupon(params).then((res) => {
              if (res.Code === 0) {
                this.init();
                this.editFormLoading = false;
                this.editVisible = false;
                this.$Message.success("编辑成功");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            // this.subAdd()
            console.log(params);
            if (params.CouponScopeType == 3) {
              params.AppIDs = [params.AppIDs];
            }
            couponApi.CouponTaskAdd(params).then((res) => {
              if (res.Code === 0) {
                this.init();
                this.editFormLoading = false;
                this.editVisible = false;
                this.$Message.success("新增成功");
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        } else {
          this.editFormLoading = false;
          this.$nextTick(() => {
            this.editFormLoading = true;
          });
        }
      });
    },

    // 点击添加优惠券
    createCoupon() {
      this.editVisible = true;
      this.editFormData = {
        ActType: 1,
        Rules: [
          { CouponId: 0, GiftId: 0, Amount: 0, LoginTimes: 0, VipLevel: 1 },
        ],
      };
    },
  },
};
</script>

<style scoped>
</style>
