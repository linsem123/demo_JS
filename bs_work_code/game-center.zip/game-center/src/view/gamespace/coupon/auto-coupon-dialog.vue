<template>
	<!-- 新增，编辑弹窗   -->
	<Modal
		v-model="editVisible"
		width="700px"
		:loading="loading"
		:title="couponForm.Id ? '编辑' : '新增'"
		:mask-closable="false"
		:footer="null"
		@on-cancel="cancelSubmmit"
	>
		<Form
			ref="couponForm"
			:model="couponForm"
			:rules="rules"
			:label-width="140"
		>
			<FormItem
				label="任务名称"
				prop="TaskName"
			>
				<Input
					class="inputStyle"
					v-model="couponForm.TaskName"
					placeholder="请输入任务名称"
				></Input>
			</FormItem>
			<FormItem
				label="基础优惠券"
				prop="CouponId"
			>
				<Input
					class="inputStyle"
					v-model="couponForm.CouponId"
					placeholder="请输入优惠券ID"
				></Input>
			</FormItem>
			<FormItem
				label="任务周期"
				prop="TaskStart"
			>
				<Row>
					<i-col :span="9">
						<DatePicker
							:value="couponForm.TaskStart"
							format="yyyy-MM-dd HH:mm:ss"
							type="datetime"
							placeholder="请设置开始时间"
							:editable="false"
							@on-change="changeStart"
						></DatePicker>
					</i-col>
					<i-col
						:span="9"
						offset="1"
					>
						<DatePicker
							:value="couponForm.TaskEnd"
							format="yyyy-MM-dd HH:mm:ss"
							type="datetime"
							placeholder="请设置结束时间"
							:editable="false"
							@on-change="changeEnd"
						></DatePicker>
					</i-col>
				</Row>
			</FormItem>
			<FormItem
				label="任务循环方式"
			> <template>
					<DatePicker
						type="month"
						size="small"
						clearable
						placeholder="请选择月"
						style="width: 120px"
						v-model="circlyMonth"
						:options="options"
						@on-change="circlyMonthChange"
					></DatePicker><span class="margin10">&nbsp;月</span>
				</template>
				<template>
					<Select
						size="small"
						style="width: 120px"
						placeholder="请选择日"
						v-model="couponForm.TaskPeriod.Day"
                        clearable
					>
						<Option
							v-for="item in days"
							:value="item"
							:key="item"
						>{{ item }}</Option>
					</Select>
					日&nbsp;&nbsp;
				</template>
				<template>
					周
					<Select
						size="small"
						class="weekSelect"
						multiple
						placeholder="请选择周"
						v-model="couponForm.TaskPeriod.Week"
					>
						<Option
							v-for="item in weekList"
							:value="item.id"
							:key="item.id"
						>{{ item.label }}</Option>
					</Select>
				</template>
				<template>
					<TimePicker
						size="small"
						format="HH:mm"
						placeholder="选择时间"
						style="width: 112px"
						v-model="circlyTime"
						@on-change="circlyTimeChange"
					></TimePicker>
				</template>
				<div class="timeTip">
					*任务循环方式配置参考案例：<br />
					-月 1日 周- 14时 30分：每月1号14：30<br />
					-月 -日 周- 10时 -分：每天10：00<br />
					-月 -日 周6 12时 -分：每周六12：00<br />
					2月 -日 周3 12时 30分：二月每周三12：30<br />
					-月 -日 周1-5 15时 -分：周一至周五每天15：00<br />
				</div>
			</FormItem>
			<FormItem
				label="优惠券的'领取有效期'"
				prop="ReceivableStartTime"
			>
				<Row>
					<i-col :span="9">
						开始时间
						<TimePicker
							v-model="couponForm.ReceivableStartTime"
							size="small"
							format="HH:mm"
							placeholder="选择时间"
							clearable
							style="width: 100px"
							@on-change="expiredTimeChange"
						></TimePicker>
					</i-col>
					<i-col
						:span="9"
						offset="1"
					>
						结束时间
						<InputNumber
							:min="1"
							size="small"
							v-model="couponForm.ReceivableLastHour"
						></InputNumber> 小时
					</i-col>
				</Row>
			</FormItem>
			<FormItem
				label="优惠券的'使用有效期'"
				prop="ExpiredStart"
			>
				<RadioGroup v-model="couponForm.CouponExpType" @on-change="expChange">
					<Radio :label="1">
						时间段内有效
					</Radio>
					<Radio :label="2">
						领取后有效
					</Radio>
				</RadioGroup>
				<div>
					<template v-if="couponForm.CouponExpType == 1">
						<Row>
							<i-col :span="9">
								开始时间
								<TimePicker
									v-model="couponForm.ExpiredStart"
									size="small"
									format="HH:mm"
									clearable
									placeholder="选择时间"
									style="width: 100px"
									@on-change="useTimeChange"
								></TimePicker>
							</i-col>
							<i-col
								:span="9"
								offset="1"
							>
								结束时间
								<InputNumber
									:min="1"
									size="small"
									v-model="couponForm.ExpiredLastHour"
								></InputNumber> 小时
							</i-col>
						</Row>
					</template>
					<template v-if="couponForm.CouponExpType == 2">
						<InputNumber
							:min="0"
							size="small"
							v-model="couponForm.UseCycle"
						></InputNumber> 天有效
					</template>
				</div>
			</FormItem>
		</Form>
		<template slot="footer">
			<Button @click="cancelSubmmit">取消</Button>
			<Button
				type="primary"
				:disabled="this.couponForm.TaskStatus == 1"
				@click="handleSubmit"
			>确定</Button>
		</template>
	</Modal>
</template>

<script>
import couponApi from '@/api/gamespace/coupon'
import { formatTimes } from '@/libs/tools'
export default {
	data() {
		const checkDate = (rule, value, callback) => {
			if (!this.couponForm.TaskStart || !this.couponForm.TaskEnd) {
				callback('请设置任务周期')
			}
			if (this.couponForm.TaskStart >= this.couponForm.TaskEnd) {
				callback('任务周期开始时间必须小于结束时间')
			}
			callback()
		}
		const checkReceiveTime = (rule, value, callback) => {
			if (!this.couponForm.ReceivableStartTime) {
				callback('请设置开始时间')
				return
			}
			callback()
		}
		const checkUseTime = (rule, value, callback) => {
			if (this.couponForm.CouponExpType == 1 && !this.couponForm.ExpiredStart && !this.couponForm.ExpiredLastHour) {
				callback('请设置开始时间')
			} else if (this.couponForm.CouponExpType == 2 && !this.couponForm.UseCycle) {
				callback('请设置领取时间')
			}
			callback()
		}
		return {
			editVisible: false,
			circlyMonth: '', // 任务循环周期的月
			circlyTime: '', // 任务循环周期的时间
			loading: false,
			days: 31,
			couponForm: {
				Id: 0,
                TaskName: '',
				CouponId: '',
				ExpiredStart: '',
				CouponExpType: 1,
				TaskStatus: 0,
                CreatedAt: '',
                TaskEnd: '',
				TaskPeriod: {
					Week: [],
					Day: '',
                    Hour: 0,
                    Minute: 0
				},
                UseCycle: 0
			},
			rules: {
				TaskName: [
					{
						required: true,
						message: '请填写任务名称',
						trigger: 'blur',
					},
				],
				CouponId: [
					{
						required: true,
						message: '请填写优惠券ID',
						trigger: 'blur',
					},
				],
				TaskStart: [
					{
						required: true,
						validator: checkDate,
						trigger: 'blur'
					},
				],
				expiredStartTime: [
					{
						required: true,
						validator: checkReceiveTime,
						trigger: 'change',
						type: 'date',
					},
				],
				ExpiredStart: [
					{
						required: true,
						validator: checkUseTime,
						trigger: 'change',
						type: 'date',
					},
				],
			},
			weekList: [
				{
					id: 1,
					label: '一',
				},
				{
					id: 2,
					label: '二',
				},
				{
					id: 3,
					label: '三',
				},
				{
					id: 4,
					label: '四',
				},
				{
					id: 5,
					label: '五',
				},
				{
					id: 6,
					label: '六',
				},
				{
					id: 7,
					label: '日',
				},
			],
			options: {
				disabledDate: date => {
					return date && this.nowYear != formatTimes(date).substring(0, 4)
				},
			},
		}
	},
	computed: {
		nowYear() {
			return formatTimes(new Date()).substring(0, 4)
		},
	},
	watch: {},
	methods: {
		// 取消提交
		async cancelSubmmit() {
			await this.$emit('getList')
			this.editVisible = false
		},
		// 确认提交
		handleSubmit() {
			this.$refs['couponForm'].validate(valid => {
				if (valid) {
                    this.couponForm.CouponId = +this.couponForm.CouponId
                    this.couponForm.TaskPeriod.Hour = this.couponForm.TaskPeriod.Hour ? +this.couponForm.TaskPeriod.Hour : 0
                    this.couponForm.TaskPeriod.Minute = this.couponForm.TaskPeriod.Minute ? +this.couponForm.TaskPeriod.Minute : 0
                    this.couponForm.TaskPeriod.Month = this.couponForm.TaskPeriod.Month ? +this.couponForm.TaskPeriod.Month : 0
                    this.couponForm.TaskPeriod.Day = this.couponForm.TaskPeriod.Day ? +this.couponForm.TaskPeriod.Day : 0
					this.loading = true
					couponApi
						.saveAutoCoupon(this.couponForm)
						.then(res => {
							if (res.Code == 0) {
								this.$emit('getList')
								this.editVisible = false
							} else {
								this.loading = false
								this.$Message.error(res.Message)
							}
						})
						.finally(() => {
							this.loading = false
						})
				} else {
                    this.$Message.error('请填写必要信息')
                }
			})
		},
		// 任务循环周期时间变化
		circlyTimeChange(value) {
			let hour = value.split(':')[0]
			let minute = value.split(':')[1]
			this.couponForm.TaskPeriod.Hour = hour ? this.formateNumber(hour) : 0
			this.couponForm.TaskPeriod.Minute = minute ? this.formateNumber(minute) : 0
		},
		// 任务循环周期月变化
		circlyMonthChange(value) {
			let month = value.substring(5)
			this.couponForm.TaskPeriod.Month = month ? this.formateNumber(month) : ''
			this.calcDays()
		},
		// 01转换为1
		formateNumber(value) {
			return value.indexOf(0) == 0 ? Number(value.substring(1)) : value
		},
		// 使用有效期选择时间
		useTimeChange(time) {
			this.couponForm.ExpiredStart = time
		},
		// 领取有效期选择时间
		expiredTimeChange(time) {
			this.couponForm.ReceivableStartTime = time
		},
		setData(data) {
			this.$refs.couponForm.resetFields()
			if (data) {
				this.circlyTime = data.TaskPeriod.Hour + ':' + data.TaskPeriod.Minute
				this.circlyMonth = data.TaskPeriod.Month ? this.nowYear + '-' + data.TaskPeriod.Month : ''
				Object.assign(this.couponForm, data)
				this.couponForm.CouponId = this.couponForm.CouponId.toString()
				this.calcDays()
			} else {
				this.couponForm = {
                    CouponId: '',
					Id: 0,
					TaskPeriod: {
						Week: [],
						Day: '',
                        Hour: 0,
                        Minute: 0
					},
                    TaskEnd: '',
                    ExpiredStart: '',
                    ReceivableStartTime: '',
                    UseCycle: 0,
                    CreatedAt: '',
					TaskStart: '',
                    TaskName: '',
					TaskStatus: 0,
					ExpiredLastHour: 0,
					CouponExpType: 1,
                    ReceivableLastHour: 0
				}
                this.circlyMonth = '' // 任务循环周期的月
                this.circlyTime = ''// 任务循环周期的时间
			}
		},
		// 开始时间
		changeStart(time) {
			this.couponForm.TaskStart = time
		},
		// 结束时间
		changeEnd(time) {
			this.couponForm.TaskEnd = time
		},
        expChange (val) {
            if (val == 1) {
                this.couponForm.UseCycle = 1
            } else {
                this.couponForm.ExpiredStart = ''
                this.couponForm.ExpiredLastHour = 1
            }
        },
		calcDays() {
			let isRun = false
			this.days = 30
			let month =
				this.couponForm.TaskPeriod && this.couponForm.TaskPeriod.Month
					? this.couponForm.TaskPeriod.Month
					: 1
			if (this.nowYear % 400 == 0 || (this.nowYear % 4 == 0 && this.nowYear % 100 != 0)) {
				isRun = true
			}
			if (
				month == 1 ||
				month == 3 ||
				month == 5 ||
				month == 7 ||
				month == 8 ||
				month == 10 ||
				month == 12
			) {
				// 1、3、5、7、8、10、12 每月31天
				this.days = 31
			} else if (month == 2) {
				if (isRun) {
					// 为闰年，则多一天为29天
					this.days = 29
				} else {
					this.days = 28
				}
			} else if (month == 4 || month == 6 || month == 9 || month == 11) {
				// 4、6、9、10、11
				this.days = 30
			}
		},
	},
}
</script>

<style lang="less" scoped>
.inputStyle {
	width: 200px;
}
.margin10 {
	margin-right: 10px;
}
.weekSelect {
	width: 150px;
	margin-right: 15px;
}
.timeTip {
	line-height: 1.5;
	font-size: 12px;
	color: rgba(0, 0, 0, 0.5);
	margin-top: 10px;
}
</style>