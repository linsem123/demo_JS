<!--新增，编辑弹窗内的表单-->
<template>
  <Form ref="form" :model="formData" :rules="rules" :label-width="140">
    <form-item label="游戏ID：" prop="AppId">
      <Input v-model="formData.AppId" placeholder="请输入游戏ID"></Input>
    </form-item>
    <form-item label="任务名称：" prop="Title">
      <Input v-model="formData.Title" placeholder="请输入任务名称"></Input>
    </form-item>
    <form-item label="任务类型：" prop="ActType">
      <Select v-model="formData.ActType" placeholder="请选择游戏">
        <Option v-for="(item, i) in actType" :key="i" :value="item.value">{{item.label}}</Option>
      </Select>
    </form-item>
    <form-item label="任务规则：" prop="Rules">
      <div v-for="count in num" :key="count">
        <Row class="m10">
          <Col :span="10" v-if="formData.ActType < 5 ||formData.ActType==12||formData.ActType==13">
            <Col v-if="count==1">优惠券ID：</Col>
            <Col :span="10">
              <InputNumber
                v-model="formData.Rules[count-1]['CouponId']"
                placeholder="请输入优惠券ID"
                style="display: inline-block; min-width:120px"
              ></InputNumber>
            </Col>
          </Col>
          <Col :span="10" v-if="formData.ActType > 5&&formData.ActType < 12">
            <Col v-if="count==1">礼包ID：</Col>
            <Col :span="10">
              <InputNumber
                v-model="formData.Rules[count-1]['GiftId']"
                placeholder="请输入礼包ID"
                style="display: inline-block; min-width:120px"
              ></InputNumber>
            </Col>
          </Col>
          <Col :span="10" v-if="formData.ActType==2||formData.ActType==7">
            <Col v-if="count==1">登陆次数：</Col>
            <Col :span="24" align="left">
              <InputNumber
                v-model="formData.Rules[count-1]['LoginTimes']"
                placeholder="请输入第几次登陆"
                style="display: inline-block; min-width:60px "
              ></InputNumber>
            </Col>
          </Col>
          <Col :span="10" v-if="formData.ActType==4||formData.ActType==9||formData.ActType==11">
            <Col v-if="count==1">充值金额：</Col>
            <Col :span="24" align="left">
              <InputNumber
                v-model="formData.Rules[count-1]['Amount']"
                placeholder="请输入充值金额"
                style="display: inline-block; min-width:80px "
              ></InputNumber>
            </Col>
          </Col>
          <Col :span="10" v-if="formData.ActType==12||formData.ActType==13">
            <Col v-if="count==1">vip等级：</Col>
            <Col :span="24" align="left">
              <InputNumber
                v-model="formData.Rules[count-1]['VipLevel']"
                placeholder="请输入vip等级"
                style="display: inline-block; min-width:80px "
              ></InputNumber>
            </Col>
          </Col>

          <Col :span="4">
            <Col :span="24" v-if="count==1">操作</Col>
            <Col :span="24">
              <Icon
                class="margin"
                size="18"
                color="#2db7f5"
                type="md-add-circle"
                @click="addInput(count)"
              />
              <Icon size="18" color="#5cadff" @click="delInput(count-1)" type="md-trash" />
            </Col>
          </Col>
        </Row>
      </div>
    </form-item>

    <form-item label="开始日期：" prop="StartTime">
      <Row>
        <i-col :span="11">
          <DatePicker
            v-model="formData.StartTime"
            type="datetime"
            placeholder="请设置开始时间"
            style="width: 100%"
          ></DatePicker>
        </i-col>
      </Row>
    </form-item>
    <form-item label="结束日期：" prop="EndTime">
      <Row>
        <i-col :span="11">
          <DatePicker
            v-model="formData.EndTime"
            type="datetime"
            placeholder="请设置结束时间"
            style="width: 100%"
          ></DatePicker>
        </i-col>
      </Row>
    </form-item>
  </Form>
</template>

<script>
import GameApi from "@/api/gamespace/game";
import couponApi from "@/api/gamespace/coupon";

export default {
  name: "",
  props: ["value"],
  model: {
    prop: "value",
    event: "change",
  },
  data() {
    return {
      formData: {},
      num: 1,
      actType: [
        { value: 1, label: "首次登陆-优惠券" },
        { value: 2, label: "累计登陆-优惠券" },
        { value: 4, label: "充值指定金额-优惠券" },
        { value: 6, label: "首次登陆-礼包" },
        { value: 7, label: "累计登陆-礼包" },
        { value: 9, label: "充值指定金额-礼包" },
        { value: 11, label: "充值包含优惠券送礼包" },
        { value: 12, label: "vip赠送" },
        { value: 13, label: "vip升级赠送" },
      ],
      rules: {
        //   AppId: [{required: true,message: '请填写AppId', trigger: 'blur'}],
        //   Title: [{required: true, message: '请填写任务名称', trigger: 'blur'}],
        //   ActType: [{required: true,type:Number, message: '请填写任务名称', trigger: 'blur'}],
        //   StartTime: [{required: true, message: '请填写开始日期', trigger: 'change'}],
      },

      // gameLoading: false,
      // gamesList: []
    };
  },
  watch: {
    formData: {
      handler(val, old) {
        this.$emit("change", this.formData);
      },
      immediate: true,
    },

    value() {
      this.formData = this.value;
      // 非所有游戏且游戏列表有数据
      // if (this.formData.CouponScopeType > 1 && this.formData.AppIDs.length > 0) {
      //   this.initGamesList()
      // }
    },
  },
  mounted() {
    this.formData = this.value;
  },
  methods: {
    addInput() {
      this.num++;
      this.formData.Rules.push({
        CouponId: 0,
        GiftId: 0,
        Amount: 0,
        LoginTimes: 0,
        VipLevel: 1,
      });
    },
    add() {
      this.visible = true;
      this.num = 1;
      this.formData = {
        ActType: formData.ActType,
        Rules: [
          { CouponId: 0, GiftId: 0, Amount: 0, LoginTimes: 0, VipLevel: 1 },
        ],
      };
    },
    delInput(i) {
      if (this.num > 1) {
        this.num--;
        this.formData.Rules.splice(i, 1);
      }
    },
  },
};
</script>

<style scoped>
.m10 {
  padding-bottom: 10px;
}
</style>
