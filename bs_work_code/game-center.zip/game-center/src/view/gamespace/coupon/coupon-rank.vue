<!--优惠券榜单-->
<template>
  <div>
    <Card>

      <Table :columns="columns" :data="tableData" border>
        <template slot="numbers" slot-scope="{row , index}">
          {{row.UsedCount}} / {{row.CouponCount}} / {{row.CouponTotalCount}}
        </template>
        <template slot="expiredEnd" slot-scope="{row , index}">
          {{formatTime(row.ExpiredEnd)}}
        </template>
        <template slot="opt" slot-scope="{row , index}">
          <Button size="small" @click="remove(row)" type="error">移除</Button>
          <Button size="small" @click="viewDetail(row)" type="primary" style="margin-left: 6px;">查看</Button>
          <Button size="small" @click="toTop(row)" type="warning" style="margin-left: 6px;">置顶</Button>
        </template>
      </Table>

      <div style="margin: 10px 0;overflow: hidden">
        <div style="float: right">
          <Page
            :total="page.total"
            :current="page.current"
            :page-size="page.size"
            :page-size-opts="[10,20,40,80,100]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>

    </Card>




    <!--查看 弹窗-->
    <Modal v-model="detailVisible" title="查看" width="600px">
      <Row>
        <Col :span="21"><DetailForm v-model="detailFormData"></DetailForm></Col>
      </Row>
    </Modal>


  </div>
</template>

<script>
  import couponApi from '@/api/gamespace/coupon'
  import {formatTime} from '@/libs/tools'
  import DetailForm from './detail-form'

  export default {
    name: '',
    components: {DetailForm},
    data () {
      return {
        search: {},
        page: {
          current: 1,
          size: 10,
          total: 0
        },

        columns: [
          {title: '序号', type: 'index', width: 80, align: 'center'},
          {title: '优惠券ID', key: 'ID', minWidth: 85},
          {title: '优惠券名称', key: 'CouponTitle', minWidth: 120},
          {title: '使用范围', key: 'UseRange', minWidth: 100},
          {title: '已使用/未发放/总数', slot: 'numbers', minWidth: 150},
          {title: '失效日期', slot: 'expiredEnd', minWidth: 120},
          {title: '操作', slot: 'opt', width: 180, fixed: 'right', align: 'center'},
        ],
        tableData: [],


        detailVisible: false,
        detailFormData: {}

      }
    },
    mounted () {
      this.init();
    },
    methods: {
      onPageChange(value) {
        this.page.current = value;
        this.init();
      },
      onPageSizechange(value) {
        this.page.size = value;
        this.init();
      },

      init () {
        let pm = Object.assign({}, {Params: this.search }, {Limit: this.page.size, Page: this.page.current})
        couponApi.RankList(pm).then(res => {
          if (res.Code === 0) {
            this.page.total = res.Data.Count
            this.tableData = res.Data.Data || []
          } else {
            this.$Message.error(res.Message)
          }
        });
      },
      // 移除
      remove (row) {
        this.$Modal.confirm({
          title: '移除',
          content: `确定将 ${row.CouponTitle} 从榜单移除吗？`,
          onOk: ()=> {
            couponApi.RemoveFromRank(row.CouponRankId).then(res => {
              if (res.Code === 0) {
                this.init()
                this.$Message.success('移除成功')
              } else {
                this.$Message.error(res.Message)
              }
            })
          }
        })
      },

      // 置顶
      toTop (row) {
        couponApi.TopRank(row.CouponRankId).then(res => {
          if (res.Code === 0) {
            this.init();
            this.$Message.success('置顶成功')
          } else {
            this.$Message.error(res.Message)
          }
        })

      },

      // 查看详情
      viewDetail (row) {
        this.detailVisible = true;
        this.detailFormData = JSON.parse(JSON.stringify(row))
      },

      formatTime (time) {
        return formatTime(time)
      },
    }
  }
</script>

<style scoped>

</style>
