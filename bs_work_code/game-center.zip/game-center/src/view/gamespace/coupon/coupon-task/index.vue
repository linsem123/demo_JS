<template>
    <Card>
        <Form :model="searchForm" ref="formValidate" :rules="ruleValidate" :inline="true" style="position: relative">
            <FormItem>
                <Select
                    filterable
                    :loading="selLoading"
                    :remote-method="getNameList"
                    placeholder="请输入任务名称"
                    v-model="searchForm.params.id"
                    clearable
                    style="width: 200px"
                >
                    <Option v-for="item in nameList" :value="item.Id" :key="item.Id">
                        {{
                        item.Name
                        }}
                    </Option>
                </Select>
            </FormItem>
            <FormItem>
                <Selection :width="160" placeholder="请选择用户范围" :dataList="scopeList" v-model="searchForm.params.user_scope_type" />
            </FormItem>
            <FormItem>
                <Selection :width="160" placeholder="请选择触发动作" :dataList="actList" v-model="searchForm.params.action_type" />
            </FormItem>
            <FormItem>
                <Selection :width="160" placeholder="请选择任务结果" :dataList="resultList" v-model="searchForm.params.resource_type" />
            </FormItem>
            <FormItem>
                <Selection :width="160" placeholder="请选择状态" :dataList="statusList" v-model="searchForm.params.action_status" />
            </FormItem>
            <FormItem>
                <Button type="primary" @click="handleSearch">查询</Button>
            </FormItem>
        </Form>

        <Table :data="tableData" :columns="columns" :loading="loading" border>
            <template slot="Time" slot-scope="{ row }">
                {{
                row.Time | TimeFilter
                }}
            </template>
            <template slot="Status" slot-scope="{ row }">
                <span v-show="row.ActionStatus == 0" style="color: orange">初始化</span>
                <span v-show="row.ActionStatus == 1" style="color: red">已暂停</span>
                <span v-show="row.ActionStatus == 2" style="color: green">进行中</span>
                <span v-show="row.ActionStatus == 3">已过期</span>
            </template>
            <template slot="action" slot-scope="{ row }">
                <!-- 修改状态:   -->
                <Button v-show="row.ActionStatus != 3" type="primary" size="small" @click="handleModal(row)">修改</Button>
                <Button
                    type="success"
                    size="small"
                    style="margin-left: 5px"
                    @click="handleStatus(2, row.Id)"
                    v-show="row.ActionStatus == 0"
                >开始</Button>
                <Button
                    type="error"
                    size="small"
                    style="margin-left: 5px"
                    @click="handleStatus(1, row.Id)"
                    v-show="row.ActionStatus == 2"
                >暂停</Button>
                <Button
                    type="success"
                    size="small"
                    style="margin-left: 5px"
                    @click="handleStatus(2, row.Id)"
                    v-show="row.ActionStatus == 1"
                >恢复</Button>
                <Button size="small" style="margin-left: 5px" @click="handleCheck(row)">查看</Button>
                <Button size="small" @click="handleCopyTrak(row.Id)" style="margin-left: 6px" type="success">复制</Button>
            </template>
        </Table>
        <Row style="margin-top: 10px">
            <Col :span="6">
                <Button @click="handleModal()" type="info" shape="circle" icon="md-add">新增自动任务</Button>
            </Col>
            <Col :span="18" align="right">
                <Page
                    show-sizer
                    :total="searchForm.total"
                    show-total
                    :page-size="searchForm.limit"
                    :current="searchForm.page"
                    @on-change="changePage"
                    @on-page-size-change="changePageSize"
                />
            </Col>
        </Row>
        <Modal v-model="showCheck" title="查看" footer-hide>
            <CheckPage
                ref="formpage"
                :editForm="editForm"
                :list="{
                    scopeList,
                    actList,
                    resultList,
                    statusList,
                    distributeList,
                    gameRadio,
                    rateList,
                    AdviseList,
                    DotTypeList,
                }"
            />
        </Modal>
    </Card>
</template>
<script>
import Selection from "_c/Selection";
import FormPage from "./form";
import CheckPage from "./check";
import CouponAPI from "@/api/gamespace/coupon";
import common from "@/view/gameCircle/pubFunc/common";
export default {
    name: "CouponTask",
    components: { Selection, FormPage, CheckPage },
    data() {
        return {
            searchForm: {
                page: 1,
                total: 0,
                limit: 10,
                params: {
                    id: undefined,
                    user_scope_type: undefined,
                    action_type: undefined,
                    resource_type: undefined,
                    action_status: undefined
                }
            },
            ruleValidate: {},
            scopeList: [
                {
                    Id: 1,
                    Name: "所有人"
                },
                {
                    Id: 2,
                    Name: "未付费用户"
                },
                {
                    Id: 3,
                    Name: "VIP用户N等级"
                },
                {
                    Id: 4,
                    Name: "SDK新用户"
                },
                {
                    Id: 5,
                    Name: "指定UnionID"
                }
            ],
            actList: [
                { Id: 1, Name: "空动作" },
                {
                    Id: 2,
                    Name: "登录"
                },
                {
                    Id: 3,
                    Name: "首次登录"
                },
                {
                    Id: 4,
                    Name: "累计登陆N次"
                },
                {
                    Id: 5,
                    Name: "N天未登录"
                },
                {
                    Id: 6,
                    Name: "单次付费"
                },
                {
                    Id: 7,
                    Name: "首次付费"
                },
                {
                    Id: 8,
                    Name: "N天未付费"
                },
                {
                    Id: 9,
                    Name: "累计充值满N金额"
                },
                {
                    Id: 10,
                    Name: "VIP权益每月发"
                },
                {
                    Id: 11,
                    Name: "VIP升到N级"
                }
            ],
            resultList: [
                {
                    Id: 1,
                    Name: "发优惠券"
                },
                {
                    Id: 2,
                    Name: "发礼包"
                },
                {
                    Id: 3,
                    Name: "鲨享券"
                },
                {
                    Id: 4,
                    Name: "鲨享券（实付返利）"
                }
            ],
            statusList: [
                {
                    Id: 2,
                    Name: "正常"
                },
                {
                    Id: 1,
                    Name: "已暂停"
                },
                {
                    Id: 3,
                    Name: "已过期"
                }
            ],
            ///下发游戏list
            distributeList: [
                {
                    Id: 1,
                    Name: "所有游戏"
                },
                {
                    Id: 2,
                    Name: "指定N个游戏"
                },
                {
                    Id: 3,
                    Name: "排除N个游戏"
                }
            ],
            //下发游戏radioliat
            gameRadio: [
                {
                    value: 1,
                    label: "游戏App ID"
                }
            ],
            //任务频率
            rateList: [
                {
                    Id: 1,
                    Name: "总限"
                },
                {
                    Id: 2,
                    Name: "每日"
                },
                {
                    Id: 3,
                    Name: "每周（自然周）"
                },
                {
                    Id: 4,
                    Name: "每月（自然月）"
                }
            ],
            actStatus: [
                {
                    Id: 0,
                    Name: "初始化"
                },
                {
                    Id: 1,
                    Name: "已暂停"
                },
                {
                    Id: 2,
                    Name: "正常"
                },
                {
                    Id: 3,
                    Name: "已过期"
                }
            ],
            AdviseList: [
                // {
                //   Id: 1,
                //   Name: "PUSH",
                // },
                {
                    Id: 2,
                    Name: "红点"
                }
                // {
                //   Id: 3,
                //   Name: "发现好游戏通知",
                // },
            ],
            DotTypeList: [
                {
                    Id: 0,
                    Name: "sdk优惠券红点"
                },
                {
                    Id: 1,
                    Name: "sdk礼包红点"
                },
                {
                    Id: 2,
                    Name: "悬浮球"
                }
            ],
            loading: false,
            tableData: [],
            columns: [
                { key: "Id", title: "任务ID", align: "center", minWidth: 60 },
                {
                    key: "Name",
                    title: "任务名称",
                    align: "center",
                    minWidth: 100
                },
                {
                    key: "ScopeName",
                    title: "用户范围",
                    align: "center",
                    minWidth: 100
                },
                {
                    key: "DistributeName",
                    title: "下发游戏",
                    align: "center",
                    minWidth: 80
                },
                {
                    key: "ActName",
                    title: "动作触发",
                    align: "center",
                    minWidth: 100
                },
                {
                    key: "ResultName",
                    title: "任务结果",
                    align: "center",
                    minWidth: 100
                },
                {
                    key: "RateName",
                    title: "任务频率",
                    align: "center",
                    minWidth: 80
                },
                {
                    slot: "Time",
                    title: "任务时间",
                    align: "center",
                    minWidth: 200
                },
                {
                    key: "AdviseName",
                    title: "通知",
                    align: "center",
                    minWidth: 100
                },
                {
                    slot: "Status",
                    title: "状态",
                    align: "center",
                    minWidth: 80
                },
                {
                    slot: "action",
                    title: "操作",
                    fixed: "right",
                    align: "center",
                    minWidth: 230
                }
            ],
            // showModal: false,
            editForm: {},
            isAdd: true, //是否新增
            showCheck: false,
            nameList: [],
            selLoading: false
        };
    },
    mounted() {
        this.searchServer();
    },
    filters: {
        TimeFilter(val) {
            if (val) {
                return `${common.formatDate(val[0], true)}~${common.formatDate(val[1], true)}`;
            }
            return "";
        }
    },
    methods: {
        //查询
        handleSearch() {
            this.searchForm.page = 1;
            this.searchServer();
        },
        getNameList(val) {
            this.selLoading = true;
            CouponAPI.LikeTask(val)
                .then(res => {
                    if (res.Code == 0) {
                        this.nameList = res.Data || [];
                    }
                })
                .finally(() => {
                    this.selLoading = false;
                });
        },
        //自增/修改
        handleModal(row) {
            if (row) {
                this.$router.push({
                    name: "coupon_new_task_edit",
                    query: {
                        id: row.Id
                    }
                });
            } else {
                this.$router.push({
                    name: "coupon_new_task_edit"
                });
            }
        },
        //查看
        handleCheck(row) {
            this.showCheck = true;
            this.editForm = row;
        },
        //开始/暂停/恢复
        handleStatus(status, ID, action) {
            if (status == 2 && action == 0) {
                this.$Modal.confirm({
                    title: "提示",
                    content: "<p>是否开始？</p>",
                    onOk: () => {
                        this.updateStatusServer(status, ID);
                    },
                    onCancel: () => {}
                });
            } else {
                this.updateStatusServer(status, ID);
            }
        },
        updateStatusServer(status, ID) {
            CouponAPI.UpdateNewTask(status, ID).then(res => {
                if (res.Code == 0) {
                    this.searchServer();
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        //改页数
        changePage(page) {
            this.searchForm.page = page;
            this.searchServer();
        },
        //改分页条数
        changePageSize(limit) {
            this.searchForm.limit = limit;
            this.searchForm.page = 1;
            this.searchServer();
        },
        searchServer() {
            this.loading = true;
            CouponAPI.NewTaskList(this.searchForm)
                .then(res => {
                    if (res.Code == 0) {
                        let arr = res.Data.Data || [];
                        this.tableData = arr.map(row => {
                            row.ScopeName = this.findName(row.UserScopeType, this.scopeList); //用户范围
                            row.DistributeName = this.findName(row.GameScopeType, this.distributeList); //下发游戏
                            row.RateName = this.findName(row.ActionCycle, this.rateList); //任务频率
                            row.ActName = this.findName(row.ActionType, this.actList); //动作触发
                            row.ResultName = this.findName(row.ResourceType, this.resultList); //任务结果
                            row.AdviseName = row.Messages
                                ? row.Messages.map(val => {
                                      return this.findName(val, this.AdviseList);
                                  }).join(", ")
                                : "";
                            row.Time = [row.StartTime, row.EndTime]; //任务结果
                            row.UnionIds = [];
                            return row;
                        });
                        this.searchForm.total = res.Data.Count;
                    } else {
                        this.$Message.error(res.Message);
                    }
                })
                .finally(() => {
                    this.loading = false;
                });
        },
        //查询ID对应的名称
        findName(ID, list) {
            if (ID + "" && list) {
                let obj = list.filter(v => v.Id == ID)[0];
                if (obj && obj.Name) return obj.Name;
            }
            return "";
        },
        //复制
        handleCopyTrak(ID) {
            this.$Modal.confirm({
                title: "提示",
                content: "<p>是否复制？</p>",
                onOk: () => {
                    CouponAPI.TaskCopy(ID).then(res => {
                        if (res.Code === 0) {
                            this.$Message.success("复制成功！");
                            this.searchServer();
                        } else if (res.Message) {
                            this.$Message.error(res.Message);
                        }
                    });
                }
            });
        }
    }
};
</script>
