<template>
  <Form :label-width="100" :model="formData" ref="formData">
    <FormItem label="任务名称："> {{ formData.Name }} </FormItem>
    <FormItem label="用户范围：">
      {{ formData.ScopeName }}
    </FormItem>
    <!-- 用户范围联动start -->
    <template v-if="formData.UserScopeType == 3">
      <FormItem label="用户VIP等级：">
        {{ formData.VipLevel }}&nbsp;级
      </FormItem>
    </template>
    <FormItem label="下发游戏：">
      {{ formData.DistributeName }}
    </FormItem>
    <!-- 下发游戏联动start -->
    <template v-if="showAppText">
      <FormItem label="游戏名称：">
        {{ formData.AppNames }}
      </FormItem>
    </template>
    <!-- 下发游戏联动end -->
    <FormItem label="动作触发：">
      {{ formData.ActName }}
    </FormItem>
    <FormItem label="任务结果：">
      {{ formData.ResultName }}
      <!-- 任务结果联动start -->
      <template v-if="showCoupon">
        <FormItem style="margin-top: 10px">
          <Table
            border
            :columns="isShow ? noNCoupon : couponCol"
            :data="formData.Rules"
          ></Table>
        </FormItem>
      </template>
      <template v-if="showAward">
        <FormItem style="margin-top: 10px">
          <Table
            border
            :columns="isShow ? noNAward : awardCol"
            :data="formData.Rules"
          ></Table>
        </FormItem>
      </template>
      <!-- 任务结果联动end -->
    </FormItem>
    <template v-if="showDiscount">
      <FormItem prop="IsCoupon" label="订单是否用券：">
        <RadioGroup v-model="formData.IsCoupon">
          <Radio :label="0" disabled>不可用券（用券则排除订单不触发）</Radio>
          <Radio :label="1" disabled>可用券</Radio>
        </RadioGroup>
      </FormItem>
      <FormItem
        label="实付："
        prop="IsDiscount"
        v-show="formData.IsCoupon == 1"
      >
        <Checkbox v-model="formData.IsDiscount" disabled></Checkbox>
      </FormItem>
    </template>
    <FormItem label="任务频率：">
      {{ formData.RateName }}
    </FormItem>
    <!-- 任务频率联动start -->
    <template v-if="showNum">
      <FormItem prop="StartNum" style="display: inline-block" label="开始："
        >{{ formData.StartNum }}
        &nbsp;
      </FormItem>
      <FormItem prop="EndNum" style="display: inline-block" label="结束："
        >{{ formData.EndNum }}&nbsp;
      </FormItem>
    </template>
    <template v-if="formData.ActionType">
      <FormItem label="频率次数：">
        {{ formData.ActionTimes }}&nbsp;次
      </FormItem>
    </template>

    <!-- 任务频率联动end -->
    <FormItem label="任务时间：">
      {{ formData.Time | TimeFilter }}
    </FormItem>
    <FormItem label="通知：">
      <CheckboxGroup v-model="formData.Messages">
        <Checkbox
          :disabled="true"
          v-for="item of list.AdviseList"
          :key="item.Id"
          :label="item.Id"
          >{{ item.Name }}</Checkbox
        >
      </CheckboxGroup>
      <template v-if="showPush">
        <Input
          v-model.trim="formData.PushInfo"
          type="textarea"
          :rows="4"
          style="margin-top: 10px"
          :readonly="true"
        />
      </template>
      <template v-if="showHot">
        <Selection
          v-model="formData.DotType"
          :dataList="list.DotTypeList"
          :width="200"
          :disabled="true"
          style="margin-top: 10px"
        />
      </template>
    </FormItem>
  </Form>
</template>
<script>
import Selection from "_c/Selection";
// import giftList from "./list";
import common from "@/view/gameCircle/pubFunc/common";
import CouponAPI from "@/api/gamespace/coupon";
export default {
  name: "CheckPage",
  components: { Selection },
  props: ["editForm", "list"],
  data() {
    return {
      formData: {},
      couponCol: [
        {
          key: "ResourceId",
          title: "优惠券ID",
        },
        {
          key: "N",
          title: "N值",
        },
      ],
      noNCoupon: [
        {
          key: "ResourceId",
          title: "优惠券ID",
        },
      ],
      noNAward: [
        {
          key: "ResourceId",
          title: "礼包ID",
        },
      ],
      awardCol: [
        {
          key: "ResourceId",
          title: "礼包ID",
        },
        {
          key: "N",
          title: "N值",
        },
      ],
    };
  },
  mounted() {
    this.formData = JSON.parse(JSON.stringify(this.editForm));
  },
  watch: {
    editForm: {
      immediate: true,
      handler: function () {
        this.formData = JSON.parse(JSON.stringify(this.editForm));
        this.formData.Rules = this.formData.Rules || [];
        this.$set(this.formData, "AppNames", "");
        this.formData.IsCoupon = this.formData.IsCoupon ? 1 : 0;
        this.formData.Rules = this.formData.Rules.map((v) => {
          if (
            this.formData.ActionType == 6 ||
            this.formData.ActionType == 7 ||
            this.formData.ActionType == 9
          ) {
            v.N = Number(v.N) / 100;
          }
          return v;
        });
        if (this.formData.AppIds) this.getAppById(this.formData.AppIds);
      },
    },
  },
  filters: {
    TimeFilter(val) {
      if (val) {
        return `${common.formatDate(val[0], true)}~${common.formatDate(
          val[1],
          true
        )}`;
      }
      return "";
    },
  },
  computed: {
    showAppText() {
      return (
        this.formData.GameScopeType == 2 || this.formData.GameScopeType == 3
      );
    },
    showRankText() {
      return (
        (this.formData.Distribute == 1 || this.formData.Distribute == 2) &&
        this.formData.DistributeType == 2
      );
    },
    showCoupon() {
      return this.formData.ResourceType && this.formData.ResourceType == 1;
    },
    showAward() {
      return this.formData.ResourceType && this.formData.ResourceType == 2;
    },
    showDiscount() {
      let arr = [6, 7, 9];
      if (
        this.formData.ResourceType == 1 &&
        arr.includes(this.formData.ActionType)
      ) {
        return true;
      }
      return false;
    },
    showNum() {
      return this.formData.ActionCycle != 1;
    },
    showPush() {
      return this.formData.Messages && this.formData.Messages.includes(1);
    },
    showHot() {
      return this.formData.Messages && this.formData.Messages.includes(2);
    },
    isShow() {
      return (
        this.formData.ActionType == 1 ||
        this.formData.ActionType == 2 ||
        this.formData.ActionType == 3
      );
    },
  },
  methods: {
    getAppById(AppIds) {
      CouponAPI.GetApp({ AppIds }).then((res) => {
        if (res.Code == 0) {
          let list = res.Data || [];
          let AppNames = list.map((v) => v.Name).join(";");
          this.$set(this.formData, "AppNames", AppNames);
        }
      });
    },
  },
};
</script>
<style scoped lang="less">
.ivu-form-item {
  margin-bottom: 10px;
}
</style>