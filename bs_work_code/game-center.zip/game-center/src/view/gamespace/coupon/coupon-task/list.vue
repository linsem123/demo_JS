<template>
    <div>
        <div class="title" v-if="isShowIcon">
            <span class="set_width">
                <slot name="left"></slot>
            </span>
            <span class="set_width" v-if="!isShow">
                <slot name="right"></slot>
            </span>
        </div>
        <div v-for="(item, index) of value" :key="index">
            <div class="item_box">
                <!-- 鲨享券实付返利：每次新增 提示也会新增 -->
                <div class="title" v-if="!isShowIcon">
                    <span class="set_width">
                        <slot name="left"></slot>
                    </span>
                    <span class="set_width" v-if="!isShow">
                        <slot name="right"></slot>
                    </span>
                </div>
                <div class="list_box item_box">
                    <span class="set_width">
                        <Input v-model="item.ResourceId" :placeholder="IDplacehoder" type="number" />
                    </span>
                    <span class="set_width" v-if="!isShow">
                        <!-- <Input v-model="item.N" :placeholder="Valplaceholder" type="number" /> -->
                        <InputNumber
                            v-model="item.N"
                            :placeholder="Valplaceholder"
                            style="width: 100%"
                            :precision="precisionCount ? 2 : 0"
                        />
                    </span>
                    <Icon
                        type="md-add-circle"
                        :color="canotAdd ? '#999' : 'rgb(56, 135, 240)'"
                        :size="24"
                        @click="handleAdd(index)"
                        v-if="!canotAdd && isShowIcon"
                    />
                    <Icon type="md-trash" color="rgb(56, 135, 240)" :size="24" @click="handleDel(index)" v-if="!canotAdd && isShowIcon" />
                </div>
                <!-- 实付返利配置项新增标题 -->
                <div class="title" v-if="!isShowIcon" style="margin-top: 10px">
                    <div class="shark_width shark_large_width">
                        <span>消费范围（金额单位：元）</span>
                        <Tooltip placement="right">
                            <div slot="content">
                                <!--  &gt;101, -->
                                <p>例如：&gt;15&lt;100,不允许区间重复</p>
                            </div>
                            <Icon type="md-alert" size="15" class="marginL" />
                        </Tooltip>
                    </div>
                    <div class="shark_width">
                        <span>返利百分比</span>
                        <Tooltip placement="right">
                            <div slot="content">
                                <p>
                                    例如：10，代表充值100返利10元
                                    <br />输入范围1-100
                                </p>
                            </div>
                            <Icon type="md-alert" size="15" class="marginL" />
                        </Tooltip>
                    </div>
                    <div class="shark_width">
                        <span>单人下发次数</span>
                        <Tooltip placement="right">
                            <div slot="content">
                                <p>
                                    例如：1，代表活动周期内，该范围只触
                                    <br />发1次任务；0，代表不限制
                                </p>
                            </div>
                            <Icon type="md-alert" size="15" class="marginL" />
                        </Tooltip>
                    </div>
                </div>
                <div v-if="ResourceType == 3 && isShowRebate" class="list_box item_box">
                    <div class="shark_large_width list_box">
                        <Input v-model="item.firstAmount" type="number" class="marginR" @on-blur="checkScope(item)">
                            <Select v-model="item.firstCode" clearable slot="prepend" style="width: 80px" @on-change="checkScope(item)">
                                <Option value=">">&gt;</Option>
                                <Option value="<">&lt;</Option>
                            </Select>
                        </Input>
                        <Input v-model="item.lastAmount" type="number" @on-blur="checkScope(item)">
                            <Select v-model="item.lastCode" clearable slot="prepend" style="width: 80px" @on-change="checkScope(item)">
                                <Option value=">">&gt;</Option>
                                <Option value="<">&lt;</Option>
                            </Select>
                        </Input>
                    </div>
                    <span class="shark_width">
                        <InputNumber
                            v-model="item.Percent"
                            placeholder="请输入返利百分比"
                            :min="1"
                            :max="100"
                            :active-change="false"
                            style="width: 100%"
                        ></InputNumber>
                    </span>
                    <span class="shark_width">
                        <InputNumber
                            v-model="item.RebateNumMax"
                            placeholder="请输入单人下发次数"
                            :min="0"
                            :active-change="false"
                            style="width: 100%"
                        ></InputNumber>
                    </span>
                    <Icon type="md-add-circle" :color="'rgb(56, 135, 240)'" :size="24" @click="handleAdd(index)" />
                    <Icon type="md-trash" color="rgb(56, 135, 240)" :size="24" @click="handleDel(index)" />
                </div>
                <div style="color:red" v-show="item.Tip">{{ item.Tip == 1 ? '消费范围有重复区间，请检查配置' : '消费范围没有重合区间，请检查配置'}}</div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    props: ["value", "IDplacehoder", "Valplaceholder", "ActionType", "ResourceType", "isShowRebate"],
    computed: {
        canotAdd() {
            // return this.ActionType == 2 || this.ActionType == 3;
            return (this.ActionType == 1 && this.ResourceType == 2) || this.ActionType == 2 || this.ActionType == 3;
        },
        isShow() {
            return this.ActionType == 1 || this.ActionType == 2 || this.ActionType == 3;
        },
        precisionCount() {
            return this.ActionType == 6 || this.ActionType == 7 || this.ActionType == 9;
        },
        isShowIcon() {
            if (this.ResourceType == 3) {
                return !this.isShowRebate;
            } else {
                return true;
            }
        }
    },
    methods: {
        handleDel(index) {
            if (this.value.length > 1) {
                let arr = this.value;
                arr.splice(index, 1);
                this.$emit("input", arr);
            } else {
                this.$Message.error("不能再减少啦！");
            }
        },
        handleAdd(index) {
            if (this.canotAdd) {
                return;
            }
            let arr = this.value;
            arr.splice(index + 1, 0, {
                ResourceId: "",
                N: "",
                firstAmount: "",
                firstCode: "",
                lastAmount: "",
                lastCode: "",
                Percent: null,
                RebateNumMax: null,
                Tip: 0
            });
            this.$emit("input", arr);
        },
        checkScope(item) {
            item.Tip = 0;
            // 两个区间暂时都是必填项
            if (!item.firstCode || !item.lastCode) {
                item.Tip = 2;
            }
            // if (item.firstCode || item.lastCode) {
            //     // item.StartAmount = (item.firstAmount || item.lastAmount) * 100;
            //     // item.WithStartAmount = true;
            //     // item.EndAmount = 0;
            //     // item.WithEndAmount = false;
            // }
            if (item.firstCode && item.lastCode) {
                // 重复区间 都是大于或小于的范围
                if (item.firstCode === item.lastCode) {
                    item.Tip = 1;
                    // item.Tip = 1;
                } else {
                    if (item.firstCode === ">") {
                        if (+item.firstAmount >= +item.lastAmount) {
                            console.log(item);
                            item.Tip = 2;
                        } else {
                            item.StartAmount = item.firstAmount * 100;
                            item.EndAmount = item.lastAmount * 100;
                            item.WithStartAmount = true;
                            item.WithEndAmount = true;
                        }
                    } else {
                        if (+item.firstAmount <= +item.lastAmount) {
                            item.Tip = 2;
                        } else {
                            item.StartAmount = item.lastAmount * 100;
                            item.EndAmount = item.firstAmount * 100;
                            item.WithStartAmount = true;
                            item.WithEndAmount = true;
                        }
                    }
                }
            }
        }
    }
};
</script>
<style scoped lang="less">
.list_box {
    display: flex !important;
    align-items: center;
    & + .list_box {
        margin-top: 5px;
    }
}
.set_width {
    display: inline-block;
    width: 35%;
    padding-right: 10px;
}
.shark_width {
    display: inline-block;
    width: 15%;
    padding-right: 10px;
    line-height: 1.5;
}
.shark_large_width {
    width: 40%;
    margin-right: 10px;
}
.marginR {
    margin-right: 10px;
}
.item_box {
    margin-bottom: 10px;
}
.marginL {
    margin-left: 2px;
}
.tip {
    color: rgba(0, 0, 0, 0.6);
}
</style>