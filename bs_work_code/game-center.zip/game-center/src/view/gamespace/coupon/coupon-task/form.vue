<template>
    <Card :title="id ? '编辑优惠券任务' : '新增优惠券任务'">
        <Form :label-width="100" :model="formData" ref="formData" :rules="rules">
            <FormItem label="任务名称：" prop="Name">
                <Input placeholder="请输入任务名称" v-model="formData.Name" style="width: 300px" />
            </FormItem>
            <FormItem label="用户范围：">
                <Selection
                    :width="300"
                    placeholder="请选择用户范围"
                    :dataList="list.scopeList"
                    v-model="formData.UserScopeType"
                    :clearable="false"
                    @on-change="selectAction"
                />
            </FormItem>
            <!-- 用户范围联动start -->
            <!-- sdk 5.5.0新增人群范围id -->
            <template v-if="formData.UserScopeType == 7">
                <FormItem label="用户分群ID" style="margin-top: 10px" prop="CrowdId">
                    <InputNumber v-model="formData.CrowdId" style="width: 80px" :min="0" />
                </FormItem>
            </template>
            <template v-if="formData.UserScopeType == 3">
                <FormItem style="margin-top: 10px" prop="VipLevel">
                    <InputNumber v-model="formData.VipLevel" style="width: 80px" :min="0" />&nbsp;级
                </FormItem>
            </template>
            <template
                v-if="
          (formData.UserScopeType == 5 || formData.UserScopeType == 6) &&
          formData.ActionStatus != 2
        "
            >
                <FormItem style="margin-top: 10px" prop="userCount">
                    <Upload
                        ref="uploadpkg"
                        action="/"
                        :before-upload="handleBeforeUpload"
                        style="display: inline-block"
                        :disabled="fileLoading"
                    >
                        <Button icon="ios-cloud-upload-outline">选择文件</Button>
                    </Upload>
                    <span v-if="fileLoading" style="margin-left: 10px">文件校验中...</span>
                    <span v-else>
                        <span style="margin-left: 10px">{{ Unionfile.name }}</span>
                        <span style="margin-left: 10px" v-if="userCount">统计到{{ userCount }}个用户</span>
                    </span>
                    <div style="color: #999">提示：用TXT文本文档，每行只能列一个UnionId</div>
                </FormItem>
            </template>
            <!-- 用户范围联动end -->
            <FormItem label="下发游戏：">
                <Selection
                    :width="300"
                    placeholder="请选择下发游戏"
                    :dataList="list.distributeList"
                    v-model="formData.GameScopeType"
                    :clearable="false"
                />
            </FormItem>
            <!-- 下发游戏联动start -->
            <template v-if="showAppText">
                <FormItem style="margin-top: 10px" prop="AppIds" label="选择游戏：">
                    <Select
                        v-model="formData.AppIds"
                        filterable
                        remote
                        clearable
                        placeholder="请输入App名称"
                        :remote-method="getAppList"
                        multiple
                        style="width: 400px"
                    >
                        <Option v-for="item in appList" :value="item.AppId" :key="item.AppId">({{ item.AppId }}){{ item.Name }}</Option>
                    </Select>
                </FormItem>
            </template>
            <!-- 下发游戏联动end -->
            <FormItem label="动作触发：">
                <Selection
                    :width="300"
                    placeholder="请选择动作触发"
                    :dataList="list.actList"
                    v-model="formData.ActionType"
                    :clearable="false"
                    @on-change="hadleCLearRules"
                />
            </FormItem>
            <FormItem label="任务结果：">
                <RadioGroup v-model="formData.ResourceType" @on-change="hadleCLearRules">
                    <Radio v-for="item of list.resultList" :key="item.Id" :label="item.Id">{{ item.Name }}</Radio>
                </RadioGroup>
                <!-- 任务结果联动start -->
                <template v-if="showCoupon">
                    <!-- 新增鲨享券 实付返利 -->
                    <FormItem style="margin-top: 10px" prop="Rules">
                        <Checkbox v-if="formData.ResourceType == 3" v-model="isShowRebate">实付返利</Checkbox>
                        <giftList
                            v-model="formData.Rules"
                            Valplaceholder="请输入N值"
                            IDplacehoder="请输入优惠券 ID"
                            :ActionType="formData.ActionType"
                            :ResourceType="formData.ResourceType"
                            :isShowRebate="isShowRebate"
                        >
                            <template v-slot:left>优惠券 ID</template>
                            <template v-slot:right>
                                {{
                                formData.ActionType == 6 ||
                                formData.ActionType == 7 ||
                                formData.ActionType == 9
                                ? "N值（金额单位：元）"
                                : "N值"
                                }}
                            </template>
                        </giftList>
                        <Checkbox v-if="formData.ResourceType == 3" v-model="formData.VipAmplifierSwitch">VIP返利百分比增幅（单位：%）</Checkbox>
                        <div v-if="formData.ResourceType == 3" class="tip">*在返利基础上增幅vip返利，不填则不代表增幅，输入范围1-50</div>
                        <div v-if="formData.ResourceType == 3 && formData.VipAmplifierSwitch" class="vip-box">
                            <div v-for="(item, index) in VipAmplifier" class="item-box">
                                <span>VIP{{item.LevelN}}</span>
                                <InputNumber v-model="item.Percent" :max="50" :min="0" style="width: 60%" :active-change="false"></InputNumber>
                            </div>
                        </div>
                    </FormItem>
                </template>
                <template v-if="showAward">
                    <FormItem style="margin-top: 10px" prop="Rules">
                        <giftList
                            v-model="formData.Rules"
                            Valplaceholder="请输入N值"
                            IDplacehoder="请输入礼包 ID"
                            :ActionType="formData.ActionType"
                            :ResourceType="formData.ResourceType"
                        >
                            <template v-slot:left>礼包 ID</template>
                            <template v-slot:right>
                                {{
                                formData.ActionType == 6 ||
                                formData.ActionType == 7 ||
                                formData.ActionType == 9
                                ? "N值（金额单位：元）"
                                : "N值"
                                }}
                            </template>
                        </giftList>
                    </FormItem>
                </template>
                <!-- 任务结果联动end -->
            </FormItem>
            <template v-if="showDiscount">
                <FormItem prop="IsCoupon" label="订单是否用券：">
                    <RadioGroup v-model="formData.IsCoupon">
                        <Radio :label="0">不可用券（用券则排除订单不触发）</Radio>
                        <Radio :label="1">可用券</Radio>
                    </RadioGroup>
                </FormItem>
                <FormItem label="实付：" prop="IsDiscount" v-show="formData.IsCoupon == 1">
                    <Checkbox v-model="formData.IsDiscount"></Checkbox>
                </FormItem>
            </template>
            <FormItem label="任务频率：" v-show="!showRate">
                <RadioGroup v-model="formData.ActionCycle" @on-change="changeRate">
                    <Radio v-for="item of list.rateList" :key="item.Id" :label="item.Id">{{ item.Name }}</Radio>
                </RadioGroup>
            </FormItem>
            <!-- 任务频率联动start -->
            <template v-if="showNum">
                <FormItem prop="StartNum" style="margin-top: 10px; display: inline-block" label="开始：">
                    <InputNumber
                        v-model="formData.StartNum"
                        style="width: 80px"
                        :max="max"
                        :min="min"
                        @on-change="(num) => changeNum(num, 'StartNum')"
                        @on-blur="(num) => blurNum('StartNum')"
                    />&nbsp;
                </FormItem>
                <FormItem prop="EndNum" style="margin-top: 10px; display: inline-block" label="结束：">
                    <InputNumber
                        v-model="formData.EndNum"
                        style="width: 80px"
                        :max="max"
                        :min="min"
                        @on-change="(num) => changeNum(num, 'EndNum')"
                        @on-blur="(num) => blurNum('EndNum')"
                    />&nbsp;
                </FormItem>
            </template>
            <template v-if="!showRate">
                <FormItem style="margin-top: 10px" label="频率次数：" prop="ActionTimes">
                    <InputNumber v-model="formData.ActionTimes" style="width: 80px" :disabled="disabled" :min="0" />&nbsp;次
                </FormItem>
            </template>
            <!-- 任务频率联动end -->
            <FormItem label="任务时间：">
                <DatePicker
                    v-model="formData.StartTime"
                    placeholder="请设置开始时间"
                    type="datetime"
                    style="margin-right: 10px"
                    format="yyyy-MM-dd HH:mm"
                />
                <DatePicker v-model="formData.EndTime" placeholder="请设置结束时间" type="datetime" format="yyyy-MM-dd HH:mm" />
            </FormItem>

            <FormItem label="通知：">
                <CheckboxGroup v-model="formData.Messages">
                    <Checkbox v-for="item of list.AdviseList" :key="item.Id" :label="item.Id">{{ item.Name }}</Checkbox>
                </CheckboxGroup>
                <template v-if="showPush">
                    <Input v-model.trim="formData.PushInfo" type="textarea" :rows="4" style="margin-top: 10px" />
                </template>
                <template v-if="showHot">
                    <Selection
                        v-model="formData.DotType"
                        :dataList="list.DotTypeList"
                        :width="200"
                        :clearable="false"
                        style="margin-top: 10px"
                    />
                </template>
            </FormItem>

            <FormItem>
                <Button @click="handelCancel" style="margin-right: 20px">取消</Button>
                <Button @click="handleCommit" type="primary" :loading="loading">确认</Button>
            </FormItem>
        </Form>
    </Card>
</template>
<script>
import Selection from "_c/Selection";
import giftList from "./list";
import CouponAPI from "@/api/gamespace/coupon";
export default {
    name: "FormPage",
    components: { Selection, giftList },
    // props: ["editForm", "list", "isAdd"],
    data() {
        const VipLevelRule = (rule, value, callback) => {
            if (!value && value != 0) {
                callback("请输入VIP等级");
                return;
            } else if (value < 0) {
                callback("VIP等级不得小于0");
                return;
            }
            callback();
        };
        const CrowedIdRule = (rule, value, callback) => {
            if (!value && value != 0) {
                callback("请输入人群定向ID");
                return;
            } else if (value == 0) {
                callback("人群定向ID不得为0");
                return;
            }
            callback();
        };
        const ActionTimesRule = (rule, value, callback) => {
            if (!value && value != 0) {
                callback("请输入频率次数");
                return;
            } else if (value < 1) {
                callback("频率次数不得小于1");
                return;
            }
            callback();
        };

        return {
            formData: {
                Name: "",
                UserScopeType: 1, //用户范围
                VipLevel: 0, //VIP等级
                CrowdId: 0, // TODO: sdk 5.5.0新增 人群定向id (修改字段名)
                UnionIds: [],
                GameScopeType: 1, //下发游戏
                AppIds: [], //
                ActionType: 1, //动作触发
                ActionCycle: 1, //任务频率
                ActionTimes: 1,
                StartNum: 0,
                EndNum: 1,
                ResourceType: 1,
                IsDiscount: false,
                Rules: [
                    {
                        ResourceId: "",
                        N: "",
                        firstAmount: "",
                        firstCode: "",
                        lastAmount: "",
                        lastCode: "",
                        Percent: null,
                        RebateNumMax: null,
                        Tip: 0
                    }
                ], // TODO: 需处理数据
                StartTime: "",
                EndTime: "",
                Messages: [],
                PushInfo: "",
                DotType: 1,
                IsCoupon: 0,
                BsIds: [],
                VipAmplifierSwitch: false // sdk 5.7新增鲨享券充值返利VIP增幅开关
            },
            rules: {
                Name: [
                    {
                        required: true,
                        message: "请输入任务名称",
                        trigger: "blur"
                    }
                ],
                VipLevel: [
                    {
                        validator: VipLevelRule,
                        trigger: "change"
                    }
                ],
                CrowdId: [
                    {
                        validator: CrowedIdRule,
                        trigger: "change"
                    }
                ],
                AppIds: [
                    {
                        required: true,
                        message: "请选择游戏名称",
                        trigger: "change",
                        type: "array"
                    }
                ],
                ActionTimes: [
                    {
                        required: true,
                        validator: ActionTimesRule,
                        trigger: "change"
                    }
                ]
            },
            //union文件
            Unionfile: {
                name: ""
            },
            min: 0,
            max: 24,
            fileLoading: false,
            appList: [],
            list: {
                scopeList: [
                    {
                        Id: 1,
                        Name: "所有人"
                    },
                    {
                        Id: 2,
                        Name: "未付费用户"
                    },
                    {
                        Id: 3,
                        Name: "VIP用户N等级"
                    },
                    {
                        Id: 4,
                        Name: "SDK新用户"
                    },
                    {
                        Id: 5,
                        Name: "指定UnionID"
                    },
                    {
                        Id: 6,
                        Name: "指定黑鲨ID"
                    },
                    {
                        Id: 7,
                        Name: "用户分群ID"
                    }
                ],
                actList: [
                    { Id: 1, Name: "空动作" },
                    {
                        Id: 2,
                        Name: "登录"
                    },
                    {
                        Id: 3,
                        Name: "首次登录"
                    },
                    {
                        Id: 4,
                        Name: "累计登陆N次"
                    },
                    {
                        Id: 5,
                        Name: "N天未登录"
                    },
                    {
                        Id: 6,
                        Name: "单次付费"
                    },
                    {
                        Id: 7,
                        Name: "首次付费"
                    },
                    {
                        Id: 8,
                        Name: "N天未付费"
                    },
                    {
                        Id: 9,
                        Name: "累计充值满N金额"
                    },
                    {
                        Id: 10,
                        Name: "VIP权益每月发"
                    },
                    {
                        Id: 11,
                        Name: "VIP升到N级"
                    }
                ],
                resultList: [
                    {
                        Id: 1,
                        Name: "发优惠券"
                    },
                    {
                        Id: 2,
                        Name: "发礼包"
                    },
                    {
                        Id: 3,
                        Name: "鲨享券"
                    }
                ],
                statusList: [
                    {
                        Id: 2,
                        Name: "正常"
                    },
                    {
                        Id: 1,
                        Name: "已暂停"
                    },
                    {
                        Id: 3,
                        Name: "已过期"
                    }
                ],
                ///下发游戏list
                distributeList: [
                    {
                        Id: 1,
                        Name: "所有游戏"
                    },
                    {
                        Id: 2,
                        Name: "指定N个游戏"
                    },
                    {
                        Id: 3,
                        Name: "排除N个游戏"
                    }
                ],
                //下发游戏radioliat
                gameRadio: [
                    {
                        value: 1,
                        label: "游戏App ID"
                    }
                ],
                //任务频率
                rateList: [
                    {
                        Id: 1,
                        Name: "总限"
                    },
                    {
                        Id: 2,
                        Name: "每日"
                    },
                    {
                        Id: 3,
                        Name: "每周（自然周）"
                    },
                    {
                        Id: 4,
                        Name: "每月（自然月）"
                    }
                ],
                AdviseList: [
                    // {
                    //   Id: 1,
                    //   Name: "PUSH",
                    // },
                    {
                        Id: 2,
                        Name: "红点"
                    }
                    // {
                    //   Id: 3,
                    //   Name: "发现好游戏通知",
                    // },
                ],
                actStatus: [
                    {
                        Id: 0,
                        Name: "初始化"
                    },
                    {
                        Id: 1,
                        Name: "已暂停"
                    },
                    {
                        Id: 2,
                        Name: "正常"
                    },
                    {
                        Id: 3,
                        Name: "已过期"
                    }
                ],
                DotTypeList: [
                    {
                        Id: 0,
                        Name: "sdk优惠券红点"
                    },
                    {
                        Id: 1,
                        Name: "sdk礼包红点"
                    },
                    {
                        Id: 2,
                        Name: "悬浮球"
                    }
                ]
            },
            loading: false,
            isShowRebate: false,
            VipAmplifier: []
        };
    },
    created() {
        for (let i = 0; i <= 17; i++) {
            this.VipAmplifier.push({
                LevelN: i + 1,
                Percent: null
            });
        }
    },
    mounted() {
        // this.formData = JSON.parse(JSON.stringify(this.editForm));
        CouponAPI.NewTaskOne(this.id).then(res => {
            if (res.Code == 0) {
                this.formData = JSON.parse(JSON.stringify(res.Data));
                this.formData.Messages = this.formData.Messages || [];
                this.formData.IsCoupon = this.formData.IsCoupon ? 1 : 0;
                if (this.formData.ActionType == 6 || this.formData.ActionType == 7 || this.formData.ActionType == 9) {
                    this.formData.Rules = res.Data.Rules.map(v => {
                        v.N = Number(v.N) / 100;
                        return v;
                    });
                }
                // 实付返利类型
                if (this.formData.ResourceType === 4) {
                    this.formData.ResourceType = 3;
                    this.isShowRebate = true;
                    this.formData.Rules = this.formData.Rules.map(v => {
                        if (v.WithStartAmount || v.WithEndAmount) {
                            this.$set(v, "firstCode", ">");
                            this.$set(v, "firstAmount", (v.StartAmount || v.EndAmount) / 100);
                            this.$set(v, "lastCode", "");
                            this.$set(v, "lastAmount", "");
                        }
                        // 处理有重合区间的情况
                        if (v.WithStartAmount && v.WithEndAmount) {
                            this.$set(v, "firstCode", ">");
                            this.$set(v, "firstAmount", v.StartAmount / 100);
                            this.$set(v, "lastCode", "<");
                            this.$set(v, "lastAmount", v.EndAmount / 100);
                        }

                        this.$set(v, "Tip", 0);
                        return v;
                    });
                }
                if (this.formData.VipAmplifierSwitch) {
                    this.formData.VipAmplifier.map(item => {
                        this.VipAmplifier[item.LevelN - 1].Percent = item.Percent;
                    });
                }
                if (this.formData.AppIds) this.getAppById(this.formData.AppIds);
            }
        });
    },
    // watch: {
    //   editForm: {
    //     immediate: true,
    //     handler: function () {
    //       this.formData = JSON.parse(JSON.stringify(this.editForm));
    //       this.getAppById(this.formData.AppIds);
    //     },
    //   },
    // },
    computed: {
        showAppText() {
            return this.formData.GameScopeType == 2 || this.formData.GameScopeType == 3;
        },
        showCoupon() {
            return this.formData.ResourceType && (this.formData.ResourceType == 1 || (this.formData.ResourceType == 3 && !this.isRebate));
        },
        showAward() {
            return this.formData.ResourceType && this.formData.ResourceType == 2;
        },
        showDiscount() {
            let arr = [6, 7, 9];
            if (
                // sdk 5.5.0 礼包 鲨享券都可见该选项
                arr.includes(this.formData.ActionType)
            ) {
                return true;
            }
            return false;
        },
        disabled() {
            let arr = [1, 3, 4, 5, 7, 8, 9, 10, 11];
            if (arr.includes(this.formData.ActionType)) {
                this.formData.ActionTimes = 1;
                return true;
            }
            return false;
        },
        showNum() {
            return this.formData.ActionCycle != 1;
        },
        userCount() {
            let UnionIds = [];
            if (this.formData.UserScopeType == 5) {
                UnionIds = this.formData.UnionIds;
            } else if (this.formData.UserScopeType == 6) {
                UnionIds = this.formData.BsIds;
            }
            return UnionIds ? UnionIds.length : undefined;
        },
        id() {
            return this.$route.query.id;
        },
        showPush() {
            return this.formData.Messages && this.formData.Messages.includes(1);
        },
        showHot() {
            return this.formData.Messages && this.formData.Messages.includes(2);
        },
        showRate() {
            return [3, 4, 5, 7, 9, 11].includes(this.formData.ActionType);
        }
    },
    methods: {
        //上传文件
        handleBeforeUpload(file) {
            console.log(file);
            if (!file.type.includes("text/plain")) {
                this.$Message.error("只支持上传TXT格式文件");
                return false;
            }
            this.fileLoading = true;
            var reader = new FileReader(); // 新建一个FileReader
            reader.readAsText(file, "UTF-8"); // 读取文件
            reader.onload = evt => {
                // 读取完文件之后会回来这里
                var fileString = evt.target.result.replace(/\r/g, ""); // 读取文件内容
                console.log(evt.target.result);
                let arr = fileString.split("\n");
                console.log(arr);
                if (this.formData.UserScopeType == 5) {
                    // 用户范围指定UnionId
                    let flag = arr.every(v => v.length == 32);
                    if (flag) {
                        this.formData.UnionIds = [...new Set(arr)];
                        this.Unionfile.name = file.name;
                    } else {
                        this.$Message.error("文件校验不通过");
                    }
                } else if (this.formData.UserScopeType == 6) {
                    // 用户范围指定黑鲨
                    this.formData.BsIds = [];
                    arr.forEach(item => {
                        this.formData.BsIds.push(Number(item));
                    });
                    // let arr1 = []
                    // arr.forEach(item => {
                    //   arr1.push(Number(item))
                    // });
                    // console.log(arr1,'arr1')
                    // this.formData.UnionIds = [...new Set(arr1)];
                    console.log(this.formData.BsIds, "this.formData.BsIds");
                    this.Unionfile.name = file.name;
                }
            };
            this.fileLoading = false;
            return false;
        },
        changeRate(Rate) {
            switch (Rate) {
                case 1:
                    this.max = 0;
                    break;
                case 2:
                    this.max = 24;
                    break;
                case 3:
                    this.max = 6;
                    break;
                case 4:
                    this.max = 30;
                    break;
            }
            this.formData.StartNum = this.min;
            this.formData.EndNum = this.max;
        },
        changeNum(num, type) {
            if (num < this.min) {
                this.formData[type] = this.min;
            }
            if (num > this.max) {
                this.formData[type] = this.max;
            }
        },
        blurNum(type) {
            if (!this.formData[type] && this.formData[type] != 0) {
                type == "StartNum" ? (this.formData[type] = 0) : (this.formData[type] = this.max);
            }
        },
        hadleCLearRules() {
            this.formData.Rules = [
                {
                    ResourceId: "",
                    N: "",
                    firstAmount: "",
                    firstCode: "",
                    lastAmount: "",
                    lastCode: "",
                    Percent: null,
                    RebateNumMax: null,
                    Tip: 0
                }
            ];
            this.formData.VipAmplifierSwitch = false;
        },
        handelCancel() {
            this.$router.push({ name: "gamespace_coupon_new_task" });
        },
        // 更改用户范围
        selectAction() {
            console.log("selectAction");
            if (this.formData.UserScopeType == 5) {
                this.formData.BsIds = [];
            } else if (this.formData.UserScopeType == 6) {
                this.formData.UnionIds = [];
            } else {
                this.formData.BsIds = [];
                this.formData.UnionIds = [];
            }
        },
        handleCommit() {
            this.$refs["formData"].validate(valid => {
                if (valid) {
                    if (this.formData.UserScopeType == 5 && !this.id && !this.userCount) {
                        this.$Message.error("请上传UnionId文件");
                        return;
                    }
                    if (this.formData.UserScopeType == 6 && !this.id && !this.userCount) {
                        this.$Message.error("请上传黑鲨id文件");
                        return;
                    }
                    if (this.showCoupon || this.showAward) {
                        let arr = [];
                        if (this.formData.ActionType == 1 || this.formData.ActionType == 2 || this.formData.ActionType == 3) {
                            arr = this.formData.Rules.filter(v => {
                                return !v.ResourceId;
                            });
                        } else {
                            arr = this.formData.Rules.filter(v => {
                                return !v.ResourceId || !v.N;
                            });
                        }

                        if (arr.length > 0) {
                            this.showCoupon
                                ? this.$Message.error("优惠券信息有未填写或填写为0的内容")
                                : this.$Message.error("礼包信息有未填写或填写为0的内容");
                            return;
                        }
                    }
                    if (
                        this.showNum &&
                        this.formData.StartNum >= this.formData.EndNum &&
                        this.formData.StartNum != 0 &&
                        this.formData.EndNum != 0
                    ) {
                        this.$Message.error("任务频率开始不得大于或等于结束");
                        return;
                    }
                    if (!this.formData.StartTime || !this.formData.EndTime) {
                        this.$Message.error("请选择任务时间的开始时间和结束时间");
                        return;
                    }
                    let start = new Date(this.formData.StartTime).getTime();
                    let end = new Date(this.formData.EndTime).getTime();
                    if (start >= end) {
                        this.$Message.error("任务时间的开始时间不得大于或等于结束时间");
                        return;
                    }
                    try {
                        this.formData.Rules.map(item => {
                            if (item.Tip) {
                                throw new Error();
                            }
                        });
                    } catch (error) {
                        this.$Message.error("请检查返利配置");
                        return;
                    }
                    let maxPercent = Math.max.apply(
                        Math,
                        this.formData.Rules.map(i => {
                            return i.Percent;
                        })
                    );
                    let maxVipPercent = 0;
                    if (this.formData.VipAmplifierSwitch) {
                        maxVipPercent = Math.max.apply(
                            Math,
                            this.VipAmplifier.map(i => {
                                return i.Percent;
                            })
                        );
                    }

                    if (maxPercent + maxVipPercent >= 100) {
                        this.$Modal.warning({
                            title: "提示",
                            content: "返利超过100%，请检查配置",
                            okText: "确认"
                        });
                        return;
                    }
                    if (maxPercent + maxVipPercent > 50 && maxPercent + maxVipPercent < 100) {
                        this.$Modal.confirm({
                            title: "提示",
                            content: "返利超过50%，是否要继续提交？",
                            okText: "提交",
                            cancelText: "取消",
                            onOk: () => {
                                this.$Modal.remove();
                                this.submitApi();
                            },
                            onCancel: () => {
                                this.$Modal.remove();
                            }
                        });
                        return;
                    }
                    this.submitApi();
                }
            });
        },
        submitApi() {
            this.loading = true;
            let params = JSON.parse(JSON.stringify(this.formData));
            params.IsCoupon = params.IsCoupon == 1 ? true : false;
            params.Rules = params.Rules.map(v => {
                v.ResourceId = Number(v.ResourceId);
                if (params.ActionType == 1 || params.ActionType == 2 || params.ActionType == 3) {
                    v.N = 0;
                }
                if (params.ActionType == 6 || params.ActionType == 7 || params.ActionType == 9) {
                    v.N = Number(v.N) * 100;
                }
                // 参数校验 若没有Percent/RebateNumMax需给默认值
                if (!v.WithStartAmount) {
                    v.StartAmount = 0;
                    v.WithStartAmount = false;
                }
                if (!v.WithEndAmount) {
                    v.EndAmount = 0;
                    v.WithEndAmount = false;
                }
                if (!v.Percent) {
                    v.Percent = 0;
                }
                if (!v.RebateNumMax) {
                    v.RebateNumMax = 0;
                }
                delete v.Tip;
                delete v.firstAmount;
                delete v.firstCode;
                delete v.lastAmount;
                delete v.lastCode;
                return v;
            });
            if (params.VipAmplifierSwitch) {
                params.VipAmplifier = this.VipAmplifier.filter(item => item.Percent);
            } else {
                params.VipAmplifier = [];
            }
            if (params.ResourceType === 3 && this.isShowRebate) {
                params.ResourceType = 4;
            }
            if (!this.id) {
                CouponAPI.AddNewTask(params)
                    .then(res => {
                        if (res.Code == 0) {
                            // this.$emit("update-list");
                            this.$Message.success("新增成功");
                            this.handelCancel();
                        } else {
                            this.$Message.error(res.Message);
                        }
                    })
                    .finally(() => {
                        this.loading = false;
                    });
            } else {
                // delete params.UnionIds;
                CouponAPI.EditNewTask({
                    ...params,
                    Id: Number(this.id)
                })
                    .then(res => {
                        if (res.Code == 0) {
                            // this.$emit("update-list");
                            this.$Message.success("编辑成功");
                            this.handelCancel();
                        } else {
                            this.$Message.error(res.Message);
                        }
                    })
                    .finally(() => {
                        this.loading = false;
                    });
            }
        },
        getAppById(AppIds) {
            CouponAPI.GetApp({ AppIds }).then(res => {
                if (res.Code == 0) {
                    this.appList = res.Data || [];
                }
            });
        },
        getAppList(value) {
            CouponAPI.LikeApp(value).then(res => {
                if (res.Code === 0) {
                    this.appList = res.Data || [];
                }
            });
        }
    }
};
</script>
<style lang="less" scoped>
.vip-box {
    width: 80%;
    display: flex;
    flex-wrap: wrap;
    .item-box {
        width: 23%;
        margin: 8px;
        span {
            width: 20%;
            text-align: left;
        }
        display: flex;
    }
}
.tip {
    color: rgba(0, 0, 0, 0.5);
}
</style>
