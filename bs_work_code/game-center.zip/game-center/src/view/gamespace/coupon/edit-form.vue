<!--新增，编辑弹窗内的表单-->
<template>
    <Form ref="form" :model="formData" :rules="rules" :label-width="140">
        <form-item label="优惠券名称：" prop="CouponTitle">
            <Input v-model="formData.CouponTitle" placeholder="请输入优惠券名称"></Input>
        </form-item>

        <form-item label="优惠券类型：" prop="CouponUseType">
            <Radio-group v-model="formData.CouponUseType" @on-change="changeClear({CouponDiscount: 0,CouponRxType: 1})">
                <Radio :label="1" :disabled="isEdit">折扣券</Radio>
                <Radio :label="2" :disabled="isEdit">满减券</Radio>
                <Radio :label="3" :disabled="isEdit">鲨享券</Radio>
            </Radio-group>
        </form-item>
        <form-item v-if="formData.CouponUseType == 3" label="总金额">
            <InputNumber :min="0" v-model="formData.CouponDiscount" :disabled="isEdit" style="width: 100px" :precision="2"></InputNumber>元
        </form-item>
        <form-item v-if="formData.CouponUseType != 3" label="优惠规则：" :disabled="isEdit" prop="CouponRuleType">
            <Radio-group v-model="formData.CouponRuleType">
                <Radio :label="1" :disabled="isEdit">指定金额</Radio>
                <Radio :label="2" :disabled="isEdit">任意金额</Radio>
            </Radio-group>
            <!--满减-->
            <div v-if="formData.CouponUseType == 2">
                <div v-if="formData.CouponRuleType == 2">
                    任意金额可用，减
                    <form-item prop="CouponDiscount" style="display: inline-block">
                        <InputNumber
                            :min="0"
                            v-model="formData.CouponDiscount"
                            :disabled="isEdit"
                            style="display: inline-block; width: 100px"
                            :precision="2"
                        ></InputNumber>元
                    </form-item>
                </div>
                <div v-if="formData.CouponRuleType == 1">
                    满
                    <form-item prop="CouponAmount" style="display: inline-block">
                        <InputNumber
                            :min="0"
                            v-model="formData.CouponAmount"
                            :disabled="isEdit"
                            style="display: inline-block; width: 90px"
                            :precision="2"
                        ></InputNumber>元可用，减
                    </form-item>
                    <form-item prop="CouponDiscount" style="display: inline-block">
                        <InputNumber
                            :min="0"
                            v-model="formData.CouponDiscount"
                            :disabled="isEdit"
                            style="display: inline-block; width: 90px"
                            :precision="2"
                        ></InputNumber>元
                    </form-item>
                </div>
            </div>

            <!--折扣-->
            <div v-if="formData.CouponUseType == 1">
                <div v-if="formData.CouponRuleType == 2">
                    <form-item prop="CouponDiscount" style="display: inline-block">
                        任意金额可用，折扣
                        <InputNumber
                            :min="0"
                            v-model="formData.CouponDiscount"
                            :disabled="isEdit"
                            style="display: inline-block; width: 90px"
                        ></InputNumber>
                    </form-item>
                </div>
                <div v-if="formData.CouponRuleType == 1">
                    满
                    <form-item prop="CouponAmount" style="display: inline-block">
                        <InputNumber
                            :min="0"
                            v-model="formData.CouponAmount"
                            :disabled="isEdit"
                            style="display: inline-block; width: 100px"
                            :precision="2"
                        ></InputNumber>
                    </form-item>
                    <form-item prop="CouponDiscount" style="display: inline-block">
                        元可用，折扣
                        <InputNumber
                            :min="0"
                            v-model="formData.CouponDiscount"
                            :disabled="isEdit"
                            style="display: inline-block; width: 100px"
                        ></InputNumber>
                    </form-item>
                </div>
            </div>
        </form-item>

        <form-item label="发放方式：">
            <Radio-group
                v-model="formData.CouponRxType"
                @on-change="changeClear({ReceiveExpiredEnd: undefined,ReceiveExpiredStart: undefined,})"
            >
                <Radio :label="1" :disabled="isEdit">用户领取</Radio>
                <Radio :label="2" :disabled="isEdit">人工发放</Radio>
                <Radio :label="3" :disabled="isEdit">活动奖品</Radio>
                <Radio :label="4" :disabled="isEdit">任务发放</Radio>
                <Radio :label="5" :disabled="isEdit">限时领取</Radio>
                <Radio :label="6" v-if="formData.CouponUseType != 3" :disabled="isEdit">VIP券</Radio>
                <Radio :label="7" v-if="formData.CouponUseType != 3" :disabled="isEdit">黑卡会员</Radio>
                <Radio :label="8" v-if="formData.CouponUseType != 3" :disabled="isEdit">抽奖优惠券</Radio>
                <Radio :label="9" v-if="formData.CouponUseType != 3" :disabled="isEdit">vip专属优惠券</Radio>
            </Radio-group>
        </form-item>
        <form-item
            v-show="formData.CouponRxType==9"
            label="VIP专属领券等级："
            prop="FilterLevel"
            :rules="{validator: (rules,value,callback) => vipCoupon(rules,value,callback), trigger: 'blur'}"
        >
            <Input v-model="formData.FilterLevel" placeholder="请输入VIP专属领券等级" style="width: 300px"></Input>
            <div style="font-size:12px;padding-left:6px;">允许范围：1-18，可输入多个等级，并用“,”分开。例：1,2,3(输入多个等级时，按顺序输入，且两等级之间不可间隔)</div>
        </form-item>
        <form-item v-if="formData.CouponUseType != 3" label="黑卡专属：">
            <i-switch :value="formData.IsBlackVip" size="large" :disabled="isEdit">
                <span slot="open">是</span>
                <span slot="close">否</span>
            </i-switch>
        </form-item>
        <form-item label="优惠券数量：" prop="CouponCount">
            <InputNumber :min="0" v-model="formData.CouponCount" placeholder="请输入优惠券数量" style="width: 100px"></InputNumber>
        </form-item>
        <form-item label="单人最大领取数：" prop="MaxReceiveCount">
            <InputNumber :min="0" v-model="formData.MaxReceiveCount" placeholder="请输入单人最大领取数" style="width: 100px"></InputNumber>
        </form-item>
        <form-item v-if="formData.CouponUseType != 3" label="折扣金额封顶：" prop="DiscountLimit">
            <InputNumber :min="0" v-model="formData.DiscountLimit" placeholder="输入折扣金额封顶" style="width: 100px" :disabled="isEdit"></InputNumber>
            <span style="padding:0 6px;">元</span>
            <span style="font-size:12px;">（不配置则代表不限制）</span>
        </form-item>
        <form-item label="领取有效期：" v-if="formData.CouponRxType == 5||formData.CouponRxType == 9" class="time_exp" prop="ReceiveExpiredStart">
            <Row>
                <i-col :span="11">
                    <DatePicker
                        v-model="formData.ReceiveExpiredStart"
                        type="datetime"
                        placeholder="请设置开始时间"
                        style="width: 100%"
                        :editable="false"
                        @on-change="changeStart()"
                    ></DatePicker>
                </i-col>
                <i-col :span="11" offset="2">
                    <DatePicker
                        v-model="formData.ReceiveExpiredEnd"
                        type="datetime"
                        placeholder="请设置结束时间"
                        style="width: 100%"
                        :editable="false"
                        @on-change="changeEnd()"
                    ></DatePicker>
                </i-col>
            </Row>
            <div>*该时间用于前端展示，定义可领取时间范围</div>
            <div>*前端倒计时=设置的开始时间-当前时间</div>
        </form-item>
        <form-item label="使用有效期：">
            <Row>
                <Radio-group v-model="formData.CouponExpType" @on-change="changeExptype">
                    <Radio :label="1">时间段内有效</Radio>
                    <Radio :label="2">领取后生效</Radio>
                </Radio-group>
            </Row>
            <Row>
                <form-item prop="ExpiredStart">
                    <i-col :span="11">
                        <DatePicker
                            v-model="formData.ExpiredStart"
                            type="datetime"
                            placeholder="请设置开始时间"
                            style="width: 100%"
                            :disabled="formData.CouponRxType == 5 && formData.CouponExpType == 2"
                        ></DatePicker>
                    </i-col>
                    <i-col :span="11" offset="2">
                        <DatePicker
                            v-model="formData.ExpiredEnd"
                            type="datetime"
                            placeholder="请设置结束时间"
                            style="width: 100%"
                            :disabled="formData.CouponRxType == 5 && formData.CouponExpType == 2"
                        ></DatePicker>
                    </i-col>
                    <div v-if="formData.CouponExpType == 1">*该时间用于定义优惠券使用有效期，属于优惠券属性</div>
                </form-item>
            </Row>
            <Row v-if="formData.CouponExpType == 2">
                <i-col :span="15" style="display: flex; align-items: center; margin-top: 20px">
                    <form-item prop="UseCycle">
                        <InputNumber v-model="formData.UseCycle" type="datetime" placeholder="请设置有效天数" style="width: 80px"></InputNumber>&nbsp;
                        <span>天有效</span>
                    </form-item>
                </i-col>
            </Row>
        </form-item>

        <form-item label="使用范围：">
            <Radio-group v-model="formData.CouponScopeType" @on-change="changeClear({RankId: undefined,AppId: undefined,})">
                <Radio :label="1" :disabled="isEdit">所有游戏</Radio>
                <Radio :label="2" :disabled="isEdit">选择部分游戏</Radio>
                <Radio :label="3" :disabled="isEdit">单款游戏</Radio>
                <Radio :label="4" :disabled="isEdit">排除部分游戏</Radio>
            </Radio-group>
            <!-- <Select
        v-if="formData.CouponScopeType == 3"
        :multiple="formData.CouponScopeType !== 3"
        filterable
        remote
        :remote-method="remoteGames"
        :loading="gameLoading"
        v-model="formData.AppId"
        placeholder="请选择游戏"
      >
        <Option v-for="item in gamesList" :value="item.ID" :key="item.ID">{{
          item.AppName
        }}</Option>
            </Select>-->
            <AppSelect
                v-if="formData.CouponScopeType == 3"
                :multiple="formData.CouponScopeType !== 3"
                :disabled="isEdit"
                v-model="formData.AppId"
                style="width: 200px"
                placeholder="请选择游戏"
            ></AppSelect>
            <Select
                v-if="formData.CouponScopeType == 2 || formData.CouponScopeType == 4"
                :multiple="false"
                :disabled="isEdit"
                filterable
                remote
                :remote-method="remoteRanks"
                :loading="rankLoading"
                v-model="formData.RankId"
                placeholder="请选择榜单"
                ref="selection"
            >
                <Option v-for="item in ranksList" :value="item.ID" :key="item.ID">
                    {{
                    item.Title
                    }}
                </Option>
            </Select>
        </form-item>

        <form-item label="优惠券说明：">
            <Input v-model="formData.CouponDesc" type="textarea" :rows="3"></Input>
        </form-item>

        <form-item label="成本分配：">
            <Radio-group v-model="formData.CouponCostType">
                <Radio :label="1" :disabled="isEdit">黑鲨与CP</Radio>
                <Radio :label="2" :disabled="isEdit">CP</Radio>
                <Radio :label="3" :disabled="isEdit">黑鲨</Radio>
            </Radio-group>
        </form-item>
        <FormItem label="展示范围：">
            <Select v-model="formData.CouponShowType" style="width: 200px">
                <Option v-for="item in showScopeList" :key="item.ID" :value="item.ID">{{item.Name}}</Option>
            </Select>
        </FormItem>
        <!-- :disabled="isEdit" -->
        <FormItem label="选择可展示机型：" v-if="formData.CouponShowType == 1">
            <SurpotModel v-model="formData.Model" />
        </FormItem>
        <FormItem label="领取范围：" v-if="formData.CouponUseType != 3">
            <Select v-model="formData.ReceiveRuleScope" style="width: 200px" multiple clearable>
                <Option v-for="item in ScopeList" :key="item.ID" :value="item.ID">{{item.Name}}</Option>
            </Select>
        </FormItem>
        <FormItem label="选择可领取机型：" v-if="formData.ReceiveRuleScope && formData.ReceiveRuleScope.includes(1)">
            <SurpotModel v-model="formData.SupportModel" />
        </FormItem>
        <template v-if="formData.Conf">
            <FormItem label="剩余不足预警：">
                <Checkbox v-model="formData.Conf.IsWarning">启用</Checkbox>
            </FormItem>
            <template v-if="formData.Conf.IsWarning">
                <FormItem label="预警节点：">
                    <CheckboxGroup v-model="formData.Conf.WarningLevel">
                        <Checkbox :label="0.3">剩余30%</Checkbox>
                        <Checkbox :label="0.1">剩余10%</Checkbox>
                        <Checkbox :label="0">剩余0%</Checkbox>
                    </CheckboxGroup>
                </FormItem>
                <FormItem label="负责人：" prop="WarningPerson">
                    <CheckboxGroup v-model="formData.Conf.WarningPerson">
                        <Checkbox v-for="item in personList" :key="item.Id" :label="item.Name">{{ item.Name }}</Checkbox>
                    </CheckboxGroup>
                </FormItem>
            </template>
        </template>
    </Form>
</template>

<script>
import GameApi from "@/api/gamespace/game";
import couponApi from "@/api/gamespace/coupon";
import SurpotModel from "_c/SurpotModel";
import AppSelect from "_c/app-select";

export default {
    name: "editForm",
    props: ["value", "personList"],
    model: {
        prop: "value",
        event: "change"
    },
    components: { SurpotModel, AppSelect },
    data() {
        const DiscountNum = (rule, value, callback) => {
            if (this.formData.CouponUseType == 1 && (Number(value) < 10 || Number(value) > 99)) {
                callback("请填写10及以上的数字，推荐80、90…的整数。90=9折");
            } else if (this.formData.CouponUseType == 2 && Number(value) <= 0) {
                callback("请填写0以上数字");
            }
            callback();
        };
        const AmountNum = (rule, value, callback) => {
            if (Number(value) <= 0) {
                callback("请填写0以上数字");
            }
            callback();
        };
        const checkDate1 = (rule, value, callback) => {
            if (!this.formData.ReceiveExpiredStart || !this.formData.ReceiveExpiredEnd) {
                callback("请设置领取有效期");
            }
            if (this.formData.ReceiveExpiredStart >= this.formData.ReceiveExpiredEnd) {
                callback("领取有效期开始时间必需小于结束时间");
            }
            callback();
        };
        const checkDate2 = (rule, value, callback) => {
            if (!this.formData.ExpiredStart || !this.formData.ExpiredEnd) {
                callback("请设置使用有效期");
            }
            if (this.formData.ExpiredStart >= this.formData.ExpiredEnd) {
                callback("使用有效期开始时间必需小于结束时间");
            }
            callback();
        };
        const warningPerson = (rule, value, callback) => {
            if (!this.formData.Conf.WarningPerson || !this.formData.Conf.WarningPerson.length) {
                callback("请选择预警负责人");
            }
            callback();
        };
        return {
            isEdit: false,
            formData: {},
            rules: {
                CouponTitle: [{ required: true, message: "请填写优惠券名称", trigger: "blur" }],
                CouponDiscount: [
                    {
                        validator: DiscountNum,
                        trigger: "blur"
                    }
                ],
                CouponAmount: [
                    {
                        validator: AmountNum,
                        trigger: "blur"
                    }
                ],
                CouponCount: [
                    {
                        validator: AmountNum,
                        trigger: "blur"
                    }
                ],
                MaxReceiveCount: [
                    {
                        validator: AmountNum,
                        trigger: "blur"
                    }
                ],
                ReceiveExpiredStart: [
                    {
                        validator: checkDate1,
                        trigger: "blur",
                        type: "date"
                    }
                ],
                ExpiredStart: [
                    {
                        validator: checkDate2,
                        trigger: "blur",
                        type: "date"
                    }
                ],
                UseCycle: [
                    {
                        validator: AmountNum,
                        trigger: "blur"
                    }
                ],
                WarningPerson: [
                    {
                        required: true,
                        validator: warningPerson,
                        trigger: "change"
                    }
                ]
            },
            gameLoading: false,
            gamesList: [],
            ScopeList: [{ ID: 1, Name: "指定机型" }],
            showScopeList: [
                { ID: 0, Name: "全部" },
                { ID: 1, Name: "指定机型" }
            ],
            rankLoading: false,
            ranksList: []
        };
    },
    watch: {
        formData: {
            handler(val, old) {
                this.$emit("change", this.formData);
            },
            immediate: true,
            deep: true
        },
        value() {
            this.formData = this.value;
            this.isEdit = this.formData.ID ? true : false;
            // sdk 5.5.0新增 防止有null的情况
            this.formData.Conf && !this.formData.Conf.WarningLevel ? (this.formData.Conf.WarningLevel = []) : "";
            this.formData.Conf && !this.formData.Conf.WarningPerson ? (this.formData.Conf.WarningPerson = []) : "";
            // if (
            //   this.formData.CouponScopeType > 1 &&
            //   this.formData.AppId> 0
            // ) {
            //   this.initGamesList();
            // }
        }
    },
    mounted() {
        this.formData = this.value;
    },
    methods: {
        // syncData () {
        //   this.$emit('change', this.formData)
        // }
        changeStart() {
            this.formData.ExpiredStart = this.formData.ReceiveExpiredStart;
            if (this.formData.ReceiveExpiredStart && !this.formData.ReceiveExpiredEnd) {
                let time = new Date(this.formData.ReceiveExpiredStart).getTime() + 24 * 60 * 60 * 1000;
                this.formData.ReceiveExpiredEnd = new Date(time);
                this.changeEnd();
            }
        },
        changeEnd() {
            if (this.formData.CouponExpType == 1 && this.formData.ReceiveExpiredEnd) {
                let time = new Date(this.formData.ReceiveExpiredEnd).getTime() + 24 * 60 * 60 * 1000;
                this.formData.ExpiredEnd = new Date(time);
            } else {
                this.formData.ExpiredEnd = this.formData.ReceiveExpiredEnd;
            }
        },
        changeExptype(val) {
            if (val == 2) {
                this.formData.ExpiredStart = this.formData.ReceiveExpiredStart;
                this.formData.ExpiredEnd = this.formData.ReceiveExpiredEnd;
            }
            this.changeClear({
                UseCycle: 1
            });
        },
        remoteGames(value) {
            if (value !== "") {
                this.gameLoading = true;
                GameApi.LikeAppByReport({ value }).then(res => {
                    if (res.Code === 0) {
                        this.gamesList = res.Data || [];
                        this.gameLoading = false;
                    } else {
                        this.gamesList = [];
                        this.gameLoading = false;
                    }
                });
            } else {
                this.gamesList = [];
            }
        },
        remoteRanks(value) {
            if (value !== "") {
                this.rankLoading = true;
                couponApi
                    .LikeLimitRank(value)
                    .then(res => {
                        if (res.Code === 0) {
                            this.ranksList = res.Data || [];
                            // this.$refs["selection"].setQuery(this.ranksList[0]["Title"]);
                            // this.$refs["selection"].toggleMenu(null, false);
                            this.rankLoading = false;
                        }
                    })
                    .finally(() => {
                        this.rankLoading = false;
                    });
            }
        },

        // 当初始化的时候还原游戏列表
        // initGamesList() {
        //   if (
        //     this.formData.CouponScopeType > 1 &&
        //     this.formData.AppId> 0
        //     // this.formData.AppIDs.length > 0
        //   ) {
        //     couponApi.GamesByIds([this.formData.AppId]).then((res) => {
        //       if (res.Code === 0) {
        //         this.gamesList = res.Data || [];
        //         this.$refs["selection"].setQuery(this.gamesList[0]["AppName"]);
        //         this.$refs["selection"].toggleMenu(null, false);
        //       }
        //     });
        //   }
        // },
        changeClear(obj) {
            for (let key in obj) {
                let value = obj[key];
                this.formData[key] = value;
            }
        },
        // vip专属优惠券增加校验
        vipCoupon(rule, value, callback) {
            if (this.formData.CouponRxType == 9 && !value) {
                callback("请填写VIP专属领券等级");
            } else {
                callback();
            }
        }
    }
};
</script>

<style scoped>
.time_exp /depp/ .ivu-form-item-error-tip {
    padding-top: 26px;
}
</style>
