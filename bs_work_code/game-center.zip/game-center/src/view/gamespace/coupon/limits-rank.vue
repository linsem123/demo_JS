<template>
  <div>
    <Card dis-hover="">
      <Row :gutter="10" style="margin-bottom: 15px">
        <i-col :span="5" :xxl="4">
          <!-- <RankSelect v-model="search.RankID"></RankSelect> -->
          <Select
            :multiple="false"
            filterable
            remote
            :remote-method="rankRemote"
            :loading="rankLoading"
            v-model="search.RankId"
            placeholder="请选择榜单"
          >
            <Option v-for="item in ranksList" :value="item.ID" :key="item.ID">{{
              item.Title
            }}</Option>
          </Select>
        </i-col>
        <Col :span="5" :xxl="4">
          <Button
            type="success"
            shape="circle"
            icon="ios-search"
            @click="getRankList"
            >搜索</Button
          >
        </Col>
      </Row>

      <Table
        :data="tableData"
        :columns="columns"
        border
        :loading="tableLoading"
      >
        <template slot-scope="{ row }" slot="Status">
          <Tag color="success" v-if="row.Status == 1">上架</Tag>
          <Tag color="error" v-else-if="row.Status == 2">下架</Tag>
          <Tag color="warning" v-else>未处理</Tag>
        </template>
        <template slot-scope="{ row }" slot="Opt">
          <Button
            @click="editTheRank(row)"
            type="primary"
            size="small"
            style="margin-right: 10px"
            >编辑</Button
          >
          <Button
            v-if="row.Status !== 1"
            @click="updateStatus(row, 1)"
            type="success"
            size="small"
            >上架</Button
          >
          <Button v-else @click="updateStatus(row, 2)" type="error" size="small"
            >下架</Button
          >
          <Button
            @click="togame(row)"
            type="info"
            size="small"
            style="margin-left: 10px"
            >榜单游戏</Button
          >
        </template>
      </Table>

      <Row style="margin-top: 10px">
        <Col :span="6">
          <Button
            @click="editTheRank()"
            type="info"
            shape="circle"
            icon="md-add"
            >新增榜单</Button
          >
          <!-- v-if="search.PoolType === 1" -->
          <!-- <span v-else>&nbsp;</span> -->
        </Col>
        <Col :span="18" align="right">
          <Page
            :total="page.total"
            :current="page.current"
            :page-size="page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </Col>
      </Row>
    </Card>

    <Modal v-model="visible" :title="formData.ID ? '编辑' : '新增'">
      <Row>
        <Col :span="21">
          <Form
            :model="formData"
            :rules="rules"
            :label-width="120"
            ref="formData"
          >
            <FormItem label="榜单名称：" prop="Title">
              <Input
                v-model="formData.Title"
                placeholder="请输入榜单名称"
              ></Input>
            </FormItem>
            <FormItem label="描述：" prop="Desc">
              <Input
                type="textarea"
                :rows="2"
                v-model="formData.Desc"
                placeholder="请输入描述信息"
              ></Input>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button @click="visible = false" type="text" size="large">取消</Button>
        <Button @click="submitForm" type="primary" size="large">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
// import GameRankAPI from "@/api/gamespace/gamerank";
import CouponApi from "@/api/gamespace/coupon";
import RankSelect from "_c/rank-select";

export default {
  name: "",
  components: { RankSelect },
  data() {
    return {
      rankLoading: false,
      ranksList: [],
      search: {
        RankId: undefined,
      },
      page: {
        total: 100,
        current: 1,
        size: 10,
      },

      tableData: [],
      columns: [
        { title: "榜单ID", key: "ID", minWidth: 85 },
        { title: "榜单名称", key: "Title", minWidth: 150 },
        { title: "描述信息", key: "Desc", minWidth: 120 },
        { title: "状态", slot: "Status", minWidth: 80 },
        {
          title: "操作",
          slot: "Opt",
          minWidth: 200,
          align: "center",
          fixed: "right",
        },
      ],
      tableLoading: false,

      visible: false,
      formData: {},
      rules: {
        Title: [{ required: true, message: "请输入榜单名称", trigger: "blur" }],
      },
    };
  },
  mounted() {
    this.getRankList();
  },
  methods: {
    onPageChange(value) {
      this.page.current = value;
      this.getRankList();
    },
    onPageSizechange(value) {
      this.page.size = value;
      this.getRankList();
    },
    getRankListChange() {
      this.search.RankID = undefined;
      this.getRankList();
    },
    rankRemote(value) {
      if (value !== "") {
        this.rankLoading = true;
        CouponApi.LikeLimitRank(value)
          .then((res) => {
            if (res.Code === 0) {
              this.ranksList = res.Data || [];
              this.rankLoading = false;
            }
          })
          .finally(() => {
            this.rankLoading = false;
          });
      }
    },
    getRankList() {
      let params = {
        Limit: this.page.size,
        Page: this.page.current,
        Params: {
          //   PoolType: this.search.PoolType,
          id: this.search.RankId,
        },
      };
      this.tableLoading = true;
      CouponApi.LimitsRank(params).then((res) => {
        if (res.Code === 0) {
          this.page.total = res.Data.Count;
          this.tableData = res.Data.Data || [];
          this.$nextTick(() => {
            setTimeout(() => {
              this.tableLoading = false;
            });
          });
        }
      });
    },

    editTheRank(item) {
      if (!item) {
        this.formData = {};
      } else {
        this.formData = JSON.parse(JSON.stringify(item));
      }
      this.visible = true;
    },

    submitForm() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          let params = JSON.parse(JSON.stringify(this.formData));
          // params.ImgUrl = params.ImgUrl[0] ? params.ImgUrl[0].url : ""
          console.log(params);
          this.rankApi(params).then((res) => {
            if (res.Code === 0) {
              this.visible = false;
              this.getRankList();
              this.$Message.success("操作成功");
              this.formData = {};
            } else {
              this.$Message.error(res.Message);
            }
          });
        }
      });
    },

    rankApi(params) {
      if (this.formData.ID) {
        return CouponApi.EditLimitsRank(params);
      } else {
        return CouponApi.AddLimitsRank(params);
      }
    },

    updateStatus(row, Status) {
      CouponApi.UpdateLimitStatus(row.ID, Status).then((res) => {
        if (res.Code === 0) {
          this.getRankList();
          this.$Message.success("状态更新成功");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    togame(row) {
      console.log(row.ID);
      this.$router.push({
        name: "gamespace_limits_game",
        params: {
          id: row.ID,
        },
      });
    },
  },
};
</script>

<style scoped lang="less">
</style>
