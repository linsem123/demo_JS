<!--新增，编辑弹窗内的表单-->
<template>
	<Form
		ref="form"
		:model="formData"
		:rules="rules"
		:label-width="140"
	>
		<form-item label="创建时间：">
			{{ formatTime(formData.CreatedAt) }}
		</form-item>
		<form-item label="优惠券ID：">
			{{ formData.ID }}
		</form-item>
		<form-item label="优惠券名称：">
			{{ formData.CouponTitle }}
		</form-item>
		<form-item label="优惠券类型：">
			<span v-if="formData.CouponUseType === 1">折扣券</span>
			<span v-if="formData.CouponUseType === 2">满减券</span>
			<span v-if="formData.CouponUseType === 3">鲨享券</span>
		</form-item>
		<form-item
			v-if="formData.CouponUseType == 3"
			label="总金额："
		>
			<span>{{ formData.CouponDiscount }}</span>
		</form-item>
		<form-item
			v-if="formData.CouponUseType != 3"
			label="优惠规则："
		>
			<span v-if="formData.CouponRuleType === 1">指定金额</span>
			<span v-if="formData.CouponRuleType === 2">任意金额</span>
			<!--满减-->
			<div v-if="formData.CouponUseType == 2">
				<div v-if="formData.CouponRuleType == 2">
					任意金额可用，减 {{ formData.CouponDiscount }} 分
				</div>
				<div v-if="formData.CouponRuleType == 1">
					满 {{ formData.CouponAmount }} 分可用，减
					{{ formData.CouponDiscount }} 分
				</div>
			</div>

			<!--折扣-->
			<div v-if="formData.CouponUseType == 1">
				<div v-if="formData.CouponRuleType == 2">
					任意金额可用，折扣 {{ formData.CouponDiscount }}
				</div>
				<div v-if="formData.CouponRuleType == 1">
					满 {{ formData.CouponAmount }} 分可用，折扣
					{{ formData.CouponDiscount }}
				</div>
			</div>
		</form-item>

		<form-item label="发放方式：">
			<span v-if="formData.CouponRxType === 1">用户领取</span>
			<span v-if="formData.CouponRxType === 2">人工发放</span>
			<span v-if="formData.CouponRxType === 3">活动奖品</span>
			<span v-if="formData.CouponRxType === 4">任务发放</span>
		</form-item>

		<form-item label="数量：">
			{{ formData.CouponCount }}
		</form-item>

		<form-item label="使用有效期：">
			{{ formatTime(formData.ExpiredStart) }} —
			{{ formatTime(formData.ExpiredEnd) }}
		</form-item>

		<form-item label="使用范围：">
			<span v-if="formData.CouponScopeType === 1">所有游戏</span>
			<span v-if="formData.CouponScopeType === 2">选择部分游戏</span>
			<span v-if="formData.CouponScopeType === 3">单款游戏</span>
			<span v-if="formData.CouponScopeType === 4">排除部分游戏</span>
			<div v-if="formData.CouponScopeType !== 1">
				<Tag v-for="g in gamesList">{{ g.AppName }}</Tag>
			</div>
		</form-item>

		<form-item label="优惠券说明：">
			{{ formData.CouponDesc }}
		</form-item>

		<form-item label="成本分配：">
			<span v-if="formData.CouponCostType === 1">黑鲨与CP</span>
			<span v-if="formData.CouponCostType === 2">CP</span>
			<span v-if="formData.CouponCostType === 3">黑鲨</span>
		</form-item>
		<!-- <form-item label="领取范围：">
      <span>{{ formData.ReceiveRuleScope | filterRuleScope }}</span>
    </form-item> -->

		<form-item label="当前状态：">
			<span v-if="formData.CouponState === 1">新建</span>
			<span v-if="formData.CouponState === 2">不通过</span>
			<span v-if="formData.CouponState === 3">生效</span>
			<span v-if="formData.CouponState === 4">作废</span>
			<span v-if="formData.CouponState === 5">过期</span>
		</form-item>
		<!-- sdk 5.5.0新增 -->
		<template v-if="formData.Conf">
			<form-item label="剩余不足预警：">
				<span>{{ formData.Conf.IsWarning ? '启用' : '禁用' }}</span>
			</form-item>
			<template v-if="formData.Conf.IsWarning">
				<form-item label="预警节点：">
                    <span v-if="!formData.Conf.WarningLevel || !formData.Conf.WarningLevel.length">无</span>
					<span
                        v-else
						style="marginRight: 10px"
						v-for="(item, index) in formData.Conf.WarningLevel"
						:key="index"
					>{{item * 100}}%</span>
				</form-item>
				<form-item label="负责人：">
                    <span v-if="!formData.Conf.WarningPerson || !formData.Conf.WarningPerson.length">无</span>
					<span
                        v-else
						style="marginRight: 10px"
						v-for="(item, index) in formData.Conf.WarningPerson"
						:key="index"
					>{{item}}</span>
				</form-item>
			</template>
		</template>

		<template v-if="formData.approve">
			<!--新建时审批-->
			<form-item
				label="选择状态："
				v-if="formData.CouponState === 1"
			>
				<Radio-group v-model="formData.ApproveState">
					<Radio :label="3">生效</Radio>
					<Radio :label="2">不通过</Radio>
				</Radio-group>
			</form-item>
			<!--生效时审批-->
			<form-item
				label="选择状态："
				v-if="formData.CouponState === 3"
			>
				<Checkbox v-model="formData.ApproveState">作废</Checkbox>
			</form-item>

			<form-item label="审核意见：">
				<Input
					type="textarea"
					:rows="3"
				></Input>
			</form-item>
		</template>
	</Form>
</template>

<script>
import { formatTime } from '@/libs/tools'
import couponApi from '@/api/gamespace/coupon'

export default {
	name: '',
	props: ['value'],
	model: {
		prop: 'value',
		event: 'change',
	},
	data() {
		return {
			formData: {},
			rules: {},

			gamesList: [],
		}
	},
	watch: {
		formData: {
			handler(val, old) {
				this.$emit('change', this.formData)
			},
			immediate: true,
		},
		value() {
			this.formData = this.value
			// 非所有游戏且游戏列表有数据
			if (this.formData.CouponScopeType > 1 && this.formData.AppIDs && this.formData.AppIDs.length > 0) {
				this.initGamesList()
			}
		},
	},
	mounted() {
		this.formData = this.value
	},
	// filters: {
	//   filterRuleScope(value) {
	//     if (value && value.length > 0) {
	//       switch (value) {
	//         case 1:
	//           return "指定机型";
	//       }
	//     }
	//     return "无";
	//   },
	// },
	methods: {
		formatTime(time) {
			return formatTime(time)
		},

		// 当初始化的时候还原游戏列表
		initGamesList() {
			if (this.formData.CouponScopeType > 1 && this.formData.AppIDs.length > 0) {
				couponApi.GamesByIds(this.formData.AppIDs).then(res => {
					if (res.Code === 0) {
						this.gamesList = res.Data || []
					}
				})
			}
		},
	},
}
</script>

<style scoped>
.ivu-form-item {
	margin-bottom: 2px;
}
</style>
