// table-expand.vue
<style scoped>
.expand-row {
  margin-bottom: 16px;
}
</style>
<template>
  <div>
    <Row v-for="(item,i) in actType" v-if="item.value == row.ActType" style="padding-bottom:16px">
      <Col span="8">
        <span class="expand-key">任务类型ID:</span>
        <span class="expand-value">{{row.ActType}}</span>
      </Col>
      <Col span="8">
        <span class="expand-key">任务类型:</span>

        <span class="expand-value">{{ item.label }}</span>
      </Col>
    </Row>
    <Row class="expand-row" v-for="(item,i) in row.Rules" :key="i">
      <Col span="8" v-if="row.ActType<6 ||row.ActType==12||row.ActType==13">
        <span class="expand-key">优惠券ID:</span>
        <span class="expand-value">{{ item.CouponId }}</span>
      </Col>
      <Col span="8" v-if="row.ActType>=6&&row.ActType < 12">
        <span class="expand-key">礼包ID:</span>
        <span class="expand-value">{{ item.GiftId }}</span>
      </Col>
      <Col span="8" v-if="row.ActType==2||row.ActType==7">
        <span class="expand-key">登陆次数:</span>
        <span class="expand-value">{{ item.LoginTimes }}</span>
      </Col>
      <Col span="8" v-if="row.ActType==4||row.ActType==9||row.ActType==11">
        <span class="expand-key">充值金额:</span>
        <span class="expand-value">{{ item.Amount }}</span>
      </Col>
      <Col span="8" v-if="row.ActType==12||row.ActType==13">
        <span class="expand-key">vip等级:</span>
        <span class="expand-value">{{ item.VipLevel }}</span>
      </Col>
    </Row>
  </div>
</template>
<script>
export default {
  data() {
    return {
      actType: [
        { value: 1, label: "首次登陆-优惠券" },
        { value: 2, label: "累计登陆-优惠券" },
        { value: 4, label: "充值指定金额-优惠券" },
        { value: 6, label: "首次登陆-礼包" },
        { value: 7, label: "累计登陆-礼包" },
        { value: 9, label: "充值指定金额-礼包" },
        { value: 11, label: "充值包含优惠券送礼包" },
        { value: 12, label: "vip赠送" },
        { value: 13, label: "vip升级赠送" },
      ],
    };
  },
  props: {
    row: Object,
  },
};
</script>
