<template>
	<Card>
		<Table
			:data="couponList"
			:columns="couponColumns"
			border
		>
			<template
				slot="state"
				slot-scope="{row}"
			>
				<span>{{ row.TaskStatus | taskStatus }}</span>
			</template>
			<template
				slot-scope="{ row }"
				slot="opt"
			>
				<Button
					@click="updateCoupon(row)"
					type="warning"
					size="small"
					class="optStyle"
				>{{ row.TaskStatus == 1 ? '下架' : '上架' }}</Button>
				<Button
					@click="editCoupon(row)"
					type="primary"
					size="small"
					class="optStyle"
				>编辑</Button>
				<Button
					@click="delCoupon(row.Id)"
					type="error"
					size="small"
				>删除</Button>
			</template>
		</Table>
		<Row style="margin-top: 10px">
			<Col :span="6">
			<Button
				@click="editCoupon()"
				type="info"
				shape="circle"
				icon="md-add"
			>新增优惠券</Button>
			</Col>
			<Col
				:span="18"
				align="right"
			>
			<Page
				:total="page.total"
				:current="page.current"
				:page-size="page.size"
				@on-change="onPageChange"
				@on-page-size-change="onPageSizechange"
				show-sizer
				show-total
			></Page>
			</Col>
		</Row>
		<editDialog
			ref="editDialog"
			:editVisible="editVisible"
			@getList="getList"
		></editDialog>
	</Card>
</template>

<script>
import { formatTimes } from '@/libs/tools'
import couponApi from '@/api/gamespace/coupon'
import editDialog from './auto-coupon-dialog'
export default {
	components: { editDialog },
	filters: {
		taskStatus(status) {
			let text = ''
			switch (Number(status)) {
				case 0:
					text = '新建'
					break
				case 1:
					text = '上架'
					break
				case 2:
					text = '下架'
					break
				default:
					break
			}
			return text
		},
	},
	data() {
		return {
			page: {
				total: 0,
				current: 1,
				size: 10,
			},
			couponList: [],
			couponColumns: [
				{ title: '任务ID', key: 'Id', width: 80 },
				{ title: '任务名称', key: 'TaskName', width: 100 },
				{ title: '基础优惠券ID', key: 'CouponId', width: 120 },
				{ title: '任务开始时间', key: 'TaskStart', minWidth: 100 },
				{ title: '任务结束时间', key: 'TaskEnd', minWidth: 90 },
				{ title: '状态', slot: 'state', minWidth: 90 },
				{
					title: '操作',
					slot: 'opt',
					minWidth: 130,
					align: 'center',
					fixed: 'right',
				},
			],
			editVisible: false, // 编辑弹窗
		}
	},
	mounted() {
		this.getList()
	},
	methods: {
		async getList() {
			let params = {
				page: this.page.current,
				limit: this.page.size,
			}
			await couponApi.getAutoCouponList(params).then(res => {
				if (res.Code == 0) {
					this.page.total = res.Data.Count
					this.couponList = res.Data.Data
				} else {
                    this.$Message.error(res.Message)
                }
			})
		},
		// 编辑优惠券
		editCoupon(row) {
			this.$refs.editDialog.setData(row)
			this.$refs.editDialog.editVisible = true
		},
        // 上下架
        updateCoupon (row) {
            let status = row.TaskStatus == 1 ? 2 : 1
            couponApi.updateAutoCoupon(row.Id, status).then(res => {
                if (res.Code == 0) {
                    this.getList()
                } else {
                    this.$Message.error(res.Message)
                }
            })
        },
		// 删除优惠券
		delCoupon(id) {
			// delAutoCoupon
			this.$Modal.confirm({
				title: '确认是否删除该任务',
				okText: '确认',
				onOk: () => {
					couponApi.delAutoCoupon(id).then(res => {
						if (res.Code === 0) {
							this.$Message.success('删除成功')
                            this.getList()
						} else {
							this.$Message.success('删除失败')
						}
					})
				},
			})
		},
		onPageChange(value) {
			this.page.current = value
			this.getList()
		},
		onPageSizechange(value) {
			this.page.size = value
			this.getList()
		},
	},
}
</script>

<style lang="less" scoped>
.optStyle {
	margin-right: 10px;
}
</style>