<!--优惠券列表-->
<template>
    <div>
        <Card>
            <Row style="margin: 10px 0 15px" :gutter="10">
                <Col span="4">
                    <Input v-model="search.ID" placeholder="请输入优惠券ID"></Input>
                </Col>
                <Col span="4">
                    <Input v-model="search.Name" placeholder="请输入优惠券名称"></Input>
                </Col>
                <Col span="4">
                    <span>状态：</span>
                    <Select v-model="search.CouponStatus" clearable style="display: inline-block; width: 75%" placeholder="优惠券状态">
                        <Option v-for="item in couponState" :value="item.value">
                            {{
                            item.name
                            }}
                        </Option>
                    </Select>
                </Col>
                <Col span="4">
                    <span>类型：</span>
                    <Select v-model="search.CouponUseType" clearable style="display: inline-block; width: 75%" placeholder="优惠券类型">
                        <Option v-for="item in couponUseType" :value="item.value">
                            {{
                            item.name
                            }}
                        </Option>
                    </Select>
                </Col>
                <Col span="5">
                    <span>发放方式：</span>
                    <Select v-model="search.CouponRxType" clearable style="display: inline-block; width: 60%">
                        <Option v-for="item in couponRxType" :value="item.value">
                            {{
                            item.name
                            }}
                        </Option>
                    </Select>
                </Col>
                <Col span="3">
                    <Button type="primary" @click="onSearch()">查询</Button>
                </Col>
            </Row>

            <Table border :columns="columns" :data="tableData">
                <template slot="numbers" slot-scope="{ row, index }">
                    {{ row.UsedCount }} / {{ row.CouponCount }} /
                    {{ row.CouponTotalCount }}
                </template>
                <template slot="couponUseType" slot-scope="{ row, index }">{{ useTypeFilter(row.CouponUseType) }}</template>
                <template slot="couponRxType" slot-scope="{ row, index }">{{ rxTypeFilter(row.CouponRxType) }}</template>
                <template slot="couponState" slot-scope="{ row, index }">{{ stateFilter(row.CouponState) }}</template>
                <template slot="CouponExpType" slot-scope="{ row }">{{ ExpTypeFilter(row.CouponExpType) }}</template>
                <template slot="ExpiredStart" slot-scope="{ row }">{{ row.ExpiredStart ? row.ExpiredStart : null | time }}</template>
                <template slot="ExpiredEnd" slot-scope="{ row }">{{ row.ExpiredStart ? row.ExpiredEnd : null | time }}</template>
                <template slot="UseCycle" slot-scope="{ row }">{{ row.CouponExpType == 2 ? row.UseCycle : "" }}</template>
                <template slot="CouponShowType" slot-scope="{ row }">{{ row.CouponShowType | ShowTypeFilter }}</template>

                <template slot="opt" slot-scope="{ row, index }">
                    <Button
                        v-show="
              (row.CouponRxType === 1 || row.CouponRxType === 5 || row.CouponRxType === 9) &&
              row.CouponState === 3
            "
                        size="small"
                        :disabled="row.CouponRankId != 0"
                        @click="sendRow(row)"
                        type="success"
                        style="margin-right: 6px"
                    >投放</Button>
                    <!-- </template> -->

                    <Button size="small" v-if="row.CouponRxType === 2" @click="exportRow(row)" type="info" style="margin-right: 6px">导出</Button>
                    <Button size="small" @click="editRow(row)" type="primary">修改</Button>
                    <!-- :disabled="row.CouponState !== 1" -->
                    <Button
                        size="small"
                        v-if="[1, 3].includes(row.CouponState)"
                        @click="approveRow(row)"
                        style="margin-left: 6px"
                        type="warning"
                    >审核</Button>
                    <Button size="small" @click="viewDetail(row)" style="margin-left: 6px" type="primary" ghost>查看</Button>
                    <Button size="small" @click="handleCopyTrak(row.ID)" style="margin-left: 6px" type="success">复制</Button>
                </template>
            </Table>

            <div style="margin: 10px 0; overflow: hidden">
                <div style="float: left">
                    <Button type="info" shape="circle" icon="md-add" @click="createCoupon">创建优惠券</Button>
                    <Button style="margin-left: 15px" type="warning" shape="circle" icon="md-add" @click="autoCreateCoupon">自动创建</Button>
                </div>
                <div style="float: right">
                    <Page
                        :total="page.total"
                        :current="page.current"
                        :page-size="page.size"
                        :page-size-opts="[10, 20, 40, 80, 100]"
                        @on-change="onPageChange"
                        @on-page-size-change="onPageSizechange"
                        show-sizer
                        show-total
                    ></Page>
                </div>
            </div>
        </Card>

        <!-- 新增，编辑弹窗   -->
        <Modal v-model="editVisible" :title="editFormData.ID ? '编辑' : '新增'" :mask-closable="false" width="600px">
            <!-- :loading="editFormLoading"
            @on-ok="submitFormData"-->
            <Row>
                <Col :span="21">
                    <EditForm ref="editForm" :personList="personList" v-model="editFormData"></EditForm>
                </Col>
            </Row>
            <template slot="footer">
                <Button @click="editVisible = false">取消</Button>
                <Button type="primary" @click="submitFormData">确定</Button>
            </template>
        </Modal>

        <!--审核、查看 弹窗-->
        <Modal
            v-model="detailVisible"
            :title="approve ? '审核' : '查看'"
            :loading="detailFormLoading"
            @on-ok="submitApproveData"
            :mask-closable="false"
            width="600px"
        >
            <Row>
                <Col :span="21">
                    <DetailForm ref="detailForm" v-model="detailFormData"></DetailForm>
                </Col>
            </Row>
        </Modal>
    </div>
</template>

<script>
/*
  CouponTitle    string          `gorm:"column:coupon_name;type:varchar(30)"`  //优惠券名称
        CouponDesc     string          `gorm:"column:coupon_desc;type:varchar(100)"` //优惠券说明
        CouponState    CouponStateType `gorm:"column:coupon_state"`                //优惠券状态
        ExpiredStart   time.Time       `gorm:"column:expired_start"`    //开始时间 YYYYMMDDHHmmss
        ExpiredEnd     time.Time       `gorm:"column:expired_end"`      //结束时间
        CouponCount    int             `gorm:"column:coupon_count"`     //优惠券数量
        CouponCostType CouponCostType  `gorm:"column:coupon_cost_type"` //成本分配方式
        CouponUseType  CouponUseType   `gorm:"column:coupon_use_type"`  // 优惠券使用类型
        CouponRuleType CouponRuleType  `gorm:"column:coupon_rule_type"` //优惠规则
        //满指定金额，CouponRuleType==CouponRuleTypeLimited 可用,金额单位为分
        CouponAmount int `gorm:"column:coupon_reducce_amount"`
        //优惠额度 CouponUseType==CouponUseTypeDiscount，折扣券为折扣百分比(1折是10 2折 20)  CouponUseType==CouponUseTypeReduce 满减金额
        CouponDiscount int          `gorm:"column:coupon_discount"`
        CouponRxType   CouponRxType `gorm:"column:coupon_rx_type"` //领取发放方式

        //CouponScopeType 使用范围
        CouponScopeType CouponScopeType `gorm:"column:coupon_scope_type"`
        AppIDs          orm.StrArray    `gorm:"column:app_ids"`
  * */

import EditForm from "./edit-form";
import DetailForm from "./detail-form";
import commentApi from "@/api/gamespace/comment";
import couponApi from "@/api/gamespace/coupon";
import common from "@/view/gameCircle/pubFunc/common";
import config from "@/config/index";

export default {
    name: "",
    data() {
        return {
            search: {},
            page: {
                current: 1,
                size: 10,
                total: 0
            },
            // 优惠券状态
            couponState: [
                { value: 1, name: "新建" },
                { value: 2, name: "不通过" },
                { value: 3, name: "生效" },
                { value: 4, name: "作废" },
                { value: 5, name: "过期" }
            ],
            // 优惠券类型
            couponUseType: [
                { value: 1, name: "折扣券" },
                { value: 2, name: "满减劵" },
                { value: 3, name: "鲨享券" }
            ],
            // 优惠券发放方式
            couponRxType: [
                { value: 1, name: "用户领取" },
                { value: 2, name: "人工发放" },
                { value: 3, name: "活动奖品" },
                { value: 4, name: "任务发放" },
                { value: 5, name: "限时领取" },
                { value: 6, name: "VIP券" }
            ],
            ExpType: [
                { value: 1, name: "时间段内有效" },
                { value: 2, name: "领取后生效" }
            ],

            columns: [
                { title: "优惠券ID", key: "ID", minWidth: 85 },
                { title: "优惠券名称", key: "CouponTitle", minWidth: 120 },
                { title: "使用范围", key: "UseRange", minWidth: 100 },
                { title: "已使用/未发放/总数", slot: "numbers", minWidth: 150 },
                { title: "单人最大领取数", key: "MaxReceiveCount", minWidth: 100 },
                { title: "优惠券类型", slot: "couponUseType", minWidth: 100 },
                { title: "发放方式", slot: "couponRxType", minWidth: 100 },
                { title: "优惠券状态", slot: "couponState", minWidth: 100 },
                { title: "使用有效期", slot: "CouponExpType", minWidth: 100 },
                { title: "使用有效期开始时间", slot: "ExpiredStart", minWidth: 100 },
                { title: "使用有效期结束时间", slot: "ExpiredEnd", minWidth: 100 },
                { title: "使用有效天数", slot: "UseCycle", minWidth: 100 },
                { title: "展示范围", slot: "CouponShowType", minWidth: 100 },
                { title: "指定机型展示范围", key: "Model", minWidth: 150 },
                {
                    title: "操作",
                    slot: "opt",
                    fixed: "right",
                    align: "left",
                    width: 270
                }
            ],
            tableData: [],

            // 新增编辑的表单数据
            editVisible: false,
            editFormLoading: true,
            editFormData: {
                CouponUseType: 1,
                CouponRuleType: 1,
                CouponRxType: 1,
                CouponScopeType: 1,
                CouponCostType: 1,
                ReceiveRuleScope: [],
                SupportModel: [],
                CouponExpType: 1,
                CouponShowType: 0,
                Model: [],
                MaxReceiveCount: 1,
                CouponCount: 1,
                UseCycle: 1,
                IsBlackVip: false,
                DiscountLimit: 0,
                FilterLevel: "",
                Conf: {
                    IsWarning: true,
                    WarningLevel: [0, 0.1, 0.3],
                    WarningPerson: []
                }
            },

            //
            detailVisible: false,
            detailFormData: {},
            detailFormLoading: false,
            approve: false, // 标记当前是审批还是查看
            personList: []
        };
    },
    components: { EditForm, DetailForm },
    mounted() {
        this.init();
        this.getPersonList();
    },
    methods: {
        onPageChange(value) {
            this.page.current = value;
            this.init();
        },
        onPageSizechange(value) {
            this.page.size = value;
            this.init();
        },

        init() {
            let pm = Object.assign({}, { Params: this.search }, { Limit: this.page.size, Page: this.page.current });
            couponApi.GetList(pm).then(res => {
                if (res.Code === 0) {
                    this.page.total = res.Data.Count;
                    this.tableData = res.Data.Data || [];
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },

        onSearch() {
            this.page.current = 1;
            this.init();
        },

        editRow(row) {
            this.editVisible = true;
            let SupportModel = row.ReceiveRuleExpandInfo.SupportModel.split(",");
            let Model = row.Model.split(",");
            let ReceiveRuleScope = row.ReceiveRuleScope || [];
            let CouponDiscount = row.CouponDiscount;
            if (row.CouponUseType == 2 || row.CouponUseType == 3) {
                CouponDiscount = row.CouponDiscount / 100;
            }
            let DiscountLimit = row.DiscountLimit / 100;
            let CouponAmount = row.CouponAmount / 100;
            this.editFormData = {
                ...row,
                DiscountLimit,
                SupportModel,
                Model,
                ReceiveRuleScope,
                CouponDiscount,
                CouponAmount
            };
            // console.log(this.editFormData)
            // row = { ...row, SupportModel,Model,ReceiveRuleScope};
            // this.editFormData = JSON.parse(JSON.stringify(row));
            // this.editFormData.SupportModel = SupportModel
            delete this.editFormData.ReceiveRuleExpandInfo;
        },
        // sdk 5.5.0新增
        getPersonList() {
            const params = {
                page: 1,
                pageSize: 9999
            };
            commentApi.GetPersonList(params).then(res => {
                if (res.Code == 0) {
                    this.personList = res.Data.List;
                } else {
                    this.$Message.error("获取预警负责人失败");
                }
            });
        },
        /*提交编辑或新增*/
        submitFormData() {
            this.editFormData.DiscountLimit = this.editFormData.DiscountLimit * 100;
            this.editFormData.FilterLevel = String(this.editFormData.FilterLevel);
            if (this.editFormData.CouponUseType == 3) this.editFormData.CouponRuleType = 2;
            if (this.editFormData.CouponShowType == 1 && this.editFormData.Model == 0) {
                this.$Message.error("可展示机型至少选择一项");
                return;
            }
            if (this.editFormData.ReceiveRuleScope.includes(1) && this.editFormData.SupportModel.length == 0) {
                this.$Message.error("可领取机型至少选择一项");
                return;
            }
            this.$refs.editForm.$refs.form.validate(valid => {
                if (valid) {
                    let params = JSON.parse(JSON.stringify(this.editFormData));
                    if (params.CouponRxType == 5) {
                        let ExpiredEnd = new Date(params.ExpiredEnd).getTime();
                        let ExpiredStart = new Date(params.ExpiredStart).getTime();
                        let ReceiveExpiredStart = new Date(params.ReceiveExpiredStart).getTime();
                        let ReceiveExpiredEnd = new Date(params.ReceiveExpiredEnd).getTime();
                        if (ExpiredEnd < ReceiveExpiredEnd) {
                            this.$Message.error("使用有效期的结束时间，必须晚于等于领取有效期的结束时间");
                            return;
                        }
                        if (ExpiredStart > ReceiveExpiredStart) {
                            this.$Message.error("使用有效期的开始时间，必须早于等于领取有效期的开始时间");
                            return;
                        }
                    }
                    if (!this.editFormData.Conf.IsWarning) {
                        params.Conf.WarningLevel = [];
                        params.Conf.WarningPerson = [];
                    }
                    params.ReceiveRuleExpandInfo = {
                        SupportModel: this.editFormData.SupportModel.join(",")
                    };
                    if (this.editFormData.CouponUseType == 2 || this.editFormData.CouponUseType == 3) {
                        params.CouponDiscount = this.editFormData.CouponDiscount * 100;
                    }
                    params.CouponAmount = this.editFormData.CouponAmount * 100;
                    params.Model = this.editFormData.Model.join(",");
                    params.ExpiredEnd ? params.ExpiredEnd : undefined;
                    params.ExpiredStart ? params.ExpiredStart : undefined;
                    params.ReceiveExpiredStart ? params.ReceiveExpiredStart : undefined;
                    params.ReceiveExpiredEnd ? params.ReceiveExpiredEnd : undefined;
                    if (params.CouponRuleType == 2) params.CouponAmount = 0;
                    delete params.SupportModel;
                    if (params.ID) {
                        // this.subEdit()
                        console.log(JSON.parse(JSON.stringify(params)));
                        couponApi.EditCoupon(params).then(res => {
                            if (res.Code === 0) {
                                this.init();
                                this.editFormLoading = false;
                                this.editVisible = false;
                                this.$Message.success("编辑成功");
                            } else {
                                this.$Message.error(res.Message);
                            }
                        });
                    } else {
                        // this.subAdd()
                        console.log(params);
                        // if (params.CouponScopeType == 3) {
                        //   params.AppIDs = [params.AppIDs];
                        // }
                        params.AppId = Number(params.AppId);
                        couponApi.AddCoupon(params).then(res => {
                            if (res.Code === 0) {
                                this.init();
                                this.editFormLoading = false;
                                this.editVisible = false;
                                this.$Message.success("新增成功");
                            } else {
                                this.$Message.error(res.Message);
                            }
                        });
                    }
                } else {
                    this.editFormLoading = false;
                    this.$nextTick(() => {
                        this.editFormLoading = true;
                    });
                }
            });
        },

        // 点击添加优惠券
        createCoupon() {
            this.editFormData = {
                CouponAmount: 0,
                CouponCostType: 1,
                CouponCount: 1,
                CouponDiscount: 0,
                CouponRuleType: 1,
                CouponRxType: 1,
                CouponScopeType: 1,
                CouponUseType: 1,
                DiscountLimit: 0,
                ExpiredEnd: "",
                ExpiredStart: "",
                FilterLevel: "",
                ReceiveRuleScope: [],
                SupportModel: [],
                CouponExpType: 1,
                CouponShowType: 0,
                Model: [],
                MaxReceiveCount: 1,
                UseCycle: 1,
                IsBlackVip: false,
                Conf: {
                    IsWarning: true,
                    WarningLevel: [0, 0.1, 0.3],
                    WarningPerson: []
                }
            };
            // this.editFormData.Conf.WarningPerson = this.personList.map(item => {
            //     return item.Name
            // })
            this.editVisible = true;
        },

        // 自动创建优惠券
        autoCreateCoupon() {
            this.$router.push({
                name: "gamespace_autocoupon_list"
            });
        },

        // 审核
        approveRow(row) {
            this.detailVisible = true;
            this.approve = true;
            this.detailFormData = Object.assign({ approve: true }, JSON.parse(JSON.stringify(row)));
        },
        // 提交审核
        submitApproveData() {
            if (this.detailFormData.approve) {
                let state = this.detailFormData.ApproveState;
                if (typeof state === "boolean") {
                    state = state ? 4 : this.detailFormData.CouponState;
                }
                if (typeof state === "undefined") {
                    state = this.detailFormData.CouponState;
                }
                this.detailFormData.ApproveState = state;
                if (this.detailFormData.ApproveState !== this.detailFormData.CouponState) {
                    couponApi.UpdateState(this.detailFormData).then(res => {
                        if (res.Code === 0) {
                            this.$Message.success("操作成功");
                            this.init();
                        } else {
                            this.$Message.error(res.Message);
                        }
                    });
                }
            }
        },
        // 查看详情
        viewDetail(row) {
            this.approve = false;
            this.detailVisible = true;
            this.detailFormData = Object.assign({ approve: false }, JSON.parse(JSON.stringify(row)));
        },

        // 导出
        exportRow(row) {
            couponApi.ExportCoupon(row.ID).then(res => {
                if (res.Code === 0) {
                    let url = res.Data;
                    url = url.replace(".", "");
                    location.href = config.fileBaseUrl + url;
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        // 投放
        sendRow(row) {
            this.$Modal.confirm({
                title: "投放优惠券",
                content: `确定投放优惠券：${row.CouponTitle} 吗？`,
                onOk: () => {
                    let params = {
                        CouponID: row.ID
                    };
                    if (row.CouponUseType == 3) params.Rank = 2;
                    couponApi.SendCoupon(params).then(res => {
                        if (res.Code === 0) {
                            this.$Message.success("投放成功");
                        } else {
                            this.$Message.error(res.Message);
                        }
                        this.init();
                    });
                }
            });
        },

        // couponState  couponUseType  couponRxType
        stateFilter(v) {
            let res = this.couponState.filter(item => item.value == v)[0];
            return (res && res.name) || "-";
        },
        useTypeFilter(v) {
            let res = this.couponUseType.filter(item => item.value == v)[0];
            return (res && res.name) || "-";
        },
        rxTypeFilter(v) {
            let res = this.couponRxType.filter(item => item.value == v)[0];
            return (res && res.name) || "-";
        },
        ExpTypeFilter(v) {
            let res = this.ExpType.filter(item => item.value == v)[0];
            return (res && res.name) || "-";
        },
        //复制
        handleCopyTrak(ID) {
            this.$Modal.confirm({
                title: "提示",
                content: "<p>是否复制？</p>",
                onOk: () => {
                    couponApi.CouponCopy(ID).then(res => {
                        if (res.Code === 0) {
                            this.$Message.success("复制成功！");
                            this.init();
                        } else if (res.Message) {
                            this.$Message.error(res.Message);
                        }
                    });
                },
                onCancel: () => {
                    //
                }
            });
        }
    },
    filters: {
        time(v) {
            if (v) return common.formatDate(v, true);
            return "";
        },
        ShowTypeFilter(v) {
            let str = ["全部", "指定机型"][v];
            return str || "";
        }
    }
};
</script>

<style scoped>
</style>
