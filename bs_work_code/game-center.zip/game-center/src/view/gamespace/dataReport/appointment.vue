<template>
  <div>
    <Card>
      <Form
        ref="formValidate"
        :model="formData"
        :rules="ruleValidate"
        :inline="true"
        style="position: relative"
      >
        <FormItem prop="AppName">
          <Select
            v-model="formData.AppId"
            clearable
            filterable
            remote
            :remote-method="handleGameSearch"
            placeholder="请输入游戏名称"
            ref="AppName"
            @on-change="changeAppName"
          >
            <Option v-for="item in gameList" :value="item.ID" :key="item.ID">{{
              item.AppName
            }}</Option>
          </Select>
        </FormItem>
        <FormItem prop="AppId">
          <Select
            v-model="formData.AppId"
            clearable
            filterable
            remote
            :remote-method="handleGamePkgNameSearch"
            placeholder="请输入游戏包名"
            ref="packageName"
            @on-change="changeValue"
          >
            <Option v-for="item in gameList" :value="item.ID" :key="item.ID">{{
              item.PkgName
            }}</Option>
          </Select>
        </FormItem>
        <FormItem label="预约来源" prop="SubPlacement" :label-width="60">
          <Selection
            v-model="formData.SubPlacement"
            :dataList="DownloadAppPlaceList"
          />
        </FormItem>
        <FormItem label="预约状态" prop="Status" :label-width="60">
          <Selection v-model="formData.Status" :dataList="StatusList" />
        </FormItem>
        <FormItem prop="Time" :label-width="15">
          <DatePicker
            v-model="formData.StartTime"
            type="date"
            format="yyyy-MM-dd"
            placeholder="开始日期"
            style="width: 120px"
            @on-change="(v) => changeDate(v, 'StartTime')"
          ></DatePicker>
          -
          <DatePicker
            v-model="formData.EndTime"
            type="date"
            format="yyyy-MM-dd"
            placeholder="结束日期"
            style="width: 120px"
            @on-change="(v) => changeDate(v, 'EndTime')"
          ></DatePicker>
        </FormItem>
        <FormItem label="聚合" prop="IsAggregation" :label-width="45">
          <Checkbox
            v-model="formData.IsAggregation"
            @on-change="
              tableData = [];
              toSearch();
            "
          />
        </FormItem>
        <Button type="primary" @click="toSearch" style="margin-right: 15px"
          >查询</Button
        >
        <Button type="success" @click="toExport">导出</Button>
      </Form>
      <Table
        border
        highlight-row
        ref="currentRowTable"
        :columns="formData.IsAggregation ? columns : columns2"
        :data="tableData"
        :loading="loading"
        :max-height="600"
        @on-selection-change="selectionChange"
      >
        <template slot-scope="{ row }" slot="Status">
          <span v-if="row.Status == 0">预约成功</span>
          <span v-if="row.Status == 1">取消预约</span>
        </template>
        <template slot-scope="{ row }" slot="SubPlacement">
          <span v-if="row.SubPlacement == 0">游戏中心</span>
          <span v-if="row.SubPlacement == 1">应用商店</span>
          <span v-if="row.SubPlacement == 2">其他</span>
        </template>
      </Table>
      <Page
        show-sizer
        :total="total"
        show-total
        :page-size="pageSize"
        :current="pageIndex"
        @on-change="changePage"
        @on-page-size-change="changePageSize"
      />
    </Card>
  </div>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
import DataReport from "@/api/gamespace/dataReport";
import Selection from "_c/Selection.vue";
import common from "@/view/gameCircle/pubFunc/common.js";
import config from "@/config/index";
export default {
  components: { Selection },
  data() {
    return {
      formData: {
        AppId: undefined,
        SubPlacement: undefined,
        Status: undefined,
        IsAggregation: true,
        StartTime: "",
        EndTime: "",
      },
      ruleValidate: {},
      DownloadAppPlaceList: [
        {
          Id: 0,
          Name: "游戏中心",
        },
        {
          Id: 1,
          Name: "应用商店",
        },
        {
          Id: 2,
          Name: "其他",
        },
      ],
      StatusList: [
        {
          Id: 0,
          Name: "预约成功",
        },
        {
          Id: 1,
          Name: "取消预约",
        },
      ],
      columns: [
        // { type: "selection", width: 50 },
        {
          title: "日期",
          key: "Day",
          align: "center",
          minWidth: 100,
        },
        {
          title: "游戏名称",
          key: "AppName",
          align: "center",
          minWidth: 200,
        },
        {
          title: "游戏包名",
          key: "PkgName",
          minWidth: 200,
          align: "center",
        },
        {
          title: "预约次数",
          key: "SubCount",
          align: "center",
          minWidth: 100,
        },
        {
          title: "真实预约人数",
          key: "RealSubCount",
          align: "center",
          minWidth: 100,
        },
        {
          title: "取消预约人数",
          key: "CancelSubCount",
          align: "center",
          minWidth: 100,
        },
        {
          title: "预约上报imei去重数",
          key: "ImeiCount",
          align: "center",
          minWidth: 100,
        },
      ],
      columns2: [
        {
          title: "游戏名称",
          key: "AppName",
          align: "center",
          minWidth: 200,
        },
        {
          title: "游戏包名",
          key: "PkgName",
          minWidth: 200,
          align: "center",
        },
        // {
        //   title: "帐号",
        //   key: "UserID",
        //   align: "center",
        //   minWidth: 100,
        // },
        {
          title: "imei",
          key: "IMEI",
          align: "center",
          minWidth: 100,
        },
        {
          title: "昵称",
          key: "NickName",
          align: "center",
          minWidth: 100,
        },
        {
          title: "预约机型",
          key: "ModelName",
          align: "center",
          minWidth: 100,
        },
        {
          title: "预约时间",
          key: "CreatedAt",
          align: "center",
          minWidth: 100,
        },
        {
          title: "预约来源",
          slot: "SubPlacement",
          align: "center",
          minWidth: 100,
        },
        {
          title: "预约状态",
          slot: "Status",
          align: "center",
          minWidth: 100,
        },
      ],
      tableData: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      loading: false,
      gameList: [],
      selection: [],
    };
  },
  mounted() {
    this.searchServer();
  },
  methods: {
    //游戏名
    changeAppName(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["packageName"].setQuery(item[0].PkgName);
        this.$refs["packageName"].toggleMenu(null, false);
      }
    },
    //包名
    changeValue(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["AppName"].setQuery(item[0].AppName);
        this.$refs["AppName"].toggleMenu(null, false);
      }
    },
    //查询游戏名称
    handleGameSearch(value) {
      GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    //查询游戏包名
    handleGamePkgNameSearch(value) {
      GameAPI.LikeAppByParams({ params: { PkgName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    selectionChange(sel) {
      this.selection = sel;
    },
    changeDate(val, type) {
      let StartTime = new Date(this.formData.StartTime).getTime();
      let EndTime = new Date(this.formData.EndTime).getTime();
      if (StartTime > EndTime) {
        this.formData[type] = "";
        this.$Message.error("开始时间不得大于结束时间");
        return;
      }
    },
    //查询
    toSearch() {
      this.pageIndex = 1;
      this.searchServer();
    },
    //导出
    toExport() {
      //   if (this.selection.length === 0) {
      //     this.$Message.error("请勾选要导出的数据");
      //   } else {
      if (!this.formData.AppId) {
        this.$Message.error("请输入游戏名称或游戏安装包");
        return;
      }
      let serveName = this.formData.IsAggregation
        ? "AggregationExport"
        : "ExportAppointment";
      DataReport[serveName]({
        params: {
          AppId: this.formData.AppId,
          IsAggregation: this.formData.IsAggregation,
        },
      }).then((res) => {
        if (res.Code === 0) {
          let url = res.Data;
          url = url.replace(".", "");
          window.location.href = config.fileBaseUrl + url;
        } else {
          this.$Message.error(res.Message);
        }
      });
      //   }
    },
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.searchServer();
    },
    searchServer() {
      //   if (!this.formData.AppID) {
      //     this.$Message.error("请输入游戏名称或游戏安装包");
      //     return;
      //   }
      this.formData.StartTime = this.formData.StartTime
        ? common.formatDate(this.formData.StartTime)
        : "";
      this.formData.EndTime = this.formData.EndTime
        ? common.formatDate(this.formData.EndTime)
        : "";
      for (let key in this.formData) {
        if (this.formData[key] === "") {
          this.formData[key] = undefined;
        }
      }
      DataReport.GetAppointment({
        Limit: this.pageSize,
        Page: this.pageIndex,
        Params: this.formData,
      }).then((res) => {
        if (res.Code == 0) {
          this.total = res.Data.Count;
          this.tableData = res.Data.Data.map((v) => {
            v.date = v.InstallTime
              ? common.formatDate(v.InstallTime, true)
              : "";
            return v;
          });
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>