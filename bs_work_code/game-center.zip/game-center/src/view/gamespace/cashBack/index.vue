<template>
    <div>
        <Row class="header">
            <Col span="2" class="header-text">状态：</Col>
            <Col span="3" style="margin-right:12px">
                <Select v-model="status" filterable>
                    <div slot="empty">not Found data</div>
                    <Option v-for="item in optionList" :value="item.value" :key="item.value">{{ item.label }}</Option>
                </Select>
            </Col>
            <Col span="4">
                <Button type="success" style="margin-right:20px" @click="searchAction">搜索</Button>
                <Button type="success" @click="addDataAction()">添加</Button>
            </Col>
        </Row>
        <Table :columns="columns" border :data="list">
            <template slot="StartAt" slot-scope="{ row }">{{ row.StartAt ? row.StartAt : null | time }}</template>
            <template slot="EndAt" slot-scope="{ row }">{{ row.EndAt ? row.EndAt : null | time }}</template>
            <template slot="Status" slot-scope="{ row }">{{ row.Status | statusFilter }}</template>
            <template slot="CreatedAt" slot-scope="{ row }">{{ row.CreatedAt ? row.CreatedAt : null | time }}</template>
            <template slot="ActDesc" slot-scope="{ row }">
                <!-- this.liveData.Description.replace(/(\r\n)|(\n)/g, "<br>"); -->
                <div v-html="row.ActDesc"></div>
            </template>
            <!-- ActDesc -->
            <template slot-scope="{ row, index }" slot="action">
                <Button type="primary" style="margin-right: 5px" @click="updateAction(row, index)">修改</Button>
                <Button type="error" @click="deleteAction(row)">删除</Button>
            </template>
        </Table>
        <div style="margin:20px 0;">
            <Page
                :total="pageTotal"
                :current="pageIndex"
                :page-size="pageSize"
                @on-change="onPageIndexChange"
                @on-page-size-change="onPageSizeChange"
                show-sizer
                show-total
            ></Page>
        </div>
        <!-- 对话框修改数据 -->
        <Modal v-model="modelShow" :title="modelTitle">
            <Form ref="formInline" :model="formData" :rules="rules" :label-width="120">
                <!-- ActName -->
                <FormItem prop="ActName" label="活动标题：">
                    <Row>
                        <Col span="15">
                            <Input type="text" v-model="formData.ActName" placeholder="请输入活动标题" :maxlength="10" />
                        </Col>
                    </Row>
                </FormItem>
                <FormItem prop="RangeType" label="下发游戏：">
                    <Row>
                        <Col span="15">
                            <Select v-model="formData.RangeType" filterable>
                                <div slot="empty">not Found data</div>
                                <Option v-for="item in RangeList" :value="item.value" :key="item.value">{{ item.label }}</Option>
                            </Select>
                        </Col>
                    </Row>
                </FormItem>
                <FormItem v-if="formData.RangeType==2" prop="RangeId" label="游戏ID：">
                    <Row>
                        <Col span="15">
                            <Input type="text" v-model="formData.RangeId" placeholder="请输入游戏ID" />
                        </Col>
                    </Row>
                </FormItem>
                <FormItem v-if="formData.RangeType==3" prop="RangeId" label="榜单ID：">
                    <Row>
                        <Col span="15">
                            <Input type="text" v-model="formData.RangeId" placeholder="请输入榜单ID" />
                        </Col>
                    </Row>
                </FormItem>
                <FormItem prop="StartAt" label="开始时间：">
                    <Row>
                        <Col span="15">
                            <DatePicker v-model="formData.StartAt" type="datetime" placeholder="选择开始时间"></DatePicker>
                        </Col>
                    </Row>
                </FormItem>
                <FormItem prop="EndAt" label="结束时间：">
                    <Row>
                        <Col span="15">
                            <DatePicker v-model="formData.EndAt" type="datetime" placeholder="选择结束时间"></DatePicker>
                        </Col>
                    </Row>
                </FormItem>
                <FormItem prop="TaskId" label="自动任务ID：">
                    <Row>
                        <Col span="15">
                            <Input type="text" v-model="formData.TaskId" placeholder="请输入自动任务" />
                        </Col>
                    </Row>
                </FormItem>
                <FormItem prop="ActDesc" label="活动说明：">
                    <Row>
                        <Col span="15">
                            <Input type="textarea" v-model="formData.ActDesc" :rows="4" :maxlength="1000" placeholder="请输入活动说明" />
                        </Col>
                    </Row>
                </FormItem>
            </Form>
            <div slot="footer">
                <Button type="default" @click="cancelAction">取消</Button>
                <Button type="primary" @click="confirmAction">确定</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
import Api from "@/api/gamespace/cashBack";
import common from "@/view/gameCircle/pubFunc/common";
export default {
    data() {
        return {
            pageIndex: 1,
            pageSize: 10,
            pageTotal: 0,
            status: 3,
            optionList: [
                {
                    value: 3,
                    label: "全部"
                },
                {
                    value: 0,
                    label: "待开始"
                },
                {
                    value: 2,
                    label: "进行中"
                },
                {
                    value: 1,
                    label: "已结束"
                }
            ],
            RangeList: [
                {
                    value: 0,
                    label: "无游戏"
                },
                {
                    value: 1,
                    label: "所有游戏"
                },
                {
                    value: 2,
                    label: "单个游戏"
                },
                {
                    value: 3,
                    label: "榜单游戏"
                }
            ],
            columns: [
                {
                    title: "活动Id",
                    minWidth: 100,
                    key: "Id"
                },
                {
                    title: "活动标题",
                    minWidth: 100,
                    key: "ActName"
                },
                {
                    title: "开始时间",
                    minWidth: 160,
                    slot: "StartAt"
                },
                {
                    title: "结束时间",
                    minWidth: 160,
                    slot: "EndAt"
                },
                {
                    title: "自动任务ID",
                    minWidth: 100,
                    key: "TaskId"
                },
                {
                    title: "活动说明",
                    minWidth: 200,
                    slot: "ActDesc"
                },
                {
                    title: "状态",
                    width: 150,
                    slot: "Status"
                },
                {
                    title: "创建时间",
                    width: 150,
                    slot: "CreatedAt"
                },
                {
                    title: "操作",
                    fixed: "right",
                    slot: "action",
                    width: 200,
                    align: "center"
                }
            ],
            list: [],
            modelShow: false,
            modelTitle: "新增活动",
            formData: {
                ActName: "消费返利",
                RangeType: 1,
                RangeId: "",
                StartAt: "",
                TaskId: "",
                EndAt: ""
            },
            rules: {
                ActName: [
                    {
                        required: true,
                        message: "请输入活动标题",
                        trigger: "blur"
                    }
                ]
            }
        };
    },
    filters: {
        time(v) {
            if (v) return common.formatDate(v, true);
            return "";
        },
        statusFilter(v) {
            let str = ["待开始", "已结束", "进行中"][v];
            return str || "";
        }
    },
    mounted() {
        this.loadList();
    },
    methods: {
        searchAction() {
            this.pageSize = 10;
            this.pageIndex = 1;
            this.loadList();
        },
        loadList() {
            let params = {
                Limit: this.pageSize,
                Page: this.pageIndex,
                Params: {
                    status: this.status
                }
            };
            Api.List(params).then(res => {
                if (res.Code === 0) {
                    this.list = res.Data.Data.map(item => {
                        item.ActDesc = item.ActDesc.replace(/(\r\n)|(\n)/g, "<br>");
                        return item;
                    });
                    this.pageTotal = res.Data.Count;
                }
            });
        },
        updateAction(row) {
            let rowData = JSON.parse(JSON.stringify(row));
            rowData.ActDesc = row.ActDesc.replace(/<br\s*V?>/gi, "\r\n");
            this.modelTitle = "编辑活动";
            this.modelShow = true;
            this.formData = rowData;
            if (!row.ActName) this.formData.ActName = "消费返利";
        },
        deleteAction(row) {
            let that = this;
            let params = {
                id: row.Id
            };
            this.$Modal.confirm({
                title: "确认是否删除该活动",
                okText: "确认",
                onOk: () => {
                    Api.Delete(params).then(res => {
                        if (res.Code === 0) {
                            this.$Message.success("删除成功");
                            this.pageSize = 10;
                            this.pageIndex = 1;
                            this.status = 3;
                            this.loadList();
                        } else {
                            this.$Message.success("删除失败");
                        }
                    });
                }
            });
        },
        onPageIndexChange(value) {
            this.pageSize = 10;
            this.pageIndex = value;
            this.status = 3;
            this.loadList();
        },
        onPageSizeChange(value) {
            this.pageSize = value;
            this.pageIndex = 1;
            this.status = 3;
            this.loadList();
        },
        // 对话框
        addDataAction() {
            this.modelShow = true;
            this.modelTitle = "新增活动";
            this.$refs.formInline.resetFields();
            this.formData = {
                RangeId: "",
                StartAt: "",
                TaskId: "",
                EndAt: "",
                ActName: "消费返利",
                ActDesc: ""
            };
        },
        confirmAction() {
            this.$refs["formInline"].validate(valid => {
                if (valid) {
                    let params = {
                        RangeType: Number(this.formData.RangeType),
                        RangeId: Number(this.formData.RangeId),
                        StartAt: this.formData.StartAt,
                        TaskId: Number(this.formData.TaskId),
                        EndAt: this.formData.EndAt,
                        Id: this.formData.Id,
                        ActName: this.formData.ActName,
                        ActDesc: this.formData.ActDesc
                    };
                    if (this.formData.Id) {
                        Api.Edit(params).then(async res => {
                            if (res.Code === 0) {
                                this.$Message.success("操作成功");
                                this.pageSize = 10;
                                this.pageIndex = 1;
                                this.status = 3;
                                this.loadList();
                                this.modelShow = false;
                            } else {
                                this.$Message.error("操作失败");
                            }
                        });
                    } else {
                        Api.Add(params).then(async res => {
                            if (res.Code === 0) {
                                this.$Message.success("操作成功");
                                this.pageSize = 10;
                                this.pageIndex = 1;
                                this.status = 3;
                                this.loadList();
                                this.modelShow = false;
                            } else {
                                this.$Message.error("操作失败");
                            }
                        });
                    }
                } else {
                    this.$Message.error("请填写必填项");
                }
            });
        },
        cancelAction() {
            this.modelShow = false;
            this.$refs["formInline"].resetFields();
            // this.formData.Title = "消费返利";
        }
    }
};
</script>

<style lang="less" scoped>
.header {
    padding-bottom: 20px;
    .header-text {
        padding-top: 6px;
        padding-left: 16px;
    }
}
</style>