<template>
    <Card title="预约指令查询">
        <Form ref="formValidate"
            :model="formData"
            :rules="ruleValidate"
            :inline="true">
            <FormItem  prop="direct">
                <gameNameSelect v-model="formData.AppId" :multiple="false" :width="250"/>
            </FormItem>
            <Button type="success" shape="circle" icon="ios-search" @click="search">搜索</Button>
        </Form>
        <div v-show="result" >
        <div style="padding:10px 0;">
            <Button type="primary" @click="copy" title="点击复制以下内容">复制</Button>
            点击复制以下内容
        </div>
        <Input readonly type="textarea" :rows="12" style="width:70%" v-model="result" ref="resultText" id="textcopy"/>
        </div>
    </Card>
</template>
<script>
import OrderDirect from "@/api/gamespace/orderDirect";
import gameNameSelect from '@/view/gameCircle/components/gameNameSelect'
export default {
    components:{
        gameNameSelect
    },
    data(){
        const isEmpty = (rule, value, callback)=>{
            if(value.trim() == ""){
                return callback(new Error('请输入预约指令'))
            }else {
                callback()
            }
        }
        return {
            formData:{
                AppId:''
            },
            ruleValidate:{direct:[{validator:isEmpty,trigger:'change'}]},
            result:""
        }
    },
    methods:{
        search(){
            OrderDirect.orderDirectData(this.formData.AppId).then(res=>{
                if(res.Code == 0){
                    this.result =res.Data
                }else {
                    this.$Message.error(res.Message)
                }
            })
        },
        copy(){
            this.$refs['resultText'].$refs['textarea'].select();
             document.execCommand("Copy");
             this.$Message.success('复制成功')
        }
    }
}
</script>