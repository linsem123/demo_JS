<template>
  <div>
    <Card>
      <Row>
        <i-col :span="12" :offset="1">
          <h3>参数配置</h3>
          <Form
            :model="templateData"
            :label-width="160"
            :rules="rules"
            ref="formData"
          >
            <FormItem label="当前活动名称：">
              <p>{{ pool.Title }}</p>
            </FormItem>
            <FormItem label="关联游戏：" prop="AppId">
              <AppSelect
                v-model="templateData.AppId"
                style="width: 200px"
                placeholder="请输入游戏名称"
                @on-change="changeApp"
              />
            </FormItem>
            <FormItem label="关联游戏包名：">
              {{ pkgName }}
            </FormItem>
            <FormItem label="宣传头图：" prop="HeadImage">
              <UploadImg
                v-model="templateData.HeadImage"
                module="award"
              ></UploadImg>
              <div style="color: red; font-size: 12px">
                注：上传的图片请小于100k
              </div>
            </FormItem>
            <FormItem label="是否显示游戏信息：" prop="IsShowAppInfo">
              <i-switch
                v-model="templateData.IsShowAppInfo"
                :true-value="1"
                :false-value="2"
              >
              </i-switch>
            </FormItem>
            <FormItem label="是否展示预约榜名次：" prop="IsShowSubscribe">
              <i-switch v-model="templateData.IsShowSubscribe"></i-switch>
            </FormItem>
            <FormItem label="背景颜色：" prop="BackgroundColor">
              <ColorPicker v-model="templateData.BackgroundColor" alpha />
            </FormItem>
            <FormItem label="模块：" prop="type">
              <Selection
                v-model="templateData.ModelType"
                :dataList="typeList"
                :clearable="false"
                :width="200"
              />
              <Button
                style="margin-left: 10px"
                @click="AddModel()"
                icon="md-add"
                shape="circle"
                >添加</Button
              >
            </FormItem>
            <div style="margin-left: 100px; color: red; font-size: 12px">
              1.上传的图片请小于100k
            </div>
            <div style="margin-left: 100px; color: red; font-size: 12px">
              2.H5活动页面底部务必配置高度>260px的色块，作为“安装button”的底图
            </div>
            <div v-if="templateData.ConfigModel.length > 0" class="model_box">
              <draggable
                id="dropBox"
                class="drop-box"
                v-bind="{ group: 'drag_list' }"
                v-model="templateData.ConfigModel"
                @input="handleListChange($event)"
                @end="handleEnd($event)"
                group="site"
              >
                <div
                  v-for="(item, index) of templateData.ConfigModel"
                  :key="index"
                  class="model_box"
                  style="position: relative"
                >
                  <p>
                    {{ typeList.filter((v) => v.Id == item.ModelType)[0].Name }}
                  </p>
                  <!-- 上传活动图片-所以模块展示  -->
                  <FormItem label="图片：" :label-width="110">
                    <div style="display: inline-block; width: 120px">
                      <p style="width: 120px">活动图片</p>
                      <UploadImg
                        v-model="
                          templateData.ConfigModel[index].BackgroundImage
                        "
                        module="gamespace"
                      ></UploadImg>
                    </div>
                  </FormItem>
                  <!-- 截图类型-截图模块展示  -->
                  <FormItem
                    label="截图类型"
                    :label-width="110"
                    v-if="item.ModelType == 4"
                  >
                    <RadioGroup
                      v-model="templateData.ConfigModel[index].Direction"
                    >
                      <Radio :label="1">竖图</Radio>
                      <Radio :label="2">横图</Radio>
                    </RadioGroup>
                  </FormItem>
                  <!-- 绑定跳转类型-自由模块展示  -->
                  <FormItem
                    label="绑定跳转类型："
                    :label-width="110"
                    v-if="item.ModelType == 2"
                  >
                    <Selection
                      :dataList="JumpList"
                      v-model="templateData.ConfigModel[index].ModuleJumpType"
                      :width="200"
                      @on-change="templateData.ConfigModel[index].AwardId = 0"
                    />
                  </FormItem>
                  <!-- 自由模块展示 -->
                  <template v-if="item.ModelType == 2">
                    <FormItem label="是否跳转：" :label-width="110">
                      <Checkbox
                        v-model="templateData.ConfigModel[index].IsJump"
                      ></Checkbox>
                    </FormItem>
                    <!-- 跳转类型-1｜3-抽奖/宣传活动｜文章 -->
                    <FormItem
                      :label="
                        item.ModuleJumpType == 1 ? '绑定H5活动：' : '绑定文章：'
                      "
                      :label-width="110"
                      v-if="
                        item.ModuleJumpType == 1 || item.ModuleJumpType == 3
                      "
                    >
                      <ActivitySelect
                        v-model="templateData.ConfigModel[index].ActivityId"
                        :type="item.ModuleJumpType == 1 ? 2 : 1"
                        @on-change="(val) => feedChange(val, index)"
                        placeholder="请输入活动名称"
                      ></ActivitySelect>
                    </FormItem>

                    <!-- 跳转类型-2-论坛帖 -->
                    <FormItem
                      label="绑定论坛帖："
                      :label-width="110"
                      v-if="item.ModuleJumpType == 2"
                    >
                      <CommonSelect
                        v-model="templateData.ConfigModel[index].AwardId"
                        placeholder="请填写论坛帖活动"
                        :serverData="postServerData"
                      />
                    </FormItem>
                    <!-- 跳转类型-4-单游戏论坛主页 -->
                    <FormItem
                      label="绑定游戏："
                      prop="AwardId"
                      :label-width="110"
                      v-if="item.ModuleJumpType == 4"
                    >
                      <AppSelect
                        v-model="templateData.ConfigModel[index].AwardId"
                        style="width: 200px"
                        placeholder="请输入游戏名称"
                        @on-change="(val) => changeSingleApp(val, index)"
                      />
                    </FormItem>
                    <!-- 跳转类型-5-榜单 -->
                    <FormItem
                      v-if="item.ModuleJumpType == 5"
                      label="榜单类型："
                      :label-width="110"
                    >
                      <Selection
                        v-model="templateData.ConfigModel[index].RankType"
                        :dataList="rankTypeList"
                        :width="200"
                        @on-change="templateData.ConfigModel[index].AwardId = 0"
                      />
                    </FormItem>
                    <FormItem
                      v-if="item.ModuleJumpType == 5"
                      label="绑定榜单："
                      :label-width="110"
                    >
                      <RankSelect
                        :rankType="templateData.ConfigModel[index].RankType"
                        v-model="templateData.ConfigModel[index].AwardId"
                      ></RankSelect>
                      <!-- @on-change="getrank" -->
                    </FormItem>
                    <FormItem
                      v-if="item.ModuleJumpType == 5"
                      label="落地页类型："
                      :label-width="110"
                    >
                      <Selection
                        v-model="templateData.ConfigModel[index].FloorPageType"
                        :dataList="floorPageList"
                        :width="200"
                      />
                    </FormItem>
                    <!-- 跳转类型-6-模块合辑 -->
                    <FormItem
                      v-if="item.ModuleJumpType == 6"
                      label="绑定模块合辑："
                      :label-width="110"
                    >
                      <CommonSelect
                        v-model="templateData.ConfigModel[index].AwardId"
                        placeholder="请填写模块合辑"
                        :serverData="serverData"
                      />
                    </FormItem>
                    <!-- 跳转类型-7-depplink -->
                    <FormItem
                      v-if="item.ModuleJumpType == 7"
                      label="绑定DeepLink包名："
                      :label-width="110"
                    >
                      <Input
                        v-model.trim="templateData.ConfigModel[index].PkgName"
                        placeholder="请填写包名"
                      ></Input>
                    </FormItem>
                    <FormItem
                      v-if="item.ModuleJumpType == 7"
                      label="绑定DeepLink："
                      :label-width="110"
                    >
                      <Input
                        v-model.trim="templateData.ConfigModel[index].DeepLink"
                        placeholder="请填写DeepLink"
                      ></Input>
                    </FormItem>
                    <!-- 跳转类型-8-链接 -->
                    <FormItem
                      v-if="item.ModuleJumpType == 8"
                      label="绑定url："
                      :label-width="110"
                    >
                      <Input
                        v-model.trim="
                          templateData.ConfigModel[index].AwardButtonUrl
                        "
                        placeholder="请填写url"
                      ></Input>
                    </FormItem>
                  </template>
                  <Icon
                    type="ios-close"
                    :size="24"
                    style="
                      position: absolute;
                      right: 10px;
                      top: 5px;
                      cursor: pointer;
                    "
                    title="点击删除"
                    @click="handleDelete(index)"
                  />
                </div>
              </draggable>
            </div>
            <div v-else class="model_box model_box_none">暂无模版数据</div>
            <FormItem label="立即下载按钮背景颜色：" prop="BottomColor">
              <ColorPicker v-model="templateData.BottomColor" />
            </FormItem>
            <FormItem label="立即下载按钮文字颜色：" prop="FontColor">
              <ColorPicker v-model="templateData.FontColor" />
            </FormItem>
            <FormItem align="center">
              <Button
                @click="submitTmp"
                type="primary"
                style="width: 150px; margin-right: 10px"
                >保 存</Button
              >
              <Button type="default" @click="cancel">取 消</Button>
            </FormItem>
          </Form>
        </i-col>
        <i-col :span="10" :offset="1">
          <h3>效果预览</h3>
          <div>
            <TmpPreview :value="preview"></TmpPreview>
          </div>
        </i-col>
      </Row>
    </Card>
  </div>
</template>

<script>
import ActivityAPI from "@/api/gamespace/publicActivity";
import UploadImg from "_c/shark-upload";
import AppSelect from "_c/app-select";
import Selection from "_c/Selection";
import TmpPreview from "./temp-preview";
import draggable from "vuedraggable";
import RankSelect from "_c/rank-select";
import ActivitySelect from "_c/activity-select";
import CommonSelect from "_c/common-select";
export default {
  name: "",
  components: {
    UploadImg,
    TmpPreview,
    AppSelect,
    Selection,
    draggable,
    ActivitySelect,
    CommonSelect,
    RankSelect,
  },
  data() {
    const AppIdValidate = (rule, value, callback) => {
      if (!value) {
        callback("请选择关联游戏");
      }
      callback();
    };
    return {
      pkgName: "",
      pool: {
        ID: 0,
        Title: "",
      },
      templateData: {
        HeadImage: "",
        BackgroundColor: "",
        AppIcon: "",
        AppId: "",
        AppName: "",
        Content: "",
        AppStatus: 1,
        FontColor: "",
        BottomColor: "",
        ModelType: 1,
        ConfigModel: [],
        IsShowSubscribe: true,
        number: 0,
        IsShowAppInfo: 1,
      },
      rules: {
        // AppId: [
        //   { required: true, validator: AppIdValidate, trigger: "change" },
        // ],
      },
      typeList: [
        { Id: 1, Name: "预约礼包" },
        { Id: 2, Name: "自由模块" },
        { Id: 3, Name: "游戏介绍" },
        { Id: 4, Name: "截图模块" },
        { Id: 5, Name: "视频模块" },
      ],
      JumpList: [
        { Id: 1, Name: "抽奖/宣传活动" },
        { Id: 2, Name: "论坛贴" },
        { Id: 3, Name: "文章" },
        { Id: 4, Name: "单游戏论坛主页" },
        { Id: 5, Name: "榜单" },
        { Id: 6, Name: "模块合辑" },
        { Id: 7, Name: "Deeplink" },
        { Id: 8, Name: "链接" },
      ],
      floorPageList: [
        { Id: 1, Name: "横版默认落地页" },
        { Id: 2, Name: "横版banner落地页" },
        { Id: 3, Name: "默认落地页" },
        { Id: 4, Name: "视频列表落地页" },
        { Id: 5, Name: "专题落地页" },
        { Id: 6, Name: "分类落地页" },
        { Id: 7, Name: "新游落地页" },
        { Id: 8, Name: "大图落地页" },
      ],
      // 内容类型
      rankTypeList: [
        { Id: 1, Name: "普通榜单" },
        { Id: 2, Name: "排行榜单" },
        { Id: 3, Name: "预约榜单" },
        { Id: 4, Name: "分类榜单" },
        { Id: 5, Name: "标签榜单" },
        { Id: 6, Name: "飙升榜单" },
      ],
      serverData: {
        likeUrl: "ModelLike",
        likeData: { type: 1 },
        setUrl: "ModelById",
        setData: {},
        IdKey: "ID",
        NameKey: "Name",
      },
      postServerData: {
        likeUrl: "PostLike",
        likeData: {},
        setUrl: "getPostList",
        setData: { IsTop: false, Limit: 10, Page: 1 },
        IdKey: "Id",
        NameKey: "Title",
      },
    };
  },
  computed: {
    preview() {
      return {
        Title: this.pool.Title,
        ...this.templateData,
        PoolID: this.$route.params.id,
      };
    },
  },
  mounted() {
    this.pool.ID = parseInt(this.$route.params.id);
    this.pool.Title = decodeURI(this.$route.params.title);
    this.getTemplate();
  },
  methods: {
    getTemplate() {
      ActivityAPI.KeyGameTemplate(this.pool.ID).then((res) => {
        if (res.Code == 0) {
          let templateData = res.Data || {};
          templateData.ConfigModel = templateData.ConfigModel.sort((a, b) => {
            return a.Sort - b.Sort;
          });
          templateData.ConfigModel = templateData.ConfigModel.map((v) => {
            // if (v.ModelType == 1 || v.ModelType == 3) {
            //   v.ModelType = 2;
            // }
            v.ModuleJumpType = v.ModuleJumpType ? v.ModuleJumpType : 1;
            v.IsJump = v.IsJump == 1 ? true : false;
            return v;
          });
          this.templateData = { ...JSON.parse(JSON.stringify(templateData)) };
          this.getRankNo();
        }
      });
    },
    getRankNo() {
      ActivityAPI.GetRankNo(this.templateData.AppId).then((res) => {
        this.templateData.number = res.Data;
      });
    },
    changeApp({ value, index }) {
      if (index != undefined) {
        this.templateData.AppName = value.label;
        this.pkgName = value.PkgName;
        // this.templateData.AppStatus = value.AppStatus;
        let {
          AppStatus,
          ImgSource,
          VideoBg,
          VideoURL,
          AppIcon,
          Title,
          OnlineTime,
          OnlineTimeDesc,
        } = {
          ...value,
        };
        let Tags = value.Tags.slice(0, 3);
        this.templateData = {
          ...this.templateData,
          Tags,
          AppStatus,
          ImgSource,
          VideoBg,
          VideoURL,
          AppIcon,
          GameTitle: Title,
          OnlineTime,
          OnlineTimeDesc,
        };
        this.getRankNo();
      } else {
        this.templateData.AppName = "";
        this.templateData.AppStatus = 1;
        this.pkgName = "";
      }
    },
    changeSingleApp({ value, index }, Modelindex) {
      if (index != undefined) {
        console.log(value);
        this.templateData.ConfigModel[Modelindex].PkgName = value.PkgName;
      } else {
        this.templateData.ConfigModel[Modelindex].AwardId = undefined;
        this.templateData.ConfigModel[Modelindex].PkgName = "";
      }
    },
    submitTmp() {
      this.$refs["formData"].validate((valid) => {
        if (valid) {
          if (
            (this.templateData.IsShowAppInfo == 1 ||
              this.templateData.IsShowSubscribe) &&
            !this.templateData.AppId
          ) {
            this.$Message.error({
              content:
                "未填写关联游戏时不允许打开「展示预约名次」和「展示游戏信息」开关",
              duration: 3,
            });
            return;
          }
          let tmpData = JSON.parse(JSON.stringify(this.templateData));
          tmpData.ConfigModel = tmpData.ConfigModel.map((item, index) => {
            item.Sort = index + 1;
            item.IsJump = item.IsJump ? 1 : 2;
            return item;
          });
          ActivityAPI.EditKeyGame(this.pool.ID, tmpData).then((res) => {
            if (res.Code === 0) {
              this.$Notice.success({
                title: "保存成功！",
              });
            } else {
              this.$Message.error(res.Message);
            }
          });
        }
      });
    },
    cancel() {
      this.$router.push({
        name: "gamespace_key_games",
      });
    },
    AddModel() {
      if (this.templateData.ModelType) {
        let item = {
          ModelType: this.templateData.ModelType,
          BackgroundImage: "",
          AwardButtonImage: "",
          AwardButtonUrl: "",
          AwardId: undefined,
          Direction: 1,
          ModuleJumpType: 0,
          DeepLinkPkgName: "",
          DeepLink: "",
          IsPropaganda: 2,
          FloorPageType: 0,
          RankType: 0,
          IsJump: true,
          ActivityId: 0,
        };
        this.templateData.ConfigModel.push(item);
      }
    },
    handleListChange() {},
    handleEnd() {},
    handleDelete(index) {
      this.templateData.ConfigModel.splice(index, 1);
    },
    feedChange(obj, index) {
      if (obj.index) {
        this.templateData.ConfigModel[index].AwardButtonUrl = obj.value.FeedURL;
        this.templateData.ConfigModel[index].IsPropaganda =
          obj.value.IsPropaganda;
        this.templateData.ConfigModel[index].AwardId = obj.value.FeedID;
        this.templateData = Object.assign({}, this.templateData);
      }
    },
  },
};
</script>

<style scoped lang="less">
.color-input {
  display: block;
  min-width: 100px;
  border: 1px solid #dcdee2;
  border-radius: 4px;
  background: #f5f7f9;
  padding: 0 2px;
  margin: 0;
  height: 32px;
  cursor: pointer;
  &:focus {
    outline: none;
  }
}
.model_box {
  border: 1px solid #eee;
  margin: 10px 0;
  padding: 10px;
}
.model_box_none {
  text-align: center;
}
</style>
