<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Form :inline="true">
          <FormItem span="6">
            <!-- <TitleSelect
              v-model="searchform.params.Id"
              :width="200"
              placeholder="请输入宣传活动标题"
            /> -->
            <Input
              v-model="searchform.params.Title"
              placeholder="请输入宣传活动标题"
            />
          </FormItem>
          <FormItem span="10">
            <gameNameSelect
              v-model="searchform.params.AppId"
              :width="300"
              :multiple="false"
            />
          </FormItem>
          <FormItem span="6">
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </FormItem>
        </Form>
      </div>

      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      >
        <!-- <template slot-scope="{ row }" slot="Place">
          <span v-if="row.Place == 0">发现好游戏</span>
          <span v-else-if="row.Place == 1">应用商店</span>
          <span v-else>--</span>
        </template> -->
        <template slot-scope="{ row }" slot="ExpiredEnd">{{
          timeFormat(row.ExpiredEnd)
        }}</template>
        <template slot-scope="{ row }" slot="StartTime">{{
          timeFormat(row.StartTime)
        }}</template>

        <template slot-scope="{ row, index }" slot="Status">
          <i-switch
            v-model="table.data[index].Status"
            size="large"
            :true-value="1"
            :false-value="2"
            @on-change="(value) => checkUpdate(row, value)"
          >
            <span slot="open">开</span>
            <span v-if="row.Status == 2" slot="close">关</span>
            <span v-else slot="close" class="no-wrap">未处理</span>
          </i-switch>
        </template>
        <template slot-scope="{ row }" slot="opt">
          <Button
            type="primary"
            size="small"
            :disabled="row.Status == 1"
            @click="editPool(row)"
            style="margin-right: 5px"
            >编辑</Button
          >
          <Button type="info" size="small" @click="addTemplate(row)"
            >配置模板</Button
          >
        </template>
      </Table>

      <div style="margin: 10px; overflow: hidden">
        <div style="float: left">
          <Button
            type="info"
            shape="circle"
            icon="plus-round"
            @click="addNewPool"
            >新增活动</Button
          >
        </div>
        <div style="float: right">
          <Page
            :total="searchform.total"
            :current="searchform.page"
            :page-size="searchform.limit"
            :page-size-opts="[10, 20, 40, 80, 100]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>

    <Modal v-model="poolVisible">
      <template slot="header">
        <b v-if="poolForm.Id" style="font-size: 14px">编辑宣传活动</b>
        <b v-else style="font-size: 14px">添加宣传活动</b>
      </template>
      <Row>
        <Col :span="21">
          <Form
            ref="poolForm"
            :model="poolForm"
            :rules="poolRules"
            :label-width="120"
          >
            <FormItem label="宣传活动标题：" prop="Title">
              <Input
                v-model="poolForm.Title"
                placeholder="请填写宣传活动标题"
              ></Input>
            </FormItem>
            <FormItem label="上传大图：" prop="BigBg">
              <UploadImg v-model="poolForm.BigBg" :module="'award'"></UploadImg>
            </FormItem>
            <FormItem label="上传中图：" prop="MidBg">
              <UploadImg v-model="poolForm.MidBg" :module="'award'"></UploadImg>
            </FormItem>
            <FormItem label="开始时间：" prop="StartTime">
              <DatePicker
                type="datetime"
                v-model="poolForm.StartTime"
                format="yyyy-MM-dd HH:mm"
                placeholder="请选择开始时间"
              ></DatePicker>
            </FormItem>
            <FormItem label="截止时间：" prop="ExpiredEnd">
              <DatePicker
                type="datetime"
                v-model="poolForm.ExpiredEnd"
                format="yyyy-MM-dd HH:mm"
                placeholder="请选择截止时间"
              ></DatePicker>
            </FormItem>
            <FormItem label="关联游戏：" prop="AppId">
              <!-- <AppSelect
                v-model="poolForm.AppId"
                style="width: 200px"
                placeholder="请输入游戏名称"
              /> -->
              <gameNameSelect
                v-model="poolForm.AppId"
                :width="300"
                :multiple="false"
              />
            </FormItem>
            <!-- <FormItem label="投放位置：">
              <Select v-model="poolForm.Place" placeholder="请选择投放位置">
                <Option
                  v-for="type in placementsList"
                  :value="type.ID"
                  :key="type.ID"
                  >{{ type.Name }}</Option
                >
              </Select>
            </FormItem> -->
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button size="large" type="text" @click="poolVisible = false"
          >取消</Button
        >
        <Button size="large" type="primary" @click="submitPool">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import ActivityAPI from "@/api/gamespace/publicActivity";
import { formatTime } from "@/libs/tools";
import UploadImg from "_c/shark-upload";
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect.vue";
import AppSelect from "_c/app-select";
// import TitleSelect from "./title-select";
export default {
  name: "gamespace_awardspool_list",
  components: { UploadImg, gameNameSelect, AppSelect },
  data() {
    return {
      searchform: {
        params: {
          Title: undefined,
          AppId: undefined,
        },
        total: 0,
        page: 1,
        limit: 10,
      },

      table: {
        loading: false,
        data: [],
        columns: [
          { title: "活动ID", key: "ID", minWidth: 80, align: "center" },
          { title: "活动标题", key: "Title", minWidth: 150 },
          { title: "游戏名称", key: "AppName", minWidth: 150 },
          { title: "开始时间", slot: "StartTime", minWidth: 150 },
          { title: "截止时间", slot: "ExpiredEnd", minWidth: 150 },
          // { title: "投放位置", slot: "Place", minWidth: 80 },
          { title: "活动状态", slot: "Status", minWidth: 100 },
          { title: "活动链接", key: "FeedURL", minWidth: 100 },
          {
            title: "操作",
            slot: "opt",
            width: 220,
            align: "center",
            fixed: "right",
          },
        ],
      },
      placementsList: [
        { ID: 0, Name: "发现好游戏" },
        { ID: 1, Name: "应用商店" },
      ],

      poolVisible: false,
      poolForm: {
        Title: "",
        ExpiredEnd: "",
        // Place: 0,
        BigBg: "",
        MidBg: "",
        AppId: undefined,
      },
      poolRules: {
        Title: [
          {
            required: true,
            message: "请填写重点游戏活动标题",
            trigger: "blur",
          },
        ],
        StartTime: [
          {
            required: true,
            type: "date",
            message: "请设置开始时间",
            trigger: "change",
          },
        ],
        ExpiredEnd: [
          {
            required: true,
            type: "date",
            message: "请设置截止时间",
            trigger: "change",
          },
        ],
        BigBg: [
          {
            required: true,
            message: "请上传大图",
            trigger: "change",
          },
        ],
        MidBg: [
          {
            required: true,
            message: "请上传中图",
            trigger: "change",
          },
        ],
      },
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    timeFormat(date) {
      return formatTime(date);
    },
    searchServer() {
      this.searchform.page = 1;
      this.init();
    },
    init() {
      let { page, limit, params } = { ...this.searchform };
      params.Title = params.Title || undefined;
      ActivityAPI.KeyGameList({ page, limit, params }).then((res) => {
        if (res.Code == 0) {
          if (res.Data.Data) {
            this.table.data = res.Data.Data;
          } else {
            this.table.data = [];
          }
          this.searchform.total = res.Data.Count;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    onPageChange(value) {
      this.searchform.page = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.limit = value;
      this.init();
    },

    addNewPool() {
      this.poolVisible = true;
      this.$refs["poolForm"].resetFields();
      this.poolForm = {
        Title: "",
        ExpiredEnd: "",
        // Place: 0,
        AppId: undefined,
        StartTime: "",
      };
    },
    editPool(pool) {
      let poolData = JSON.parse(JSON.stringify(pool));
      this.poolForm = poolData;
      this.poolVisible = true;
    },
    submitPool() {
      this.$refs["poolForm"].validate((valid) => {
        if (valid) {
          let start = new Date(this.poolForm.StartTime).getTime();
          let end = new Date(this.poolForm.ExpiredEnd).getTime();
          if (start >= end) {
            this.$Message.error("开始时间不得大于结束时间");
            return;
          }
          let params = JSON.parse(JSON.stringify(this.poolForm));
          if (params.ID) {
            // let { AppId, ExpiredEnd, StartTime, Title } = {
            //   ...params,
            // };
            ActivityAPI.EditKeyGame(params.ID, params).then((res) => {
              if (res.Code === 0) {
                this.poolVisible = false;
                this.init();
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            ActivityAPI.AddKeyGame(params).then((res) => {
              if (res.Code === 0) {
                this.poolVisible = false;
                this.init();
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },

    //切换状态
    checkUpdate(pool, value) {
      ActivityAPI.SetStatus(pool.ID, value).then((res) => {
        if (res.Code != 0) {
          this.$Message.error(res.Message);
          this.init();
        }
      });
    },
    addTemplate(item) {
      this.$router.push({
        name: "gamespace_keygames_list",
        params: {
          id: item.ID,
          title: encodeURI(item.Title),
        },
      });
    },
  },
};
</script>

<style scoped>
.big-bg,
.mid-bg {
  height: 40px;
}
.no-wrap {
  white-space: nowrap;
  font-size: 12px;
  display: block;
  transform: scale(0.8);
  left: -5px;
  position: relative;
}
</style>
