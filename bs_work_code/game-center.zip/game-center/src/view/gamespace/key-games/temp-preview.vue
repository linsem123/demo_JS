<template>
  <div class="pbody">
    <div class="back">
      <div class="back-inner">
        <div class="backbtn">
          <div class="arrow-btn"></div>
        </div>
        <div class="backtitle">
          <div id="marquee">{{ value.Title }}</div>
        </div>
      </div>
    </div>
    <div class="vir-dom">
      <div class="header">
        <img :src="value.HeadImage" class="header_img" v-if="value.HeadImage" />
        <div
          class="game_info"
          v-if="value.HeadImage && value.IsShowAppInfo == 1"
        >
          <Img :src="value.AppIcon" class="app_icon" />
          <div class="info_center">
            <span class="tips_1">{{ value.AppName }}</span>
            <span
              class="tips_2"
              v-if="value.AppStatus == 3 && value.OnlineTimeDesc"
              >{{ value.OnlineTimeDesc }}</span
            >
            <span class="tips_2" v-else>{{ value.Title }}</span>
            <span class="tips_3">
              <span v-for="(tag, index) of value.Tags" :key="index">{{
                tag
              }}</span>
            </span>
          </div>
          <div
            v-if="
              value.IsShowSubscribe && value.AppStatus == 3 && value.number > 0
            "
            class="rank_no"
          >
            <span>{{ value.number }}</span>
            <span>预&nbsp;约&nbsp;榜</span>
          </div>
        </div>
        <div
          class="content_box"
          :style="`background:linear-gradient(180deg, rgba(20, 24, 33, 0) 0%, ${value.BackgroundColor} 100%);`"
        ></div>
      </div>
      <div>
        <div v-for="(item, index) of value.ConfigModel" :key="index">
          <img
            v-if="item.ModelType == 1 || item.ModelType == 3"
            :src="item.BackgroundImage"
            class="model_1"
            style="position: relative"
          />
          <div v-if="item.ModelType == 2" class="model_2">
            <img :src="item.BackgroundImage" />
            <img
              v-if="item.AwardButtonImage"
              :src="item.AwardButtonImage"
              class="btn_img"
              @click="handleJumpTo(item.AwardButtonUrl)"
            />
          </div>
          <div
            v-show="item.ModelType == 4 && item.BackgroundImage"
            class="model_4"
          >
            <img :src="item.BackgroundImage" />
            <Swiper
              :options="item.Direction == 1 ? swiperVertical : swiperHorizental"
              ref="mySwiper"
            >
              <SwiperSlide
                v-for="(imgurl, index) of value.ImgSource"
                :key="index"
              >
                <div
                  :class="
                    item.Direction == 1
                      ? 'vertical_imgbox'
                      : 'horizental_imgbox'
                  "
                >
                  <img :src="imgurl" />
                </div>
              </SwiperSlide>
            </Swiper>
          </div>
          <div
            v-show="item.ModelType == 5 && item.BackgroundImage"
            class="model_5"
          >
            <img :src="item.BackgroundImage" />
            <div class="video_box">
              <video
                :poster="value.VideoBg"
                :src="value.VideoURL"
                :controls="!showDialog"
                :ref="'video' + index"
                x5-playsinline=""
                playsinline=""
                webkit-playsinline=""
              ></video>
              <div class="video_dialog" v-show="showDialog">
                <svg
                  width="37"
                  height="37"
                  viewBox="0 0 108 108"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  style="
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                  "
                  @click="handlePlay(index)"
                >
                  <circle
                    cx="54"
                    cy="54"
                    r="54"
                    fill="white"
                    fill-opacity="0.2"
                  />
                  <circle
                    cx="54"
                    cy="54"
                    r="51"
                    stroke="white"
                    stroke-opacity="0.8"
                    stroke-width="6"
                  />
                  <path
                    d="M70 52.2679C71.3333 53.0377 71.3333 54.9622 70 55.732L47.5 68.7224C46.1667 69.4922 44.5 68.53 44.5 66.9904L44.5 41.0096C44.5 39.47 46.1667 38.5078 47.5 39.2776L70 52.2679Z"
                    fill="white"
                    fill-opacity="0.8"
                  />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer">
        <span
          class="click_btn"
          :style="
            'background:' + value.BottomColor + ';color:' + value.FontColor
          "
          >{{ value.AppStatus == 3 ? "立即预约" : "立即下载" }}</span
        >
        <!-- <span class="read_comment">
          <img src="@/assets/images/pinglun.png" />
        </span> -->
      </div>
    </div>
  </div>
</template>

<script>
import { Swiper, SwiperSlide } from "vue-awesome-swiper";
import "swiper/swiper.less";
import SwiperCore, { EffectCoverflow } from "swiper";
SwiperCore.use([EffectCoverflow]);
export default {
  name: "",
  components: { Swiper, SwiperSlide },
  props: ["value"],
  data() {
    return {
      showDialog: true,
      swiperVertical: {
        loop: true, //开启循环
        loopedSlides: 5, //在loop模式下使用slidesPerview:'auto',还需使用该参数设置所要用到的loop个数。
        slidesPerView: "auto", //设置slider容器能够同时显示的slides数量(carousel模式)。另外，支持'auto'值，会根据容器container的宽度调整slides数目。
        centeredSlides: true, //设定为true时，active slide会居中，而不是默认状态下的居左。
        loopAdditionalSlides: 100,
        effect: "coverflow",
        coverflowEffect: {
          rotate: 0, //slide做3d旋转时Y轴的旋转角度。默认50。
          stretch: 110, //每个slide之间的拉伸值（距离），越大slide靠得越紧。 默认0
          depth: 170, //slide的位置深度。值越大z轴距离越远，看起来越小。 默认100。
          modifier: 2,
          slideShadows: false, //开启slide阴影。默认 true。
        },
      },
      swiperHorizental: {
        loop: true, //开启循环
        loopedSlides: 5, //在loop模式下使用slidesPerview:'auto',还需使用该参数设置所要用到的loop个数。
        slidesPerView: "auto", //设置slider容器能够同时显示的slides数量(carousel模式)。另外，支持'auto'值，会根据容器container的宽度调整slides数目。
        centeredSlides: true, //设定为true时，active slide会居中，而不是默认状态下的居左。
        loopAdditionalSlides: 100,
        effect: "coverflow",
        coverflowEffect: {
          rotate: 0, //slide做3d旋转时Y轴的旋转角度。默认50。
          stretch: 127, //每个slide之间的拉伸值（距离），越大slide靠得越紧。 默认0
          depth: 190, //slide的位置深度。值越大z轴距离越远，看起来越小。 默认100。
          modifier: 2,
          slideShadows: false, //开启slide阴影。默认 true。
        },
      },
    };
  },
  filters: {
    FilterTimer(val) {
      if (val) {
        let time = new Date(val);
        let month = time.getMonth() + 1;
        let day = time.getDate();
        return `${month}月${day}日首发`;
      }
      return "";
    },
  },
  methods: {
    handlePlay() {},
    handleJumpTo(url) {
      if (url) window.location.href = url;
      // window.bsamagent.navToCampaignList();
    },
  },
};
</script>

<style scoped lang="less">
.pbody {
  transform: scale(1);
  border: 1px solid #ccc;
  width: 375px;
  .vir-dom {
    position: relative;
    height: 700px;
    padding-top: 50px;
    overflow: auto;
    box-sizing: border-box;
    &::-webkit-scrollbar {
      /*滚动条整体样式*/
      width: 2px; /*高宽分别对应横竖滚动条的尺寸*/
      height: 1px;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 2px;
      -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      background: #999;
    }
    &::-webkit-scrollbar-track {
      /*滚动条里面轨道*/
      -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      background: #ededed;
    }
  }
}
body {
  padding: 0;
  margin: 0;
}
img {
  border: 0;
  width: 100%;
  display: block;
  font-size: 0;
}

.back {
  position: fixed;
  z-index: 120;
  background: #fff;
  left: 0;
  top: 0;
  width: 100%;
  padding-top: 8px;
  padding-bottom: 8px;
  box-sizing: border-box;
  transform: rotate(0);
  color: #000;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  .back-inner {
    width: 380px;
    margin: auto;
  }
  .backbtn {
    float: left;
    width: 34px;
    height: 34px;
    text-align: center;
    .arrow-btn {
      margin: 6px 6px 0 0;
    }
  }
  .backtitle {
    overflow: hidden;
    width: 340px;
    height: 34px;
    line-height: 34px;
    font-size: 18px;
    font-weight: 500;
  }
}

.arrow-btn {
  display: inline-block;
  vertical-align: middle;
  position: relative;
  width: 20px;
  height: 20px;
  border-color: #222;
  &::before,
  &::after {
    content: "";
    display: block;
    border-top: 2px solid;
    border-color: inherit;
    width: 12.5px;
    height: 0px;
    position: absolute;
    left: 3px;
    border-radius: 1px;
  }
  &::before {
    transform: rotateZ(-45deg);
    top: 5.4px;
  }
  &::after {
    transform: rotateZ(45deg);
    top: 13px;
  }
}

.header {
  position: relative;
  img {
    height: 406.22px;
  }
  .game_info {
    position: absolute;
    width: 100%;
    height: 74.6px;
    padding: 0 75.3px 0 20.8px;
    // background-color: red;
    bottom: 13.88px;
    // transform: translateY(50%);
    display: flex;
    align-items: center;
    z-index: 2;
    font-weight: 500;
    font-size: 17.5px;
    line-height: 20px;
    color: #fff;

    .app_icon {
      width: 74.3px;
      height: 74.3px;
    }

    .info_center {
      display: flex;
      flex-direction: column;
      margin-left: 12.5px;
      margin-top: 7.6px;
    }

    .tips_1,
    .tips_2 {
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
      max-width: 190.96px;
    }

    .tips_2 {
      font-size: 12.5px;
      line-height: 16.67px;
      opacity: 0.8;
      margin-top: 2px;
    }

    .tips_3 {
      opacity: 0.6;

      & span {
        display: inline-block;
        border: 1px solid #fff;
        border-radius: 2px;
        font-size: 9.7px;
        line-height: 14.6px;
        height: 14.6px;
        padding: 0 7px;
        margin-top: 9.7px;

        & + span {
          margin-left: 8.33px;
        }
      }
    }

    .rank_no {
      position: absolute;
      width: 54.5px;
      height: 42.36px;
      right: 20.83px;
      top: 7.64px;
      background: linear-gradient(180deg, #ff581f 0%, #ff9909 100%);
      border-radius: 4.2px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;

      & span:first-of-type {
        font-size: 16.67px;
        line-height: 22.22px;
      }

      & span:last-of-type {
        font-size: 8.68px;
        line-height: 12.85px;
        opacity: 0.8;
      }
    }
  }
}

.model_1 {
  width: 100%;
  display: block;
  font-size: 0;
}

.model_2,
.model_4,
.model_5 {
  position: relative;
}

.model_2 .btn_img {
  position: absolute;
  bottom: 69px;
  left: 50%;
  transform: translateX(-50%);
  width: 133px;
  height: 28px;
}

.model_5 {
  .video_box {
    width: 333px;
    height: 160.4px;
    position: absolute;
    bottom: 43px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2;
    border-radius: 8.33px;
    box-shadow: 0px 0px 22.22px rgba(0, 0, 0, 0.12);
    overflow: hidden;
  }

  .video_dialog {
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.4);
    position: absolute;
    top: 0;
    z-index: 3;
  }

  video {
    width: 100%;
    height: 100%;
    object-fit: fill;
  }
}

.footer {
  position: fixed;
  bottom: 20.83px;
  z-index: 100;
  display: flex;
  padding: 0 20.83px;
  width: 100%;
  justify-content: center;

  .click_btn {
    background: linear-gradient(272.13deg, #ff7100 3.52%, #ffad00 100%);
    border-radius: 24.3px;
    width: 264px;
    height: 48.6px;
    line-height: 48.6px;
    display: inline-block;
    font-size: 16px;
    text-align: center;
    color: #ffffff;
  }

  .read_comment {
    width: 48.6px;
    height: 48.6px;
    display: inline-block;
    border-radius: 24.3px;
    background: rgba(255, 255, 255, 0.2);
    display: flex;
    justify-content: center;
    align-items: center;

    img {
      width: 19.44px;
      height: 19.44px;
    }
  }
}

//轮播图
.swiper-container {
  width: 333px;
  margin: 0 auto;
  position: absolute;
  bottom: 43px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 2;
}

.vertical_height {
  height: 295px;
}

.orizental_height {
  height: 139px;
}

.swiper-container img {
  width: 100%;
  height: 100%;
}

.swiper-container .vertical_imgbox {
  border-radius: 8.33px;
  overflow: hidden;
  display: block;
  // width: 159.7px;
  // height: 277.8px;
  width: 198px;
  height: 343.7px;
  margin: 0 auto;
}

.swiper-container .horizental_imgbox {
  border-radius: 8.33px;
  overflow: hidden;
  display: block;
  // width: 231px;
  // height: 129px;
  width: 277.7px;
  height: 154.5px;
  margin: 0 auto;
}

.swiper-container-horizontal > .swiper-pagination-bullets,
.swiper-pagination-custom,
.swiper-pagination-fraction {
  bottom: 0;
  left: 0;
  width: 100%;
}

.swiper-pagination-bullet-active {
  background-color: #ffd200;
}

.swiper-slide {
  border-radius: 8.33px;
  overflow: hidden;
}
.content_box {
  position: absolute;
  // top: 259px;
  bottom: 0;
  padding-top: 91px;
  width: 100%;
}
</style>
