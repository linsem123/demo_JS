<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.appname.loading"
              clearable
              filterable
              remote
              :remote-method="handleGameSearch"
              placeholder="请输入游戏名称"
            >
              <Option
                v-for="item in searchform.appname.data"
                :value="item.ID"
                :key="item.ID"
              >{{ item.AppName }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
        </Row>
      </div>
      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      ></Table>
      <div style="margin: 10px;overflow: hidden">
         <div style="float: left">
          <Button type="info" shape="circle" icon="plus-round" @click="openAdd">新增文章</Button>
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>
    <check-status ref="checkstatus" @onClose="closeCheckStatus"/>
  </div>
</template>

<script>
import GamePaperAPI from "@/api/gamespace/gamepaper";
import GameAPI from "@/api/gamespace/game";
// import GameGiftAPI from "@/api/gamespace/gamegif";
import Tables from "_c/tables";
import CheckStatus from "_c/gamespace/gamepaper/status";
export default {
  name: "gamespace_gamepaper_list",
  components: {
    CheckStatus
  },
  data() {
    return {
      currentGame: null,
      showgifmodal: false,
      gifFile: null,
      searchform: {
        params: { id: undefined },
        page: {
          total: 100,
          current: 1,
          size: 10
        },
        appname: {
          loading: false,
          data: []
        }
      },
      table: {
        loading: false,
        data: [],
        columns: [
          {
            title: "活动ID",
            align: "center",
            width: 80,
            key: "Tags",
             fixed: "left",
            render: (h, params) => {
              return h("p", { props: {} }, params.row.ID);
            }
          },
          {
            title: "游戏名称",
            fixed: "left",
            width: 200,
            render: (h, params) => {
              if (params.row.AppID === 0) {
                return h("span","-")
              }
              const div = [];
              if (params.row.IconURL !== "") {
                let icon = h("Avatar", {
                  props: {
                    shape: "square",
                    src: params.row.AppIcon,
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  }
                });
                div.push(icon);
              }
              if (params.row.ButtonText !== "") {
                let tag = h("Tag", { props: {} }, params.row.AppName);
                div.push(tag);
              }
              return h("div", div);
            }
          },
          {
            title: "游戏包名",
            // width: 250,
            render: (h, params) => {
              if (params.row.AppID === 0) {
                return h("span","-")
              }
              return h("Tag", { props: {} }, params.row.PkgName);
            }
          },
          {
            title: "活动状态",
            align: "center",
            fixed: "left",
            width: 100,
            key: "Status",
            render: (h, params) => {
              if (params.row.Status === 0) {
                return h("Tag", { props: { color: "warning" } }, "待处理");
              }
              if (params.row.Status === 1) {
                return h("Tag", { props: { color: "success" } }, "上架");
              }
              if (params.row.Status === 2) {
                return h("Tag", { props: { color: "error" } }, "下架");
              }
              if (params.row.Status === 3) {
                return h("Tag", { props: { color: "primary" } }, "预约");
              }
            }
          },
          {
            title: "活动标题",
            // width: 300,
            key: "Tags",
            render: (h, params) => {
              return h("Tag", { props: {} }, params.row.Title);
            }
          },
          {
            title: "活动作者",
            // width: 300,
            key: "Tags",
            render: (h, params) => {
              return h("Tag", { props: {} }, params.row.Author);
            }
          },
          {
            title: "操作",
            fixed: "right",
            width: 200,
            key: "handle",
            options: ['edit'],
            button: [
              (h, params, vm) => {
                return h(
                  "Button",
                  {
                    props: {
                      type: "warning",
                      size: "small"
                    },
                    on: {
                      click: () => {
                        this.$refs.checkstatus.show(
                          params.row.ID,
                          params.row.Status,
                          params.row.Opinion
                        );
                      }
                    },
                    style: {
                      marginRight: "5px"
                    }
                  },
                  "审核发布"
                );
              }
            ]
          }
        ]
      }
    };
  },
  methods: {
    handleGameSearch(value) {
      GameAPI.LikeApp({ value }).then(res => {
        this.searchform.appname.data = res.Data;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    closeCheckStatus() {
      this.init();
    },
    init() {
      GamePaperAPI.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then(res => {
        if (res.Data.Data) {
          this.table.data = res.Data.Data;
        } else {
          this.table.data = [];
        }
        this.searchform.page.total = res.Data.Count;
      });
    },
    openAdd () {
      this.$router.push({
        name: 'gamespace_gamepaper_add'
      })
    },
    edit (params) {
      if(params.row.Status === 1){
        this.$Message.error("已上架不可编辑")
        return;
      }
      this.$router.push({
        name: 'gamespace_gamepaper_edit',
        params: { id: params.row.ID }
      })
    },
  },
  mounted() {
    this.table.columns = Tables.RenderColumns(this.table.columns, this);
    this.init();
    this.$on('on-edit', this.edit)
    // 注册监听事件
  },
  activated() {
    this.init();
  }
};
</script>
