<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>编辑文章-{{formScope.AppName}}
    </p>
    <view-form @on-form-submit="handleSubmit" :formScope="formScope"></view-form>
  </Card>
</template>
<script>
import GamePaperAPI from "@/api/gamespace/gamepaper";
import ViewForm from "_c/gamespace/gamepaper/form";
import { mapMutations} from 'vuex'
export default {
  name: "Edit",
  components: {
      ViewForm,
  },
  data() {
    return {
      formScope: {
        AppName: ""
      }
    }
  },
  methods: {
    ...mapMutations(['closeTag']),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      GamePaperAPI.Edit(formScope).then(res => {
        this.$Loading.finish();
        this.loading = false;
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "编辑成功!"
        });
        this.closeTag(this.$route);
        // this.$emit("on-close", undefined, undefined, this.$route);
        this.$router.push({
          name: "gamespace_gamepaper_list"
        });
      });
    }
  },
  mounted() {
    GamePaperAPI.Get(this.$route.params.id).then(res => {
      if (res.Code > 0) {
        this.$Message.warning(res.Message);
        return;
      }
      this.formScope = res.Data;
    });
  }
};
</script>
