<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>更新游戏-{{formScope.AppName}}
    </p>
    <view-form @on-form-submit="handleSubmit" :formScope="formScope" :edit=true></view-form>
  </Card>
</template>
<script>
import GamePaperAPI from "@/api/gamespace/gamepaper";
import ViewForm from "_c/gamespace/gamepaper/form";
import { mapMutations } from "vuex";
export default {
  name: "edit",
  components: {
    ViewForm
  },
  data() {
    return {
      formScope: {
        type: Object
      }
    };
  },
  methods: {
    ...mapMutations(["closeTag"]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      GamePaperAPI.Edit(formScope).then(res => {
        this.$Loading.finish();
        this.loading = false;
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "更新游戏成功"
        });
        this.close();
      });
    },
    close() {
      this.closeTag(this.$route);
      // this.$emit("on-close", undefined, undefined, this.$route);
      this.$router.push({
        name: "gamespace_game"
      });
    }
  },
  mounted() {
    GamePaperAPI.Get(this.$route.params.id).then(res => {
      if (res.Code > 0) {
        this.$Message.warning(res.Message);
        return;
      }
      this.formScope = res.Data;
    });
  }
};
</script>