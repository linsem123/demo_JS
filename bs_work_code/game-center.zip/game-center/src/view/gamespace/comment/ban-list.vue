<template>
    <div>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="3">
            <Select v-model="search.params.BanType" clearable placeholder="请选择禁言类型">
              <Option v-for="item in banTypeSelList" :value="item.ID" :key="item.ID">{{item.Name}}</Option>
            </Select>
          </Col>
          <Col span="3">
            <Input v-model="search.params.IMEI" clearable placeholder="请输入IMEI"/>
          </Col>
          <Col span="3">
            <Select v-model="search.params.UserID" clearable filterable remote :remote-method="handleUserSearch" placeholder="请输入用户名称">
              <Option v-for="item in userList" :value="item.ID" :key="item.ID">{{item.NickName}}</Option>
            </Select>
          </Col>
          <Col span="3">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
        </Row>
      </div>
      <Table :loading="table.loading" border :columns="table.columns" :data="table.data">
        <template slot-scope="{row, index}" slot="BanType">
          <span v-if="row.BanType == 1">设备ID + 账号</span>
          <span v-if="row.BanType == 2">账号</span>
          <span v-if="row.BanType == 3">设备ID</span>
        </template>
        <template slot-scope="{row, index}" slot="CreatedAt">
          {{timeFormat(row.CreatedAt)}}
        </template>
        <template slot-scope="{row, index}" slot="Cycle">
          <span v-if="row.Cycle == 1">3天</span>
          <span v-if="row.Cycle == 2">1个月</span>
          <span v-if="row.Cycle == 3">永久</span>
          <span v-if="row.Cycle == 4">其他</span>
        </template>
        <template slot-scope="{row, index}" slot="opt">
          <Button @click="liftBan(row.ID)" type="info" size="small" style="marginRight: 5px">解禁</Button>
        </template>
      </Table>
      <div style="float: right">
        <Page :total="search.page.total" :current="search.page.current" :page-size="search.page.size"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>

      <!--禁言选项弹窗-->
      <Modal v-model="banVisible" title="禁言选项">
        <Form :label-width="150" class="detail-form">
          <FormItem label="禁言类型：">
            <RadioGroup v-model="banFormData.BanType">
              <Radio v-for="t in banTypeList" :label="t.value">{{t.label}}</Radio>
            </RadioGroup>
          </FormItem>
          <FormItem label="禁言开始时间：">
            <DatePicker :value="banFormData.StartDate" type="date"  placement="bottom-start" placeholder="请选择日期" style="width: 200px"></DatePicker>
          </FormItem>
          <FormItem label="禁言周期：">
            <RadioGroup v-model="banFormData.Cycle">
              <Radio v-for="t in cycleList" :label="t.value">{{t.label}}</Radio>
            </RadioGroup>
          </FormItem>
          <FormItem v-if="banFormData.Cycle ==4"label="禁言时间：">
            <DatePicker :value="banFormData.EndDate" type="date"  placement="bottom-start" placeholder="请选择日期" style="width: 200px"></DatePicker>
          </FormItem>
          <FormItem label="禁言原因：">
            <Input v-model="banFormData.Reason" type="textarea" :rows="4" placeholder="请输入禁言原因"></Input>
          </FormItem>
        </Form>
        <div slot="footer">
          <Row>
            <Col span="6" offset="18">
              <Button type="success" :loading="banLoading" @click="handleEditBanSubmit">确认</Button>
            </Col>
          </Row>
        </div>
      </Modal>

    </div>
</template>

<script>
  import UserAPI from "@/api/gamespace/user";
  import Tables from "_c/tables";
  import { formatTime } from "@/libs/tools"
  import CommentAPI from "@/api/gamespace/comment";
    export default {
      name: "gamespace_comment_ban",
      data() {
        return {
          search: {
            params: {
              BanType: undefined,
              IMEI: undefined,
              UserID: undefined,
            },
            page : {
              total: 100,
              current: 1,
              size: 10
            }
          },
          banTypeSelList: [
            {
              ID: 1,
              Name: '设备ID + 账号'
            }, {
              ID: 2,
              Name: '账号'
            }, {
              ID: 3,
              Name: '设备ID'
            }
          ],
          userList: [],
          table: {
            loading: false,
            data: [],
            columns: [
              {title: '禁言类型', slot: 'BanType', minWidth: 150},
              {title: '用户昵称', key: 'NickName', minWidth: 100},
              {title: '设备ID', key: 'DeviceID', minWidth: 200}, // 4.11
              {title: 'IMEI', key: 'IMEI', minWidth: 200},
              {title: '禁言时间', slot: 'CreatedAt', minWidth: 150},
              {title: '禁言周期', slot: 'Cycle', minWidth: 100},
              {title: '禁言原因', key: 'Reason', minWidth: 300},
              {title: '操作', slot: 'opt', width: 400, align: 'center', fixed: 'right'}
            ]
          },
          banLoading : false,
          banFormData : {
            ID : undefined,
            UserID : undefined,
            IMEI : undefined,
            BanType : undefined,
            Cycle : undefined,
            Reason : undefined,
            StartDate : undefined,
            EndDate : undefined,
          },
          banVisible : false,
          banTypeList : [
            {value: 1, label: 'IMEI + 账号'},
            {value: 2, label: '仅账号'},
            {value: 3, label: 'IMEI'},
          ],
          cycleList : [
            {value: 1, label: '3天'},
            {value: 2, label: '1个月'},
            {value: 3, label: '永久'},
            {value: 4, label: '其他'},
          ],
        }
      },
      methods: {
        timeFormat (date) {
          return formatTime(date)
        },
        init(){
          CommentAPI.BanList(
            this.search.page.size,
            this.search.page.current,
            this.search.params
          ).then(res => {
            if (res.Data.Data) {
              this.table.data = res.Data.Data;
            }
            this.search.page.total = res.Data.Count;
          });
        },
        onPageChange(value) {
          this.search.page.current = value;
          this.init();
        },
        onPageSizechange(value) {
          this.search.page.size = value;
          this.init();
        },
        liftBan(id){
          CommentAPI.LiftBan(
            id
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("解禁成功")
            this.init();
          });
        },
        handleUserSearch(value) {
          UserAPI.LikeUser({ value }).then(res => {
            this.userList = res.Data;
          });
        },
        handleEditBanSubmit(){
          CommentAPI.EditBan(
            this.banFormData
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("修改成功")
            this.init();
            this.banVisible = false
          });
        }

      },
      created (){
        this.table.columns = Tables.RenderColumns(this.table.columns, this);
      },
      mounted() {
        this.init();
      }
    }
</script>

<style scoped>

</style>
