<template>
  <div>
    <Card :bordered="false">
      <p slot="title">管理员信息配置</p>
      <Form :model="adminForm" :rules="rules" :label-width="80">
        <FormItem label="昵称:" prop="NickName">
          <Input v-model="adminForm.NickName" placeholder="昵称" style="width:200px"></Input>
        </FormItem>
        <FormItem label="头像:" prop="Url">
          <UploadImg v-model="adminForm.Url" module="admin"></UploadImg>
        </FormItem>
        <FormItem>
          <Button type="primary" @click="handleAdminSubmit">提交</Button>
        </FormItem>
      </Form>
    </Card>
  </div>
</template>

<script>
  import UploadImg from '_c/gamespace/upload-img.vue'
  import CommentAPI from "@/api/gamespace/comment";
    export default {
      name: "admin-info",
      components: { UploadImg},
      data(){
        return{
          adminForm: {
            NickName : '',
            HeaderImg : '',
            Url : []
          },
          rules: {
            NickName: [{required: true, message: '请填写名称', trigger: 'blur'}],
            Url: [{required: true, type: 'array', message: '请上传图片', trigger: 'blur'}],
          },
        }
      },
      methods: {
        init() {
          this.getAdminInfo()
        },
        getAdminInfo(){
          CommentAPI.GetAdminInfo().then(res =>{
            this.adminForm.HeaderImg = res.Data.HeaderImg
            this.adminForm.Url= []
            this.adminForm.Url.push(
              {
                url : res.Data.HeaderImg
              }
            )
            this.adminForm.NickName = res.Data.NickName
          })
        },
        handleAdminSubmit(){
          if (this.adminForm.Url.length >0) {
            this.adminForm.HeaderImg = this.adminForm.Url[0].url
          }
          console.log(this.adminForm)
          CommentAPI.SetAdminInfo(this.adminForm).then(res => {
            if(res.Code!=0){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("修改成功")
            this.init();
          })
        }
      },
      mounted() {
        this.init()
      }
    }
</script>

<style scoped>

</style>
