<template>
  <div>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="3">
            <Select v-model="search.params.CommentType" @on-change="typeChange" clearable filterable  placeholder="请选择评论类型">
              <Option v-for="item in commentTypeList" :value="item.ID" :key="item.ID">{{item.Title}}</Option>
            </Select>
          </Col>
          <Col span="3">
            <Input v-model="search.params.Content" clearable placeholder="请输入评论内容"/>
          </Col>
          <Col span="3" v-if="search.params.CommentType == 1">
            <Select v-model="search.params.TypeID" clearable filterable remote :remote-method="handleGameSearch" placeholder="请输入App名称">
              <Option v-for="item in typeList" :value="item.ID" :key="item.ID">{{item.AppName}}</Option>
            </Select>
          </Col>
          <Col span="3" v-if="search.params.CommentType == 2">
            <Select v-model="search.params.TypeID" clearable filterable remote :remote-method="handlePaperSearch" placeholder="请输入文章标题">
              <Option v-for="item in typeList" :value="item.FeedID" :key="item.FeedID">{{item.Title}}</Option>
            </Select>
          </Col>
          <Col span="3">
            <Select v-model="search.params.UserID" clearable filterable remote :remote-method="handleUserSearch" placeholder="请输入用户名称">
              <Option v-for="item in userList" :value="item.ID" :key="item.ID">{{item.NickName}}</Option>
            </Select>
          </Col>
          <Col span="3">
            <Select v-model="search.params.Score" clearable filterable  placeholder="请选择评论分数">
              <Option v-for="item in scoreList" :value="item.ID" :key="item.ID">{{item.Score}}</Option>
            </Select>
          </Col>
          <Col span="4">
            <DatePicker :value="initRange" @on-change="dateChange" type="daterange" :options="options" placement="bottom-start" placeholder="请选择日期" style="width: 100%"></DatePicker>
          </Col>
          <Col span="3">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
        </Row>
      </div>
      <Table :loading="table.loading" border :columns="table.columns" :data="table.data">
        <template slot-scope="{row, index}" slot="Score">
          <span v-if="row.Score == 0">-</span>
          <span v-else>{{row.Score}}</span>
        </template>
        <template slot-scope="{row, index}" slot="Like">
          <span v-if="row.CommentType == 2">-</span>
          <span v-else>{{row.Like}}</span>
        </template>
        <template slot-scope="{row, index}" slot="imgs">

          <img v-for="(img, i) in row.Imgs" :src="img" @click="imgClick(i, row.Imgs)"
               style="display:inline-block;width:40px;height:40px;cursor:pointer;vertical-align:middle;margin-right: 4px;">

        </template>
        <template slot-scope="{row, index}" slot="CommentType">
          <span v-if="row.CommentType == 1">App评论</span>
          <span v-else>文章评论</span>
        </template>
        <template slot-scope="{row, index}" slot="CommentName">
          <span v-if="row.CommentType == 1">{{row.AppName}}</span>
          <span v-else>{{row.PaperTitle}}</span>
        </template>
        <template slot-scope="{row, index}" slot="Status">
          <span v-if="row.Status == 0">未处理</span>
          <span v-if="row.Status == 1">审核通过</span>
          <span v-if="row.Status == 2">审核失败</span>
          <span v-if="row.Status == 3">已删除</span>
        </template>
        <template slot-scope="{row, index}" slot="CreatedAt">
          {{timeFormat(row.CreatedAt)}}
        </template>
        <template slot-scope="{row, index}" slot="opt">
          <Button @click="one(row)" type="warning" size="small" style="margin-right: 5px">详细信息</Button>
          <Button @click="showReply(row)" type="primary" size="small" style="marginRight: 5px">回复</Button>
          <Button @click="upItem(row.ID)" type="success" size="small" style="marginRight: 5px">置顶</Button>
          <Button @click="liftItem(row.ID)" type="success" size="small" style="marginRight: 5px">取消置顶</Button>
          <Button @click="deleteItem(row.ID)" type="error" size="small" style="marginRight: 5px">删除</Button>
          <Button @click="showBan(row)" type="info" size="small" style="marginRight: 5px">禁言</Button>
          <Button @click="showReplyList(row)" type="error" size="small" style="margin-right: 5px">删除回复</Button>
        </template>
      </Table>
    <div style="float: right">
      <Page
        :total="search.page.total"
        :current="search.page.current"
        :page-size="search.page.size"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizechange"
        show-sizer
        show-total
      ></Page>
    </div>

    <!--审核弹窗-->
    <Modal v-model="checkVisible" width="600">
      <p slot="header">
        <Icon type="information-circled"></Icon>
        <span>发布审核</span>
      </p>
      <Form ref="checkFormData" :model="checkFormData" label-position="right" :rules="checkRules" :label-width="100" style="margin-right:100px;">
        <FormItem label="审核结果" prop="Status">
          <Select v-model="checkFormData.Status">
            <Option v-for="item in statusList" :value="item.value" :key="item.value">{{ item.label }}</Option>
          </Select>
        </FormItem>
        <FormItem label="审核意见" prop="Opinion">
          <Input v-model="checkFormData.Option" type="textarea" :rows="4" placeholder="请输入审核意见"></Input>
        </FormItem>
      </Form>
      <div slot="footer">
        <Row>
          <Col span="6" offset="18">
            <Button type="success" :loading="checkLoading" @click="handleCheckSubmit">审核</Button>
          </Col>
        </Row>
      </div>
    </Modal>

    <!--回复弹窗-->
    <Modal v-model="replyVisible" width="600">
      <p slot="header">
        <Icon type="information-circled"></Icon>
        <span>发布回复</span>
      </p>
      <Form ref="replyFormData" :model="replyFormData" label-position="right" :rules="replyRules" :label-width="100" style="margin-right:100px;">
        <FormItem label="回复内容" prop="Content">
          <Input v-model="replyFormData.Content" type="textarea" :rows="4" placeholder="请输入回复内容"></Input>
        </FormItem>
      </Form>
      <div slot="footer">
        <Row>
          <Col span="6" offset="18">
            <Button type="success" :loading="replyLoading" @click="handleReplySubmit">回复</Button>
          </Col>
        </Row>
      </div>
    </Modal>

    <!--详情弹窗-->
    <Modal v-model="oneVisible" title="模块详情">
      <Form :label-width="150" class="detail-form">
        <FormItem label="手机型号：">{{oneFormData.Model}}</FormItem>
        <FormItem label="rom版本：">{{oneFormData.Rom}}</FormItem>
        <FormItem v-if="oneFormData.CommentType == 1 "label="游戏版本：">{{oneFormData.GameVersion}}</FormItem>
        <FormItem v-if="oneFormData.CommentType == 2 "label="文章标题：">{{oneFormData.PaperName}}</FormItem>
        <FormItem label="IMEI：">{{oneFormData.IMEI}}</FormItem>
        <FormItem label="发现好游戏版本：">{{oneFormData.FindGameVersion}}</FormItem>
      </Form>
    </Modal>

    <!--禁言选项弹窗-->
    <Modal v-model="banVisible" title="禁言选项">
      <Form :label-width="150" class="detail-form">
        <FormItem label="禁言类型：">
          <RadioGroup v-model="banFormData.BanType">
            <Radio v-for="t in banTypeList" :label="t.value">{{t.label}}</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem label="禁言周期：">
          <RadioGroup v-model="banFormData.Cycle">
            <Radio v-for="t in cycleList" :label="t.value">{{t.label}}</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem v-if="banFormData.Cycle ==4"label="禁言时间：">
          <DatePicker :value="banFormData.EndDate" type="date"  placement="bottom-start" placeholder="请选择日期" style="width: 200px"></DatePicker>
        </FormItem>
        <FormItem label="禁言原因：">
          <Input v-model="banFormData.Reason" type="textarea" :rows="4" placeholder="请输入禁言原因"></Input>
        </FormItem>
      </Form>
      <div slot="footer">
        <Row>
          <Col span="6" offset="18">
            <Button type="success" :loading="banLoading" @click="handleBanSubmit">确认</Button>
          </Col>
        </Row>
      </div>
    </Modal>

    <!--回复列表-->
    <Modal v-model="replyListVisible" title="回复列表" width="1000px">
      <Table :loading="replyList.table.loading" border :columns="replyList.table.columns" :data="replyList.table.data">
        <template slot-scope="{row, index}" slot="CommentType">
          <span v-if="row.UserID == 0">管理员评论</span>
        </template>
        <template slot-scope="{row, index}" slot="Status">
          <span v-if="row.Status == 0">未处理</span>
          <span v-if="row.Status == 1">上线</span>
          <span v-if="row.Status == 3">已删除</span>
        </template>
        <template slot-scope="{row, index}" slot="CreatedAt">
          {{timeFormat(row.CreatedAt)}}
        </template>
      </Table>
    </Modal>


<!--    查看图片-->
    <Modal v-model="viewImgsVisible" title="查看图片" :width="800" @on-visible-change="closeViewImg">
      <Carousel :value="startIndex" v-if="previewImgs.length > 0">
        <CarouselItem v-for="img in previewImgs">
          <div class="img-carousel">
            <img :src="img" alt="">
          </div>
        </CarouselItem>
      </Carousel>
    </Modal>

  </div>
</template>

<script>
  import ActivityApi from '@/api/gamespace/activitylist'
  import Tables from "_c/tables";
  import { formatTime } from "@/libs/tools"
  import GameAPI from "@/api/gamespace/game";
  import UserAPI from "@/api/gamespace/user";
  import CommentAPI from "@/api/gamespace/comment";
  import CollapsedMenu from "../../../components/main/components/side-menu/collapsed-menu";
    export default {
        name: "gamespace_comment_list",
      components: {CollapsedMenu},
      data() {
          return {
            Version :{
              Date : null,
              Radio : true,
            },
            //审核相关
            checkLoading : false,
            checkVisible : false,
            banLoading : false,
            banVisible : false,
            checkRules: {
              Status: {
                required: true,
                type: "number",
                message: "请选择审核结果",
                trigger: "blur"
              },
              Opinion: {
                required: true,
                message: "请输入审核意见",
                trigger: "blur"
              }
            },
            checkFormData: {
              ID : undefined,
              Status : 1,
              Option : ""
            },
            //回复相关
            replyLoading : false,
            replyVisible : false,
            replyListVisible : false,
            oneVisible : false,
            replyRules: {
              Content: {
                required: true,
                message: "请输入回复内容",
                trigger: "blur"
              }
            },
            oneFormData: {
              CommentType : undefined,
              ID : undefined,
              Model: undefined,
              Rom : undefined,
              GameVersion: undefined,
              IMEI: undefined,
              FindGameVersion : undefined,
              PaperName : undefined
            },
            replyFormData: {
              ID : undefined,
              Content : ""
            },
            banFormData : {
              UserID : undefined,
              IMEI : undefined,
              DeviceID: undefined, // 4.11
              BanType : undefined,
              Cycle : undefined,
              Reason : undefined,
              StartDate : undefined,
              EndDate : undefined,
            },
            replyListFormData : {
              CommentID : undefined,
              Content : undefined,
              Status : undefined,
              CreatedAt: undefined,
            },

            initRange: [],
            cycleInitRange: [],
            search :{
              params:{
                CommentType : undefined,
                Content : undefined,
                TypeID : undefined,
                UserID : undefined,
                Score : undefined,
                StartDate : undefined,
                EndDate: undefined,
              },
              page : {
                total: 100,
                current: 1,
                size: 10
              }

            },
            scoreList : [
              {
                ID : 1,
                Score : 1
              },
              {
                ID : 2,
                Score : 2
              },
              {
                ID : 3,
                Score : 3
              },
              {
                ID : 4,
                Score : 4
              },
              {
                ID : 5,
                Score : 5
              },
              {
                ID : 6,
                Score : 6
              },
              {
                ID : 7,
                Score : 7
              },
              {
                ID : 8,
                Score : 8
              },
              {
                ID : 9,
                Score : 9
              },
              {
                ID : 10,
                Score : 10
              },
            ],
            commentTypeList : [
              {
                ID : 1,
                Title: "App"

              },
              {
                ID : 2,
                Title: "文章"

              }
            ],
            statusList: [
              { value: 1, label: "上线" },
              { value: 2, label: "撤销" },
            ],
            typeList : [],
            userList : [],
            banTypeList : [
              {value: 1, label: '设备ID + 账号'},
              {value: 2, label: '仅账号'},
              {value: 3, label: '设备ID'},
            ],
            cycleList : [
              {value: 1, label: '3天'},
              {value: 2, label: '1个月'},
              {value: 3, label: '永久'},
              {value: 4, label: '其他'},
            ],
            replyList : {
              table: {
                loading: false,
                data: [],
                columns: [
                  {title: '评论类型', slot: 'CommentType', minWidth: 100},
                  {title: '评论内容', key: 'Content', minWidth: 300},
                  {title: '状态', slot: 'Status', minWidth: 100},
                  {title: '时间', slot: 'CreatedAt', minWidth: 150},
                  {title: '操作', width: 100, align: 'center', fixed: 'right',
                    render: (h, params) => {
                      if (params.row.Status == 1) {
                        return h(
                          'Button',
                          {
                            props: {
                              type: 'error',
                              size: 'small'
                            },
                            on: {
                              click: () => {
                                this.delReply(params.row);
                              }
                            },
                            style: {
                              marginRight: '5px'
                            }
                          },
                          '删除'
                        )
                      }else {
                        return h(
                          'Button',
                          {
                            props: {
                              type: 'error',
                              size: 'small',
                              disabled: true,
                            },
                            on: {
                              click: () => {
                                this.delReply(params.row);
                              }
                            },
                            style: {
                              marginRight: '5px'
                            }
                          },
                          '删除'
                        )
                      }
                    }
                  }
                ]
              }
            },
            table: {
              loading: false,
              data: [],
              columns: [
                {title: '用户昵称', key: 'NickName', minWidth: 100},
                {title: '设备ID', key: 'DeviceID', minWidth: 150}, // 4.11
                {title: 'IMEI', key: 'IMEI', minWidth: 150},
                {title: '评论类型', slot: 'CommentType', minWidth: 100},
                {title: '名称', slot: 'CommentName', minWidth: 200},
                {title: '评论内容', key: 'Content', minWidth: 300},
                {title: '评分', slot: 'Score', minWidth: 100},
                {title: '点赞', slot: 'Like', minWidth: 100},
                {title: '图片', minWidth: 200, slot: 'imgs'},
                {title: '状态', slot: 'Status', minWidth: 100},
                {title: '时间', slot: 'CreatedAt', minWidth: 150},
                {title: '操作', slot: 'opt', width: 500, align: 'center', fixed: 'right'}
              ]
            },


            options: {
              shortcuts: [
                {
                  text: '近一周',
                  value () {
                    const end = new Date()
                    const start = new Date()
                    start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
                    return [start, end]
                  }
                },
                {
                  text: '近两周',
                  value () {
                    const end = new Date()
                    const start = new Date()
                    start.setTime(start.getTime() - 3600 * 1000 * 24 * 14)
                    return [start, end]
                  }
                },
                {
                  text: '一个月',
                  value () {
                    const end = new Date()
                    const start = new Date()
                    start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
                    return [start, end]
                  }
                },
                {
                  text: '三个月',
                  value () {
                    const end = new Date()
                    const start = new Date()
                    start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
                    return [start, end]
                  }
                }
              ]
            },

            viewImgsVisible: false,
            startIndex: 0,
            previewImgs: []
          }
        },
      methods: {
        imgClick (i, imgs) {
          this.viewImgsVisible = true
          this.$nextTick(() => {
            this.previewImgs = imgs
            this.startIndex = i
          })
        },
        closeViewImg (bl) {
          if (!bl) {
            this.previewImgs = []
            this.startIndex = 0
          }
        },
        timeFormat (date) {
          return formatTime(date)
        },
        onPageChange(value) {
          this.search.page.current = value;
          this.init();
        },
        onPageSizechange(value) {
          this.search.page.size = value;
          this.init();
        },

        typeChange(){
          this.typeList = []
          this.search.params.TypeID = undefined
        },
        handleGameSearch(value) {
          // this.typeList= []
          GameAPI.LikeApp({ value }).then(res => {
            this.typeList = res.Data;
          });
          console.log(this.typeList)
        },
        handlePaperSearch(value) {
          // this.typeList= []
          ActivityApi.LikeActivity(value , 1).then(res => {
            this.typeList = res.Data;
          });
          console.log(this.typeList)
        },
        handleUserSearch(value) {
          UserAPI.LikeUser({ value }).then(res => {
            this.userList = res.Data;
          });
        },


        dateChange (date) {
          this.search.params.StartDate = date[0]
          this.search.params.EndDate = date[1]
        },

        cycleDateChange (date) {
          this.Version.Radio = false
          this.banFormData.EndDate = date[1]
        },


        setInitRange () {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
          this.initRange = [start, end]
          this.search.params.StartDate = this.addZero(start.getFullYear()) + '-' + this.addZero(start.getMonth() + 1) + '-' + this.addZero(start.getDate())
          this.search.params.EndDate = this.addZero(end.getFullYear()) + '-' + this.addZero(end.getMonth() + 1) + '-' + this.addZero(end.getDate())
        },
        addZero (num) {
          if (num < 10) {
            return '0' + num
          }
          return num + ''
        },

        deleteItem(ID){
          CommentAPI.UpdateStatus(
            ID,3
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("评论删除成功")
            this.init();
          });
        },

        upItem(ID){
          CommentAPI.Up(
            ID
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("置顶成功")
            this.init();
          });
        },

        liftItem(ID){
          CommentAPI.Lift(
            ID
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("取消置顶成功")
            this.init();
          });
        },

        handleCheckSubmit(){
          CommentAPI.UpdateStatus(
            this.checkFormData.ID,
            this.checkFormData.Status
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("审核成功")
            this.init();
            this.checkVisible = false
          });
        },

        one(params){
          this.oneFormData.CommentType = params.CommentType
          CommentAPI.One(
            params.CommentType,
            params.ID
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.oneFormData.PaperName = res.Data.PaperName
            this.oneFormData.IMEI = res.Data.Imei
            this.oneFormData.FindGameVersion = res.Data.FindGameVersionName
            this.oneFormData.GameVersion = res.Data.AppVersionName
            this.oneFormData.Model = res.Data.Model
            this.oneFormData.Rom = res.Data.Rom
          });
          this.oneVisible = true
        },
        showBan(params){
          this.banFormData.UserID = parseInt(params.UserID)
          this.banFormData.IMEI = params.IMEI
          this.banFormData.DeviceID = params.DeviceID; // 4.11
          this.banVisible = true
        },

        showReplyList(params){
          this.replies(params.ID)
          this.replyListVisible = true
        },

        showReply(params){
          this.replyFormData.ID = params.ID
          this.replyFormData.Content = undefined
          this.replyVisible = true
        },

        replies(id){
          CommentAPI.ReplyList(
            id
          ).then(res =>{
            if (res.Data) {
              this.replyList.table.data = res.Data;
            }
          })
        },

        handleReplySubmit(){
          CommentAPI.Reply(
            this.replyFormData.ID,
            this.replyFormData
          ).then(res => {
            if(res.Code!=0){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("回复成功")
            this.init();
            this.replyVisible = false
          });
        },

        handleBanSubmit(){
          CommentAPI.Ban(
            this.banFormData
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            if(res.Code == 402 || res.Code == 403){
              this.$Message.warning("该用户已被禁言")
              return
            }
            this.$Message.success("禁言成功")
            this.init();
            this.banVisible = false
          });
        },
        delReply(params){
          CommentAPI.UpdateStatus(
            params.ID,
            3
          ).then(res => {
            if(res.Code==103){
              this.$Message.error(res.Message)
              return
            }
            this.$Message.success("删除成功")
            this.replies(params.PID)
          });
        },

        init() {
          CommentAPI.FindByPage(
            this.search.page.size,
            this.search.page.current,
            this.search.params
          ).then(res => {
            if (res.Data.Data) {
              this.table.data = res.Data.Data;
            }
            this.search.page.total = res.Data.Count;
          });
        }

      },
      created () {
        this.table.columns = Tables.RenderColumns(this.table.columns, this);
        // this.replyList.table.columns = Tables.RenderColumns(this.replyList.table.columns, this);
        this.setInitRange()
      },
      mounted() {
        this.init();
      }
    }
</script>

<style scoped lang="less">
  .ivu-carousel-item{
    width: 768px;
    height: 500px;
  }
.img-carousel{
  width: 100%;
  height: 500px;
  display: block;
  img{
    display: block;
    max-width: 100%;
    max-height: 100%;
    margin: auto;
  }
}
</style>
