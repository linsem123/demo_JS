<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.thematic.loading"
              clearable
              filterable
              remote
              :remote-method="handleThematicSearch"
              placeholder="请输入集合名称"
            >
              <Option
                v-for="item in searchform.thematic.list"
                :value="item.ID"
                :key="item.ID"
                >{{ item.Title }}</Option
              >
            </Select>
          </Col>
          <Col span="6">
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </Col>
        </Row>
      </div>
      <Table :data="tableData" :columns="columns">
        <template slot-scope="{ row }" slot="CreatedAt">
          {{ timeFormat(row.CreatedAt) }}
        </template>
        <template slot-scope="{ row }" slot="Status">
          <Tag color="success" v-if="row.Status == 1">上架</Tag>
          <Tag color="error" v-else-if="row.Status == 2">下架</Tag>
          <Tag color="warning" v-else>未处理</Tag>
        </template>
        <template slot-scope="{ row }" slot="Opt">
          <Button
            @click="addThematic(row)"
            type="primary"
            size="small"
            style="margin-right: 10px"
            >编辑</Button
          >
          <Button
            @click="thematicManage(row.ID)"
            type="info"
            size="small"
            style="margin-right: 10px"
            >内容管理</Button
          >
          <Button
            v-if="row.Status !== 1"
            @click="updateStatus(row.ID, 1)"
            type="success"
            size="small"
            style="margin-right: 10px"
            >上架</Button
          >
          <Button
            v-else
            @click="updateStatus(row.ID, 2)"
            type="error"
            size="small"
            style="margin-right: 10px"
            >下架</Button
          >
        </template>
      </Table>
      <div style="margin: 10px; overflow: hidden">
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>

      <Row style="margin-top: 10px">
        <Col :span="6">
          <Button
            @click="addThematic()"
            type="info"
            shape="circle"
            icon="md-add"
            >新增榜单专题</Button
          >
        </Col>
      </Row>
    </Card>

    <!--新增 编辑 专题 model-->
    <Modal v-model="visible" :title="formData.ID ? '编辑' : '新增'">
      <Row>
        <Col :span="21">
          <Form :model="formData" :label-width="120" ref="formData">
            <FormItem label="名称：" prop="Title">
              <Input
                v-model="formData.Title"
                placeholder="请输入专题名称 "
              ></Input>
            </FormItem>
            <FormItem label="描述：" prop="Desc">
              <Input
                type="textarea"
                :rows="2"
                v-model="formData.Desc"
                placeholder="请输入描述信息"
              ></Input>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button @click="visible = false" type="text" size="large">取消</Button>
        <Button @click="submitForm" type="primary" size="large">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import Tables from "_c/tables";
import ThematicApi from "@/api/gamespace/thematic";
import { formatTime } from "@/libs/tools";
export default {
  name: "thematic",
  data() {
    return {
      searchform: {
        params: { id: undefined },
        page: {
          total: 100,
          current: 1,
          size: 10,
        },
        thematic: {
          loading: false,
          list: [],
        },
      },
      tableData: [],
      columns: [
        { title: "合集名称", key: "Title", minWidth: 150 },
        { title: "合集描述", key: "Desc", minWidth: 150 },
        { title: "创建时间", slot: "CreatedAt", minWidth: 120 },
        { title: "状态", slot: "Status", minWidth: 80 },
        {
          title: "操作",
          slot: "Opt",
          minWidth: 130,
          align: "center",
          fixed: "right",
        },
      ],
      visible: false,
      formData: {
        ID: undefined,
        Title: "",
        Desc: "",
      },
    };
  },
  methods: {
    timeFormat(date) {
      return formatTime(date);
    },
    init() {
      ThematicApi.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then((res) => {
        if (res.Data.Data) {
          this.tableData = res.Data.Data;
        }
        this.searchform.page.total = res.Data.Count;
      });
    },
    handleThematicSearch(value) {
      ThematicApi.Like(value).then((res) => {
        this.searchform.thematic.list = res.Data;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    addThematic(item) {
      if (!item) {
        this.formData = {};
      } else {
        this.formData = JSON.parse(JSON.stringify(item));
      }
      this.visible = true;
    },
    submitForm() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          let params = JSON.parse(JSON.stringify(this.formData));
          this.thematicApi(params).then((res) => {
            if (res.Code === 0) {
              this.$Message.success("操作成功");
              this.visible = false;
              this.init();
            } else {
              this.$Message.error(res.Message);
            }
          });
        }
      });
    },
    // 编辑、新增
    thematicApi(params) {
      if (this.formData.ID) {
        return ThematicApi.EditThematic(params, params.ID);
      } else {
        return ThematicApi.AddThematic(params);
      }
    },
    updateStatus(id, status) {
      ThematicApi.UpdateStatus(id, status).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("操作成功");
          this.init();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    thematicManage(id) {
      this.$router.push({
        name: "gamespace_thematic_rank_manage",
        query: {
          ID: id,
        },
      });
    },
  },
  mounted() {
    this.columns = Tables.RenderColumns(this.columns, this);
    this.init();
    this.$on("on-edit", this.edit);
    // 注册监听事件
  },
  activated() {
    this.init();
  },
};
</script>

<style scoped>
</style>
