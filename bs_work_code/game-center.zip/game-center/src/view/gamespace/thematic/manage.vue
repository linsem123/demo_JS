<template>
  <div>
    <Card>
      <!--<div style="margin: 10px">-->
        <!--<Row :gutter="10">-->
          <!--<Col span="6">-->
            <!--<Select v-model="formData.RankID" clearable filterable remote :remote-method="handleRankSearch" placeholder="请输入榜单名称">-->
              <!--<Option v-for="item in rankList" :value="item.ID" :key="item.ID">{{item.Title}}</Option>-->
            <!--</Select>-->
          <!--</Col>-->
          <!--<Col span="6">-->
            <!--<Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>-->
          <!--</Col>-->
        <!--</Row>-->
      <!--</div>-->
      <Table :data="tableData" :columns="columns">
        <template slot-scope="{row, index}" slot="Opt">
          <Button @click="unBind(row.ID)" type="error" size="small" style="margin-right: 10px;">解绑</Button>
          <Button @click="sort(row.ID)" type="info" size="small" style="margin-right: 10px;">置顶</Button>
        </template>
      </Table>
      <Row style="margin-top: 10px;">
        <Col :span="6">
          <Button @click="addRank()" type="info" shape="circle" icon="md-add">绑定榜单</Button>
        </Col>
      </Row>
    </Card>

    <!--新增 编辑 专题 model-->
    <Modal v-model="visible" title="专题绑定榜单" >
      <Row>
        <Col :span="21">
          <Form :model="formData" :label-width="120" ref="formData">
            <FormItem label="名称：" prop="Title">
              <Select v-model="bindForm.RankID" clearable filterable remote :remote-method="handleBindRankSearch" placeholder="请输入榜单名称">
                <Option v-for="item in bindRankList" :value="item.ID" :key="item.ID">{{item.Title}}</Option>
              </Select>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button @click="visible = false" type="text" size="large">取消</Button>
        <Button @click="submitForm" type="primary" size="large">确定</Button>
      </template>
    </Modal>

  </div>
</template>

<script>
  import Tables from "_c/tables";
  import HomeModuleAPI from '@/api/gamespace/homemodule'
  import ThematicApi from '@/api/gamespace/thematic'
    export default {
        name: "manage",
      data(){
          return {
            visible: false,
            thematicID :undefined,
            formData: {
              RankID : undefined,
            },
            bindForm: {
              ThematicID: undefined,
              RankID: undefined
            },
            bindRankList: [],
            rankList: [],
            tableData: [],
            columns: [
              {title: '榜单名称', key: 'RankTitle'},
              {title: '榜单描述', key: 'RankDesc'},
              {title: '操作', slot: 'Opt', align: 'center', fixed: 'right'},
            ],
          }
        },
      created() {
        this.thematicID = parseInt(this.$route.query.ID)
      },
      mounted() {
        this.columns = Tables.RenderColumns(this.columns, this);
        this.init();
        this.$on('on-edit', this.edit)
      },
      methods: {
        init(){
          ThematicApi.ThematicRankList(this.thematicID).then(res => {
            console.log(res)
            if (res.Data) {
              this.tableData = res.Data
            }
          })
        },
        handleRankSearch(value){
          if (!parseInt(value)) {
            HomeModuleAPI.LikeRank(value).then(res => {
              this.rankList = res.Data;
            });
          }
        },
        handleBindRankSearch(value){
          if (!parseInt(value)) {
            HomeModuleAPI.LikeRank(value).then(res => {
              this.bindRankList = res.Data;
            });
          }
        },
        unBind(id){
          ThematicApi.UnBind(id).then(res => {
            if (res.Code === 0) {
              this.$Message.success('操作成功')
              this.init()
            } else {
              this.$Message.error(res.Message)
            }
          })
        },
        bind(){
          ThematicApi.Bind(this.bindForm).then(res => {
            if (res.Code === 0) {
              this.$Message.success('操作成功')
              this.init()
              this.visible = false
            } else {
              this.$Message.error(res.Message)
            }
          })
        },
        sort(id){
          ThematicApi.Sort(id).then(res => {
            if (res.Code === 0) {
              this.$Message.success('操作成功')
              this.init()
            } else {
              this.$Message.error(res.Message)
            }
          })
        },
        addRank(){
          this.bindForm.RankID = undefined
          this.bindForm.ThematicID = this.thematicID
          this.visible = true
        },
        submitForm(){
          this.bind()
        }
      }
    }
</script>

<style scoped>

</style>
