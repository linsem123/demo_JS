<template>
  <div>
    <Tabs :animated="false" style="padding-bottom: 150px">
      <TabPane label="模块管理" icon="ios-apps">
        <Card>
          <Table :data="tableData" :columns="columns" border>
            <!-- <template slot-scope="{ row, index }" slot="RankId">
              {{ rankFilter(row.RankId) }}
            </template> -->
            <template slot-scope="{ row, index }" slot="Status">
              <Tag v-if="row.Status == 1" color="success">上架</Tag>
              <Tag v-else-if="row.Status == 2" color="error">下架</Tag>
              <Tag v-else color="warning">待处理</Tag>
            </template>
            <template slot-scope="{ row, index }" slot="opt">
              <Button
                @click="editTheModule(row)"
                type="primary"
                size="small"
                class="table-opt"
                >编辑</Button
              >
              <Button
                @click="updateStatus(row, 1)"
                type="success"
                v-if="row.Status != 1"
                size="small"
                class="table-opt"
                >上架</Button
              >
              <Button
                @click="updateStatus(row, 2)"
                type="error"
                v-else
                size="small"
                class="table-opt"
                >下架</Button
              >
            </template>
          </Table>

          <Row style="margin-top: 10px">
            <Col :span="6">
              <Button
                @click="editTheModule()"
                type="info"
                shape="circle"
                icon="md-add"
                >新增模块</Button
              >
            </Col>
            <Col :span="18" align="right">
              <Page
                :total="searchform.page.total"
                :current="searchform.page.current"
                :page-size="searchform.page.size"
                @on-change="onPageChange"
                @on-page-size-change="onPageSizechange"
                show-sizer
                show-total
              ></Page>
            </Col>
          </Row>
        </Card>
      </TabPane>
      <TabPane label="热词管理" icon="ios-pulse">
        <HotWord></HotWord>
      </TabPane>
      <TabPane label="搜索词管理" icon="ios-pulse">
        <SearchWord />
      </TabPane>
    </Tabs>

    <!--    编辑新增弹出-->
    <Modal v-model="visible" :title="formData.ID ? '编辑' : '新增'">
      <Row>
        <Col :span="21">
          <Form
            :model="formData"
            :rules="rules"
            ref="formData"
            :label-width="120"
          >
            <FormItem label="模块名称：" prop="Name">
              <Input
                v-model="formData.Name"
                placeholder="请输入模块名称"
              ></Input>
            </FormItem>
            <FormItem label="搜索提示词：" prop="Title">
              <Input
                v-model="formData.Title"
                placeholder="请输入搜索提示词"
              ></Input>
            </FormItem>
            <FormItem label="榜单类型：">
              <Select v-model="rankParams.type" clearable>
                <Option
                  v-for="item in rankTypeList"
                  :value="item.id"
                  :key="item.id"
                  >{{ item.name }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="绑定榜单：">
              <!-- <Select v-model="formData.RankId">
                <Option v-for="r in rankList" :value="r.ID">{{r.Title}}</Option>
              </Select> -->
              <RankSelect
                :rankType="rankParams.type"
                v-model="formData.RankId"
                ref="rank"
                @on-change="getrank"
                placeholder="请输入榜单名称"
                style="width: 200px"
              ></RankSelect>

              <!-- <Fuzzy
                v-model="formData.RankId"
                :data="NameData"
                :params="{rankType:rankParams.type}"
                :getone="formData.RankId"
                @on-change="getrank"
              ></Fuzzy>-->
            </FormItem>
            <FormItem label="榜单显示数量：" prop="ShowCount">
              <InputNumber
                v-model="formData.ShowCount"
                :min="1"
                :max="99"
              ></InputNumber>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button @click="visible = false" type="text" size="large">取消</Button>
        <Button @click="submitConfig" type="primary" size="large">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import SearchConApi from "@/api/gamespace/searchconfig";
import HotWord from "./hotword";
import SearchWord from "./SearchWord";
import RankSelect from "@/components/rank-select";

export default {
  name: "",
  components: { HotWord, RankSelect, SearchWord },
  data() {
    return {
      searchform: {
        page: {
          total: 0,
          current: 1,
          size: 10,
        },
        name: "",
      },
      rankList: [],
      tableData: [],
      columns: [
        { title: "模块名", key: "Name", minWidth: 150 },
        { title: "搜索提示词", key: "Title", minWidth: 90 },
        // { title: "绑定榜单", slot: "RankId", minWidth: 90 },
        { title: "绑定榜单", key: "RankTitle", minWidth: 90 },
        { title: "显示数量", key: "ShowCount", minWidth: 90 },
        { title: "状态", slot: "Status", minWidth: 80 },
        {
          title: "操作",
          slot: "opt",
          minWidth: 130,
          align: "center",
          fixed: "right",
        },
      ],

      visible: false,
      formData: {},
      rules: {
        Name: [{ required: true, message: "请输入模块名称", trigger: "blur" }],
        Title: [
          { required: true, message: "请输入搜索提示词", trigger: "blur" },
        ],
        RankId: [
          {
            required: true,
            type: "number",
            message: "请绑定榜单",
            trigger: "blur",
          },
        ],
        // ShowCount: [{required: true, message: '请设置榜单元素显示数量', trigger: 'blur'}],
      },
      rankTypeList: [
        { id: 1, name: "普通榜单" },
        { id: 2, name: "排行榜单" },
        { id: 3, name: "预约榜单" },
        { id: 4, name: "分类榜单" },
        { id: 5, name: "标签榜单" },
        { id: 6, name: "飙升榜单" },
      ],
      rankParams: {
        type: undefined,
      },
    };
  },
  mounted() {
    this.getModules();
    // this.getRankList();
  },
  methods: {
    onPageChange(value) {
      this.searchform.page.current = value;
      this.getModules();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.getModules();
    },
    // getRankList() {
    //   SearchConApi.GetRankList().then((res) => {
    //     if (res.Code === 0) {
    //       this.rankList = res.Data || [];
    //     }
    //   });
    // },

    getModules() {
      SearchConApi.GetSearchModels({
        Page: this.searchform.page.current,
        Limit: this.searchform.page.size,
      }).then((res) => {
        if (res.Code === 0) {
          this.tableData = res.Data.Data || [];
          this.searchform.page.total = res.Data.Count;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },

    updateStatus(row, status) {
      let that = this;
      this.$Modal.confirm({
        title: `确定要将 ${row.Name} ${status == 1 ? "上" : "下"}架吗？`,
        onOk: () => {
          SearchConApi.UpdateStatus(row.ID, status).then((res) => {
            if (res.Code === 0) {
              that.$Message.success("操作成功");
              that.getModules();
            } else {
              that.$Message.error(res.Message);
            }
          });
        },
      });
    },

    // 编辑模块
    editTheModule(item) {
      if (!item) {
        this.formData = {};
      } else {
        this.formData = JSON.parse(JSON.stringify(item));
      }
      this.visible = true;
    },

    submitConfig() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          this.submitApi(this.formData).then((res) => {
            if (res.Code === 0) {
              this.visible = false;
              this.$Message.success("操作成功");
              this.getModules();
            } else {
              this.$Message.error(res.Message);
            }
          });
        }
      });
    },

    submitApi(params) {
      if (this.formData.ID) {
        return SearchConApi.EditSearchModels(params);
      } else {
        return SearchConApi.AddSearchModels(params);
      }
    },

    // rankFilter(val) {
    //   let res = this.rankList.filter((item) => {
    //     return item.ID == val;
    //   })[0];
    //   return (res && res.Title) || "--";
    // },
    getrank() {},
  },
};
</script>

<style scoped>
</style>
