<template>
  <div>
    <Card>
      <Form :model="formData" :inline="true" style="position: relative">
        <FormItem prop="Keyword">
          <Input
            v-model="formData.Keyword"
            style="width: 200px"
            placeholder="请输入搜索词"
          />
        </FormItem>

        <FormItem prop="AppId" :label-width="30">
          <gameNameSelect
            v-model="formData.AppId"
            :width="200"
            :multiple="false"
          />
        </FormItem>
        <FormItem :label-width="30">
          <Button
            type="success"
            shape="circle"
            icon="ios-search"
            @click="getWord"
            >搜索</Button
          >
          <Button
            @click="
              visible = true;
              isEdit = false;
              formModify.SearchType = 1;
            "
            type="success"
            icon="md-add"
            style="margin-left: 30px"
            >新增热词</Button
          >
        </FormItem>
      </Form>
      <Table
        border
        highlight-row
        ref="currentRowTable"
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :max-height="600"
      >
        <template slot-scope="{ row }" slot="ResultSort">
          {{ row.ResultSort || "/" }}
        </template>
        <template slot-scope="{ row }" slot="AssociationSort">
          {{ row.AssociationSort || "/" }}
        </template>
        <template slot-scope="{ row }" slot="action">
          <Button type="primary" size="small" @click="editWord(row)"
            >编辑</Button
          >
          <Button
            type="error"
            size="small"
            style="margin-left: 15px"
            @click="delWord(row.ID)"
            >删除</Button
          >
        </template>
      </Table>
      <Page
        show-sizer
        :total="total"
        show-total
        :page-size="pageSize"
        :current="pageIndex"
        @on-change="changePage"
        @on-page-size-change="changePageSize"
      />
    </Card>
    <!-- 新增/修改痰喘 -->
    <Modal
      v-model="visible"
      :title="isEdit ? '编辑' : '新增'"
      @on-visible-change="visibleChange"
    >
      <Form
        ref="formValidate"
        :model="formModify"
        :rules="ruleValidate"
        style="position: relative"
        :label-width="120"
      >
        <FormItem prop="Keyword" label="搜索词">
          <Input
            v-model="formModify.Keyword"
            style="width: 200px"
            placeholder="请输入搜索词"
          />
        </FormItem>

        <FormItem prop="AppId" label="游戏名称：">
          <AppSelect
            v-if="visible"
            v-model="formModify.AppId"
            style="width: 200px"
            placeholder="请输入游戏名称"
            @on-change="appChange"
          />
        </FormItem>
        <FormItem prop="SearchType" label="联想app位置：" :required="true">
          <Selection
            v-model="formModify.SearchType"
            :dataList="dataList"
            style="width: 200px"
            :clearable="false"
          />
        </FormItem>
        <FormItem prop="Sort" label="搜索结果页位置：">
          <Input v-model="formModify.Sort" style="width: 200px" type="number" />
        </FormItem>
      </Form>
      <template slot="footer">
        <Button @click="clearModal" type="text" size="large">取消</Button>
        <Button @click="doValidator" type="primary" size="large">确定</Button>
      </template>
    </Modal>
  </div>
</template>
<script>
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect";
import AppSelect from "_c/app-select";
import Selection from "_c/Selection.vue";
import SearchConApi from "@/api/gamespace/searchconfig";
export default {
  components: { gameNameSelect, AppSelect, Selection },
  data() {
    const numValidator = (rule, value, callback) => {
      if (!value || parseInt(value) <= 0) {
        callback("请输入大于0的搜索结果页位置");
      }
      callback();
    };
    const AppValidator = (rule, value, callback) => {
      if (!value && parseInt(value) != 0) {
        callback("请输入关联游戏");
      }
      callback();
    };
    return {
      formData: {
        AppId: undefined,
        Keyword: "",
      },
      columns: [
        {
          title: "搜索词",
          key: "Keyword",
          align: "center",
        },
        {
          title: "关联游戏",
          key: "AppName",
          align: "center",
        },
        {
          title: "搜索结果页位置",
          slot: "ResultSort",
          align: "center",
        },
        {
          title: "联想app位置",
          slot: "AssociationSort",
          align: "center",
        },
        {
          title: "操作",
          slot: "action",
          align: "center",
        },
      ],
      tableData: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      loading: false,
      visible: false,
      isEdit: false,
      Id: "",
      formModify: {
        Keyword: "",
        AppId: undefined,
        PageType: 0,
        Sort: 0,
        Place: 0,
        SearchType: 1,
      },
      ruleValidate: {
        Keyword: [{ required: true, message: "请输入搜索词", trigger: "blur" }],
        AppId: [
          {
            required: true,
            trigger: "blur",
            validator: AppValidator,
          },
        ],
        Sort: [
          {
            required: true,
            // message: "请输入搜索结果页位置",
            trigger: "blur",
            validator: numValidator,
          },
        ],
      },
      dataList: [
        {
          Id: 1,
          Name: "结果搜索",
        },
        {
          Id: 2,
          Name: "联想搜索",
        },
      ],
    };
  },
  mounted() {
    this.getWord();
  },
  methods: {
    visibleChange(value) {
      if (!value) this.clearModal();
    },
    editWord(row) {
      for (let key in this.formModify) {
        this.formModify[key] = row[key];
      }
      this.Id = row.ID;
      this.isEdit = true;
      this.visible = true;
    },
    //
    delWord(Id) {
      SearchConApi.delSearchWord(Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("删除成功");
          this.getWord();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    doValidator() {
      this.$refs["formValidate"].validate((valid) => {
        if (valid) {
          this.formModify.Sort = parseInt(this.formModify.Sort);
          SearchConApi.validateSearchWord({ ...this.formModify }).then(
            (res) => {
              if (res.Code == 0) {
                let content = "";
                if (res.Data.CurrentAddressAppName) {
                  content =
                    content +
                    `<p>该搜索词下当前位置已配置${res.Data.CurrentAddressAppName}游戏，是否覆盖之前的设置？<p>`;
                }
                if (
                  res.Data.OtherAddress.AppName &&
                  res.Data.OtherAddress.Sort > 0
                ) {
                  content =
                    content +
                    `<p>该搜索词下第${res.Data.OtherAddress.Sort}位已配置${res.Data.OtherAddress.AppName}游戏，是否覆盖之前的设置？<p>`;
                }
                if (content) {
                  this.$Modal.confirm({
                    title: "提示",
                    content: content,
                    okText: "是",
                    cancelText: "否",
                    loading: true,
                    onOk: () => {
                      this.submitConfig();
                      this.$Modal.remove();
                    },
                  });
                } else {
                  this.submitConfig();
                }
              }
            }
          );
        }
      });
    },
    //新增/修改
    submitConfig() {
      this.formModify.Sort = parseInt(this.formModify.Sort);
      if (this.isEdit) {
        //编辑
        SearchConApi.editSearchWord(this.Id, { ...this.formModify }).then(
          (res) => {
            if (res.Code == 0) {
              this.$Message.success("编辑成功");
              this.getWord();
              this.visible = false;
            } else {
              this.$Message.error(res.Message);
            }
          }
        );
      } else {
        //新增
        SearchConApi.addSearchWord({ ...this.formModify }).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("新增成功");
            this.getWord();
            this.visible = false;
          } else {
            this.$Message.error(res.Message);
          }
        });
      }
      //   this.clearModal();
    },
    clearModal() {
      this.formModify.Sort = 0;
      this.formModify.Keyword = "";
      this.formModify.AppId = undefined;
      this.visible = false;
    },
    appChange() {},
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.getWord();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.getWord();
    },
    getWord() {
      SearchConApi.getSearchList({
        limit: this.pageSize,
        page: this.pageIndex,
        params: {
          Keyword: this.formData.Keyword ? this.formData.Keyword : undefined,
          AppId: this.formData.AppId,
        },
      }).then((res) => {
        if (res.Code == 0) {
          this.tableData = res.Data.Data;
          this.total = res.Data.Count;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>