<template>
  <div>
    <Card>
      <Row
        style="margin-bottom: 20px"
        type="flex"
        justify="center"
        align="middle"
      >
        <i-col :span="4">热词总数： {{ total }}</i-col>
        <i-col :span="6">
          <Input
            v-model="key"
            @on-change="keyChange"
            placeholder="输入热词，快速定位"
          ></Input>
        </i-col>
        <i-col :span="14" align="right">
          <Button @click="visible = true" type="success" icon="md-add"
            >新增热词</Button
          >
        </i-col>
      </Row>

      <div>
        <div
          class="hot-item"
          v-for="(h, index) in hotList"
          :key="index"
          :class="{ active: keyList.includes(h.ID) }"
        >
          <span class="title">{{ h.Title }}</span>
          <span @click="deleteHot(h)" class="close">
            <Icon type="md-close" size="16" />
          </span>
        </div>
      </div>

      <Row>
        <Page
          :total="total"
          :current="page"
          :page-size="pageSize"
          :page-size-opts="[20, 50, 80, 100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </Row>
    </Card>

    <Modal v-model="visible" title="新增热词">
      <Row>
        <Col :span="21">
          <Form
            :model="formData"
            :rules="rules"
            :label-width="120"
            ref="formData"
          >
            <FormItem label="热词：" prop="Title">
              <Input
                v-model="formData.Title"
                @on-keydown.enter="submitForm"
                placeholder="请输入要新增的热词"
              ></Input>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button @click="visible = false" type="text" size="large">取消</Button>
        <Button @click="submitForm" type="primary" size="large">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import SearchConApi from "@/api/gamespace/searchconfig";

export default {
  name: "",
  data() {
    return {
      page: 1,
      pageSize: 50,
      total: 0,

      key: "",
      keyList: [], // 用于静态过滤
      hotList: [],

      visible: false,
      formData: {},
      rules: {
        Title: [{ required: true, message: "请输入热词", trigger: "blur" }],
      },
    };
  },
  mounted() {
    this.getHotWord();
  },
  methods: {
    onPageChange(value) {
      this.page = value;
      this.getHotWord();
    },
    onPageSizechange(value) {
      this.pageSize = value;
      this.getHotWord();
    },
    getHotWord() {
      SearchConApi.GetHotList({ Page: this.page, Limit: this.pageSize }).then(
        (res) => {
          if (res.Code === 0) {
            this.hotList = res.Data.Data || [];
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        }
      );
    },

    deleteHot(row) {
      this.$Modal.confirm({
        title: "提示",
        content: `确定删除热词‘${row.Title}’吗？`,
        onOk: () => {
          SearchConApi.deleteHotWord({ ID: row.ID, Title: row.Title }).then(
            (res) => {
              if (res.Code == 0) {
                this.$Message.success("删除成功");
                this.getHotWord();
              } else {
                this.$Message.error(res.Message);
              }
            }
          );
        },
      });
    },

    submitForm() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          SearchConApi.AddHotWord(this.formData).then((res) => {
            if (res.Code === 0) {
              this.getHotWord();
              this.visible = false;
              this.$Message.success("新增成功");
              this.formData = {};
            } else {
              this.$Message.error(res.Message);
            }
          });
        }
      });
    },

    keyChange() {
      if (this.key && this.key.trim() !== "") {
        let likeArr = this.hotList.filter((h) => {
          return h.Title.match(this.key);
        });

        this.keyList = likeArr.map((m) => {
          return m.ID;
        });
      } else {
        this.keyList = [];
      }
    },
  },
};
</script>

<style scoped lang="less">
.hot-item.active {
  color: #19be6b;
  box-shadow: 0 1px 6px rgba(25, 190, 107, 0.8);
}
.hot-item {
  display: inline-block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  background: #fff;
  padding: 8px 15px;
  border-radius: 5px;
  box-sizing: border-box;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.2);
  margin: 0 0 15px 15px;
  transition: all 0.1s;
  border: 1px solid #fff;
  &:hover {
    transform: scale(1.05);
  }
  .close {
    display: inline-block;
    vertical-align: bottom;
    cursor: pointer;
    margin-left: 15px;
    &:hover {
      color: #2d8cf0;
    }
  }
}
</style>
