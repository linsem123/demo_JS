<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>
      版本编辑-{{ formScope.AppName }}
    </p>
    <view-form
      @on-form-submit="handleSubmit"
      :formScope="formScope"
      ref="formPage"
      :isEdit="true"
    ></view-form>
  </Card>
</template>
<script>
import GameVersionAPI from "@/api/gamespace/gameversion";
// import GameAPI from "@/api/gamespace/game";
import ViewForm from "_c/gamespace/gameversion/form";
import { mapMutations } from "vuex";
export default {
  name: "Add",
  components: {
    ViewForm,
  },
  data() {
    return {
      formScope: {
        AppName: "",
      },
    };
  },
  methods: {
    ...mapMutations(["closeTag"]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      let ImgSource = formScope.ImgSource.map((item) => {
        return item.url;
      });
      GameVersionAPI.Edit({
        ...{},
        ...formScope,
        ...{ ImgSource: ImgSource },
      }).then((res) => {
        this.$Loading.finish();
        this.loading = false;
        if (res.Code > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "更新成功!",
        });
        this.closeTag(this.$route);
        // this.$emit("on-close", undefined, undefined, this.$route);
        this.$router.push({
          name: "gamespace_gameversion",
        });
      });
    },
  },
  mounted() {
    GameVersionAPI.Get(this.$route.params.id).then((res) => {
      if (res.Code > 0) {
        this.$Message.warning(res.Message);
        return;
      }
      //当游戏状态处于刚添加的状态的时候，可以发起预约，否则，只能上线。
      res.Data.ImgSource = res.Data.ImgSource.map((item) => {
        return { url: item };
      });
      res.Data.IsShow = false;
      this.formScope = res.Data;
      // this.formScope.AppID = parseInt(this.$route.params.id);
    });
  },
};
</script>
