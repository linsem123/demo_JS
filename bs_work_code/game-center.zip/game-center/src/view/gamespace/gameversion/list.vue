<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Form inline>
          <FormItem>
            <Select
              v-model="searchform.params.id"
              :loading="searchform.appname.loading"
              clearable
              filterable
              remote
              :remote-method="handleGameSearch"
              placeholder="请输入游戏名称"
              ref="AppName"
              @on-change="changeAppName"
              style="width: 200px"
            >
              <Option
                v-for="item in searchform.appname.data"
                :value="item.ID"
                :key="item.ID"
                >{{ item.AppName }}</Option
              >
            </Select>
          </FormItem>
          <FormItem>
            <Select
              v-model="searchform.params.id"
              :loading="searchform.appname.loading"
              clearable
              filterable
              remote
              :remote-method="handleGamePkgNameSearch"
              placeholder="请输入游戏包名"
              ref="packageName"
              @on-change="changeValue"
              style="width: 200px"
            >
              <Option
                v-for="item in searchform.appname.data"
                :value="item.ID"
                :key="item.ID"
                >{{ item.PkgName }}</Option
              >
            </Select>
          </FormItem>
          <FormItem label="状态：" :label-width="60">
            <Selection
              :dataList="stateList"
              v-model="searchform.params.AppStatus"
            />
          </FormItem>
          <FormItem label="下载源：" :label-width="60">
            <Selection
              :dataList="placeList"
              v-model="searchform.params.DownloadSource"
            />
          </FormItem>
          <FormItem label="游戏类型：" :label-width="75">
            <Selection
              :dataList="appTypeList"
              v-model="searchform.params.AppType"
            />
          </FormItem>
          <FormItem label="开发者：" :label-width="65">
            <LikeSearch
              v-model="searchform.params.Provider"
              placeholder="请输入开发者"
              :serverData="postProviderData"
              clearable
              style="width: 200px"
            />
          </FormItem>
          <FormItem>
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </FormItem>
        </Form>
      </div>
      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      >
        <template slot-scope="{ row, index }" slot="download">
          <span v-if="row.DownloadStatus == 0">-</span>
          <span v-else-if="row.DownloadStatus == 1">下载中</span>
          <span v-else-if="row.DownloadStatus == 2">下载成功</span>
          <span v-else-if="row.DownloadStatus == 3">下载失败</span>
          <span v-else>未知类型</span>
        </template>
        <template slot-scope="{ row, index }" slot="channelID">
          <span v-if="row.ChannelID == 0">-</span>
          <span v-else>{{ row.ChannelID }}</span>
        </template>
        <template slot-scope="{ row, index }" slot="failedReason">
          <span v-if="row.DownloadFailedReason == ''">-</span>
          <span v-else>{{ row.DownloadFailedReason }}</span>
        </template>
      </Table>
      <div style="margin: 10px; overflow: hidden">
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>
    <check-status ref="checkstatus" @onClose="closeCheckStatus" />
  </div>
</template>

<script>
import GameVersionAPI from "@/api/gamespace/gameversion";
import GameAPI from "@/api/gamespace/game";
import CheckStatus from "_c/gamespace/gameversion/status";
import Tables from "_c/tables";
import { formatTimes } from "@/libs/tools";
import Selection from "_c/Selection";
import LikeSearch from "_c/like-search";
export default {
  name: "gamespace_gameversion",
  components: {
    CheckStatus,
    Selection,
    LikeSearch,
  },
  data() {
    return {
      searchform: {
        params: {
          id: undefined,
          AppStatus: 99,
          DownloadSource: 99,
          Provider: undefined,
          AppType: 99,
        },
        page: {
          total: 100,
          current: 1,
          size: 10,
        },
        appname: {
          loading: false,
          data: [],
        },
      },
      table: {
        loading: false,
        data: [],
        columns: [
          {
            title: "游戏名称",
            fixed: "left",
            width: 180,
            render: (h, params) => {
              const div = [];
              if (params.row.IconURL !== "") {
                let icon = h("Avatar", {
                  props: {
                    shape: "square",
                    src: params.row.AppIcon,
                    size: "small",
                  },
                  style: {
                    marginRight: "5px",
                  },
                });
                div.push(icon);
              }
              if (params.row.ButtonText !== "") {
                let tag = h("Tag", { props: {} }, params.row.AppName);
                div.push(tag);
              }
              return h("div", div);
            },
          },
          {
            title: "游戏包名",
            width: 250,
            render: (h, params) => {
              return h("Tag", { props: {} }, params.row.PkgName);
            },
          },
          {
            title: "游戏分类",
            width: 150,
            render: (h, params) => {
              return h("Tag", { props: {} }, params.row.CategoryName);
            },
          },
          {
            title: "下载源",
            align: "center",
            fixed: "left",
            width: 100,
            key: "DownloadSource",
            render: (h, params) => {
              if (params.row.DownloadSource === 0) {
                return h("Tag", { props: { color: "default" } }, "黑鲨");
              }
              if (params.row.DownloadSource === 1) {
                return h("Tag", { props: { color: "default" } }, "小米");
              }
              if (params.row.DownloadSource === 4) {
                return h("Tag", { props: { color: "default" } }, "应用宝");
              }
            },
          },
          {
            title: "游戏状态",
            align: "center",
            fixed: "left",
            width: 120,
            key: "Status",
            render: (h, params) => {
              if (params.row.Status === 0) {
                return h("Tag", { props: { color: "warning" } }, "待处理");
              }
              if (params.row.Status === 1) {
                return h("Tag", { props: { color: "success" } }, "上线");
              }
              if (params.row.Status === 2) {
                return h("Tag", { props: { color: "error" } }, "撤销");
              }
              if (params.row.Status === 3) {
                return h("Tag", { props: { color: "error" } }, "审核失败");
              }
              if (params.row.Status === 4) {
                return h("Tag", { props: { color: "warning" } }, "待上线");
              }
            },
          },
          {
            title: "版本类型",
            width: 100,
            render: (h, params) => {
              //预约状态下可以修改包名
              if (params.row.ReleaseType === 0) {
                return h("Tag", { props: { color: "success" } }, "正式");
              }
              if (params.row.ReleaseType === 1) {
                return h("Tag", { props: {} }, "内测");
              }
            },
          },
          {
            title: "发布描述",
            minWidth: 100,
            key: "ReleaseTypeDesc",
          },
          {
            title: "时间范围描述",
            minWidth: 100,
            key: "ReleasePeriodDesc",
          },
          {
            title: "定时发布时间",
            minWidth: 160,
            key: "PublishTime",
            render: (h, params) => {
              if (params.row.PublishType === 1) {
                return h(
                  "div",
                  { props: { color: "warning" } },
                  this.timeFormat(params.row.PublishTime)
                );
              }
            },
          },
          { title: "sdk版本名称", width: 150, key: "SdkVersionName" },
          { title: "sdk版本号", width: 150, key: "SdkVersionCode" },
          {
            title: "版本类型",
            align: "center",
            fixed: "left",
            width: 120,
            key: "Status",
            render: (h, params) => {
              if (params.row.AppVersionType === 1) {
                return h("Tag", { props: { color: "warning" } }, "游戏预约");
              }

              if (params.row.AppVersionType === 0) {
                return h("Tag", { props: { color: "success" } }, "游戏更新");
              }
            },
          },
          {
            title: "发布类型",
            align: "center",
            fixed: "left",
            width: 120,
            key: "Status",
            render: (h, params) => {
              if (params.row.PublishType === 1) {
                return h("Tag", { props: { color: "warning" } }, "定时发布");
              }

              if (params.row.PublishType === 0) {
                return h("Tag", { props: { color: "success" } }, "立即发布");
              }
            },
          },
          {
            title: "游戏标签",
            width: 200,
            key: "Tags",
            render: (h, params) => {
              let div = [];
              if (params.row.Tags) {
                for (const item of params.row.Tags) {
                  div.push(h("Tag", {}, item));
                }
              }
              return h("div", div);
            },
          },
          {
            title: "版本信息",
            width: 200,
            align: "center",
            render: (h, params) => {
              if (params.row.SubType === 0) {
                return h("Tag", { props: { color: "warning" } }, "游戏预约");
              }
              return h("div", [
                h("Tag", {}, params.row.VersionName),
                h("Tag", {}, params.row.VersionCode),
              ]);
            },
          },
          { title: "开发者", width: 200, key: "Provider" },
          { title: "下载状态", slot: "download", width: 130 },
          { title: "ChannelID", slot: "channelID", width: 130 },
          { title: "失败原因", slot: "failedReason", width: 150 },
          {
            title: "操作",
            fixed: "right",
            width: 215,
            key: "handle",
            options: ["edit"],
            button: [
              (h, params, vm) => {
                return h(
                  "Button",
                  {
                    props: {
                      type: "warning",
                      size: "small",
                      disabled:
                        params.row.DownloadStatus == 1 ||
                        params.row.DownloadStatus == 3,
                    },
                    on: {
                      click: () => {
                        this.$refs.checkstatus.show(
                          params.row.ID,
                          params.row.Status,
                          params.row.Opinion
                        );
                      },
                    },
                    style: {
                      marginRight: "5px",
                    },
                  },
                  "审核发布"
                );
              },
              (h, params, vm) => {
                return h(
                  "Button",
                  {
                    props: {
                      type: "success",
                      size: "small",
                    },
                    on: {
                      click: () => {
                        this.$router.push({
                          name: "gamespace_gameversion_childApk",
                          params: { row: params.row },
                        });
                      },
                    },
                  },
                  "子包管理"
                );
              },
            ],
          },
        ],
      },
      stateList: [
        {
          Id: 99,
          Name: "全部",
        },
        {
          Id: 0,
          Name: "待处理",
        },
        {
          Id: 1,
          Name: "上线",
        },
        {
          Id: 2,
          Name: "撤销",
        },
        {
          Id: 3,
          Name: "审核失败",
        },
        {
          Id: 4,
          Name: "待上线",
        },
      ],
      placeList: [
        {
          Id: 99,
          Name: "全部",
        },
        {
          Id: 0,
          Name: "黑鲨",
        },
        {
          Id: 1,
          Name: "小米",
        },
        {
          Id: 4,
          Name: "应用宝",
        },
      ],
      appTypeList: [
        {
          Id: 99,
          Name: "全部",
        },
        {
          Id: 0,
          Name: "游戏",
        },
        {
          Id: 1,
          Name: "应用",
        },
      ],
      postProviderData: {
        likeUrl: "LikeDeveloper",
        likeData: {},
        IdKey: "Name",
        NameKey: "Name",
      },
    };
  },
  methods: {
    timeFormat(date) {
      return formatTimes(date);
    },
    //游戏名
    changeAppName(val) {
      if (val) {
        let item = this.searchform.appname.data.filter((v) => v.ID == val);
        this.$refs["packageName"].setQuery(item[0].PkgName);
        this.$refs["packageName"].toggleMenu(null, false);
      }
    },
    //包名
    changeValue(val) {
      if (val) {
        let item = this.searchform.appname.data.filter((v) => v.ID == val);
        this.$refs["AppName"].setQuery(item[0].AppName);
        this.$refs["AppName"].toggleMenu(null, false);
      }
    },
    handleGameSearch(value) {
      // GameAPI.LikeApp({ value }).then((res) => {
      //   this.searchform.appname.data = res.Data;
      // });
      //模糊搜索增加包名
      GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        this.searchform.appname.data = res.Data;
      });
    },
    handleGamePkgNameSearch(value) {
      GameAPI.LikeAppByParams({ params: { PkgName: value } }).then((res) => {
        this.searchform.appname.data = res.Data;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    edit(params) {
      this.$router.push({
        name: "gamespace_gameversion_edit",
        params: { id: params.row.ID },
      });
    },
    enable(param) {
      GamepAPI.Enable(param.row.ID, !param.row.Enable).then((res) => {
        this.init();
      });
    },
    closeCheckStatus() {
      this.init();
    },
    publishversion(params) {
      // 发布版本
      this.$router.push({
        name: "gamespace_gameversion_add",
        params: { id: params.row.ID },
      });
    },
    init() {
      let searchData = JSON.parse(JSON.stringify(this.searchform));
      if (searchData.params.AppStatus == 99) {
        searchData.params.AppStatus = undefined;
      }
      if (searchData.params.DownloadSource == 99) {
        searchData.params.DownloadSource = undefined;
      }
      if (searchData.params.AppType == 99) {
        searchData.params.AppType = undefined;
      }
      GameVersionAPI.FindByPage(
        searchData.page.size,
        searchData.page.current,
        searchData.params
      ).then((res) => {
        if (res.Code == 0) {
          this.table.data = res.Data.Data || [];
          this.searchform.page.total = res.Data.Count;
        } else {
          this.$Message.error(res.Message || "查询失败");
        }
      });
    },
  },
  mounted() {
    this.table.columns = Tables.RenderColumns(this.table.columns, this);
    this.$on("on-edit", this.edit);
    this.init();
    // 注册监听事件
  },
  activated() {
    this.init();
  },
};
</script>
