<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>
      游戏版本更新-{{ formScope.AppName }}
    </p>
    <view-form
      @on-form-submit="handleSubmit"
      :formScope="formScope"
      :isEdit="false"
      ref="formPage"
    ></view-form>
  </Card>
</template>
<script>
import GameVersionAPI from "@/api/gamespace/gameversion";
import GameAPI from "@/api/gamespace/game";
import ViewForm from "_c/gamespace/gameversion/form";
import { mapMutations } from "vuex";
export default {
  name: "Add",
  components: {
    ViewForm,
  },
  data() {
    return {
      formScope: {
        AppName: "",
      },
    };
  },
  methods: {
    ...mapMutations(["closeTag"]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      let ImgSource = formScope.ImgSource.map((item) => {
        return item.url;
      });
      formScope.ID = 0;
      GameVersionAPI.Add({
        ...{},
        ...formScope,
        ...{ ImgSource: ImgSource },
      }).then((res) => {
        this.$Loading.finish();
        this.loading = false;
        if (res.Code > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "添加成功!",
        });
        this.closeTag(this.$route);
        this.$refs.formPage.upByUrlData.loading = false; //取消任务上传状态
        // this.$emit("on-close", undefined, undefined, this.$route);
        this.$router.push({
          name: "gamespace_gameversion",
        });
      });
    },
  },
  mounted() {
    GameAPI.Get(this.$route.params.id).then((res) => {
      if (res.Code > 0) {
        this.$Message.warning(res.Message);
        return;
      }
      //当游戏状态处于刚添加的状态的时候，可以发起预约，否则，只能上线。
      let formScope = res.Data;
      formScope.AppID = parseInt(this.$route.params.id);
      formScope.ImgSource = (formScope.ImgSource || []).map((item) => ({
        url: item || "",
      }));
      formScope.IsShow = true;
      this.formScope = formScope;
      this.formScope.isAdd = true;
    });
  },
  beforeRouteLeave(to, from, next) {
    if (this.$refs.formPage.upByUrlData.loading) {
      //通过链接上传apk，上传中切换页面二次弹窗确认是否离开页面
      this.$Modal.confirm({
        title: "提示",
        content: "<p>是否删除当前上传任务</p>",
        onOk: () => {
          this.$refs.formPage.delTaskServer();
          this.$Modal.remove();
          next();
        },
        onCancel: () => {
          next(false);
          this.$Modal.remove();
        },
      });
    } else {
      next();
    }
  },
};
</script>
