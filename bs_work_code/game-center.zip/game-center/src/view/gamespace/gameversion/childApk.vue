<template>
  <Card>
    <p slot="title"  style="height:32px;line-height:32px">
      <Icon type="information-circled"></Icon>
      版本编辑-子包管理
       <Button style="float:right" type="info"  @click="re">刷新</Button>
       <Button style="float:right;margin-right:5px;" type="success" :disabled="isadd" @click="addlist">添加自渠道包</Button>
       
    </p>
    <Row>
    <div v-for="(item,i) in list" :key="i">
      <childrenform  :form="item" @getisAdd="getisAdd"></childrenform>
    </div>
    <!-- <childrenform :row="this.$route.params.row"></childrenform> -->
    </Row>
  </Card>
</template>
<script>
import GameVersionAPI from "@/api/gamespace/gameversion";
// import GameAPI from "@/api/gamespace/game";
import childrenform from "_c/gamespace/gameversion/childrenForm";
import { mapMutations } from "vuex";
export default {
  inject:['reload'],
  name: "Add",
  components: {
    childrenform,
    
  },
  data() {
    return {
       list:[],
       isadd:true
    };
  },
  methods: {

    re(){
this.reload();
    },
      getlist(){
          
      GameVersionAPI.getChildrenlist(this.$route.params.row.AppID,this.$route.params.row.VersionCode).then(res=>{
           if(res.Code==0){
               if(res.Data.length>0){
                 this.list=[]
                 res.Data.map(item=>{
                   this.list.push(item)
                   this.isadd=false
                })
               }else{
                   this.list.push(this.getlistpush())
               } 
           }
      })
  },
  addlist(){
     this.list.push(this.getlistpush())
     this.isadd=true
  },
  getlistpush(){
      let obj={}
      obj["package_name"] = this.$route.params.row.PkgName
      obj["app_name"] = this.$route.params.row.AppName
      obj["app_id"] = this.$route.params.row.AppID
      obj["icon_url"] = this.$route.params.row.AppIcon
      obj["version_code"]=this.$route.params.row.VersionCode
      obj["summary"] = this.$route.params.row.Title
      obj["video_url"] = this.$route.params.row.VideoURL
      obj["pic_url"] = this.$route.params.row.ImgSource.join(",")
      obj["detail_desc"] = this.$route.params.row.Content
      obj["update_desc"] = this.$route.params.row.UpdateContent
        return obj
  },
  getisAdd(q){
   this.isadd = q
   }
  },
  mounted() {
      this.getlist()
  }
};
</script>
