<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>添加分类
    </p>
    <view-form @on-form-submit="handleSubmit"></view-form>
  </Card>
</template>
<script>
import GameCategoryAPI from "@/api/gamespace/gamecategory";
import ViewForm from "_c/gamespace/gamecategory/form";
import { mapMutations} from 'vuex'
export default {
  name: "Add",
  components: {
      ViewForm,
  },
  data() {
    return {

    }
  },
  methods: {
    ...mapMutations([
      'closeTag'
    ]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      GameCategoryAPI.Add(formScope).then(res => {
        this.$Loading.finish();
        this.loading = false;
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "添加成功!"
        });
        this.closeTag(this.$route);
        // this.$emit("on-close", undefined, undefined, this.$route);
        this.$router.push({
          name: "gamespace_gamecategory"
        });
      });
    }
  }
};
</script>
