<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>编辑分类-{{formScope.Name}}
    </p>
    <view-form @on-form-submit="handleSubmit" :formScope="formScope"></view-form>
  </Card>
</template>
<script>
import GameCategoryAPI from "@/api/gamespace/gamecategory";
import ViewForm from "_c/gamespace/gamecategory/form";
import { mapMutations } from "vuex";
export default {
  name: "Edit",
  components: {
    ViewForm
  },
  data() {
    return {
      formScope: {
        type: Object
      }
    };
  },
  methods: {
    ...mapMutations(["closeTag"]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      GameCategoryAPI.Edit(formScope.ID,formScope).then(res => {
        this.$Loading.finish();
        this.loading = false;
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "更新成功"
        });
        this.close();
      });
    },
    close() {
      this.closeTag(this.$route);
      // this.$emit("on-close", undefined, undefined, this.$route);
      this.$router.push({
         name: "gamespace_gamecategory"
      });
    }
  },
  mounted() {
    GameCategoryAPI.Get(this.$route.params.id).then(res => {
      if (res.error > 0) {
        this.$Message.warning(res.Message);
        return;
      }
      this.formScope = res.Data;
    });
  }
};
</script>