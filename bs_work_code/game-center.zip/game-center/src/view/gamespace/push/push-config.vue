<template>
  <div>
    <Card title="配置" style="margin-bottom: 20px">
      <Form :label-width="250">
        <FormItem label="是否开启push：">
          <Row>
            <i-col :span="10">
              <i-switch
                v-model="formData.Status"
                size="large"
                @on-change="checkStatus"
              >
                <span slot="open">开</span>
                <span v-if="formData.Status" slot="close">关</span>
              </i-switch>
            </i-col>
          </Row>
        </FormItem>

        <FormItem label="是否开启禁止评论：">
          <Row>
            <i-col :span="10">
              <i-switch
                v-model="commentFormData.Status"
                size="large"
                @on-change="changeCommentStatus"
              >
                <span slot="open">开</span>
                <span v-if="!commentFormData.Status" slot="close">关</span>
              </i-switch>
            </i-col>
          </Row>
        </FormItem>

        <FormItem label="是否开启优惠券：">
          <Row>
            <i-col :span="10">
              <i-switch
                v-model="couponData.Status"
                size="large"
                @on-change="changeCouponStatus"
              >
                <span slot="open">开</span>
                <span v-if="!couponData.Status" slot="close">关</span>
              </i-switch>
            </i-col>
          </Row>
        </FormItem>

        <!-- <FormItem label="是否开启游戏详情页论坛Tab：">
          <Row>
            <i-col :span="10">
              <i-switch v-model="forumData.Status" size="large" @on-change="changeForumStatus">
                <span slot="open">开</span>
                <span v-if="!couponData.Status" slot="close">关</span>
              </i-switch>
            </i-col>
          </Row>
        </FormItem> -->
        <FormItem label="是否自动下发预约游戏静默安装指令:">
          <Row>
            <i-col :span="10">
              <i-switch
                v-model="direct.Status"
                size="large"
                @on-change="changeDirectStatus"
              >
                <span v-if="direct.Status" slot="open">开</span>
                <span v-else slot="close">关</span>
              </i-switch>
            </i-col>
          </Row>
        </FormItem>
        <FormItem label="是否开启积分系统:">
          <Row>
            <i-col :span="10">
              <i-switch
                v-model="Integral.Status"
                size="large"
                @on-change="changeIntegral"
              >
                <span v-if="Integral.Status" slot="open">开</span>
                <span v-else slot="close">关</span>
              </i-switch>
            </i-col>
          </Row>
        </FormItem>
        <FormItem label="是否开启小米库同步:">
          <Row>
            <i-col :span="10">
              <i-switch v-model="MiStatus" size="large" @on-change="changeMi">
                <span v-if="MiStatus" slot="open">开</span>
                <span v-else slot="close">关</span>
              </i-switch>
            </i-col>
          </Row>
        </FormItem>
      </Form>
    </Card>
  </div>
</template>

<script>
import GameAPI from "@/api/gamespace/game";
import ConfigAPI from "@/api/gamespace/globol_config";
import Tags from "@/api/gameCircle/tagsManage";
export default {
  name: "push-config",
  data() {
    return {
      formData: {
        Status: false,
      },
      commentFormData: {
        Status: false,
      },
      couponData: {
        Status: false,
      },
      // forumData: {
      //   Status : false
      // },
      direct: {
        Status: false,
      },
      Integral: {
        Status: false,
      },
      MiStatus: false,
    };
  },
  methods: {
    init() {
      this.pushStatus();
      this.getConfigStatus();
      this.initStatus(); //全局禁言初始化
      this.getIntegral();
      this.getMiStatus();
    },
    pushStatus() {
      GameAPI.PushStatus().then((res) => {
        this.formData.Status = res.Data;
      });
    },
    checkStatus() {
      GameAPI.ChangePushStatus(this.formData.Status).then((res) => {
        if (res.Code == 0) {
          this.init();
        }
      });
    },

    getConfigStatus() {
      ConfigAPI.GetConfig().then((res) => {
        this.commentFormData.Status = res.Data[1];
        this.couponData.Status = res.Data[2];
        // this.forumData.Status = res.Data[3]
      });
    },
    changeCommentStatus() {
      ConfigAPI.SetConfig(1, this.commentFormData.Status).then((res) => {
        if (res.Code == 0) {
          this.init();
        }
      });
    },
    changeCouponStatus() {
      ConfigAPI.SetConfig(2, this.couponData.Status).then((res) => {
        if (res.Code == 0) {
          this.init();
        }
      });
    },
    // changeForumStatus () {
    //   ConfigAPI.SetConfig(3, this.forumData.Status)
    //     .then(res=>{
    //       if (res.Code == 0) {
    //         this.init()
    //       }
    //     })
    // },
    changeDirectStatus(value) {
      let status = value ? 2 : 1; //1-false 2-true
      Tags.setStatus(2, status).then((res) => {
        if (res.Code == 0) {
          this.initStatus();
        }
      });
    },

    //全是否自动下发预约游戏静默安装指令初始化
    initStatus() {
      Tags.configStatus(2).then((res) => {
        this.direct.Status = res.Data.SwitchStatus == 1 ? false : true;
      });
    },
    //是否开启积分系统
    changeIntegral(value) {
      let status = value ? 1 : 0; //1-true 0-false
      ConfigAPI.setIntegral(status).then((res) => {
        if (res.Code == 0) {
          this.getIntegral();
        }
      });
    },
    getIntegral() {
      ConfigAPI.getIntegral().then((res) => {
        if (res.Code == 0) {
          this.Integral.Status = res.Data.IsOpen;
        }
      });
    },
    //是否开启小米库同步
    changeMi(value) {
      let status = value ? 1 : 0; //1-true 0-false
      ConfigAPI.setMiStatus(status).then((res) => {
        if (res.Code == 0) {
          this.getMiStatus();
        }
      });
    },
    getMiStatus() {
      ConfigAPI.getMiStatus().then((res) => {
        if (res.Code == 0) {
          this.MiStatus = res.Data.IsOpen == 1 ? true : false;
        }
      });
    },
  },

  mounted() {
    this.init();
  },
};
</script>

<style scoped>
</style>
