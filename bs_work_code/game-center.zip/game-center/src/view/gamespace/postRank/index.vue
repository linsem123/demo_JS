<template>
    <Card>
        <Row style="margin-bottom: 15px">
            榜单类型：
            <RadioGroup v-model="PoolType" type="button" @on-change="getRankListChange">
                <Radio v-for="item in rankTypeList" :label="item.id" :key="item.id">{{
          item.name
        }}</Radio>
            </RadioGroup>
        </Row>
        <div style="margin-bottom: 20px">
            <LikeSearch v-model="RankId" placeholder="请输入榜单名称" :serverData="postServerData"
                style="width: 200px; margin-right: 10px" clearable />
            <Button type="primary" @click="handleSearch">查询</Button>
        </div>
        <Table border :data="tableData" :columns="columns" :loading="loading">
            <template slot="Status" slot-scope="{ row }">
                <Tag v-if="row.Status == 1" color="success">上架</Tag>
                <Tag v-else-if="row.Status == 2" color="error">下架</Tag>
                <Tag v-else color="warning">待处理</Tag>
            </template>
            <template slot="action" slot-scope="{ row }">
                <Button type="primary" size="small" @click="handleModify(row)" style="margin-right: 5px">编辑</Button>
                <Button type="error" size="small" @click="handleUpdate(row.Id, 2)" v-show="row.Status == 1"
                    style="margin-right: 5px">下架</Button>
                <Button type="success" size="small" @click="handleUpdate(row.Id, 1)" v-show="row.Status != 1"
                    style="margin-right: 5px">上架</Button>
                <Button type="info" size="small" @click="handleJumpTo(row)">榜单帖子</Button>
            </template>
        </Table>
        <div style="margin: 10px; overflow: hidden">
            <div style="float: left">
                <Button type="info" shape="circle" icon="plus-round" @click="addNew" v-if="PoolType == 1">新增榜单</Button>
            </div>
            <div style="float: right">
                <Page :total="total" :current="Page" :page-size="Limit" :page-size-opts="[10, 20, 40, 80, 100]"
                    @on-change="onPageChange" @on-page-size-change="onPageSizechange" show-sizer show-total></Page>
            </div>
        </div>
        <Modal v-model="showModal" :title="checkedData.Id ? '编辑' : '新增'">
            <Form :label-width="100" :model="checkedData" :rules="rules" ref="formDom">
                <FormItem label="榜单名称：" prop="Title">
                    <Input v-model.trim="checkedData.Title" placeholder="" />
                </FormItem>
                <FormItem label="描述：">
                    <Input type="textarea" v-model.trim="checkedData.Desc" />
                </FormItem>
            </Form>
            <template slot="footer">
                <Button @click="showModal = false">取消</Button>
                <Button type="primary" @click="doSubmit">确定</Button>
            </template>
        </Modal>
    </Card>
</template>
<script>
    import LikeSearch from "_c/like-search";
    import serveApi from "@/api/gamespace/postRank";
    export default {
        name: "PostRank",
        components: { LikeSearch },
        data() {
            return {
                tableData: [],
                columns: [
                    {
                        title: "榜单ID",
                        key: "Id",
                        align: "center",
                        maxWidth: 100,
                    },
                    {
                        title: "榜单名称",
                        key: "Title",
                        align: "center",
                    },
                    {
                        title: "描述信息",
                        key: "Desc",
                        align: "center",
                    },
                    {
                        title: "状态",
                        slot: "Status",
                        align: "center",
                    },
                    {
                        title: "操作",
                        slot: "action",
                        align: "center",
                        maxWidth: 200,
                        width: 200,
                    },
                ],
                loading: false,
                postServerData: {
                    likeUrl: "PostRankLike",
                    likeData: {},
                    IdKey: "Id",
                    NameKey: "Title",
                },
                total: 0,
                Page: 1,
                Limit: 10,
                RankId: undefined,
                showModal: false,
                checkedData: { Title: "", Desc: "" },
                rules: {
                    Title: [
                        {
                            required: true,
                            message: "请输入帖子榜单名称",
                            trigger: "blur",
                        },
                    ],
                },
                PoolType: 1,
                rankTypeList: [
                    {
                        id: 1,
                        name: "普通榜单",
                    },
                    {
                        id: 2,
                        name: "全量视频帖",
                    },
                    {
                        id: 3,
                        name: "游戏榜单（按游戏筛选）",
                    },
                ],
            };
        },
        mounted() {
            this.searchServe();
        },
        methods: {
            //更改榜单类型
            getRankListChange() {
                this.Page = 1;
                this.searchServe();
            },
            //新增
            addNew() {
                this.showModal = true;
                this.checkedData = {
                    Title: "",
                    Desc: "",
                };
            },
            //更改榜单状态
            handleUpdate(Id, status) {
                serveApi.updateStatus(Id, status).then((res) => {
                    if (res.Code == 0) {
                        this.$Message.success("成功！");
                        this.searchServe();
                    } else {
                        this.$Message.error(res.Message);
                    }
                });
            },
            //提交
            doSubmit() {
                this.$refs.formDom.validate((valid) => {
                    if (valid) {
                        if (this.checkedData.Id) {
                            //编辑
                            serveApi.editRank(this.checkedData).then((res) => {
                                if (res.Code == 0) {
                                    this.showModal = false;
                                    this.searchServe();
                                } else {
                                    this.$Message.error(res.Message);
                                }
                            });
                        } else {
                            //新增
                            this.checkedData.ForumType = 1;
                            serveApi.addRank(this.checkedData).then((res) => {
                                if (res.Code == 0) {
                                    this.showModal = false;
                                    this.searchServe();
                                } else {
                                    this.$Message.error(res.Message);
                                }
                            });
                        }
                    }
                });
            },
            //跳转至绑定帖子列表
            handleJumpTo(row) {
                this.$router.push({
                    name: "post_rank_list",
                    params: { id: row.Id },
                    query: { title: row.Title, type: this.PoolType },
                });
            },
            //编辑
            handleModify(row) {
                this.showModal = true;
                this.checkedData = row;
            },
            onPageChange(page) {
                this.Page = page;
                this.searchServe();
            },
            onPageSizechange(size) {
                this.Page = 1;
                this.Limit = size;
                this.searchServe();
            },
            handleSearch() {
                this.Page = 1;
                this.searchServe();
            },
            searchServe() {
                this.loading = true;
                serveApi
                    .GetRankList({
                        limit: this.Limit,
                        page: this.Page,
                        params: { id: this.RankId, type: this.PoolType },
                    })
                    .then((res) => {
                        if (res.Code == 0) {
                            this.tableData = res.Data.Data || [];
                            this.total = res.Data.Count;
                        } else {
                            this.$Message.error(res.Message);
                        }
                    })
                    .finally(() => {
                        this.loading = false;
                    });
            },
        },
    };
</script>