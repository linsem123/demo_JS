<template>
  <Card>
    当前帖子榜单:{{ title }}
    <div style="margin: 20px 0">
      <LikeSearch
        v-model="PostId"
        placeholder="请输入帖子标题"
        :serverData="postServerData"
        style="width: 200px; margin-right: 10px"
        clearable
      />
      <Button type="primary" @click="handleSearch">查询</Button>
    </div>
    <Table
      border
      :data="tableData"
      :columns="columns"
      :draggable="Page == 1"
      @on-drag-drop="handleDrop"
      :loading="loading"
    >
      <template slot="PostCreatedAt" slot-scope="{ row }">
        {{ row.PostCreatedAt | filterTime }}
      </template>
      <template slot="Status" slot-scope="{ row, index }">
        <i-switch
          v-model="tableData[index].Status"
          size="large"
          :true-value="1"
          :false-value="row.Status ? 2 : 0"
          @on-change="(status) => handleSheild(status, row.Id, index)"
        >
          <span slot="open">开启</span>
          <span v-if="row.Status" slot="close">关闭</span>
          <span v-else slot="close" class="no-wrap">未处理</span>
        </i-switch>
      </template>
      <template slot="img" slot-scope="{ row }">
        <img :src="row.ImgUrl" alt="" style="width: 50px; height: 50px" />
      </template>
      <template slot="action" slot-scope="{ row }">
        <Button
          type="primary"
          size="small"
          @click="handleUpdate(row.Id, 2)"
          style="margin-right: 5px"
          v-if="row.Sort != 2"
          >置顶</Button
        >
        <Button
          v-if="row.Sort == 2"
          type="primary"
          size="small"
          @click="handleUpdate(row.Id, 1)"
          style="margin-right: 5px"
          >取消置顶</Button
        >
        <Button
          type="error"
          size="small"
          @click="handleChangeBind(row.Id, 'unbindPost')"
          style="margin-right: 5px"
          >解绑</Button
        >
        <Button type="info" size="small" @click="handleDetail(row.PostId)"
          >详情</Button
        >
      </template>
    </Table>
    <div style="margin: 10px; overflow: hidden">
      <div style="float: left">
        <Button
          type="info"
          shape="circle"
          icon="plus-round"
          @click="addNew"
          style="margin-right: 5px"
          v-if="type == 1"
          >绑定帖子</Button
        >
        <Button shape="circle" icon="plus-round" @click="handleJumpTo"
          >返回榜单管理</Button
        >
      </div>
      <div style="float: right">
        <Page
          :total="total"
          :current="Page"
          :page-size="Limit"
          :page-size-opts="[10, 20, 30, 40]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>
    </div>
    <Modal v-model="showModal" title="绑定帖子">
      <Form
        :label-width="100"
        :model="formData"
        :rules="rules"
        v-if="showModal"
      >
        <FormItem label="帖子标题：">
          <LikeSearch
            v-model="formData.PostId"
            placeholder="请输入帖子标题"
            :serverData="postServerData"
            style="width: 300px"
            clearable
            ref="likesearch"
          />
        </FormItem>
        <FormItem label="帖子ID：" prop="PostId">
          <Input
            v-model="formData.PostId"
            style="width: 300px"
            clearable
            type="number"
            @on-blur="handleBlur"
          />
        </FormItem>
        <FormItem label="图片：">
          <UploadImg v-model="formData.ImgUrl" module="gamespace"></UploadImg
        ></FormItem>
      </Form>
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button type="primary" @click="doSubmit">确定</Button>
      </template>
    </Modal>
    <Modal v-model="showDetail" title="查看" :width="700" footer-hide>
      <detailPage v-if="showDetail" :checkedTable="checkedTable" />
    </Modal>
    <wangEditor v-show="false" ref="editorPanel" />
  </Card>
</template>
<script>
import LikeSearch from "_c/like-search";
import detailPage from "@/view/gameCircle/components/detailPage";
import wangEditor from "@/view/gameCircle/components/editor/wangEditor";
import Post from "@/api/gameCircle/postManagement";
import serveApi from "@/api/gamespace/postRank";
import common from "@/view/gameCircle/pubFunc/common";
import UploadImg from "_c/shark-upload/index";
export default {
  name: "PostRank",
  components: { LikeSearch, detailPage, wangEditor, UploadImg },
  data() {
    const checkNum = (rule, value, callback) => {
      let reg = /[^\d]/g;
      if (!value || reg.test(value) || !Number(value)) {
        callback("仅支持大于0的整数");
      }
      callback();
    };
    return {
      tableData: [],
      columns: [
        {
          title: "帖子ID",
          key: "PostId",
          align: "center",
          maxWidth: 100,
        },
        {
          title: "帖子标题",
          key: "PostTitle",
          align: "center",
        },
        {
          title: "关联游戏",
          key: "AppName",
          align: "center",
        },
        {
          title: "发布帐号",
          key: "Author",
          align: "center",
        },
        {
          title: "图片",
          slot: "img",
          align: "center",
        },
        {
          title: "发帖时间",
          slot: "PostCreatedAt",
          align: "center",
        },
        {
          title: "是否启用",
          slot: "Status",
          align: "center",
        },
        {
          title: "操作",
          slot: "action",
          align: "center",
          width: 200,
        },
      ],
      postServerData: {
        likeUrl: "PostLike",
        likeData: {},
        IdKey: "Id",
        NameKey: "Title",
      },
      total: 0,
      Page: 1,
      Limit: 10,
      PostId: undefined,
      showModal: false,
      formData: {
        PostId: undefined,
        ImgUrl: "",
      },
      rules: {
        PostId: [
          {
            validator: checkNum,
            trigger: "blur",
          },
        ],
      },
      showDetail: false,
      loading: false,
    };
  },
  mounted() {
    this.searchServe();
  },
  computed: {
    RankId() {
      return Number(this.$route.params.id);
    },
    title() {
      return this.$route.query.title;
    },
    type() {
      return this.$route.query.type;
    },
  },
  filters: {
    filterTime(value) {
      if (value) return common.formatDate(value, true);
      else return "";
    },
  },
  methods: {
    //新增
    addNew() {
      this.showModal = true;
      this.formData.PostId = undefined;
      this.formData.ImgUrl = "";
    },
    //是否置顶
    handleUpdate(Id, Sort) {
      serveApi.Top(Id, Sort).then((res) => {
        if (res.Code == 0) {
          this.searchServe();
          if (Sort == 1) {
            this.$Message.success("取消置顶成功");
          } else {
            this.$Message.success("置顶成功");
          }
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //取消置顶
    handleCancelTop(Id) {},
    //提交绑定
    doSubmit() {
      if (!this.formData.PostId) {
        this.$Message.error("请输入帖子标题或帖子ID");
        return;
      }
      serveApi
        .bindPost({
          ...this.formData,
          RankId: this.RankId,
          PostId: Number(this.formData.PostId),
        })
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success("绑定成功");
            this.formData.PostId = undefined;
            this.formData.ImgUrl = "";
            this.$refs.likesearch.clearText();
            this.searchServe();
          } else {
            this.$Message.error(res.Message);
          }
        });
    },
    //跳转至榜单页面
    handleJumpTo() {
      this.$router.push({
        name: "post_rank_manage",
      });
    },
    //解绑接口调用
    handleChangeBind(ID) {
      serveApi.unbindPost(ID).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("解绑成功");
          this.searchServe();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //启用/禁用
    handleSheild(status, Id) {
      serveApi
        .changeSheild(Id, status)
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success("成功");
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.searchServe();
        });
    },
    //拖拽排序
    handleDrop(idx1, idx2) {
      let item1 = this.tableData.splice(idx1, 1);
      this.tableData.splice(idx2, 0, item1[0]);
      let Ids = this.tableData.map((v) => v.Id).reverse();

      //调用接口
      serveApi.Sort({ Ids }).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("排序成功");
          this.searchServe();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //详情
    handleDetail(postId) {
      Post.postDetails(postId).then((res) => {
        if (res.Code == 0) {
          if (res.Data.Content) {
            let content = JSON.parse(res.Data.Content);
            this.$refs.editorPanel.setEditorData(content);
            res.Data.Content = this.$refs.editorPanel.getEditorHTMLData();
            this.$refs.editorPanel.clearEditor();
          }
          this.checkedTable = Object.assign({}, res.Data);
          this.showDetail = true;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    onPageChange(page) {
      this.Page = page;
      this.searchServe();
    },
    onPageSizechange(size) {
      this.Page = 1;
      this.Limit = size;
      this.searchServe();
    },
    handleSearch() {
      this.Page = 1;
      this.searchServe();
    },
    searchServe() {
      this.loading = true;
      serveApi
        .GetPostRankList({
          limit: this.Limit,
          page: this.Page,
          params: {
            postId: this.PostId,
            rankId: this.RankId,
          },
        })
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.Data || [];
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    handleBlur() {
      Post.getPostList({
        PostId: Number(this.formData.PostId),
        ForumType: 1,
        Page: 1,
        Limit: 1,
      }).then((res) => {
        if (res.Code == 0) {
          //数据处理
          let data = res.Data.Data || [];
          let title = " ";
          if (data.length > 0) {
            title = res.Data.Data[0].Title;
          }
          // console.log(title);
          this.$refs.likesearch.setQuery({
            id: Number(this.formData.PostId),
            title: title,
          });
        }
      });
    },
  },
};
</script>
<style lang="less">
.no-wrap {
  white-space: nowrap;
  font-size: 12px;
  display: block;
  transform: scale(0.8);
  left: -5px;
  position: relative;
}
</style>