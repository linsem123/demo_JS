<template>
  <div>
    <Row>
      <Col span="4" style="padding-bottom:12px">
        <Select
          v-model="appId"
          clearable
          filterable
          remote
          :remote-method="handleGameSearch"
          placeholder="请输入游戏名称"
          @on-change="changeAppName"
          style="width: 200px"
        >
          <Option
            v-for="item in gameList"
            :value="item.ID"
            :key="item.ID"
            >{{ item.AppName }}</Option
          >
        </Select>
      </Col>
      <Col span="4" style="padding-top:12px">
        app包名：{{pkgName}}
      </Col>
      <Col span="4">
        <Button type="success" shape="circle" icon="ios-search" @click="loadList">搜索</Button>
      </Col>
    </Row>
    <Table :columns="columnsData" :data="gameTimeList" border></Table>
    <div style="margin: 10px; overflow: hidden">
        <div style="float: right">
          <Page
            :total="pageTotal"
            :current="pageIndex"
            :page-size="pageSize"
            @on-change="pageChange"
            @on-page-size-change="pageSizeChange"
            show-sizer
            show-total
          ></Page>
        </div>
    </div>
  </div>
</template>

<script>
import GameAPI from "@/api/gamespace/game";
export default {
  data(){
    return{
      columnsData: [
        {
          title: '游戏名称',
          key: 'AppName'
        },{
          title: '开始下载时间',
          key: 'CreatedAt'
        },{
          title: '下载用时',
          key: 'DownloadTime'
        },
        // 4.11 时取消MergeTime字段
        // {
        //   title: '合包用时',
        //   key: 'MergeTime'
        // },
        {
          title: '解析apk用时',
          key: 'ParseApkTime'
        },{
          title: '解析channelID用时',
          key: 'ParseChannelIdTime'
        },{
          title: '文件移动用时',
          key: 'MoveFileTime'
        },
      ],
      gameTimeList: [
      ],
      pageTotal: 0,
      pageSize: 10,
      pageIndex: 1,
      appId:'',
      pkgName: '',
      gameList:[],
    }
  },
  mounted(){
    this.loadList()
  },
  methods:{
    loadList(){
      let params = {
        Page: this.pageIndex,
        Limit: this.pageSize,
        Params:{
          AppId: this.appId
        }
      }
      GameAPI.getGameTimeList(params).then(res=>{
        if(res.Code==0){
          this.gameTimeList = res.Data.Data
          this.pageTotal = res.Data.Count
        }
      })
    },
    pageChange(value){
        this.pageIndex = value;
        this.loadList();
    },
    pageSizeChange(value){
        this.pageSize = value;
        this.pageIndex = 1;
        this.loadList();
    },
    // 获取游戏名称列表
    handleGameSearch(value){
      GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    //选择框选中游戏改变时
    changeAppName(value){
      if (value) {
        let item = this.gameList.filter((v) => v.ID == value);
        this.pkgName=  item[0].PkgName
      }else{
        this.pkgName = ''
      }
    }
  }
}
</script>

<style>

</style>