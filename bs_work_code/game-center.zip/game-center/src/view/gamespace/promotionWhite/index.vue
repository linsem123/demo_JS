<template>
  <Card style="overflow: hidden">
    <div style="padding: 10px 0">
      <Button type="primary" @click="handleAdd">添加</Button>
    </div>
    <Table :columns="columns" border :data="tableData">
      <template slot="action" slot-scope="{ row }">
        <Button @click="handleDel(row.ID)" type="error" size="small">解绑</Button>
      </template>
    </Table>
    <Modal v-model="showModal" title="添加游戏白名单">
      <Form :moel="formData" :label-width="100" ref="formDom">
        <FormItem label="游戏名称：" prop="AppId">
          <Select v-model="formData.AppId" clearable filterable remote
            :remote-method="(val) => handleGameSearch(val, true)" placeholder="请输入游戏名称" ref="formAppName"
            @on-change="(val) => changeApp(val, 'formPkgName', 'PkgName')">
            <Option v-for="item in formAppList" :value="item.ID" :key="item.ID">{{ item.AppName }}</Option>
          </Select>
        </FormItem>
        <FormItem label="游戏包名：">
          <Select v-model="formData.AppId" clearable filterable remote
            :remote-method="(val) => handlePkgSearch(val, true)" placeholder="请输入游戏包名" ref="formPkgName"
            @on-change="(val) => changeApp(val, 'formAppName', 'AppName')">
            <Option v-for="item in formAppList" :value="item.ID" :key="item.ID">{{ item.PkgName }}</Option>
          </Select>
        </FormItem>
      </Form>
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button type="primary" @click="doSubmit">确定</Button>
      </template>
    </Modal>
  </Card>
</template>
<script>
  import API from "@/api/gamespace/promotionWhite";
  import GameAPI from "@/api/gamespace/game";
  export default {
    name: "PromotionWhite",
    data() {
      return {
        AppId: undefined,
        appList: [],
        tableData: [],
        columns: [
          {
            title: "ID",
            key: "ID",
            align: "center",
            width: 80,
          },
          {
            title: "游戏名称",
            key: "AppName",
            align: "center",
          },
          {
            title: "包名",
            key: "PkgName",
            align: "center",
          },
          {
            title: "操作",
            slot: "action",
            align: "center",
            width: 100,
          },
        ],

        showModal: false,
        formAppList: [],
        formData: {
          AppId: undefined,
          AppName: "",
          PkgName: "",
        },
      };
    },
    created() {
      this.getList();
    },
    methods: {
      //游戏名/包名
      changeApp(val, refName, keys) {
        if (val) {
          console.log(val, refName, keys);
          let item;
          if (refName == "formAppName" || refName == "formPkgName") {
            item = this.formAppList.filter((v) => v.ID == val);
            this.formData.PkgName = item[0].PkgName;
            this.formData.AppName = item[0].AppName;
          } else {
            item = this.appList.filter((v) => v.ID == val);
          }
          this.$refs[refName].setQuery(item[0][keys]);
          this.$refs[refName].toggleMenu(null, false);
        } else {
          this.formData.PkgName = "";
          this.formData.AppName = "";
        }
      },
      handleGameSearch(val, isForm) {
        GameAPI.LikeAppByParams({ params: { AppName: val } }).then((res) => {
          isForm ? (this.formAppList = res.Data) : (this.appList = res.Data);
        });
      },
      handlePkgSearch(val, isForm) {
        GameAPI.LikeAppByParams({ params: { PkgName: val } }).then((res) => {
          isForm ? (this.formAppList = res.Data) : (this.appList = res.Data);
        });
      },
      handleAdd() {
        this.showModal = true;
      },
      doSubmit() {
        if (!this.formData.AppId) {
          this.$Message.error("请填写游戏名称和游戏包名");
          return;
        }
        let param = JSON.parse(JSON.stringify(this.formData));
        // param.Scene = param.Scene.join(",");
        // console.log('===', param);
        API.Add(param).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("添加成功");
            this.formData.AppId = undefined;
            // this.formData.Scene = [1, 2, 3];
            this.getList();
            this.showModal = false;
          } else {
            this.$Message.error(res.Message || "添加失败");
          }
        });
      },
      //解绑
      handleDel(id) {
        API.changeStatus(id).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("解绑成功");
            this.getList();
          } else {
            this.$Message.error(res.Message || "解绑失败");
          }
        });
      },
      getList() {
        API.GetList().then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.List || [];
          }
        });
      },
    },
  };
</script>