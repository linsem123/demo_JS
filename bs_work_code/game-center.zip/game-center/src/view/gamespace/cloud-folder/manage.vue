<template>
  <div>
    <Card>
      <Table :data="tableData" :columns="columns">
        <template slot-scope="{ row, index }" slot="RankTitle">
          <span v-show="row.RankID == 0">未绑定</span>
          <span v-show="row.RankID > 0">{{ row.RankTitle }}</span>
        </template>
        <template slot-scope="{ row, index }" slot="FolderType">
          <div v-for="(item, i) in FolderTypeList" :key="i">
            <span v-if="row.FolderType == item.ID">{{ item.Title }}</span>
          </div>
        </template>
        <template slot-scope="{ row, index }" slot="Status">
          <Tag color="success" v-if="row.Status == 1">上架</Tag>
          <Tag color="error" v-else-if="row.Status == 2">下架</Tag>
          <Tag color="warning" v-else>未处理</Tag>
        </template>
        <template slot-scope="{ row, index }" slot="Opt">
          <Button
            @click="editCloudFolder(row)"
            type="primary"
            size="small"
            style="margin-right: 10px"
            >编辑</Button
          >
          <Button
            v-if="row.Status !== 1"
            @click="updateStatus(row.ID, 1)"
            type="success"
            size="small"
            >上架</Button
          >
          <Button
            v-else
            @click="updateStatus(row.ID, 2)"
            type="error"
            size="small"
            >下架</Button
          >
        </template>
      </Table>

      <Row style="margin-top: 10px">
        <Col :span="6">
          <Button
            @click="editCloudFolder()"
            type="info"
            shape="circle"
            icon="md-add"
            >新增云文件夹</Button
          >
        </Col>
      </Row>
    </Card>

    <Modal
      v-model="visible"
      @on-visible-change="visibleChange"
      :title="formData.ID ? '编辑' : '新增'"
    >
      <Row>
        <Col :span="21">
          <Form :model="formData" :label-width="120" ref="formData">
            <FormItem label="机型：" prop="Title">
              <Input v-model="formData.Model" placeholder="请输入机型"></Input>
            </FormItem>
            <FormItem label="类型：" prop="Title">
              <Select
                v-model="formData.FolderType"
                style="width: 200px"
                clearable
              >
                <Option v-for="s in FolderTypeList" :value="s.ID">{{
                  s.Title
                }}</Option>
              </Select>
            </FormItem>
            <FormItem label="描述：" prop="Desc">
              <Input
                type="textarea"
                :rows="2"
                v-model="formData.Desc"
                placeholder="请输入描述信息"
              ></Input>
            </FormItem>
            <FormItem label="展示条数：" prop="ShowCount">
              <Input
                v-model="formData.ShowCount"
                placeholder="请输入展示条数"
              ></Input>
            </FormItem>
            <FormItem label="绑定榜单：" prop="RankID">
              <Select
                v-model="formData.RankID"
                clearable
                filterable
                remote
                :remote-method="handleRankSearch"
                placeholder="请输入榜单名称"
              >
                <Option
                  v-for="item in rankList"
                  :value="item.ID"
                  :key="item.ID"
                  >{{ item.Title }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="云文件夹名称：" prop="Desc">
              <Input
                type="textarea"
                :rows="3"
                v-model="formData.Lang"
                placeholder="请输入语言"
              ></Input>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button @click="visible = false" type="text" size="large">取消</Button>
        <Button @click="submitForm" type="primary" size="large">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";
import CloudFolderApi from "@/api/gamespace/cloudfolder";
export default {
  name: "cloud-folder-manage",
  data() {
    return {
      rankList: [],
      tableData: [],
      columns: [
        { title: "机型", key: "Model", minWidth: 150 },
        { title: "文件夹类型", slot: "FolderType", minWidth: 150 },
        { title: "描述信息", key: "Desc", minWidth: 120 },
        { title: "展示条数", key: "ShowCount", minWidth: 120 },
        { title: "绑定榜单", slot: "RankTitle", minWidth: 120 },
        { title: "状态", slot: "Status", minWidth: 80 },
        {
          title: "操作",
          slot: "Opt",
          minWidth: 130,
          align: "center",
          fixed: "right",
        },
      ],
      FolderTypeList: [
        { ID: 1, Title: "桌面文件夹" },
        { ID: 2, Title: "桌面文件夹-猜你喜欢" },
        { ID: 3, Title: "安装完成-猜你喜欢" },
        { ID: 4, Title: "全局搜索-热门应用精选" },
        { ID: 5, Title: "桌面文件夹(支持游戏混合应用)" },
      ],

      visible: false,
      formData: {
        ID: undefined,
        Model: undefined,
        FolderType: 1,
        ShowCount: undefined,
        RankID: undefined,
        Desc: "",
        Lang: "",
      },
    };
  },
  mounted() {
    this.getCloudFolderList();
  },
  methods: {
    getCloudFolderList() {
      CloudFolderApi.GetCloudFolderList().then((res) => {
        if (res.Code === 0) {
          this.tableData = res.Data || [];
        }
      });
    },

    editCloudFolder(item) {
      if (!item) {
        this.formData = {};
      } else {
        this.getRanks(item.RankID);
        this.formData.ID = item.ID;
        this.formData.Desc = item.Desc;
        this.formData.RankID = item.RankID;
        this.formData.Model = item.Model;
        this.formData.ShowCount = item.ShowCount;
        this.formData.Lang = item.Lang;
        this.formData.FolderType = item.FolderType;
      }
      this.visible = true;
    },

    submitForm() {
      this.formData.ShowCount = parseInt(this.formData.ShowCount);
      if (this.formData.ID) {
        //编辑
        CloudFolderApi.EditCloudFolder(this.formData, this.formData.ID).then(
          (res) => {
            if (res.Code === 0) {
              this.$Message.success("操作成功");
              this.visible = false;
              this.getCloudFolderList();
            } else {
              this.$Message.error(res.Message);
            }
          }
        );
      } else {
        //新增
        CloudFolderApi.AddCloudFolder(this.formData).then((res) => {
          if (res.Code === 0) {
            this.$Message.success("操作成功");
            this.visible = false;
            this.getCloudFolderList();
          } else {
            this.$Message.error(res.Message);
          }
        });
      }
    },

    handleRankSearch(value) {
      if (!parseInt(value)) {
        HomeModuleAPI.LikeRank(value).then((res) => {
          this.rankList = res.Data;
        });
      }
    },
    getRanks(id) {
      HomeModuleAPI.GetRankById(id).then((res) => {
        this.rankList = [res.Data];
      });
    },
    updateStatus(id, status) {
      CloudFolderApi.UpdateStatus(id, status).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("操作成功");
          this.getCloudFolderList();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    visibleChange(val) {
      if (!val) {
        this.formData = {
          ID: undefined,
          Model: undefined,
          ShowCount: undefined,
          RankID: undefined,
          Desc: "",
          Lang: "",
        };
      }
    },
  },
};
</script>

<style scoped>
</style>
