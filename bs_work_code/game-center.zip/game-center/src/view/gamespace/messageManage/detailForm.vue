<!--查看任务详情-->
<template>
    <Modal
        v-model="modalShow"
        title="任务详情"
        footer-hide
        @on-cancel="cancel"
    >
        <Form
            ref="form"
            :model="formData"
            :label-width="140"
        >
            <form-item label="消息组：">
                {{ formData.MessageGroup || '-' }}
            </form-item>
            <form-item label="任务名称：">
                {{ formData.TaskName || '-' }}
            </form-item>
            <form-item label="短信类型：">
                {{ formData.TaskType === 1 ? '营销短信' : '通知短信' }}
            </form-item>
            <form-item label="短信签名：">
                {{ formData.SmsSign || '-' }}
            </form-item>
            <form-item label="短信模板ID：">
                {{ formData.SmsTemplateID || '-' }}
            </form-item>
            <!-- <form-item label="短信完整内容：">
                {{ formData.messageDetail || '-' }}
            </form-item> -->
        </Form>
    </Modal>
</template>

<script>

export default {
    props:{
        modalShow: {
            type: Boolean,
            default: false,
        },
        formData: {
            type: Object,
            default: {}
        }
    },
	data() {
		return {
			
		}
    },
    methods: {
        cancel() {
            this.$emit("on-close");
        }
    },
}
</script>