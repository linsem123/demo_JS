<template>
    <Card style="overflow: hidden">
        <div style="padding: 10px 0">
            任务名称：
            <Input v-model="searchform.TaskName" placeholder="请输入任务名称" clearable style="width: 150px;margin-right: 20px"></Input>
            短信类型：
            <Selection :dataList="typeList" v-model="searchform.TaskType" :clearable="false" style="width: 100px;margin-right: 20px" />
            任务状态：
            <Selection :dataList="statusList" v-model="searchform.TaskStatus" :clearable="false" style="width: 100px;margin-right: 20px" />
    
            <Button type="primary" @click="handleSearch" style="margin-left: 10px;">查询</Button>
            <Button type="primary" style="float: right" @click="handleAdd"
            >创建任务</Button
            >
        </div>

        <Table :columns="columns" border :data="tableData">
            <template slot-scope="{ row }" slot="TaskType">
                {{ row.TaskType === 1 ? '营销短信' : '通知短信' }}
            </template>
            <template slot-scope="{ row }" slot="TaskStatus">
                {{ filterStatus(row.TaskStatus) }}
            </template>
            <template slot-scope="{ row }" slot="CreatedAt">
                {{ formatTime(row.CreatedAt) || "-" }}
            </template>
            <template slot-scope="{ row }" slot="SendAt">
                {{ formatTime(row.CreatedAt) || "-" }}
            </template>
            <template slot="action" slot-scope="{ row }">
            <Button @click="handleDetail(row)" type="primary" size="small"
                >查看</Button
            >
            </template>
        </Table>
        <div style="float: right; padding: 10px 0">
            <Page
            :total="total"
            :current="Page"
            :page-size="Limit"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
            ></Page>
        </div>

        <!-- 任务详情 -->
        <Detail :modalShow="showDetail" :formData="detailData" @on-close="closeDetail"></Detail>
        <!-- 创建任务 -->
        <TaskModel :modalShow="showTaskModal" :formData="formData" @on-success="createSuccess" @on-close-model="closeAddModel"></TaskModel>
    </Card>
  </template>
  <script>
  import Selection from "_c/Selection";
  import Detail from "./detailForm.vue";
  import { formatTime } from '@/libs/tools';
  import TaskModel from "./form.vue";

  import API from "@/api/gamespace/messageManage";
  export default {
    name: "promotion_messageManage",
    components: { Selection, Detail, TaskModel },
    data() {
      return {
        searchform: {
            TaskName: "",
            TaskType: 99,
            TaskStatus: 99
        },
        total: 0,
        Page: 1,
        Limit: 10,
        tableData: [],
        columns: [
          {
            title: "任务ID",
            key: "Id",
            align: "center",
            // fixed: "left",
            // width: 80,
          },
          {
            title: "任务名称",
            key: "TaskName",
            align: "center",
            // fixed: "left",
            // width: 180,
          },
          {
            title: "短信类型",
            slot: "TaskType",
            align: "center",
            // fixed: "left",
            // width: 100,
          },
          {
            title: "发送数",
            key: "SendNum",
            align: "center",
            // width: 100,
          },
          {
            title: "成功数",
            key: "SendSucNum",
            align: "center",
            // width: 100,
          },
          {
            title: "创建时间",
            slot: "CreatedAt",
            align: "center",
            // width: 140,
          },
          {
            title: "发送时间",
            slot: "SendAt",
            align: "center",
            // width: 140,
          },
          {
            title: "任务状态",
            slot: "TaskStatus",
            align: "center",
            // width: 100,
          },
          {
            title: "操作",
            slot: "action",
            align: "center",
            // width: 100,
            // fixed: "right"
          },
        ],
        showDetail: false,
        detailData: {},
        typeList: [
            {
                Id: 99,
                Name: "全部"
            },
            {
                Id: 1,
                Name: "营销短信"
            },
            {
                Id: 2,
                Name: "通知短信"
            },
        ],
        statusList: [
            {
                Id: 99,
                Name: "全部"
            },
            {
                Id: 1,
                Name: "已完成"
            },
            {
                Id: 0,
                Name: "待执行"
            },
            {
                Id: 2,
                Name: "已取消"
            },
        ],
        showTaskModal: false,
        formData: {}
      };
    },
    mounted() {
        this.getList();
    },
    methods: {
        handleSearch() {
            this.Page = 1;
            this.getList();
        },
        getList() {
            let params = JSON.parse(JSON.stringify(this.searchform));
            if(params.TaskType == 99) {
                params.TaskType = undefined;
            }
            if(params.TaskStatus == 99) {
                params.TaskStatus = undefined;
            }
            API.GetList(this.Page, this.Limit, params).then((res) => {
                if (res.Code == 0) {
                    this.total = res.Data.Count;
                    this.tableData = res.Data.Data || [];
                }
            });
        },
        handleAdd() {
            this.formData = {
                MessageGroup: null,
                TaskName: null,
                TaskType: 1,
                SmsSign: null,
                SmsTemplateID: null,
                TargetUser: 1,
                UserGroupId: null, // TargetUser = 1 的时候传
                file: null, // TargetUser = 2 的时候传
                Mobile: null, // TargetUser = 3 的时候传
            },
            this.showTaskModal = true;
        },
        createSuccess() {
            this.showTaskModal = false;
            this.Page = 1;
            this.getList();
        },
        closeAddModel() {
            this.showTaskModal = false;
        },
        handleDetail(row) {
            this.showDetail = true;
            this.detailData = row;
        },
        closeDetail() {
            this.showDetail = false;
        },
        onPageChange(value) {
            this.Page = value;
            this.getList();
        },
        onPageSizechange(value) {
            this.Limit = value;
            this.Page = 1;
            this.getList();
        },
        formatTime,
        filterStatus(value) {
            let index = this.statusList.findIndex((v) => v.Id == value);
            return index > -1 ? this.statusList[index].Name : "-";
        },
    },
  };
  </script>