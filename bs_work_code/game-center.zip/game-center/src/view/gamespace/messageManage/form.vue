<template>
	<div>
		<Modal
			v-model="modalShow"
			title="创建短信发送任务"
			@on-cancel="modalCancel"
			:mask-closable="false"
		>
			<Form
				ref="formData"
				:model="formData"
				label-position="right"
				:label-width="120"
				:rules="rules"
            >
				<FormItem
					label="消息组："
					prop="MessageGroup"
				>
					<Input
						v-model="formData.MessageGroup"
						placeholder="请输入消息组"
					></Input>
                </FormItem>
                <FormItem
					label="任务名称："
					prop="TaskName"
				>
					<Input
						v-model="formData.TaskName"
						placeholder="请输入任务名称"
					></Input>
                </FormItem>
                <FormItem
					label="短信类型："
                    prop="TaskType"
                    required
				>
                    <RadioGroup v-model="formData.TaskType">
                        <Radio :label="1">
                          <span>营销短信</span>
                        </Radio>
                    </RadioGroup>
                </FormItem>
                <FormItem
					label="短信签名："
					prop="SmsSign"
				>
					<Input
						v-model="formData.SmsSign"
						placeholder="请输入短信签名"
					></Input>
                </FormItem>
                <FormItem
					label="短信模板ID："
					prop="SmsTemplateID"
				>
					<Input
						v-model="formData.SmsTemplateID"
						placeholder="请输入短信模板ID"
					></Input>
                </FormItem>
                <FormItem
					label="目标用户："
					prop="TargetUser"
				>
                    <RadioGroup v-model="formData.TargetUser">
                        <Radio :label="1">
                            <span>用户群</span>
                        </Radio>
                        <Radio :label="2">
                            <span>上传文件</span>
                        </Radio>
                        <Radio :label="3">
                            <span>手动输入</span>
                        </Radio>
                    </RadioGroup>
                </FormItem>
                <FormItem
                    v-if="formData.TargetUser === 1"
					label="用户群ID："
					prop="UserGroupId"
				>
					<Input
						v-model="formData.UserGroupId"
						placeholder="请输入用户群ID"
					></Input>
                </FormItem>
                <FormItem
                    v-if="formData.TargetUser === 2"
					label="上传文件："
					prop="file"
				>
                    <Upload
                        action="/"
                        :before-upload="handleUpload"
                        style="display: inline-block;"
                    >
                        <Button type="primary" ghost icon="md-cloud-upload">{{ formData.file ? '重新上传' : '上传' }}</Button>
                        <span v-if="formData.file" style="margin-left: 5px">{{ formData.file.name }}</span>
                    </Upload>
                    <div>最多支持上传100万条手机号，请上传50MB以内.csv、.xlsx格式</div>
                </FormItem>
                <FormItem
                    v-if="formData.TargetUser === 3"
					label="手动输入："
					prop="Mobile"
				>
                    <Input
                        v-model="formData.Mobile"
                        type="textarea"
                        :autosize="{ minRows: 4, maxRows: 20 }"
                        placeholder="请输入目标用户"
                    ></Input>
                    <div>最多可输入100个11位手机号。手机号请使用英文,或换行符分隔</div>
                </FormItem>
                <Divider dashed><span style="font-size: 12px">可发送测试短信确认触达效果</span></Divider>
                <FormItem
                    label="测试手机号："
                >
                    <Row>
                        <Col :span="16">
                            <Input
                                v-model="testPhone"
                                placeholder="多个手机号，请用英文,分隔"
                            ></Input>
                        </Col>
                        <Col :span="6">
                            <Button style="margin-left: 5px" @click="sendTest">发送</Button>
                        </Col>
                    </Row>
                </FormItem>
                <Divider dashed></Divider>
			</Form>
			<div slot="footer">
				<Button
					type="text"
					size="large"
					@click="modalCancel"
				>取消</Button>
				<Button
					type="primary"
					size="large"
					@click="addTask"
					:loading="submitting"
				>创建任务</Button>
			</div>
		</Modal>
	</div>
</template>
<script>
    import API from "@/api/gamespace/messageManage";
    import { getSuffix } from "@/libs/tools";
    export default {
        name: 'form',
        props: {
            modalShow: {
                type: Boolean,
                default: false,
            },
            formData: {
                type: Object,
            },
        },
        data() {
            return {
                show: false,
                submitting: false,
                testPhone: "",
                rules: {
                    MessageGroup: [
                        {
                            required: true,
                            message: '消息组不能为空',
                            trigger: 'blur',
                        },
                    ],
                    TaskName: [
                        {
                            required: true,
                            message: '任务名称不能为空',
                            trigger: 'blur',
                        },
                    ],
                    SmsSign: [
                        {
                            required: true,
                            message: '短信签名不能为空',
                            trigger: 'blur',
                        },
                    ],
                    SmsTemplateID: [
                        {
                            required: true,
                            message: '短信模板ID不能为空',
                            trigger: 'blur',
                        },
                    ],
                    // UserGroupId: [
                    //     {
                    //         required: this.formData.TargetUser === 1,
                    //         message: '用户群ID不能为空',
                    //         trigger: 'blur',
                    //     },
                    // ],
                    // file: [
                    //     {
                    //         required: this.formData.TargetUser === 2,
                    //         message: '请上传文件',
                    //         trigger: 'blur',
                    //     },
                    // ],
                    // Mobile: [
                    //     {
                    //         required: this.formData.TargetUser === 3,
                    //         message: '输入内容不能为空',
                    //         trigger: 'blur',
                    //     },
                    // ],
                }
            }
        },
        watch: {
            modalShow(val) {
                this.testPhone = "";
            }
        },
        methods: {
            modalCancel() {
                this.$refs["formData"].resetFields();
                this.$emit('on-close-model');
            },
            sendTest() {
                if(!this.testPhone) {
                    this.$Message.error("请输入手机号！");
                    return;
                }
                if(!this.formData.MessageGroup) {
                    this.$Message.error("请先输入消息组！");
                    return;
                }
                if(!this.formData.SmsSign) {
                    this.$Message.error("请先输入短信签名！");
                    return;
                }
                if(!this.formData.SmsTemplateID) {
                    this.$Message.error("请先输入短信模板ID！");
                    return;
                }
                let formData = JSON.parse(JSON.stringify(this.formData));
                let formatForm = new FormData();
                formatForm.append("MessageGroup", formData.MessageGroup.replace(/\s/g,""));
                formatForm.append("SmsSign", formData.SmsSign.replace(/\s/g,""));
                formatForm.append("SmsTemplateID", formData.SmsTemplateID.replace(/\s/g,""));
                formatForm.append("TestMobile", this.testPhone.replace(/\s/g,""));
                // let params = {
                //     MessageGroup: this.formData.MessageGroup,
                //     SmsSign: this.formData.SmsSign,
                //     SmsTemplateID: this.formData.SmsTemplateID,
                //     TestMobile: this.testPhone
                // }
                API.TestSmsSend(formatForm).then(res => {
                    if (res.Code === 0) {
                        this.$Message.success('已发送!');
                    } else {
                        this.$Message.error(res.Message);
                    }
                })
            },
            addTask() {
                this.$refs['formData'].validate(valid => {
                    if (valid) {
                        this.submitting = true;
                        let formData = JSON.parse(JSON.stringify(this.formData));
                        let formatForm = new FormData();
                        formatForm.append("MessageGroup", formData.MessageGroup.replace(/\s/g,""));
                        formatForm.append("TaskName", formData.TaskName);
                        formatForm.append("TaskType", formData.TaskType);
                        formatForm.append("SmsSign", formData.SmsSign.replace(/\s/g,""));
                        formatForm.append("SmsTemplateID", formData.SmsTemplateID.replace(/\s/g,""));
                        formatForm.append("TargetUser", formData.TargetUser);

                        // let params = {
                        //     MessageGroup: this.formData.MessageGroup,
                        //     TaskName: this.formData.TaskName,
                        //     TaskType: this.formData.TaskType,
                        //     SmsSign: this.formData.SmsSign,
                        //     SmsTemplateID: this.formData.SmsTemplateID,
                        //     TargetUser: this.formData.TargetUser
                        // }
                        // this.formData.UserGroupId = 26;
                        
                        if(this.formData.TargetUser === 1) {
                            // params.UserGroupId = this.formData.UserGroupId;
                            formatForm.append("UserGroupId", this.formData.UserGroupId);
                        }
                        if(this.formData.TargetUser === 2) {
                            // params.file = this.formData.file;
                            formatForm.append("file", this.formData.file);
                        }
                        if(this.formData.TargetUser === 3) {
                            // params.Mobile = this.formData.Mobile;
                            formatForm.append("Mobile", this.formData.Mobile);
                        }
                        API.CreateTask(formatForm).then(res => {
                            if (res.Code === 0) {
                                this.$Message.success(res.Message);
                                this.submitting = false;
                                this.$refs["formData"].resetFields();
                                this.$emit('on-success');
                            } else {
                                this.submitting = false;
                                this.$Message.error(res.Message);
                            }
                        });
                    }
                })
            },
            handleUpload(file) {
                // 校验上传文件格式
                const nameSuffix = getSuffix(file.name);
                if(nameSuffix != "xlsx" && nameSuffix != "csv") {
                    this.$Message.error("请上传.csv、.xlsx格式！");
                    return false;
                }
                // 校验文件大小
                if(file.size / 1024 / 1024 > 50) {
                    this.$Message.error("文件大小不超过50MB！");
                    return false;
                }
                this.formData.file = file;
                return false;
            },
        },
    }
</script>