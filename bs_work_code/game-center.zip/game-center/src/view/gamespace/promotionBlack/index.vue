<template>
  <Card style="overflow: hidden">
    <div style="padding: 10px 0">
      <Select
        v-model="AppId"
        clearable
        filterable
        remote
        :remote-method="(val) => handleGameSearch(val)"
        placeholder="请输入游戏名称"
        ref="searchAppName"
        style="width: 200px; margin-right: 10px"
        @on-change="(val) => changeApp(val, 'searchPkgName', 'PkgName')"
      >
        <Option v-for="item in appList" :value="item.ID" :key="item.ID">{{
          item.AppName
        }}</Option>
      </Select>
      <Select
        v-model="AppId"
        clearable
        filterable
        remote
        :remote-method="(val) => handlePkgSearch(val)"
        placeholder="请输入游戏包名"
        ref="searchPkgName"
        style="width: 200px; margin-right: 10px"
        @on-change="(val) => changeApp(val, 'searchAppName', 'AppName')"
      >
        <Option v-for="item in appList" :value="item.ID" :key="item.ID">{{
          item.PkgName
        }}</Option>
      </Select>

      <Button type="primary" @click="handleSearch">查询</Button>
      <Button type="primary" style="float: right" @click="handleAdd"
        >添加</Button
      >
    </div>
    <Table :columns="columns" border :data="tableData">
      <template slot="Status" slot-scope="{ row }">
        {{ ["待处理", "上架", "下架", "预约"][row.AppStatus] }}
      </template>
      <template slot="Scene" slot-scope="{ row }">
        {{ row.Scene | filterScene }}
      </template>
      <template slot="action" slot-scope="{ row }">
        <Button @click="handleDel(row.ID)" type="error" size="small"
          >解除屏蔽</Button
        >
      </template>
    </Table>
    <div style="float: right; padding: 10px 0">
      <Page
        :total="total"
        :current="Page"
        :page-size="Limit"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizechange"
        show-sizer
        show-total
      ></Page>
    </div>
    <Modal v-model="showModal" title="添加游戏黑名单">
      <Form :moel="formData" :label-width="100" ref="formDom">
        <FormItem label="游戏名称：" prop="AppId">
          <Select
            v-model="formData.AppId"
            clearable
            filterable
            remote
            :remote-method="(val) => handleGameSearch(val, true)"
            placeholder="请输入游戏名称"
            ref="formAppName"
            @on-change="(val) => changeApp(val, 'formPkgName', 'PkgName')"
          >
            <Option
              v-for="item in formAppList"
              :value="item.ID"
              :key="item.ID"
              >{{ item.AppName }}</Option
            >
          </Select>
        </FormItem>
        <FormItem label="游戏包名：">
          <Select
            v-model="formData.AppId"
            clearable
            filterable
            remote
            :remote-method="(val) => handlePkgSearch(val, true)"
            placeholder="请输入游戏包名"
            ref="formPkgName"
            @on-change="(val) => changeApp(val, 'formAppName', 'AppName')"
          >
            <Option
              v-for="item in formAppList"
              :value="item.ID"
              :key="item.ID"
              >{{ item.PkgName }}</Option
            >
          </Select>
        </FormItem>
        <FormItem label="屏蔽场景：" prop="Scene">
          <CheckboxGroup v-model="formData.Scene">
            <Checkbox
              v-for="item of sceneList"
              :key="item.value"
              :label="item.value"
              >{{ item.label }}</Checkbox
            >
          </CheckboxGroup>
        </FormItem>
      </Form>
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button type="primary" @click="doSubmit">确定</Button>
      </template>
    </Modal>
  </Card>
</template>
<script>
import API from "@/api/gamespace/promotionBlack";
import GameAPI from "@/api/gamespace/game";
export default {
  name: "PromotionBlack",
  data() {
    return {
      AppId: undefined,
      appList: [],
      tableData: [],
      columns: [
        {
          title: "ID",
          key: "ID",
          align: "center",
          width: 80,
        },
        {
          title: "游戏名称",
          key: "AppName",
          align: "center",
        },
        {
          title: "包名",
          key: "PkgName",
          align: "center",
        },
        {
          title: "游戏状态",
          slot: "Status",
          align: "center",
          width: 100,
        },
        {
          title: "屏蔽场景",
          slot: "Scene",
          align: "center",
        },
        {
          title: "操作",
          slot: "action",
          align: "center",
          width: 100,
        },
      ],
      total: 0,
      Page: 1,
      Limit: 10,

      showModal: false,
      formAppList: [],
      formData: {
        AppId: undefined,
        Scene: [1, 2, 3],
        PkgName: "",
        Status: 1,
      },
      sceneList: [
        {
          value: 1,
          label: "搜索联想",
        },
        {
          value: 2,
          label: "搜索结果页",
        },
        {
          value: 3,
          label: "排行榜",
        },
      ],
    };
  },
  created() {
    this.getList();
  },
  filters: {
    filterScene(val) {
      if (val) {
        let arr = ["", "搜索联想", "搜索结果页", "排行榜"];
        val = val.split(",");
        return val
          .map((scene) => {
            return arr[Number(scene)];
          })
          .join(",");
      }
      return "";
    },
  },
  methods: {
    //游戏名/包名
    changeApp(val, refName, keys) {
      if (val) {
        let item;
        if (refName == "formAppName" || refName == "formPkgName") {
          item = this.formAppList.filter((v) => v.ID == val);
          this.formData.PkgName = item[0].PkgName;
        } else {
          item = this.appList.filter((v) => v.ID == val);
        }
        this.$refs[refName].setQuery(item[0][keys]);
        this.$refs[refName].toggleMenu(null, false);
      } else {
        this.formData.PkgName = "";
      }
    },
    handleGameSearch(val, isForm) {
      GameAPI.LikeAppByParams({ params: { AppName: val } }).then((res) => {
        isForm ? (this.formAppList = res.Data) : (this.appList = res.Data);
      });
    },
    handlePkgSearch(val, isForm) {
      GameAPI.LikeAppByParams({ params: { PkgName: val } }).then((res) => {
        isForm ? (this.formAppList = res.Data) : (this.appList = res.Data);
      });
    },
    handleAdd() {
      this.showModal = true;
    },
    doSubmit() {
      if (!this.formData.AppId) {
        this.$Message.error("请填写游戏名称和游戏包名");
        return;
      }
      let param = JSON.parse(JSON.stringify(this.formData));
      param.Scene = param.Scene.join(",");
      API.Add(param).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("添加成功");
          this.formData.AppId = undefined;
          this.formData.Scene = [1, 2, 3];
          this.getList();
          this.showModal = false;
        } else {
          this.$Message.error(res.Message || "添加失败");
        }
      });
    },
    //解除屏蔽
    handleDel(id) {
      API.changeStatus(id, 2).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("解除成功");
          this.getList();
        } else {
          this.$Message.error(res.Message || "解除失败");
        }
      });
    },
    onPageChange(value) {
      this.Page = value;
      this.getList();
    },
    onPageSizechange(value) {
      this.Limit = value;
      this.Page = 1;
      this.getList();
    },
    handleSearch() {
      this.Page = 1;
      this.getList();
    },
    getList() {
      API.GetList({
        Page: this.Page,
        Limit: this.Limit,
        Params: { AppId: this.AppId },
      }).then((res) => {
        if (res.Code == 0) {
          this.total = res.Data.Count;
          this.tableData = res.Data.Data;
        }
      });
    },
  },
};
</script>