<!--首页配置模板数据的列表-->
<template>
  <Card dis-hover>
    <div style="margin: 10px">
      <Row :gutter="10">
        <Col span="5">
          <Select
            v-model="searchform.params.id"
            clearable
            filterable
            remote
            :remote-method="handleCollectionSearch"
            placeholder="请输入合集名称"
          >
            <Option
              v-for="item in collectionList"
              :value="item.ID"
              :key="item.ID"
              >{{ item.Name }}</Option
            >
          </Select>
        </Col>
        <Col span="6">
          <Button
            type="success"
            shape="circle"
            icon="ios-search"
            @click="searchList"
            >搜索</Button
          >
        </Col>
      </Row>
    </div>
    <Table :data="tableData" :columns="columns" border>
      <template slot-scope="{ row }" slot="status">
        <Tag v-if="row.Status == 1" color="success">上架</Tag>
        <Tag v-if="row.Status == 2" color="error">下架</Tag>
        <Tag v-if="row.Status == 0" color="warning">初始化</Tag>
      </template>
      <template slot-scope="{ row }" slot="opt">
        <Button
          type="primary"
          size="small"
          @click="edit(row)"
          style="margin-right: 8px"
          >编辑</Button
        >
        <Button
          @click="changeStatus(row, 2)"
          type="error"
          v-if="row.Status == 1"
          size="small"
          >下架</Button
        >
        <Button @click="changeStatus(row, 1)" type="success" v-else size="small"
          >上架</Button
        >

        <Button
          @click="toDrag(row)"
          size="small"
          type="primary"
          ghost
          style="margin-left: 8px"
          >内容管理</Button
        >
      </template>
    </Table>

    <Row style="margin-top: 20px">
      <i-col :span="4">
        <Button @click="add" type="success" icon="md-add" shape="circle"
          >新增</Button
        >
      </i-col>
      <i-col :span="20" align="right">
        <Page
          :total="page.total"
          :current="page.current"
          :page-size="page.size"
          :page-size-opts="[10, 20, 40, 80, 100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </i-col>
    </Row>

    <Modal
      v-model="visible"
      :title="formData.ID ? '编辑' : '新增'"
      :loading="loading"
      @on-ok="handleSub"
    >
      <Form ref="form" :model="formData" :rules="rules" :label-width="130">
        <Row>
          <i-col :span="21">
            <FormItem label="合辑名称：" prop="Name">
              <Input
                v-model="formData.Name"
                placeholder="请输入合辑名称"
              ></Input>
            </FormItem>
            <FormItem label="描述：" prop="Desc">
              <Input v-model="formData.Desc" type="textarea"></Input>
            </FormItem>
            <FormItem label="上传底图：">
              <UploadImg v-model="formData.BackgroundImage" />
            </FormItem>
            <FormItem label="配置底色：">
              <ColorPicker v-model="formData.BackgroundColor" />
            </FormItem>
          </i-col>
        </Row>
      </Form>
    </Modal>
  </Card>
</template>

<script>
import HomeModuleApi from "@/api/gamespace/homemodule";
import UploadImg from "_c/shark-upload/index";
export default {
  name: "List",
  components: { UploadImg },
  data() {
    return {
      searchform: {
        params: {
          id: undefined,
        },
      },
      collectionList: [],
      page: {
        current: 1,
        size: 10,
        total: 0,
      },

      tableData: [],
      columns: [
        { title: "ID", key: "ID", width: 80 },
        { title: "合辑名称", key: "Name", minWidth: 150 },
        { title: "描述", key: "Desc", minWidth: 150 },
        { title: "状态", slot: "status", minWidth: 100 },
        { title: "操作", slot: "opt", minWidth: 130 },
      ],

      visible: false,
      formData: {
        BackgroundColor: "",
      },
      loading: true,
      rules: {
        Name: [{ required: true, message: "请输入合辑名称", trigger: "blur" }],
      },
    };
  },
  mounted() {
    this.getList();
  },
  methods: {
    onPageChange(value) {
      this.page.current = value;
      this.getList();
    },
    onPageSizechange(value) {
      this.page.size = value;
      this.getList();
    },
    handleCollectionSearch(value) {
      if (!value) return;
      HomeModuleApi.moduleTypes(value, 0).then((res) => {
        if (res.Code === 0) {
          this.collectionList = res.Data || [];
        }
      });
    },
    searchList() {
      this.page.current = 1;
      this.getList();
    },
    getList() {
      let p = {
        Limit: this.page.size,
        Page: this.page.current,
        Params: {
          ID: this.searchform.params.id,
        },
      };
      HomeModuleApi.CollectionList(p).then((res) => {
        if (res.Code === 0) {
          this.tableData = res.Data.Data || [];
          this.page.total = res.Data.Count;
        }
      });
    },

    add() {
      this.formData = {};
      this.visible = true;
    },

    edit(row) {
      this.formData = JSON.parse(JSON.stringify(row));
      this.visible = true;
    },

    submitForm() {
      if (this.formData.ID) {
        return HomeModuleApi.EditCollection(this.formData);
      } else {
        return HomeModuleApi.AddCollection(this.formData);
      }
    },

    handleSub() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.submitForm().then((res) => {
            if (res.Code === 0) {
              this.visible = false;
              this.getList();
              this.$Message.success("操作成功");
            } else {
              this.$Message.error(res.Message);
              this.loading = false;
              this.$nextTick(() => (this.loading = true));
            }
          });
        } else {
          this.loading = false;
          this.$nextTick(() => (this.loading = true));
        }
      });
    },

    changeStatus(row, status) {
      HomeModuleApi.CollectionStatus(row.ID, status).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("更新成功");
        }
        this.getList();
      });
    },

    toDrag(row) {
      this.$router.push({
        name: "gamespace_activity_home_index",
        params: {
          id: row.ID,
        },
      });
    },
  },
};
</script>

<style scoped>
</style>
