<template>
  <div style="height: 100%">
    <Row :gutter="15" style="height: 100%">
      <i-col :span="8" style="position: relative">
        <div class="submit-box" ref="subbox">
          <Row :gutter="20">
            <i-col :span="9">
              <Button @click="back" type="default" long>返回</Button>
            </i-col>
            <i-col :span="15">
              <Button @click="submitHomeData" type="primary" long>保存</Button>
            </i-col>
          </Row>
          <Row :gutter="20">
            <Input
              @on-change="modelSearch"
              v-model="searchVal"
              style="margin-top: 10px; width: 100%; margin-left: 10px"
            ></Input>
          </Row>
        </div>
        <div
          class="index-cont left-index-cont"
          ref="leftcont"
          style="margin-top: 40px"
        >
          <draggable
            id="dropBox1"
            class="drop-box1"
            :options="options"
            :value="moduleListCopy"
            @input="handleListChange($event, 'left')"
            @end="handleEnd($event, 'left')"
          >
            <div
              class="drag-list-item left-item"
              :class="'model-type-' + item.ModelType"
              v-for="(item, index) in moduleListCopy"
              :key="`drag_li1_${index}`"
            >
              {{ item.Name }}
            </div>
          </draggable>

          <!--          <div style="text-align: center; margin-bottom: 15px;">-->
          <!--            <Button v-if="hasMore" type="default" @click="getModules()">加载更多</Button>-->
          <!--            <p v-else>暂无更多</p>-->
          <!--          </div>-->
        </div>
      </i-col>

      <i-col :span="16">
        <div class="index-cont right-index-cont" :class="className">
          <draggable
            id="dropBox2"
            class="drop-box2"
            :options="options"
            :value="list2"
            @input="handleListChange($event, 'right')"
            @end="handleEnd($event, 'right')"
          >
            <div
              class="drag-list-item"
              :class="
                'model-type-' +
                item.ModelType +
                ' ' +
                'model-sort-' +
                item.BannerSortType
              "
              v-for="(item, index) in list2"
              :key="`drag_li2_${index}`"
            >
              <div class="opt-box">
                <!-- 27模块类型不可设置元素 -->
                <Button
                  @click="toSetting(item)"
                  size="small"
                  type="primary"
                  :disabled="[27, 33].includes(item.ModelType)"
                  >设置</Button
                >
              </div>

              <!--轮播大图-->
              <!-- <div v-if="item.ModelType == 1" class="banner-wrap wrap">
                轮播大图 - {{ item.Name }}
              </div> -->
              <!--轮播中图-->
              <!-- <div v-if="item.ModelType == 15" class="banner-wrap wrap">
                轮播中图 - {{ item.Name }}
              </div> -->

              <!--大图-->
              <div v-if="item.ModelType == 2" class="bigimg-wrap wrap">
                <!--纵向-->
                <div v-if="item.BannerSortType == 2" class="bigimg-v">
                  <div style="line-height: 40px">
                    大图纵向 - {{ item.Name }} - 1
                  </div>
                  <div style="line-height: 40px">
                    大图纵向 - {{ item.Name }} - 2
                  </div>
                </div>
                <!--横向-->
                <div v-else class="bigimg-h">
                  <div>大图横向 - {{ item.Name }}</div>
                </div>
              </div>

              <!--中图-->
              <!-- <div v-if="item.ModelType == 3" class="miding-wrap wrap">
                <div>中图 - {{ item.Name }}</div>
              </div> -->

              <!--小图-->
              <!-- <div v-if="item.ModelType == 4" class="small-wrap wrap">
                <div>小图 - {{ item.Name }}</div>
              </div> -->

              <!--榜单，游戏列表-->
              <div
                v-if="item.ModelType == 5"
                class="list-wrap wrap"
                :class="{
                  'list-wrap-v': item.BannerSortType == 2,
                  'list-wrap-h': item.BannerSortType == 1,
                }"
              >
                <div v-if="item.BannerSortType == 2">
                  榜单纵向 - {{ item.Name }}
                </div>
                <div v-if="item.BannerSortType == 1">
                  榜单横向 - {{ item.Name }}
                </div>
              </div>
              <!--游戏视频-->
              <div v-if="item.ModelType == 6" class="video-wrap wrap">
                <div v-if="item.BannerSortType == 2">
                  视频纵向 - {{ item.Name }}
                </div>
                <div v-if="item.BannerSortType == 1">
                  视频横向 - {{ item.Name }}
                </div>
              </div>
              <!--榜单，游戏列表-->
              <div
                v-if="item.ModelType == 7"
                class="list-wrap wrap"
                :class="{
                  'list-wrap-v': item.BannerSortType == 2,
                  'list-wrap-h': item.BannerSortType == 1,
                }"
              >
                <div v-if="item.BannerSortType == 2">
                  专题纵向 - {{ item.Name }}
                </div>
                <div v-if="item.BannerSortType == 1">
                  专题横向 - {{ item.Name }}
                </div>
              </div>

              <!--Tab列表-->
              <!-- <div v-if="item.ModelType == 8" class="tab-wrap wrap">
                <div>Tab列表 - {{ item.Name }}</div>
              </div> -->
              <!--游戏列表（带图）-->
              <!-- <div v-if="item.ModelType == 19" class="list-wrap wrap">
                <div>游戏列表（带图） - {{ item.Name }}</div>
              </div>
              <div v-if="item.ModelType == 20" class="tab-wrap wrap">
                <div>顶部大卡 - {{ item.Name }}</div>
              </div>
              <div v-if="item.ModelType == 21" class="tab-wrap wrap">
                <div>轮播图2 - {{ item.Name }}</div>
              </div>
              <div v-if="item.ModelType == 22" class="tab-wrap wrap">
                <div>单游戏推荐 - {{ item.Name }}</div>
              </div>
              <div v-if="item.ModelType == 23" class="tab-wrap wrap">
                <div>活动内容 - {{ item.Name }}</div>
              </div>
              <div v-if="item.ModelType == 24" class="tab-wrap wrap">
                <div>轮播小图 - {{ item.Name }}</div>
              </div>
              <div v-if="item.ModelType == 25" class="tab-wrap wrap">
                <div>内容轮播图 - {{ item.Name }}</div>
              </div>
              <div v-if="item.ModelType == 27" class="tab-wrap wrap">
                <div>热门圈子 - {{ item.Name }}</div>
              </div> -->
              <div
                v-if="
                  typeList.filter((v) => v.value == item.ModelType).length > 0
                "
                class="tab-wrap wrap"
              >
                <div>
                  {{ typeList.find((v) => v.value == item.ModelType).label }}
                  -
                  {{ item.Name }}
                </div>
              </div>
            </div>
          </draggable>
        </div>
      </i-col>
    </Row>
  </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";
import { on, off } from "@/libs/tools";
import draggable from "vuedraggable";

export default {
  name: "",
  components: {
    draggable,
  },
  data() {
    return {
      page: {
        current: 1,
        size: 20,
      },
      hasMore: true,
      scrollHeight: 300,
      moduleList: [],
      moduleListCopy: [],
      searchVal: "",
      moduleVisible: false,

      options: { group: "drag_list" },
      list2: [],

      // 内容类型ModelType
      typeList: [
        { value: 1, label: "轮播大图" },
        { value: 15, label: "轮播中图" },
        { value: 3, label: "中图" },
        { value: 4, label: "小图" },
        { value: 8, label: "Tab列表" },
        { value: 19, label: "游戏列表（带图）" },
        { value: 20, label: "顶部大卡" },
        { value: 21, label: "轮播图2" },
        { value: 22, label: "单游戏推荐位" },
        { value: 23, label: "活动内容" },
        { value: 24, label: "轮播小图" },
        { value: 25, label: "内容轮播图" },
        { value: 26, label: "已关注圈子" }, //4.7迭代新增
        { value: 27, label: "热门圈子" }, //4.7迭代新增
        { value: 28, label: "多小图" }, //4.7迭代新增
        { value: 29, label: "圈子信息流" }, //4.7迭代新增
        { value: 30, label: "图文资讯" }, //4.7迭代新增
        { value: 31, label: "自定义话题" }, //4.9迭代新增
        { value: 32, label: "父模块" }, //4.9迭代新增
        { value: 33, label: "视频贴模块" }, //4.10迭代新增
      ],

      container: null,
      collectionId: parseInt(this.$route.params.id),
      className: "shu-ban",
    };
  },
  created() {
    // 特殊定制：横版，其他都是竖版
    if (this.collectionId === 10) {
      this.className = "heng-ban";
    }
  },
  mounted() {
    this.getModules();
    this.getHomeData();

    this.container = document.querySelector(".content-wrapper");
    on(this.container, "scroll", this.handleScroll);

    setTimeout(() => {
      let outhei = document.querySelector(".content-wrapper").clientHeight - 36;
      this.$refs.leftcont.style.height = outhei + "px";
      document.getElementById("dropBox2").style.minHeight = outhei - 20 + "px";
    }, 500);
  },
  beforeDestroy() {
    off(this.container, "scroll", this.handleScroll);
  },
  methods: {
    // 获取可以使用的模块
    getModules() {
      HomeModuleAPI.GetModelByStatus(this.collectionId).then((res) => {
        if (res.Code === 0) {
          this.moduleList = res.Data || [];
          this.moduleListCopy = res.Data || [];
        } else {
          this.$Message.error(res.Message);
        }
        this.moduleVisible = true;
      });
    },
    modelSearch() {
      if (!this.searchVal) {
        this.moduleListCopy = JSON.parse(JSON.stringify(this.moduleList));
        return;
      }
      let res = [];
      this.moduleList.forEach((m) => {
        if (m.Name.indexOf(this.searchVal) >= 0) {
          res.push(m);
        }
      });
      this.moduleListCopy = res;
      console.log(res);
    },

    handleChange(value, type) {
      console.log("change");
      console.log(value);
      console.log(type);
    },
    handleRemove(value, type) {
      console.log("remove");
      console.log(value);
    },

    handleListChange(value, type) {
      console.log("input");
      if (type === "right") {
        console.log(value);
        this.list2 = value;
      } else if (type === "left") {
        this.moduleListCopy = value;
      }
    },
    handleEnd(event, type) {
      // console.log(event)
      // console.log(type)

      console.log(event.newIndex);
      console.log(event.oldIndex);
    },

    removeThis(item, index) {
      let delItem = this.list2.splice(index, 1);
      console.log(delItem);
    },

    // 查询当前首页的配置
    getHomeData() {
      HomeModuleAPI.GetHomeConfig(this.collectionId).then((res) => {
        if (res.Code === 0) {
          this.list2 = res.Data;
          // 将list2中已有的模块从moduleList中过滤掉
          this.filterList();
        }
      });
    },

    filterList() {
      if (this.moduleVisible) {
        this.list2.map((item) => {
          for (let i = 0; i < this.moduleList.length; i++) {
            if (item.ID == this.moduleList[i].ID) {
              this.moduleList.splice(i, 1, "");
            }
          }
        });
        this.moduleList = this.moduleList.filter((p) => {
          return p;
        });
      } else {
        setTimeout(() => {
          this.filterList();
        }, 200);
      }
    },

    // 保存首页配置
    submitHomeData() {
      let resList = this.list2.map((item, index) => {
        return { ModelID: item.ID, Sort: index + 1 };
      });
      console.log(resList);
      HomeModuleAPI.SaveHomeConfig({
        CollectionID: this.collectionId,
        Models: resList,
      }).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("保存成功");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },

    handleScroll() {
      let leftcont = this.$refs.leftcont;
      let subbox = this.$refs.subbox;
      if (leftcont) {
        leftcont.style.transform =
          "translateY(" + this.container.scrollTop + "px)";
      }
      if (subbox) {
        subbox.style.transform =
          "translateY(" + this.container.scrollTop + "px)";
      }
    },

    toSetting(row) {
      let type = row.ModelType; // 5:榜单

      if (type == 5) {
        this.$router.push({
          name: "gamespace_rank",
          params: {
            id: row.ResourceID,
          },
          query: {
            type: 1,
          },
        });
      } else if (type == 7) {
        this.$router.push({
          name: "gamespace_thematic_rank_manage",
          query: {
            ID: row.ResourceID,
          },
        });
      } else {
        sessionStorage.setItem("ModuleElManage", JSON.stringify(row));
        this.$router.push({
          name: "gamespace_activity_homemodule_elemanage",
          params: {
            modelType: row.ModelType,
            modelId: row.ID,
          },
          query: {
            titleType: row.TitleType,
            modelType: row.ModelType,
          },
        });
      }
    },

    back() {
      this.$router.back();
    },
  },
};
</script>

<style scoped lang="less">
.index-cont {
  background: #fff;
  padding: 10px;
}
.left-index-cont {
  padding: 50px 0 0 10px;
  height: 100%;
  overflow: auto;
  position: relative;
  box-sizing: border-box;
}
.submit-box {
  position: absolute;
  width: calc(100% - 16px);
  padding: 12px;
  z-index: 11;
  background: #fff;
  box-sizing: border-box;
}

.drop-box1 {
  padding: 15px 10px 15px 0;
}
.sortable-chosen {
  border: 1px solid #f0f0f0;
  border-radius: 2px;
  padding: 15px;
  text-align: center;
  box-sizing: border-box;
}
.drag-list-item.left-item {
  border: 1px solid #f0f0f0;
  border-radius: 2px;
  padding: 10px;
  text-align: left;
  margin-bottom: 8px;
}
.drag-list-item.left-item.sortable-chosen {
  padding: 10px;
}
.drag-list-item {
  position: relative;
  .opt-box {
    position: absolute;
    display: none;
    width: 100%;
    background: rgba(0, 0, 0, 0.2);
    padding: 6px 10px;
    top: 0;
    color: #fff;
    .cursor {
      cursor: pointer;
      user-select: none;
      float: right;
      margin-left: 20px;
      display: inline-block;
      padding: 0 5px;
    }
    button {
      float: right;
    }
  }

  &:hover .opt-box {
    display: block;
    z-index: 9;
  }
}
.drop-box2 {
  .drag-list-item {
    margin-bottom: 15px;
    vertical-align: middle;
    .wrap {
      border: 1px solid #ccc;
      text-align: center;
      position: relative;
    }
  }
  .sortable-chosen {
    padding: 0;
  }
}
/*---------*/
.drop-box2 {
  padding-bottom: 50px;
}
.heng-ban {
  .drop-box2 {
    padding-bottom: 50px;
    .model-type-1 {
    }
    .model-type-2 {
      display: inline-block;
      width: 48%;
      margin-left: 1%;
      margin-right: 1%;
    }
    .model-type-3 {
      display: inline-block;
      width: 48%;
      margin-left: 1%;
      margin-right: 1%;
    }
    .model-type-4 {
      display: inline-block;
      width: 32%;
      margin-left: 0.65%;
      margin-right: 0.65%;
    }
    .model-type-5 {
    }
    .model-type-5.model-sort-2 {
      display: inline-block;
      width: 48%;
      margin-left: 5px;
      margin-right: 5px;
    }
    .model-type-6 {
      display: inline-block;
      width: 48%;
      margin-left: 5px;
      margin-right: 5px;
    }
  }

  .banner-wrap {
    display: block;
    height: 100px;
    line-height: 100px;
  }
  .bigimg-wrap {
    height: 250px;
    .bigimg-v {
      line-height: 125px;
      > div:nth-child(1) {
        height: 125px;
        border-bottom: 1px solid #ccc;
      }
    }
    .bigimg-h {
      height: 250px;
      line-height: 250px;
    }
  }
  .miding-wrap {
    height: 200px;
    line-height: 200px;
  }
  .small-wrap {
    height: 180px;
    line-height: 180px;
  }
  .list-wrap {
  }
  .list-wrap-v {
    height: 250px;
    line-height: 250px;
  }
  .list-wrap-h {
    height: 80px;
    line-height: 80px;
  }
  .video-wrap {
    height: 250px;
    line-height: 250px;
  }
  .tab-wrap {
    height: 60px;
    line-height: 60px;
  }
}

/*竖版*/
.shu-ban {
  width: 420px;
  margin: auto;
  .wrap {
    height: 80px;
    line-height: 80px;
  }
}
</style>
