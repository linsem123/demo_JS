<template>
  <div class="pbody">
    <div class="back">
      <div class="back-inner">
        <div class="backbtn">
          <div class="arrow-btn"></div>
        </div>
        <div class="backtitle">
          <div id="marquee">{{ value.Title }}</div>
        </div>
      </div>
    </div>
    <div class="vir-dom">
      <img class="act_bg" :src="value.BackGroundPicture" />
      <div v-if="value.AppId && value.IsShowSuspend" class="footer" :style="{ backgroundColor: value.BottomColor }">
        <div style="display: flex; align-items: center">
          <img :src="value.AppIcon" class="game_icon" />
          <span class="text_box">
            <span id="game_name">{{ value.AppName }}</span>
            <span id="game_content">{{ value.Content }}</span>
          </span>
        </div>
        <button
          :style="{
            backgroundColor: value.ButtonColor,
            color: value.FontColor,
          }"
        >
          {{ value.AppStatus == 3 ? "立即预约" : "立即下载" }}
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "",
  props: ["value"],
  data() {
    return {};
  },
};
</script>

<style scoped lang="less">
.pbody {
  transform: scale(1);
  border: 1px solid #ccc;
  width: 400px;
  .vir-dom {
    position: relative;
    height: 700px;
    padding-top: 50px;
    overflow: auto;
    box-sizing: border-box;
    &::-webkit-scrollbar {
      /*滚动条整体样式*/
      width: 2px; /*高宽分别对应横竖滚动条的尺寸*/
      height: 1px;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 2px;
      -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      background: #999;
    }
    &::-webkit-scrollbar-track {
      /*滚动条里面轨道*/
      -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      background: #ededed;
    }
    .act_bg {
      width: 100%;
      display: block;
    }
    .footer {
      position: fixed;
      left: 0;
      bottom: 0;
      padding: 0 20px;
      height: 80px;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #fff;
      border-radius: 15px 15px 0 0;
      .game_icon {
        margin-right: 5px;
        width: 36px;
        height: 39px;
      }
      & div {
        display: flex;
        align-items: center;

        .text_box {
          display: flex;
          flex-direction: column;
        }
        #game_name {
          font-size: 17.8px;
        }
        #game_content {
          font-size: 12px;
          max-width: 200px;
          color: rgba(242, 242, 242, 0.8);
          text-overflow: -o-ellipsis-lastline;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          line-clamp: 2;
          -webkit-box-orient: vertical;
        }
      }
    }
    button {
      height: 34px;
      width: 98px;
      font-size: 17px;
      line-height: 34px;
      background: #fff;
      text-align: center;
      border-radius: 17px;
      text-decoration: unset;
      color: #14b9c7;
      border: none;
      box-shadow: none;
    }
  }
}
body {
  padding: 0;
  margin: 0;
}
img {
  border: 0;
}

.back {
  position: fixed;
  z-index: 120;
  background: #fff;
  left: 0;
  top: 0;
  width: 100%;
  padding-top: 8px;
  padding-bottom: 8px;
  box-sizing: border-box;
  transform: rotate(0);
  color: #000;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  .back-inner {
    width: 380px;
    margin: auto;
  }
  .backbtn {
    float: left;
    width: 34px;
    height: 34px;
    text-align: center;
    .arrow-btn {
      margin: 6px 6px 0 0;
    }
  }
  .backtitle {
    overflow: hidden;
    width: 340px;
    height: 34px;
    line-height: 34px;
    font-size: 18px;
    font-weight: 500;
  }
}
.arrow-btn {
  display: inline-block;
  vertical-align: middle;
  position: relative;
  width: 20px;
  height: 20px;
  border-color: #222;
  &::before,
  &::after {
    content: "";
    display: block;
    border-top: 2px solid;
    border-color: inherit;
    width: 12.5px;
    height: 0px;
    position: absolute;
    left: 3px;
    border-radius: 1px;
  }
  &::before {
    transform: rotateZ(-45deg);
    top: 5.4px;
  }
  &::after {
    transform: rotateZ(45deg);
    top: 13px;
  }
}
</style>
