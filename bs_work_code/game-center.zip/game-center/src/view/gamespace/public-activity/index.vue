<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Form :inline="true">
          <FormItem span="6">
            <!-- <Input
              type="text"
              v-model="searchform.params.Title"
              clearable
              placeholder="请输入宣传活动标题"
              style="width: 200px"
            ></Input> -->
            <TitleSelect
              v-model="searchform.params.Id"
              :width="200"
              placeholder="请输入宣传活动标题"
            />
          </FormItem>
          <FormItem span="6">
            <gameNameSelect
              v-model="searchform.params.AppId"
              :width="200"
              :multiple="false"
            />
          </FormItem>
          <FormItem span="6">
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </FormItem>
        </Form>
      </div>

      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      >
        <template slot-scope="{ row }" slot="BigBg">
          <img :src="row.BigBg" alt class="big-bg" />
        </template>
        <template slot-scope="{ row }" slot="MidBg">
          <img :src="row.MidBg" alt class="mid-bg" />
        </template>
        <template slot-scope="{ row }" slot="Place">
          <span v-if="row.Place == 0">发现好游戏</span>
          <span v-else-if="row.Place == 1">应用商店</span>
          <span v-else-if="row.Place == 2">全部</span>
          <span v-else>--</span>
        </template>
        <template slot-scope="{ row }" slot="ExpiredEnd">{{
          timeFormat(row.ExpiredEnd)
        }}</template>
        <template slot-scope="{ row }" slot="Status">
          <i-switch
            v-model="row.Status"
            size="large"
            :true-value="1"
            :false-value="0"
            @on-change="checkUpdate(row)"
          >
            <span slot="open">开</span>
            <span v-if="row.Status == 0" slot="close">关</span>
            <span v-else slot="close" class="no-wrap">未处理</span>
          </i-switch>
        </template>
        <template slot-scope="{ row }" slot="opt">
          <Button
            type="primary"
            size="small"
            :disabled="row.Status == 1"
            @click="editPool(row)"
            style="margin-right: 5px"
            >编辑</Button
          >
          <Button type="info" size="small" @click="addTemplate(row)"
            >配置模板</Button
          >
          <!-- <Button type="info" size="small" @click="addTemplate(row)"
            >复制链接</Button
          > -->
        </template>
      </Table>

      <div style="margin: 10px; overflow: hidden">
        <div style="float: left">
          <Button
            type="info"
            shape="circle"
            icon="plus-round"
            @click="addNewPool"
            >新增活动</Button
          >
        </div>
        <div style="float: right">
          <Page
            :total="searchform.total"
            :current="searchform.page"
            :page-size="searchform.limit"
            :page-size-opts="[10, 20, 40, 80, 100]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>

    <Modal v-model="poolVisible">
      <template slot="header">
        <b v-if="poolForm.Id" style="font-size: 14px">编辑宣传活动</b>
        <b v-else style="font-size: 14px">添加宣传活动</b>
      </template>
      <Row>
        <Col :span="21">
          <Form
            ref="poolForm"
            :model="poolForm"
            :rules="poolRules"
            :label-width="120"
          >
            <FormItem label="宣传活动标题：" prop="Title">
              <Input
                v-model="poolForm.Title"
                placeholder="请填写宣传活动标题"
              ></Input>
            </FormItem>
            <FormItem label="上传大图：" prop="BigBg">
              <UploadImg v-model="poolForm.BigBg" :module="'award'"></UploadImg>
            </FormItem>
            <FormItem label="上传中图：" prop="MidBg">
              <UploadImg v-model="poolForm.MidBg" :module="'award'"></UploadImg>
            </FormItem>
            <FormItem label="截止时间：" prop="ExpiredEnd">
              <DatePicker
                type="datetime"
                v-model="poolForm.ExpiredEnd"
                format="yyyy-MM-dd HH:mm:ss"
                placeholder="请选择截止时间"
              ></DatePicker>
            </FormItem>
            <FormItem label="关联游戏：" prop="AppId">
              <AppSelect
                v-model="poolForm.AppId"
                style="width: 200px"
                placeholder="请输入游戏名称"
              />
            </FormItem>
            <FormItem label="投放位置：">
              <Select v-model="poolForm.Place" placeholder="请选择投放位置">
                <Option
                  v-for="type in placementsList"
                  :value="type.ID"
                  :key="type.ID"
                  >{{ type.Name }}</Option
                >
              </Select>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button size="large" type="text" @click="poolVisible = false"
          >取消</Button
        >
        <Button size="large" type="primary" @click="submitPool">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import ActivityAPI from "@/api/gamespace/publicActivity";
import { formatTime } from "@/libs/tools";
import UploadImg from "_c/gamespace/upload-img.vue";
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect.vue";
import AppSelect from "_c/app-select";
import TitleSelect from "./title-select";
export default {
  name: "gamespace_awardspool_list",
  components: { UploadImg, gameNameSelect, AppSelect, TitleSelect },
  data() {
    return {
      searchform: {
        params: {
          Id: undefined,
          AppId: undefined,
        },
        total: 0,
        page: 1,
        limit: 10,
      },

      table: {
        loading: false,
        data: [],
        columns: [
          { title: "活动ID", key: "Id", width: 80, align: "center" },
          { title: "活动标题", key: "Title", minWidth: 150 },
          { title: "大图", slot: "BigBg", width: 100 },
          { title: "中图", slot: "MidBg", width: 100 },
          { title: "游戏名称", key: "AppName", width: 100 },
          { title: "截止时间", slot: "ExpiredEnd", width: 150 },
          { title: "投放位置", slot: "Place", minWidth: 80 },
          { title: "活动状态", slot: "Status", minWidth: 100 },
          { title: "活动链接", key: "FeedUrl", minWidth: 100 },
          {
            title: "操作",
            slot: "opt",
            width: 220,
            align: "center",
            fixed: "right",
          },
        ],
      },
      placementsList: [
        { ID: 2, Name: "全部" },
        { ID: 0, Name: "发现好游戏" },
        { ID: 1, Name: "应用商店" },
      ],

      poolVisible: false,
      poolForm: {
        Title: "",
        BigBg: [],
        MidBg: [],
        ExpiredEnd: "",
        Place: 0,
        AppId: undefined,
      },
      poolRules: {
        Title: [
          { required: true, message: "请填写宣传活动标题", trigger: "blur" },
        ],
        // BigBg: [
        //   {
        //     required: true,
        //     type: "array",
        //     message: "请上传大图",
        //     trigger: "change",
        //   },
        // ],
        // MidBg: [
        //   {
        //     required: true,
        //     type: "array",
        //     message: "请上传中图",
        //     trigger: "change",
        //   },
        // ],
        // ExpiredEnd: [
        //   {
        //     required: true,
        //     type: "date",
        //     message: "请设置截止时间",
        //     trigger: "change",
        //   },
        // ],
      },
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    timeFormat(date) {
        // 过滤掉系统初始化时间
        const stampLevel = new Date('2000-01-01T00:00:00+08:00').getTime();
        const timestamp = new Date(date).getTime();
        return (date && timestamp > stampLevel) ? formatTime(date) : '';
    },
    init() {
      let { page, limit, params } = { ...this.searchform };
      ActivityAPI.GetList({ page, limit, params }).then((res) => {
        if (res.Code == 0) {
          if (res.Data.Data) {
            this.table.data = res.Data.Data;
          } else {
            this.table.data = [];
          }
          this.searchform.total = res.Data.Count;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    onPageChange(value) {
      this.searchform.page = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.limit = value;
      this.init();
    },

    addNewPool() {
      this.poolVisible = true;
      this.$refs["poolForm"].resetFields();
      this.poolForm = {
        Title: "",
        BigBg: [],
        MidBg: [],
        ExpiredEnd: "",
        Place: 0,
        AppId: undefined,
      };
    },
    editPool(pool) {
      this.$refs["poolForm"].resetFields();
      let poolData = JSON.parse(JSON.stringify(pool));
      poolData.BigBg = poolData.BigBg ? [{ url: poolData.BigBg }] : [];
      poolData.MidBg = poolData.MidBg ? [{ url: poolData.MidBg }] : [];
      this.poolForm = poolData;
      this.poolVisible = true;
    },
    submitPool() {
      this.$refs["poolForm"].validate((valid) => {
        if (valid) {
            let params = JSON.parse(JSON.stringify(this.poolForm));
            params.BigBg = params.BigBg[0] && params.BigBg[0].url ? params.BigBg[0].url : "";
            params.MidBg = params.MidBg[0] && params.MidBg[0].url ? params.MidBg[0].url : "";
            if (!params.ExpiredEnd) {
                this.$Modal.confirm({
                    title: "提示",
                    okText: "确认",
                    cancelText: "取消",
                    loading: true,
                    content: "<p>还未设置截止时间，是否继续提交？</p>",
                    onOk: () => {
                        params.ExpiredEnd = params.ExpiredEnd ? params.ExpiredEnd : "2098-12-31T16:00:00.000Z";
                        this.submit(params);
                        this.$Modal.remove();
                    },
                })
            } else {
                this.submit(params);
            };
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },

    submit(params) {
        console.log(params);
        if (params.Id) {
            let { AppId, BigBg, MidBg, ExpiredEnd, Place, Title } = {
              ...params,
            };
            ActivityAPI.Edit(params.Id, {
              AppId,
              BigBg,
              MidBg,
              ExpiredEnd,
              Place,
              Title,
            }).then((res) => {
              if (res.Code === 0) {
                this.poolVisible = false;
                this.init();
              } else {
                this.$Message.error(res.Message);
              }
            });
        } else {
            ActivityAPI.Add(params).then((res) => {
              if (res.Code === 0) {
                this.poolVisible = false;
                this.init();
              } else {
                this.$Message.error(res.Message);
              }
            });
        }
    },

    //切换状态
    checkUpdate(pool) {
      ActivityAPI.Check(pool.Id, pool.Status).then((res) => {
        if (res.Code != 0) {
          this.$Message.error(res.Message);
        }
        this.init();
      });
    },
    addTemplate(item) {
      this.$router.push({
        name: "gamespace_downtemplate_list",
        params: {
          id: item.Id,
          title: encodeURI(item.Title),
        },
      });
    },
  },
};
</script>

<style scoped>
.big-bg,
.mid-bg {
  height: 40px;
}
.no-wrap {
  white-space: nowrap;
  font-size: 12px;
  display: block;
  transform: scale(0.8);
  left: -5px;
  position: relative;
}
</style>
