<template>
  <div>
    <Card>
      <Row>
        <i-col :span="12" :offset="1">
          <h3>参数配置</h3>
          <Form
            :model="templateData"
            :label-width="160"
            :rules="rules"
            ref="formData"
          >
            <FormItem label="活动名称：">
              <p>{{ pool.Title }}</p>
            </FormItem>

            <!-- 4.11迭代 -->
            <FormItem v-if="templateData.AppId" label="关联游戏：">
                <p>{{ templateData.AppName }}</p>
            </FormItem>
            <!-- <FormItem label="关联游戏：" prop="AppId">
              <AppSelect
                v-model="templateData.AppId"
                style="width: 200px"
                placeholder="请输入游戏名称"
                @on-change="changeApp"
              />
            </FormItem> -->

            <FormItem v-if="templateData.AppId" label="游戏icon：">
              <div style="width: 60px; height: 60px">
                <img
                  :src="templateData.AppIcon"
                  style="width: 100%; height: 100%"
                />
              </div>
            </FormItem>

            <!-- 4.11迭代 -->
            <!-- 当创建活动时配置了游戏，显示“是否显示悬浮条” -->
            <FormItem v-if="templateData.AppId" label="是否显示悬浮条：">
                <Checkbox v-model="templateData.IsShowSuspend"></Checkbox>
            </FormItem>
            <template v-if="templateData.AppId && templateData.IsShowSuspend">
                <FormItem label="悬浮条颜色：" prop="BottomColor">
                    <ColorPicker v-model="templateData.BottomColor" alpha />
                </FormItem>
                <FormItem label="下载button背景颜色：" prop="ButtonColor">
                    <ColorPicker v-model="templateData.ButtonColor" />
                </FormItem>
                <FormItem label="下载button文本颜色：" prop="FontColor">
                    <ColorPicker v-model="templateData.FontColor" />
                </FormItem>
            </template>
            <FormItem label="是否引导跳转：">
                <Checkbox v-model="templateData.IsShowJump"></Checkbox>
            </FormItem>
            <template v-if="templateData.IsShowJump">
                <FormItem label="绑定Deeplink包名：" prop="DeepLinkPkgName">
                    <Input v-model="templateData.DeepLinkPkgName" placeholder="请输入跳转目标app包名" />
                </FormItem>
                <FormItem label="绑定Deeplink：" prop="DeepLink">
                    <Input v-model="templateData.DeepLink" placeholder="请输入deeplink" />
                </FormItem>
            </template>

            <FormItem label="宣传长图" prop="BackGroundPicture">
              <UploadImg
                v-model="templateData.BackGroundPicture"
                module="award"
              ></UploadImg>
            </FormItem>

            <!-- <FormItem label="悬浮条颜色：" prop="BottomColor">
              <ColorPicker v-model="templateData.BottomColor" alpha />
            </FormItem>
            <FormItem label="立即下载按钮背景颜色：" prop="ButtonColor">
              <ColorPicker v-model="templateData.ButtonColor" />
            </FormItem>

            <FormItem label="立即下载按钮文字颜色：" prop="FontColor">
              <ColorPicker v-model="templateData.FontColor" />
            </FormItem> -->
            <FormItem align="center">
              <Button
                @click="submitTmp"
                type="primary"
                style="width: 150px; margin-right: 10px"
                >保 存</Button
              >
              <Button type="default" @click="cancel">取 消</Button>
            </FormItem>
          </Form>
        </i-col>
        <i-col :span="10" :offset="1">
          <h3>效果预览</h3>
          <div>
            <TmpPreview :value="preview"></TmpPreview>
          </div>
        </i-col>
      </Row>
    </Card>
  </div>
</template>

<script>
import ActivityAPI from "@/api/gamespace/publicActivity";
import UploadImg from "_c/shark-upload";
import AppSelect from "_c/app-select";
import TmpPreview from "./down-temp-preview";

export default {
  name: "",
  components: { UploadImg, TmpPreview, AppSelect },
  data() {
    const AppIdValidate = (rule, value, callback) => {
      if (!value) {
        callback("请选择关联游戏");
      }
      callback();
    };
    return {
      pool: {
        ID: 0,
        Title: "",
      },
      templateData: {
        BackGroundPicture: "",
        BottomColor: "#ffffff",
        AppIcon: "",
        AppId: "",
        AppName: "",
        Content: "",
        AppStatus: 1,
        ButtonColor: "",
        FontColor: "",
        // 4.11
        IsShowSuspend: false,
        IsShowJump: false,
        DeepLink: "",
        DeepLinkPkgName: ""
      },
      rules: {
        AppId: [
          { required: true, validator: AppIdValidate, trigger: "change" },
        ],
        BackGroundPicture: [
          { required: true, message: "请上传宣传长图", trigger: "change" },
        ],
        BottomColor: [
          { required: true, message: "请选择悬浮条颜色", trigger: "change" },
        ],
        ButtonColor: [
          {
            required: true,
            message: "请选择下载按钮背景颜色",
            trigger: "change",
          },
        ],
        FontColor: [
          {
            required: true,
            message: "请选择下载按钮文本颜色",
            trigger: "change",
          },
        ],
        DeepLinkPkgName: [
          {
            required: true,
            message: "请输入跳转目标app包名",
            trigger: "change",
          },
        ],
        DeepLink: [
          {
            required: true,
            message: "请输入deeplink",
            trigger: "change",
          },
        ]
      },
      gameList: [],
    };
  },
  computed: {
    preview() {
      return {
        Title: this.pool.Title,
        ...this.templateData,
        PoolID: this.$route.params.id,
      };
    },
  },
  mounted() {
    this.pool.ID = parseInt(this.$route.params.id);
    this.pool.Title = decodeURI(this.$route.params.title);
    this.getTemplate();
  },
  methods: {
    getTemplate() {
      // let this_ = this;
      ActivityAPI.GetTemplate(this.pool.ID).then((res) => {
        let templateData = res.Data || {};
        this.templateData = Object.assign(this.templateData, templateData);
      });
    },
    changeApp({ value, index }) {
      console.log(value);
      if (index != undefined) {
        this.templateData.AppName = value.label;
        this.templateData.AppIcon = value.AppIcon;
        this.templateData.Content = value.Content;
        this.templateData.AppStatus = value.AppStatus;
      } else {
        this.templateData.AppName = "";
        this.templateData.AppIcon = "";
        this.templateData.Content = "";
        this.templateData.AppStatus = 1;
      }
    },
    submitTmp() {
        this.$refs["formData"].validate((valid) => {
            if (valid) {
                const tmpData = JSON.parse(JSON.stringify(this.templateData));

                // 4.11
                const { BackGroundPicture, AppIcon, AppId, AppName, Content, AppStatus, IsShowSuspend, IsShowJump } = tmpData;
                const params = { BackGroundPicture, AppIcon, AppId, AppName, Content, AppStatus, IsShowSuspend, IsShowJump };
                if(IsShowSuspend) {
                    params.BottomColor = tmpData.BottomColor;
                    params.ButtonColor = tmpData.ButtonColor;
                    params.FontColor = tmpData.FontColor;
                }
                if(IsShowJump) {
                    params.DeepLink = tmpData.DeepLink.replace(/^\s*|\s*$/g,"");
                    params.DeepLinkPkgName = tmpData.DeepLinkPkgName.replace(/^\s*|\s*$/g,"");
                }

                // 4.11
                // ActivityAPI.Edit(this.pool.ID, params).then((res) => {
                ActivityAPI.EditTemplate(this.pool.ID, params).then((res) => {
                    if (res.Code === 0) {
                    this.$Notice.success({
                        title: "保存成功！",
                    });
                    } else {
                    this.$Message.error(res.Message);
                    }
                });
            }
        });
    },
    cancel() {
      this.$router.push({
        name: "gamespace_public_activity",
      });
    },
  },
};
</script>

<style scoped lang="less">
.color-input {
  display: block;
  min-width: 100px;
  border: 1px solid #dcdee2;
  border-radius: 4px;
  background: #f5f7f9;
  padding: 0 2px;
  margin: 0;
  height: 32px;
  cursor: pointer;
  &:focus {
    outline: none;
  }
}
</style>
