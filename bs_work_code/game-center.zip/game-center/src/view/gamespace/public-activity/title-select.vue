<template>
  <Select
    :value="value"
    :multiple="multiple"
    clearable
    filterable
    remote
    @on-change="updateVal"
    :remote-method="handleGamesSearch"
    :placeholder="placeholder"
    :style="'width:' + width + 'px'"
  >
    <Option v-for="j in gameList" :value="j.ID" :key="j.ID">{{
      j.Title
    }}</Option>
  </Select>
</template>
<script>
import ActivityAPI from "@/api/gamespace/publicActivity";
export default {
  props: {
    value: {
      default: () => [],
    },
    width: {
      type: Number,
      default: 400,
    },
    multiple: {
      default: false,
    },
    placeholder: {
      default: "请输入标题",
    },
  },
  data() {
    return {
      gameList: [],
    };
  },
  mounted() {},
  methods: {
    handleGamesSearch(value) {
      //   if (!parseInt(value)) {
      ActivityAPI.Like(value).then((res) => {
        this.gameList = res.Data;
      });
      //   }
    },
    updateVal(value) {
      this.$emit("input", value);
    },
  },
};
</script>
<style lang="less" scoped>
</style>