<template>
  <Card>
    <div style="margin: 10px 0">
      <Input
        style="width: 200px; margin-right: 10px"
        placeholder="请输入分类/标签名称"
        :clearable="true"
        v-model.trim="searchData.Name"
      />
      <Input
        style="width: 200px; margin-right: 10px"
        placeholder="请输入分类/标签ID"
        :clearable="true"
        v-model.trim="searchData.LevelId"
        @on-keyup="
          searchData.LevelId = searchData.LevelId
            ? Number(searchData.LevelId.replace(/[^\d]/g, '')).toString()
            : undefined
        "
      />
      <Button @click="handleSearch" type="primary" shape="circle">查询</Button>
      <Button type="primary" style="float: right" @click="handleUpload">{{
        btnText
      }}</Button>
      <input type="file" id="upload" v-show="false" @change="doUpload" />
    </div>
    <Table :data="tableData" :columns="columns" border :loading="tableLoading">
    </Table>

    <div style="margin: auto">
      <Page
        :total="total"
        :current="Page"
        :page-size="Limit"
        :page-size-opts="[10, 20, 40, 80, 100]"
        @on-change="onPageChange"
        @on-page-size-change="onPageSizechange"
        show-sizer
        show-total
      ></Page>
    </div>
  </Card>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
export default {
  name: "ClassifyTag",
  data() {
    return {
      tableData: [],
      columns: [
        { title: "分类ID", key: "ParentLevelId" },
        { title: "分类名称", key: "ParentName" },
        { title: "标签ID", key: "LevelId" },
        { title: "标签名称", key: "Name" },
      ],
      tableLoading: false,
      btnText: "更新分类标签表",
      btnLoading: false,
      Page: 1,
      Limit: 10,
      total: 0,
      timer: null,
      uploadpercent: 0,
      searchData: {
        Name: undefined,
        LevelId: undefined,
      },
      LevelId: undefined,
    };
  },
  mounted() {
    this.searchServer();
  },
  methods: {
    //点击上传文件
    handleUpload() {
      if (this.btnLoading) {
        this.$Message.error("上传中……");
      } else {
        const inpotDom = document.getElementById("upload");
        inpotDom.click();
      }
    },
    //选择文件后
    doUpload($event) {
      this.btnLoading = true;
      let file = $event.target.files[0];
      let nameIndex = file.name.lastIndexOf("."); //取到文件名开始到最后一个点的长度
      let name = file.name.substring(nameIndex + 1);
      if (name != "xlsx") {
        this.$Message.error("仅支持上传xlsx格式文件");
        return false;
      }
      this.timeInterval(99, 50, () => {
        clearInterval(this.timer);
        this.timer = null;
      });
      let formatFile = new FormData();
      formatFile.append("file", file);
      GameAPI.uploadMiTag(formatFile)
        // GameAPI.uploadMiData(formatFile)
        .then((res) => {
          if (res.Code == 0) {
            clearInterval(this.timer);
            this.timer = null;
            this.timeInterval(100, 10, () => {
              this.$Message.success("上传成功");
              this.clearTimer();
              this.handleSearch();
            });
          } else {
            this.$Message.error(res.Message || "上传失败");
            this.clearTimer();
          }
        })
        .catch((err) => {
          this.$Message.error("上传失败");
          this.clearTimer();
        });
    },
    timeInterval(num, time, func) {
      this.timer = setInterval(() => {
        if (this.uploadpercent < num) {
          this.uploadpercent += 1;
          this.btnText = "更新分类标签表(" + this.uploadpercent + "%)";
        } else {
          func && func();
        }
      }, time);
    },
    clearTimer() {
      this.btnLoading = false;
      //初始化数据
      clearInterval(this.timer);
      this.timer = null;
      this.btnText = "更新分类标签表";
      this.uploadpercent = 0;
      document.getElementById("upload").value = "";
    },
    onPageChange(value) {
      this.Page = value;
      this.searchServer();
    },
    onPageSizechange(value) {
      this.Limit = value;
      this.Page = 1;
      this.searchServer();
    },
    handleSearch() {
      this.Page = 1;
      this.searchServer();
    },
    searchServer() {
      this.tableLoading = true;
      GameAPI.getMiTagList({
        Page: this.Page,
        Limit: this.Limit,
        Params: {
          Name: this.searchData.Name || undefined,
          LevelId: Number(this.searchData.LevelId) || undefined,
        },
      })
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.Data || [];
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message || "查询失败");
          }
        })
        .finally(() => {
          this.tableLoading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>