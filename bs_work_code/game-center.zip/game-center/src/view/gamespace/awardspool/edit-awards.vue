<template>
  <div>
    <!--主弹窗 当前奖品列表-->
    <Modal
      v-model="awardsVisible"
      width="800"
      :title="'奖品管理（当前奖池：' + pool.Title + '）'"
      @on-visible-change="visibleChange"
    >
      <div style="min-height: 250px">
        <Table border :data="awardsList" :columns="columns">
          <template slot-scope="{row, index}" slot="AwardType">
            <span v-if="row.AwardType === 1">虚拟</span>
            <span v-if="row.AwardType === 2">真实</span>
            <span v-if="row.AwardType === 3">谢谢参与</span>
          </template>
          <template slot-scope="{row, index}" slot="Num">
            <span>{{row.LimitCount}}/{{row.Num}}</span>
          </template>
          <template slot-scope="{row, index}" slot="opt">
            <Button
              @click="editTheAward(row)"
              type="primary"
              size="small"
              style="margin-right: 5px;"
            >编辑</Button>
            <!--<Button type="error" size="small">删除</Button>-->
          </template>
        </Table>
      </div>
      <template slot="footer">
        <Button type="text" size="large" @click="visibleChange(false)">取消</Button>
        <Button type="primary" size="large" @click="newAwards">添加奖品</Button>
      </template>
    </Modal>

    <!--辅助弹窗 编辑奖品-->
    <Modal v-model="editVisible" :title="formData.ID ? '编辑奖品' : '添加奖品'">
      <!-- {{formData}} -->
      <Row>
        <Col :span="21">
          <Form ref="formData" :model="formData" :rules="rules" :label-width="120">
            <FormItem label="奖品名称：" prop="Title">
              <Input v-model="formData.Title" placeholder="请填写奖品名称"></Input>
            </FormItem>
            <FormItem label="奖品图片：" prop="URL">
              <UploadImg v-model="formData.URL" :module="'award'"></UploadImg>
            </FormItem>
            <FormItem label="奖品类型：" prop="AwardType">
              <RadioGroup v-model="formData.AwardType">
                <Radio :label="1">
                  <span>虚拟奖品</span>
                </Radio>
                <Radio :label="2">
                  <span>真实奖品</span>
                </Radio>
                <Radio :label="3">
                  <span>谢谢参与</span>
                </Radio>
              </RadioGroup>
            </FormItem>
            <FormItem label="绑定礼包：" prop="GiftID" v-if="formData.AwardType === 1">
              <Select v-model="formData.GiftID" @on-change="giftChange" clearable filterable remote :remote-method="handleGiftSearch" placeholder="请输入礼包名称">
                <Option v-for="j in giftList" :value="j.ID" :key="j.ID">{{j.Title}}</Option>
              </Select>
            </FormItem>
            <FormItem label="奖品数量：" prop="Num">
              <InputNumber v-model="formData.Num" :min="0" placeholder></InputNumber>
            </FormItem>
            <FormItem label="奖品内容：" prop="Content">
              <Input
                type="textarea"
                :rows="2"
                v-model="formData.PrizeContent"
                :maxlength="255"
                placeholder
              ></Input>
            </FormItem>
            <FormItem label="使用方法：" prop="Content">
              <Input
                type="textarea"
                :rows="2"
                v-model="formData.Content"
                :maxlength="255"
                placeholder
              ></Input>
            </FormItem>
            <!--<FormItem v-if="formData.AwardType === 1 && !formData.ID" label="CDKEY：">-->
              <!--<Upload action="//jsonplaceholder.typicode.com/posts/" :before-upload="handleUpload">-->
                <!--<Button icon="ios-cloud-upload-outline">选择文件</Button>-->
              <!--</Upload>-->
              <!--&lt;!&ndash; <p>{{formData.CDKey}}</p> &ndash;&gt;-->
            <!--</FormItem>-->
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button type="text" size="large" @click="editVisible = false">取消</Button>
        <Button type="primary" size="large" @click="submitAwards">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import AwardsPoolAPI from '@/api/gamespace/awardspool'
import UploadImg from '_c/gamespace/upload-img.vue'
import GameGifAPI from "@/api/gamespace/gamegif";

export default {
  name: '',
  components: { UploadImg },
  model: {
    // 默认返回数据为数组
    prop: 'visible',
    event: 'uploadVisible'
  },
  props: {
    visible: false,
    row: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  watch: {
    visible() {
      this.awardsVisible = this.visible
    },
    row() {
      this.pool = this.row
      this.getPoolAwards()
    }
  },
  data() {
    return {
      giftList: [],
      awardsVisible: false,
      awardsList: [],
      columns: [
        { title: '序号', type: 'index', width: 60, align: 'center' },
        { title: '奖品标题', key: 'Title' },
        { title: '奖品数量', slot: 'Num', width: 85 },
        { title: '奖品类型', slot: 'AwardType', width: 120 },
        { title: '奖品内容', key: 'PrizeContent', tooltip: true },
        { title: '使用方法', key: 'Content', tooltip: true },
        {
          title: '操作',
          slot: 'opt',
          width: 140,
          fixed: 'right',
          align: 'center'
        }
      ],
      pool: {},

      //
      editVisible: false,
      formData: {
        Num: 0,
        GiftID: undefined,
        URL: []
      },
      rules: {
        Title: [{ required: true, message: '请填写奖品名称', trigger: 'blur' }],
        URL: [
          {
            required: true,
            type: 'array',
            message: '请上传奖品图片',
            trigger: 'change'
          }
        ],
        AwardType: [
          {
            required: true,
            type: 'number',
            message: '请选择奖品类型',
            trigger: 'change'
          }
        ]
      },
      cdkeyFile: null
    }
  },
  mounted() {},
  methods: {
    giftChange(){
      this.giftList.forEach(v=> {
        if (v.ID == this.formData.GiftID) {
          this.formData.PrizeContent = v.Content
          this.formData.Content = v.Instruction
          this.formData.Num = v.Count
          this.formData.LimitCount = v.Count
        }
      })
    },
    handleGiftSearch(value) {
      GameGifAPI.LikeGift({value}).then(res => {
          this.giftList = res.Data;
        });
    },


    getPoolAwards() {
      let this_ = this
      AwardsPoolAPI.GetAwards(this.pool.ID).then(res => {
        if (res.Code === 0) this_.awardsList = res.Data
      })
    },
    // 打开奖品编辑弹窗
    newAwards() {
      if (this.awardsList.length < 8) {
        this.editVisible = true
        this.formData = { URL: [] }
        this.$refs.formData.resetFields()
      } else {
        this.$Message.warning('最多添加8个奖品')
      }
    },
    handleUpload(file) {
      console.log(file)
      if (file.type !== 'text/plain' || file.type < 100) {
        this.$Message.error('请选择正确的文件')
        this.cdkeyFile = null
        return false
      }

      let reader = new FileReader() // 新建一个FileReader
      let this_ = this
      reader.readAsText(file, 'UTF-8') // 读取文件
      reader.onload = function(evt) {
        // 读取完文件之后会回来这里
        let result = evt.target.result // 读取文件内容
        result = result
          .split('\n')
        let cdkeys = []
        result.forEach(function(item) {
          if (item.match(/^\s*$/)) {
            console.log('空格')
          } else {
            cdkeys.push(item.replace('\r', ''))
          }
        })
        this_.$set(this_.formData, 'CDKey', cdkeys)
      }

      this.cdkeyFile = file
      return false
    },
    editTheAward(item) {
      GameGifAPI.GiftsByType(3).then(res => {
        this.giftList = res.Data;
        let formData = JSON.parse(JSON.stringify(item))
        formData.URL = [{ url: formData.URL }]
        this.formData = formData
        this.editVisible = true
      });
    },
    submitAwards() {
      this.$refs.formData.validate(valid => {
        if (valid) {
          let params = JSON.parse(JSON.stringify(this.formData))
          params.URL = params.URL[0] ? params.URL[0].url : ''
          params.PoolID = this.pool.ID

          if (params.ID) {
            let edit = {
              ID: params.ID,
              PoolID: params.PoolID,
              URL: params.URL,
              Title: params.Title,
              Num: params.Num,
              AwardType: params.AwardType,
              Content: params.Content,
              PrizeContent: params.PrizeContent,
              CDKey: params.CDKey,
              GiftID: params.GiftID,
              LimitCount: params.LimitCount
            }
            AwardsPoolAPI.editAwards(edit).then(res => {
              if (res.Code === 0) {
                this.getPoolAwards()
                this.editVisible = false
              } else {
                this.$Message.warning(res.Message)
              }
            })
          } else {
            AwardsPoolAPI.newAwards(params).then(res => {
              if (res.Code === 0) {
                this.getPoolAwards()
                this.editVisible = false
              } else {
                this.$Message.warning(res.Message)
              }
            })
          }
        }
      })
    },

    visibleChange(val) {
      this.$emit('uploadVisible', val)
      setTimeout(() => {
        if (!val) {
          this.awardsList = []
        }
      }, 500)
    }
  }
}
</script>

<style scoped>
</style>
