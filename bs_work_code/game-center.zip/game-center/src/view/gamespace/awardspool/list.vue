<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Input
              type="text"
              v-model="searchform.params.Title"
              clearable
              placeholder="请输入奖池标题"
            ></Input>
          </Col>
          <Col span="6">
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="init"
              >搜索</Button
            >
          </Col>
          <Col span="12" align="right">
            <Button @click="handleDownload" type="primary" icon="md-download"
              >导出</Button
            >
          </Col>
        </Row>
      </div>

      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
        @on-selection-change="selectionChange"
      >
        <template slot-scope="{ row, index }" slot="BigBg">
          <img :src="row.BigBg" alt class="big-bg" />
        </template>
        <template slot-scope="{ row, index }" slot="MidBg">
          <img :src="row.MidBg" alt class="mid-bg" />
        </template>
        <template slot-scope="{ row, index }" slot="PoolType">
          <span v-if="row.PoolType === 1">单游戏抽奖</span>
          <span v-else-if="row.PoolType === 2">每日抽奖</span>
          <span v-else-if="row.PoolType === 3">多游戏抽奖</span>
          <span v-else>-</span>
        </template>
        <template slot-scope="{ row, index }" slot="Placement">
          <span v-if="row.Placement === 1">发现好游戏</span>
          <span v-else-if="row.Placement === 2">黑鲨装备箱</span>
          <span v-else-if="row.Placement === 4">应用商店</span>
          <span v-else>-</span>
        </template>
        <template slot-scope="{ row, index }" slot="ExpiredEnd">{{
          timeFormat(row.ExpiredEnd)
        }}</template>
        <template slot-scope="{ row, index }" slot="Status">
          <i-switch
            v-model="row.Status"
            size="large"
            :true-value="1"
            :false-value="row.Status ? 2 : 0"
            @on-change="checkUpdate(row)"
          >
            <span slot="open">开</span>
            <span v-if="row.Status" slot="close">关</span>
            <span v-else slot="close" class="no-wrap">未处理</span>
          </i-switch>
        </template>
        <template slot-scope="{ row, index }" slot="opt">
          <Button
            type="primary"
            size="small"
            :disabled="row.Status == 1"
            @click="editPool(row)"
            style="margin-right: 5px"
            >编辑</Button
          >
          <Button
            type="warning"
            size="small"
            @click="addAwards(row)"
            style="margin-right: 5px"
            >奖品管理</Button
          >
          <Button type="info" size="small" @click="addTemplate(row)"
            >配置模板</Button
          >
        </template>
      </Table>

      <div style="margin: 10px; overflow: hidden">
        <div style="float: left">
          <Button
            type="info"
            shape="circle"
            icon="plus-round"
            @click="addNewPool"
            >新增奖池</Button
          >
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            :page-size-opts="[10, 20, 40, 80, 100]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>

    <!--奖池编辑弹窗-->
    <Modal v-model="poolVisible">
      <template slot="header">
        <b v-if="poolForm.ID" style="font-size: 14px">编辑奖池</b>
        <b v-else style="font-size: 14px">添加奖池</b>
      </template>
      <Row>
        <Col :span="21">
          <Form
            ref="poolForm"
            :model="poolForm"
            :rules="poolRules"
            :label-width="120"
          >
            <FormItem label="奖池标题：" prop="Title">
              <Input
                v-model="poolForm.Title"
                placeholder="请填写奖池标题"
              ></Input>
            </FormItem>
            <FormItem label="上传大图：" prop="BigBg">
              <UploadImg v-model="poolForm.BigBg" :module="'award'"></UploadImg>
            </FormItem>
            <FormItem label="上传中图：" prop="MidBg">
              <UploadImg v-model="poolForm.MidBg" :module="'award'"></UploadImg>
            </FormItem>
            <FormItem label="截止时间：" prop="ExpiredEnd">
              <DatePicker
                type="datetime"
                v-model="poolForm.ExpiredEnd"
                format="yyyy-MM-dd HH:mm"
                placeholder="请选择截止时间"
              ></DatePicker>
            </FormItem>
            <FormItem label="奖池类型：" prop="PoolType">
              <Select v-model="poolForm.PoolType" placeholder="请选择奖池类型">
                <Option
                  v-for="type in poolTypesList"
                  :value="type.ID"
                  :key="type.ID"
                  >{{ type.Name }}</Option
                >
              </Select>
            </FormItem>

            <FormItem label="投放位置：">
              <Select v-model="poolForm.Placement" placeholder="请选择投放位置">
                <Option
                  v-for="type in placementsList"
                  :value="type.ID"
                  :key="type.ID"
                  >{{ type.Name }}</Option
                >
              </Select>
            </FormItem>
          </Form>
        </Col>
      </Row>
      <template slot="footer">
        <Button size="large" type="text" @click="poolVisible = false"
          >取消</Button
        >
        <Button size="large" type="primary" @click="submitPool">确定</Button>
      </template>
    </Modal>

    <!--添加奖品弹窗-->
    <edit-awards-modal
      v-model="awardsModalVisible"
      :row="currentPool"
    ></edit-awards-modal>
  </div>
</template>

<script>
import AwardsPoolAPI from "@/api/gamespace/awardspool";
import { formatTime } from "@/libs/tools";
import UploadImg from "_c/gamespace/upload-img.vue";
import EditAwardsModal from "./edit-awards";
import config from "@/config/index";
export default {
  name: "gamespace_awardspool_list",
  components: { UploadImg, EditAwardsModal },
  data() {
    return {
      searchform: {
        params: {
          Title: "",
        },
        page: {
          total: 0,
          current: 1,
          size: 10,
        },
      },

      table: {
        loading: false,
        data: [],
        columns: [
          { type: "selection", width: 50 },
          { title: "奖池ID", key: "ID", width: 80, align: "center" },
          { title: "奖池标题", key: "Title", minWidth: 150 },
          { title: "大图", slot: "BigBg", width: 100 },
          { title: "中图", slot: "MidBg", width: 100 },
          { title: "截止时间", slot: "ExpiredEnd", width: 150 },
          { title: "奖池类型", slot: "PoolType", minWidth: 80 },
          { title: "投放位置", slot: "Placement", minWidth: 80 },
          { title: "奖池状态", slot: "Status", minWidth: 100 },
          {
            title: "操作",
            slot: "opt",
            width: 220,
            align: "center",
            fixed: "right",
          },
        ],
      },

      poolTypesList: [
        { ID: 1, Name: "单游戏抽奖" },
        { ID: 2, Name: "每日抽奖" },
        { ID: 3, Name: "多游戏抽奖" },
      ],
      placementsList: [
        { ID: 1, Name: "发现好游戏" },
        { ID: 2, Name: "黑鲨装备箱" },
        { ID: 3, Name: "应用商店" },
      ],

      poolVisible: false,
      poolForm: {
        Title: "",
        BigBg: [],
        MidBg: [],
        ExpiredEnd: "",
        PoolType: "",
        Placement: "",
      },
      poolRules: {
        Title: [{ required: true, message: "请填写奖池标题", trigger: "blur" }],
        BigBg: [
          {
            required: true,
            type: "array",
            message: "请上传大图",
            trigger: "change",
          },
        ],
        MidBg: [
          {
            required: true,
            type: "array",
            message: "请上传中图",
            trigger: "change",
          },
        ],
        ExpiredEnd: [
          {
            required: true,
            type: "date",
            message: "请设置截止时间",
            trigger: "change",
          },
        ],
        PoolType: [
          {
            required: true,
            type: "number",
            message: "请选择奖池类型",
            trigger: "change",
          },
        ],
      },

      //
      awardsModalVisible: false,
      currentPool: {},

      selection: [],
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    timeFormat(date) {
      return formatTime(date);
    },
    init() {
      AwardsPoolAPI.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then((res) => {
        if (res.Data.Data) {
          this.table.data = res.Data.Data;
        } else {
          this.table.data = [];
        }
        this.searchform.page.total = res.Data.Count;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },

    addNewPool() {
      this.poolVisible = true;
      this.$refs["poolForm"].resetFields();
      this.poolForm = {
        Title: "",
        BigBg: [],
        MidBg: [],
        ExpiredEnd: "",
        PoolType: "",
      };
    },
    editPool(pool) {
      let poolData = JSON.parse(JSON.stringify(pool));
      poolData.BigBg = [{ url: poolData.BigBg }];
      poolData.MidBg = [{ url: poolData.MidBg }];
      this.poolForm = poolData;
      this.poolVisible = true;
    },
    submitPool() {
      this.$refs["poolForm"].validate((valid) => {
        if (valid) {
          let params = JSON.parse(JSON.stringify(this.poolForm));
          params.BigBg = params.BigBg[0].url;
          params.MidBg = params.MidBg[0].url;
          console.log(params);
          let this_ = this;

          if (params.ID) {
            AwardsPoolAPI.Edit(params).then((res) => {
              if (res.Code === 0) {
                this_.poolVisible = false;
                this.init();
              }
            });
          } else {
            AwardsPoolAPI.Add(params).then((res) => {
              if (res.Code === 0) {
                this_.poolVisible = false;
                this.init();
              }
            });
          }
        } else {
          this.$Message.error("请填写必需信息!");
        }
      });
    },

    //
    checkUpdate(pool) {
      AwardsPoolAPI.Check(pool.ID, pool.Status).then((res) => {
        if (res.Code !== 0) {
          this.init();
        }
      });
    },

    addAwards(row) {
      this.currentPool = row;
      this.awardsModalVisible = true;
    },

    addTemplate(item) {
      this.$router.push({
        name: "gamespace_edittemplate_list",
        // name: "gamespace_downtemplate_list",
        params: {
          id: item.ID,
          title: encodeURI(item.Title),
          placement: item.Placement,
        },
        query: {
          poolType: item.PoolType,
        },
      });
    },

    selectionChange(sel) {
      this.selection = sel.map((s) => {
        return s.ID;
      });
      console.log(this.selection);
    },

    handleDownload() {
      if (this.selection.length === 0) {
        this.$Message.error("请勾选要导出的数据");
      } else {
        AwardsPoolAPI.exportList({ Ids: this.selection }).then((res) => {
          if (res.Code === 0) {
            let url = res.Data;
            url = url.replace(".", "");
            console.log(config.fileBaseUrl + url);
            window.location.href = config.fileBaseUrl + url;
          } else {
            this.$Message.error(res.Message);
          }
        });
      }
    },
  },
};
</script>

<style scoped>
.big-bg,
.mid-bg {
  height: 40px;
}
.no-wrap {
  white-space: nowrap;
  font-size: 12px;
  display: block;
  transform: scale(0.8);
  left: -5px;
  position: relative;
}
</style>
