<template>
  <div>
    <Card>
      <Row>
        <i-col :span="12" :offset="1">
          <h3>参数配置</h3>
          <Form :model="templateData" :label-width="150">
            <FormItem label="当前奖池：">
              <!--<Input readonly :value="pool.Title"></Input>-->
              <p>{{pool.Title}}</p>
            </FormItem>
            <FormItem v-if="!templateData.ID && pool.PoolType == 1" label="选择游戏：">
              <Select
                v-model="templateData.AppID"
                :remote-method="handleGameSearch"
                clearable
                filterable
                remote
                placeholder="请输入游戏名称"
              >
                <Option v-for="item in gameList" :value="item.ID" :key="item.ID">{{ item.AppName }}</Option>
              </Select>
            </FormItem>

            <FormItem v-if="templateData.ID && pool.PoolType == 1" label="当前游戏：">
              <Input readonly :value="templateData.AppName"></Input>
            </FormItem>
            <FormItem label="KV图">
              <UploadImg v-model="templateData.KvBg" module="award"></UploadImg>
            </FormItem>
            <Row>
              <i-col :span="12">
                <FormItem label="整体布局背景颜色：">
                  <ColorPicker v-model="templateData.BgColor" />
                </FormItem>
              </i-col>
              <i-col :span="12">
                <FormItem label="奖品或规则区域背景颜色：">
                  <ColorPicker v-model="templateData.AwardColor" />
                </FormItem>
              </i-col>
            </Row>
            <Row>
              <i-col :span="12">
                <FormItem label="安装/预约按钮背景颜色：">
                  <ColorPicker v-model="templateData.SubmitBgColor" />
                </FormItem>
              </i-col>
              <i-col :span="12">
                <FormItem label="安装/预约按钮文字色：">
                  <ColorPicker v-model="templateData.SubmitColor" />
                </FormItem>
              </i-col>
            </Row>

            <FormItem label="开始抽奖（GO）背景颜色：">
              <ColorPicker v-model="templateData.StartColor" />
            </FormItem>

            <Divider></Divider>
            <FormItem label="中奖记录背景颜色：">
              <ColorPicker v-model="templateData.PrizeBgColor" />
            </FormItem>
            <Row>
              <i-col :span="12">
                <FormItem label="奖品名称颜色：">
                  <ColorPicker v-model="templateData.PrizeNameColor" />
                </FormItem>
              </i-col>
              <i-col :span="12">
                <FormItem label="“查看中奖记录”字体颜色：">
                  <ColorPicker v-model="templateData.PrizeTitleColor" />
                </FormItem>
              </i-col>
            </Row>

            <Row>
              <i-col :span="12">
                <FormItem label="查看按钮背景颜色：">
                  <ColorPicker v-model="templateData.BtnBg" />
                </FormItem>
              </i-col>
              <i-col :span="12">
                <FormItem label="查看按钮文字颜色：">
                  <ColorPicker v-model="templateData.BtnText" />
                </FormItem>
              </i-col>
            </Row>

            <template v-if="pool.PoolType == 3">
              <Divider></Divider>
              <FormItem label="选择游戏：">
                <Select
                  v-model="templateData.AppIDs"
                  multiple
                  clearable
                  filterable
                  remote
                  :remote-method="handleGameSearch"
                  placeholder="请输入游戏名称"
                  style="width: 100%"
                >
                  <Option v-for="j in gameList" :value="j.ID" :key="j.ID">{{j.AppName}}</Option>
                </Select>
              </FormItem>
              <FormItem v-if="pool.PoolType == 3" label="app包名：">
                <Select
                  v-model="templateData.AppIDs"
                  multiple
                  clearable
                  filterable
                  remote
                  :remote-method="handleGameSearch"
                  placeholder="请输入游戏名称"
                  style="width: 100%"
                  disabled
                >
                  <Option v-for="j in gameList" :value="j.ID" :key="j.ID">{{j.PkgName}}</Option>
                </Select>
              </FormItem>
              <!--            <FormItem label="剩余抽奖次数字体颜色：">-->
              <!--              <ColorPicker v-model="templateData.AwardLimitCountColor" />-->
              <!--            </FormItem>-->
              <FormItem label="游戏列表标题颜色：">
                <ColorPicker v-model="templateData.AppListTitleColor" />
              </FormItem>
              <FormItem label="游戏名称字体颜色：">
                <ColorPicker v-model="templateData.AppNameColor" />
              </FormItem>
              <FormItem label="游戏一句话简介字体颜色：">
                <ColorPicker v-model="templateData.AppDescColor" />
              </FormItem>
            </template>

            <Divider></Divider>

            <Row>
              <i-col :span="12">
                <FormItem label="活动规则标题颜色：">
                  <ColorPicker v-model="templateData.RuleTitleColor" />
                </FormItem>
              </i-col>
              <i-col :span="12">
                <FormItem label="活动规则内容字体颜色：">
                  <ColorPicker v-model="templateData.RuleColor" />
                </FormItem>
              </i-col>
            </Row>
            <FormItem label="活动规则标题：">
              <Input v-model="templateData.RuleTitle" placeholder="请输入活动规则标题"></Input>
            </FormItem>
            <FormItem label="活动规则内容：">
              <Input
                type="textarea"
                :rows="6"
                placeholder="请输入活动规则内容"
                v-model="templateData.RuleContent"
              ></Input>
            </FormItem>
            <template v-if="pool.Placement == 2">
              <FormItem label="立即抽奖按钮图片：">
                <UploadImg v-model="templateData.StartDrawButton" module="award"></UploadImg>
              </FormItem>
              <FormItem label="查看奖品按钮图片：">
                <UploadImg v-model="templateData.LookDrawButton" module="award"></UploadImg>
              </FormItem>
              <FormItem label="未中奖按钮图片：">
                <UploadImg v-model="templateData.NotDrawButton" module="award"></UploadImg>
              </FormItem>
            </template>
            <FormItem align="center">
              <Button
                @click="submitTmp"
                type="primary"
                style="width: 150px; margin-right: 10px;"
              >保 存</Button>
              <Button type="default" @click="cancel">取 消</Button>
            </FormItem>
          </Form>
        </i-col>
        <i-col :span="10" :offset="1">
          <h3>效果预览</h3>
          <div>
            <TmpPreview :value="preview"></TmpPreview>
          </div>
        </i-col>
      </Row>
    </Card>
  </div>
</template>

<script>
import AwardsPoolAPI from "@/api/gamespace/awardspool";
import GameAPI from "@/api/gamespace/game";
import UploadImg from "_c/shark-upload";
import TmpPreview from "./tmp-preview";

export default {
  name: "",
  components: { UploadImg, TmpPreview },
  data() {
    return {
      pool: {
        ID: 0,
        PoolType: 1,
        Title: "",
        Placement: 1,
      },
      templateData: {
        // StartDrawButton: [], LookDrawButton: [], NotDrawButton: [],
        KvBg: "",
        BgColor: "#ffffff",
        AwardColor: "",
        RuleTitleColor: "",
        RuleColor: "",
        SubmitBgColor: "",
        SubmitColor: "",
        StartColor: "",
        PrizeBgColor: "",
        PrizeNameColor: "",
        PrizeTitleColor: "",
        BtnBg: "",
        BtnText: "",
        AppIDs: [],
        AwardLimitCountColor: "",
        AppListTitleColor: "",
        AppNameColor: "",
        AppDescColor: "",
        RuleTitle: "",
        RuleContent: "",
      },
      gameList: [],
    };
  },
  computed: {
    preview() {
      return {
        Title: this.pool.Title,
        ...this.templateData,
        // StartDrawButton: this.templateData.StartDrawButton[0] && this.templateData.StartDrawButton[0].url,
        // LookDrawButton:this.templateData.LookDrawButton[0] && this.templateData.LookDrawButton[0].url,
        // NotDrawButton:this.templateData.NotDrawButton[0] && this.templateData.NotDrawButton[0].url,
        PoolID: this.$route.params.id,
        PoolType: this.$route.query.poolType,
      };
    },
  },
  mounted() {
    this.pool.ID = this.$route.params.id;
    this.pool.PoolType = this.$route.query.poolType;
    this.pool.Title = decodeURI(this.$route.params.title);
    this.pool.Placement = this.$route.params.placement;
    this.getTemplate();
  },
  methods: {
    getTemplate() {
      let this_ = this;
      AwardsPoolAPI.GetTemplate(this.pool.ID).then((res) => {
        let templateData = res.Data || {};
        templateData.PoolID = parseInt(this.pool.ID);
        // if (templateData.StartDrawButton) {
        //   templateData.StartDrawButton = [{url: templateData.StartDrawButton}];
        // } else {templateData.StartDrawButton = []}
        if (templateData.AppIDs && templateData.AppIDs.length > 0) {
          this.gameList = [];
          GameAPI.GetGames(templateData.AppIDs).then((res) => {
            this.gameList = res.Data;
          });
        }
        // if (templateData.LookDrawButton) {
        //   templateData.LookDrawButton = [{url: templateData.LookDrawButton}];
        // } else {templateData.LookDrawButton = []}
        // if (templateData.NotDrawButton) {
        //   templateData.NotDrawButton = [{url: templateData.NotDrawButton}];
        // } else {templateData.NotDrawButton = []}
        this_.templateData = Object.assign(this_.templateData, templateData);
      });
    },
    handleGameSearch(value) {
      GameAPI.LikeApp({ value }).then((res) => {
        this.gameList = res.Data;
      });
    },
    submitTmp() {
      let this_ = this;
      let tmpData = JSON.parse(JSON.stringify(this.templateData));
      // tmpData.StartDrawButton = tmpData.StartDrawButton[0] ? tmpData.StartDrawButton[0].url : '';
      // tmpData.LookDrawButton = tmpData.LookDrawButton[0] ? tmpData.LookDrawButton[0].url : '';
      // tmpData.NotDrawButton = tmpData.NotDrawButton[0] ? tmpData.NotDrawButton[0].url : '';
      AwardsPoolAPI.SaveTemplate(tmpData).then((res) => {
        if (res.Code === 0) {
          this_.$Notice.success({
            title: "保存成功！",
          });
        }
      });
    },
    cancel() {
      this.$router.push({
        path: "/gamespace/awardspool/list",
      });
    },
  },
};
</script>

<style scoped lang="less">
.color-input {
  display: block;
  min-width: 100px;
  border: 1px solid #dcdee2;
  border-radius: 4px;
  background: #f5f7f9;
  padding: 0 2px;
  margin: 0;
  height: 32px;
  cursor: pointer;
  &:focus {
    outline: none;
  }
}
</style>
