<template>
  <Card>
    <p slot="title"><Icon type="information-circled"></Icon>添加游戏应用</p>
    <view-form
      :pagenema="gamemanage"
      @on-form-submit="handleSubmit"
    ></view-form>
  </Card>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
import ViewForm from "_c/gamespace/game/form";
import { mapMutations } from "vuex";
export default {
  name: "Add",
  components: {
    ViewForm,
  },
  data() {
    return {
      gamemanage: "gamemanage",
    };
  },
  methods: {
    ...mapMutations(["closeTag"]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      formScope.FirstLaunchTime =
        formScope.FirstLaunchTime || new Date("2001-01-01 00:00");
      GameAPI.Add(formScope).then((res) => {
        this.$Loading.finish();
        this.loading = false;
        if (res.Code != 0) {
          this.$Message.error(res.Message);
          return;
        }
        this.$Notice.success({
          title: "添加成功!",
        });
        this.closeTag(this.$route);
        // this.$emit("on-close", undefined, undefined, this.$route);
        this.$router.push({
          name: "gamespace_game",
        });
      });
    },
  },
};
</script>
