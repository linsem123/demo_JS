<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>
      更新游戏-{{ formScope.AppName }}
    </p>
    <view-form
      @on-form-submit="handleSubmit"
      :pagenema="gamemanage"
      :formScope="formScope"
      :edit="true"
    ></view-form>
  </Card>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
import ViewForm from "_c/gamespace/game/form";
import { mapMutations } from "vuex";
export default {
  name: "edit",
  components: {
    ViewForm,
  },
  data() {
    return {
      formScope: {
        type: Object,
      },
      gamemanage: "gamemanage",
    };
  },
  methods: {
    ...mapMutations(["closeTag"]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      formScope.FirstLaunchTime =
        formScope.FirstLaunchTime || new Date("2001-01-01 00:00");
      GameAPI.Edit(formScope).then((res) => {
        this.$Loading.finish();
        this.loading = false;
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "更新游戏成功",
        });
        this.close();
      });
    },
    close() {
      this.closeTag(this.$route);
      // this.$emit("on-close", undefined, undefined, this.$route);
      this.$router.push({
        name: "gamespace_game",
      });
    },
  },
  mounted() {
    GameAPI.Get(this.$route.params.id).then((res) => {
      if (res.Code > 0) {
        this.$Message.warning(res.Message);
        return;
      }
      this.formScope = res.Data;
    });
  },
};
</script>
