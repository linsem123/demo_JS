<template>
    <div>
        <Card>
            <div style="margin: 10px">
                <Form inline>
                    <FormItem>
                        <Select
                            v-model="searchform.params.id"
                            :loading="searchform.appname.loading"
                            clearable
                            filterable
                            remote
                            :remote-method="handleGameSearch"
                            placeholder="请输入游戏名称"
                            ref="searchAppName"
                            @on-change="changeAppNameValue"
                            style="width: 200px"
                        >
                            <Option v-for="item in searchform.appname.data" :value="item.ID" :key="item.ID">{{ item.AppName }}</Option>
                        </Select>
                    </FormItem>
                    <FormItem>
                        <Select
                            v-model="searchform.params.id"
                            :loading="searchform.appname.loading"
                            clearable
                            filterable
                            remote
                            :remote-method="handleGamePkgNameSearch"
                            placeholder="请输入游戏包名"
                            ref="searchPkgName"
                            @on-change="changePkgValue"
                            style="width: 200px"
                        >
                            <Option v-for="item in searchform.appname.data" :value="item.ID" :key="item.ID">{{ item.PkgName }}</Option>
                        </Select>
                    </FormItem>
                    <FormItem label="状态：" :label-width="60">
                        <Selection :dataList="stateList" v-model="searchform.params.AppStatus" />
                    </FormItem>
                    <FormItem label="下载源：" :label-width="60">
                        <Selection :dataList="placeList" v-model="searchform.params.DownloadSource" />
                    </FormItem>
                    <FormItem label="游戏类型：" :label-width="75">
                        <Selection :dataList="appTypeList" v-model="searchform.params.AppType" />
                    </FormItem>
                    <FormItem label="开发者：" :label-width="65">
                        <LikeSearch
                            v-model="searchform.params.Provider"
                            placeholder="请输入开发者"
                            :serverData="postProviderData"
                            clearable
                            style="width: 200px"
                        />
                    </FormItem>

                    <FormItem>
                        <Button type="success" shape="circle" icon="ios-search" @click="init" style="margin-right: 10px">搜索</Button>
                    </FormItem>
                    <FormItem>
                        <Upload
                            action="#"
                            :before-upload="handleUpload"
                            :format="['txt']"
                            style="display: inline-block; margin-right: 10px"
                        >
                            <Button icon="md-cloud-upload">导入</Button>
                        </Upload>

                        <Button @click="handleExport" type="primary" icon="md-cloud-download">导出</Button>
                    </FormItem>
                </Form>
            </div>
            <Table :loading="table.loading" border ref="selection" :columns="table.columns" :data="table.data">
                <template slot="PkgName" slot-scope="{ row }">
                    <Tag>{{ row.PkgName }}</Tag>
                    <span>
                        <Button
                            v-if="row.AppType == 0"
                            type="primary"
                            size="small"
                            @click="hadlePkgModify(row)"
                            style="margin-right: 5px"
                        >修改包名</Button>
                        <Button
                            v-if="
                row.AppType == 0 && (row.Status == 3 || row.ReleaseType == 1)
              "
                            type="primary"
                            size="small"
                            @click="hadleDataModify(row)"
                        >数据迁移</Button>
                    </span>
                </template>
            </Table>
            <div style="margin: 10px; overflow: hidden">
                <div style="float: left">
                    <Button type="info" shape="circle" icon="plus-round" @click="openAdd">新增游戏</Button>
                    <Button shape="circle" icon="plus-round" @click="openTag">标签管理</Button>
                    <Button shape="circle" icon="plus-round" @click="openCategory">分类管理</Button>
                    <Button shape="circle" icon="plus-round" @click="openDeveloper">开发者管理</Button>
                </div>
                <div style="float: right">
                    <Page
                        :total="searchform.page.total"
                        :current="searchform.page.current"
                        :page-size="searchform.page.size"
                        @on-change="onPageChange"
                        @on-page-size-change="onPageSizechange"
                        show-sizer
                        show-total
                    ></Page>
                </div>
            </div>

            <Modal v-model="modal_show">
                <p slot="header">
                    <Icon type="information-circled"></Icon>
                    <span>商务审核</span>
                </p>
                <Form ref="formData" :model="formData" :rules="ruleValidate" :label-width="120">
                    <Row>
                        <Col :span="21">
                            <FormItem label="审核结果" prop="CheckStatus">
                                <Select v-model="formData.CheckStatus">
                                    <Option v-for="item in statusList" :value="item.value" :key="item.value">{{ item.label }}</Option>
                                </Select>
                            </FormItem>
                            <FormItem label="审核意见" prop="Opinion">
                                <Input v-model="formData.Opinion" type="textarea" :rows="4" placeholder="请输入审核意见"></Input>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <div slot="footer">
                    <Row>
                        <Col span="6" offset="18">
                            <Button type="success" :loading="loading" @click="handleSubmit">审核</Button>
                        </Col>
                    </Row>
                </div>
            </Modal>
        </Card>
        <AddGifModel v-if="showgifmodal" :currentGame.sync="currentGame" :personList="personList" @on-close-model="closeModel"></AddGifModel>

        <!-- 修改游戏包名弹窗 -->
        <Modal title="修改包名" v-model="packageModify.packgeModel" width="450px" :mask-closable="false">
            <Form :model="packageModify" label-position="right" :label-width="100">
                <FormItem label="当前游戏名称：">{{ packageModify.AppName }}</FormItem>
                <FormItem label="当前游戏包名：">{{ packageModify.PkgName }}</FormItem>
                <FormItem label="游戏包名：">
                    <Input v-model.trim="packageModify.packageName" placeholder="请输入游戏包名" style="width: 200px" clearable />
                    <div style="color: red" v-show="packageModify.errorMsg">包名不合规：{{ packageModify.errorMsg }}</div>
                </FormItem>
            </Form>
            <Alert type="warning" show-icon>包名修改操作不可逆，请再次确认期望包名是否正确！</Alert>
            <template slot="footer">
                <Button @click="packageModify.packgeModel = false">取消</Button>
                <Button @click="commitModifyPkgName" type="primary" style="margin-left: 20px">确认</Button>
            </template>
        </Modal>
        <Modal title="数据迁移" v-model="dataModify.packgeModel" width="700px" :styles="{ top: '30px' }" :mask-closable="false">
            <Form inline :label-width="110" style="border: 1px solid #eee">
                <Row>
                    <Col span="12">
                        <FormItem label="迁入游戏包名：">{{ dataModify.PkgName }}</FormItem>
                    </Col>
                    <Col span="12">
                        <FormItem label="迁出游戏包名：">
                            <LikeSearch
                                v-model="dataModify.appId"
                                placeholder="请输入游戏包名"
                                :serverData="postServerData"
                                ref="pakgsearch"
                                clearable
                                style="width: 200px"
                                @on-change="changePkgName"
                                v-if="dataModify.packgeModel"
                            />
                            <div
                                style="color: red; position: absolute; left: -100px;white-space: nowrap;"
                                v-show="dataModify.errorMsg"
                            >{{ dataModify.errorMsg }}</div>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="12">
                        <FormItem label="迁入游戏主键ID：">{{ dataModify.ID }}</FormItem>
                    </Col>
                    <Col span="12">
                        <FormItem label="迁出游戏主键ID：">{{ dataModify.appId }}</FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="12">
                        <FormItem label="迁入游戏名称：">{{ dataModify.AppName }}</FormItem>
                    </Col>
                    <Col span="12">
                        <FormItem label="迁出游戏名称：">{{ dataModify.name }}</FormItem>
                    </Col>
                </Row>
            </Form>
            <p style="color: red">
                1、数据迁移，将会对迁出游戏、迁入游戏部分数据项产生影响，请务必仔细查看！
                <br />2、务必在数据迁移后，检查迁出、迁入游戏的资源位、活动、推广黑名单、搜索干预、游戏圈配置，是否符合运营策略！
                <br />3、迁出游戏为小米游戏，需考虑是否黑鲨、小米共存；迁出游戏为黑鲨游戏，需注意登录、支付、优惠券是否正常！
                <br />
            </p>

            <div style="border: 1px solid #eee; padding: 10px; margin-bottom: 10px">
                <h4>以下数据项，对迁出游戏、迁入游戏均有影响</h4>
                <span class="span-width-one">预约用户：</span>合并到迁入游戏，迁出游戏不保留
                <br />
                <span class="span-width-one">论坛帖：</span>通过app、cms、pc发帖器发布的合并到迁入游戏，开放平台、三方同步的保留在迁出游戏
                <br />
                <span class="span-width-one">圈子关注用户：</span>合并到迁入游戏，迁出游戏不保留（前端展示会存在延迟）
                <!-- <br />
                <h4>以下数据项，仅对迁出游戏有影响</h4>
                <span class="span-width-two">是否静默/预约安装开关：</span>迁出游戏，开关关闭；迁入游戏，保持原状态
                <br />
                <span class="span-width-two">是否屏蔽子论坛开关：</span>迁出游戏，开关关闭；迁入游戏，保持原状态
                <br />
                <span class="span-width-two">攻略站入口配置：</span>迁出游戏，状态解绑；迁入游戏，保持原状态
                <br />
                <span class="span-width-two">游戏/版本：</span>迁出游戏，状态下架；迁入游戏，保持原状态
                <br />
                <span class="span-width-two">版本定时任务：</span>迁出游戏，删除定时任务；迁入游戏，保留
                <br />
                <span class="span-width-two">沉浸式详情页：</span>迁出游戏，开关关闭；迁入游戏，保持原状态
                <br />
                <span class="span-width-two">文章：</span>迁出游戏，状态下架；迁入游戏，保持原状态
                <br />-->
            </div>
            <Alert type="warning" show-icon>迁移数据操作不可逆，请再次确认迁出游戏，迁入游戏是否正确！确定迁移请点击</Alert>
            <template slot="footer">
                <Button @click="dataModify.packgeModel = false">取消</Button>
                <Button @click="commitDataModify" type="primary" style="margin-left: 20px" :disabled="!!dataModify.errorMsg">确认</Button>
            </template>
        </Modal>
    </div>
</template>

<script>
import GameAPI from "@/api/gamespace/game";
import commentApi from "@/api/gamespace/comment";
import Tables from "_c/tables";
import AddGifModel from "_c/gamespace/game/addgif";
import config from "@/config/index";
import { formatTime } from "@/libs/tools";
import Selection from "_c/Selection";
import LikeSearch from "_c/like-search";
export default {
    name: "gamespace_game",
    components: {
        AddGifModel,
        Selection,
        LikeSearch
    },
    data() {
        return {
            loading: false,
            formData: {
                ID: undefined,
                CheckStatus: undefined,
                Opinion: ""
            },
            statusList: [
                { value: 1, label: "通过" },
                { value: 2, label: "撤销" }
            ],
            ruleValidate: {
                CheckStatus: {
                    required: true,
                    type: "number",
                    message: "请选择审核结果",
                    trigger: "blur"
                },
                Opinion: {
                    required: true,
                    message: "请输入审核意见",
                    trigger: "blur"
                }
            },
            modal_show: false,
            currentGame: null,
            showgifmodal: false,
            gifFile: null,
            personList: [], // 预警人列表
            searchform: {
                params: {
                    id: undefined,
                    AppStatus: 99,
                    DownloadSource: 99,
                    Provider: undefined,
                    AppType: 99
                },
                page: {
                    total: 100,
                    current: 1,
                    size: 10
                },
                appname: {
                    loading: false,
                    data: []
                }
            },
            table: {
                loading: false,
                data: [],
                columns: [
                    {
                        title: "ID",
                        fixed: "left",
                        width: 80,
                        key: "ID"
                    },
                    {
                        title: "游戏名称",
                        fixed: "left",
                        width: 200,
                        render: (h, params) => {
                            const div = [];
                            if (params.row.IconURL !== "") {
                                let icon = h("Avatar", {
                                    props: {
                                        shape: "square",
                                        src: params.row.AppIcon,
                                        size: "small"
                                    },
                                    style: {
                                        marginRight: "5px"
                                    }
                                });
                                div.push(icon);
                            }
                            if (params.row.ButtonText !== "") {
                                let tag = h("Tag", { props: {} }, params.row.AppName);
                                div.push(tag);
                            }
                            return h("div", div);
                        }
                    },
                    {
                        title: "游戏包名",
                        width: 300,
                        slot: "PkgName"
                        // render: (h, params) => {
                        //   //预约状态下可以修改包名
                        //   if (params.row.Status === 3) {
                        //     return h("div", [
                        //       h("Tag", { props: {} }, params.row.PkgName),
                        //       // h(
                        //       //   "Button",
                        //       //   {
                        //       //     props: {
                        //       //       type: "primary",
                        //       //       size: "small",
                        //       //     },
                        //       //     on: {
                        //       //       click: () => {
                        //       //         this.packageModify.packgeModel = true;
                        //       //         this.packageModify.packageName = params.row.PkgName;
                        //       //         this.packageModify.ID = params.row.ID;
                        //       //       },
                        //       //     },
                        //       //     style: {
                        //       //       marginRight: "5px",
                        //       //     },
                        //       //   },
                        //       //   "修改包名"
                        //       // ),
                        //     ]);
                        //   }
                        //   return h("Tag", { props: {} }, params.row.PkgName);
                        // },
                    },
                    {
                        title: "版本类型",
                        width: 100,
                        render: (h, params) => {
                            //预约状态下可以修改包名
                            if (params.row.ReleaseType === 0) {
                                return h("Tag", { props: { color: "success" } }, "正式");
                            }
                            if (params.row.ReleaseType === 1) {
                                return h("Tag", { props: {} }, "内测");
                            }
                        }
                    },
                    {
                        title: "游戏类型",
                        align: "center",
                        fixed: "left",
                        width: 100,
                        key: "AppType",
                        render: (h, params) => {
                            if (params.row.AppType === 0) {
                                return h("Tag", { props: { color: "default" } }, "游戏");
                            }
                            if (params.row.AppType === 1) {
                                return h("Tag", { props: { color: "default" } }, "应用");
                            }
                        }
                    },
                    {
                        title: "是否静默/预约安装",
                        width: 160,
                        render: (h, params) => {
                            return h("i-switch", {
                                props: {
                                    value: params.row.IsAutoDownload == 1 ? true : false,
                                    size: "small"
                                },
                                on: {
                                    "on-change": value => {
                                        this.updateIsAutoDownload(params.row.ID, value);
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: "游戏分类",
                        width: 200,
                        render: (h, params) => {
                            return h("Tag", { props: {} }, params.row.CategoryName);
                        }
                    },
                    {
                        title: "下载源",
                        align: "center",
                        fixed: "left",
                        width: 100,
                        key: "Status",
                        render: (h, params) => {
                            if (params.row.DownloadSource === 0) {
                                return h("Tag", { props: { color: "default" } }, "黑鲨");
                            }
                            if (params.row.DownloadSource === 1) {
                                return h("Tag", { props: { color: "default" } }, "小米");
                            }
                            if (params.row.DownloadSource === 4) {
                                return h("Tag", { props: { color: "default" } }, "应用宝");
                            }
                        }
                    },
                    {
                        title: "游戏状态",
                        align: "center",
                        fixed: "left",
                        width: 100,
                        key: "Status",
                        render: (h, params) => {
                            if (params.row.Status === 0) {
                                return h("Tag", { props: { color: "warning" } }, "待处理");
                            }
                            if (params.row.Status === 1) {
                                return h("Tag", { props: { color: "success" } }, "上架");
                            }
                            if (params.row.Status === 2) {
                                return h("Tag", { props: { color: "error" } }, "下架");
                            }
                            if (params.row.Status === 3) {
                                return h("Tag", { props: { color: "primary" } }, "预约");
                            }
                        }
                    },
                    {
                        title: "是否允许强制下载",
                        width: 160,
                        render: (h, params) => {
                            return h("i-switch", {
                                props: {
                                    value: params.row.IsForceUpdate,
                                    size: "small"
                                },
                                on: {
                                    "on-change": value => {
                                        this.updateParamStatusByType(params.row.ID, value, 1);
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: "是否禁止搜索",
                        width: 160,
                        render: (h, params) => {
                            return h("i-switch", {
                                props: {
                                    value: params.row.IsSearch,
                                    size: "small"
                                },
                                on: {
                                    "on-change": value => {
                                        this.updateParamStatusByType(params.row.ID, value, 2);
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: "是否屏蔽子论坛",
                        width: 160,
                        render: (h, params) => {
                            return h("i-switch", {
                                props: {
                                    // value: params.row.IsShowForum,
                                    value: this.table.data[params.index].IsShowForum,
                                    size: "small"
                                },
                                on: {
                                    "on-change": value => {
                                        this.updateForum(params.row.ID, value, params.index);
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: "游戏标签",
                        width: 200,
                        key: "Tags",
                        render: (h, params) => {
                            let div = [];
                            if (params.row.Tags) {
                                for (const item of params.row.Tags) {
                                    div.push(h("Tag", {}, item));
                                }
                            }
                            return h("div", div);
                        }
                    },
                    {
                        title: "版本信息",
                        width: 200,
                        align: "center",
                        render: (h, params) => {
                            if (params.row.VersionID === "") {
                                return h("Tag", { props: { color: "error" } }, "暂无版本");
                            }
                            if (params.row.SubType === 0) {
                                return h("Tag", { props: { color: "warning" } }, "游戏预约");
                            }
                            return h("div", [h("Tag", {}, params.row.VersionName), h("Tag", {}, params.row.VersionCode)]);
                        }
                    },
                    { title: "sdk版本名称", width: 150, key: "SdkVersionName" },
                    { title: "sdk版本号", width: 150, key: "SdkVersionCode" },
                    { title: "开发者", width: 200, key: "Provider" },
                    {
                        title: "开服时间",
                        width: 200,
                        key: "FirstLaunchTime",
                        render: (h, params) => {
                            return h("span", formatTime(params.row.FirstLaunchTime) || "暂无开服时间");
                        }
                    },
                    {
                        title: "操作",
                        fixed: "right",
                        width: 250,
                        key: "handle",
                        options: ["edit"],
                        button: [
                            (h, param, vm) => {
                                return h(
                                    "Button",
                                    {
                                        props: {
                                            type: "warning",
                                            size: "small"
                                        },
                                        on: {
                                            click: () => {
                                                this.publishversion(param);
                                            }
                                        },
                                        style: {
                                            marginRight: "5px"
                                        }
                                    },
                                    "增版本"
                                );
                            },
                            (h, param, vm) => {
                                return h(
                                    "Button",
                                    {
                                        props: {
                                            type: "default",
                                            size: "small"
                                        },
                                        on: {
                                            click: () => {
                                                this.showAddGameGif(param);
                                            }
                                        },
                                        style: {
                                            marginRight: "5px"
                                        }
                                    },
                                    "发礼包"
                                );
                            },
                            (h, param, vm) => {
                                return h(
                                    "Button",
                                    {
                                        props: {
                                            type: "error",
                                            size: "small"
                                        },
                                        on: {
                                            click: () => {
                                                this.gameTakeDown(param.row.ID);
                                            }
                                        },
                                        style: {
                                            marginRight: "5px"
                                        }
                                    },
                                    "下架"
                                );
                            }
                        ]
                    }
                ]
            },
            packageModify: {
                loading: true,
                packgeModel: false,
                // typeValue: 1,
                PkgName: "",
                appId: "",
                // gameList: [],
                packageName: "",
                ID: "",
                errorMsg: ""
            },
            dataModify: {
                packgeModel: false,
                package: "",
                name: "",
                appId: "",
                errorMsg: ""
            },
            stateList: [
                {
                    Id: 99,
                    Name: "全部"
                },
                {
                    Id: 0,
                    Name: "待处理"
                },
                {
                    Id: 1,
                    Name: "上架"
                },
                {
                    Id: 2,
                    Name: "下架"
                },
                {
                    Id: 3,
                    Name: "预约"
                }
            ],
            placeList: [
                {
                    Id: 99,
                    Name: "全部"
                },
                {
                    Id: 0,
                    Name: "黑鲨"
                },
                {
                    Id: 1,
                    Name: "小米"
                },
                {
                    Id: 4,
                    Name: "应用宝"
                }
            ],
            postServerData: {
                likeUrl: "LikeAppByParams",
                likeData: {},
                IdKey: "ID",
                NameKey: "PkgName"
            },
            appTypeList: [
                {
                    Id: 99,
                    Name: "全部"
                },
                {
                    Id: 0,
                    Name: "游戏"
                },
                {
                    Id: 1,
                    Name: "应用"
                }
            ],
            postProviderData: {
                likeUrl: "LikeDeveloper",
                likeData: {},
                IdKey: "Name",
                NameKey: "Name"
            }
        };
    },
    methods: {
        //数据迁移
        hadleDataModify(row) {
            GameAPI.checkReleaseVersion(row.ID).then(res => {
                if (res.Code == 0) {
                    let data = res.Data || [];
                    if (data.length > 0) {
                        this.$Message.error("该游戏存在非预约非内测版本，不支持数据迁移");
                    } else {
                        this.dataModify = {
                            package: "",
                            name: "",
                            appId: "",
                            packgeModel: true,
                            ID: row.ID,
                            AppName: row.AppName,
                            PkgName: row.PkgName,
                            errorMsg: ""
                        };
                        this.$nextTick(() => {
                            this.$refs.pakgsearch.clearText();
                        });
                    }
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        //修改包名
        hadlePkgModify(row) {
            if (row.Status != 2) {
                this.$Message.error("请先下架游戏");
                return;
            }
            if (row.AppReporterType == 1) {
                this.$Message.error("仅支持对小米或cms来源游戏修改包名");
                return;
            }
            GameAPI.checkSubVersion(row.ID).then(res => {
                if (res.Code == 0) {
                    let data = res.Data || [];
                    if (data.length > 0) {
                        this.$Message.error("该游戏存在非预约版本，不支持修改包名");
                    } else {
                        this.packageModify = {
                            appId: "",
                            packageName: "",
                            errorMsg: "",
                            packgeModel: true,
                            ID: row.ID,
                            AppName: row.AppName,
                            PkgName: row.PkgName
                        };
                    }
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        //选择包名带出游戏名称和包名
        async changePkgName(value) {
            if (value) {
                this.dataModify.name = value.AppName;
                this.dataModify.package = value.PkgName;
                if (value.AppType != 0) {
                    this.dataModify.errorMsg = "该app类型非游戏，不支持数据迁移";
                    return;
                }
                if (value.AppStatus != 2) {
                    this.dataModify.errorMsg = "该游戏未下线，不支持数据迁移";
                    return;
                }
                if (value.IsAutoDownload == 1) {
                    this.dataModify.errorMsg = "该游戏的“是否静默/预约安装”开关未关闭，不支持数据迁移";
                    return;
                }
                let res = await GameAPI.checkReleaseVersion(value.ID);
                if (res.Code == 0) {
                    let data = res.Data || [];
                    if (data.length > 0) {
                        this.dataModify.errorMsg = "该游戏存在非预约非内测版本，不支持数据迁移";
                        return;
                    }
                }
                this.dataModify.errorMsg = "";
            } else {
                this.dataModify.name = "";
                this.dataModify.package = "";
                this.dataModify.errorMsg = "";
            }
        },
        //提交数据迁移
        commitDataModify() {
            if (!this.dataModify.appId) {
                this.$Message.error("请输入迁出游戏包名");
                return;
            }
            GameAPI.subMergeData({
                MoveOutAppId: this.dataModify.appId,
                MoveInAppId: this.dataModify.ID
            }).then(res => {
                this.dataModify.packgeModel = false;
                if (res.Code == 0) {
                    this.$Modal.success({
                        title: "数据迁移成功",
                        width: 500,
                        content: `<h4>请关注以下事项：</h4>
                         <p>1、迁入游戏的预约用户数是否正确</p>
                        <p>2、迁出游戏若为小米游戏，请决策是否同时上线</p>
                        <p>3、迁出游戏若为黑鲨SDK游戏，请检查迁入/迁出游戏的优惠券是否正常</p>
                        <p>4、请检查迁入/迁出游戏的资源位配置、礼包配置、活动配置</p>
                        <p>5、请检查迁入/迁出游戏的推广黑名单、搜索词管理、重点游戏白名单</p>
                        <p>6、请检查迁入/迁出游戏的预约静默开关、子论坛开关</p>`
                        //             content: `<h4>请关注一下数据项：</h4><p>迁出游戏是否配置黑名单：${res.MoveOutHasShield ? "是" : "否"}</p>
                        // <p>迁入游戏是否配置黑名单：${res.MoveInHasShield ? "是" : "否"}</p>
                        // <p>迁出游戏是否配置搜索页：${res.MoveOutHasSearchConfig ? "是" : "否"}</p>
                        // <p>迁入游戏是否配置搜索页：${res.MoveInHasSearchConfig ? "是" : "否"}</p>`
                    });
                    this.init();
                } else {
                    this.$Modal.error({
                        title: "数据迁移失败，请重试",
                        content: `<h4>失败原因：</h4><p>${res.Message}</p>`
                    });
                }
            });
        },
        //游戏名
        changeAppNameValue(val) {
            if (val) {
                let item = this.searchform.appname.data.filter(v => v.ID == val);
                this.$refs["searchPkgName"].setQuery(item[0].PkgName);
                this.$refs["searchPkgName"].toggleMenu(null, false);
            }
        },
        //包名
        changePkgValue(val) {
            if (val) {
                let item = this.searchform.appname.data.filter(v => v.ID == val);
                this.$refs["searchAppName"].setQuery(item[0].AppName);
                this.$refs["searchAppName"].toggleMenu(null, false);
            }
        },
        handleGameSearch(value) {
            // GameAPI.LikeApp({ value }).then((res) => {
            //   this.searchform.appname.data = res.Data;
            // });
            GameAPI.LikeAppByParams({ params: { AppName: value } }).then(res => {
                this.searchform.appname.data = res.Data;
            });
        },
        handleGamePkgNameSearch(value) {
            GameAPI.LikeAppByParams({ params: { PkgName: value } }).then(res => {
                this.searchform.appname.data = res.Data;
            });
        },
        onPageChange(value) {
            this.searchform.page.current = value;
            this.init();
        },
        onPageSizechange(value) {
            this.searchform.page.current = 1;
            this.searchform.page.size = value;
            this.init();
        },
        openAdd() {
            this.$router.push({
                name: "gamespace_game_add"
            });
        },
        openTag() {
            this.$router.push({
                name: "gamespace_gametag"
            });
        },
        openCategory() {
            this.$router.push({
                name: "gamespace_gamecategory"
            });
        },
        openDeveloper() {
            this.$router.push({
                name: "gamespace_developer"
            });
        },
        closeAdd() {
            this.init();
        },
        edit(params) {
            this.$router.push({
                name: "gamespace_game_edit",
                params: { id: params.row.ID }
            });
        },
        enable(param) {
            GamepAPI.Enable(param.row.ID, !param.row.Enable).then(res => {
                this.init();
            });
        },
        publishversion(params) {
            // 发布版本
            this.$router.push({
                name: "gamespace_gameversion_add",
                params: { id: params.row.ID }
            });
        },
        showAddGameGif(params) {
            this.currentGame = params.row;
            this.currentGame.ShowType = true;
            this.showgifmodal = true;
        },
        closeModel() {
            console.log("fix ...............");
            this.showgifmodal = false;
        },
        updateParamStatusByType(id, status, type) {
            GameAPI.updateParamStatusByType(id, status, type).then(res => {
                if (res.Code == 0) {
                    this.$Message.success("成功");
                } else {
                    this.$Message.error(res.Message);
                }
                this.init();
            });
        },
        updateForum(id, status, index) {
            //是否屏蔽子论坛状态更改
            GameAPI.UpdateForum(id, status).then(res => {
                if (res.Code == 0) {
                    this.$Message.success("成功");
                } else {
                    this.$Message.error(res.Message);
                    this.table.data[index].IsShowForum = !this.table.data[index].IsShowForum;
                }
                this.init();
            });
        },
        updateIsAutoDownload(ID, status) {
            //是否屏蔽子论坛状态更改
            let val = status ? 1 : 2;
            GameAPI.Edit_down(ID, val).then(res => {
                if (res.Code == 0) {
                    this.$Message.success("成功");
                } else {
                    this.$Message.error(res.Message);
                }
                this.init();
            });
        },
        gameTakeDown(id) {
            this.$Modal.confirm({
                title: "下架提醒",
                content: "您确定要 <span style='color:red'>下架</span> 吗？",
                cancelText: "再考虑",
                onOk: () => {
                    GameAPI.GameTakeDown(id).then(res => {
                        if (res.Code == 103) {
                            this.$Message.error(res.Message);
                            return;
                        }
                        this.$Message.success("游戏下架成功");
                        this.init();
                    });
                }
            });
        },
        businessCheck(id, status) {
            GameAPI.BusinessCheck(id, status).then(res => {
                if (res.Code == 103) {
                    this.$Message.error(res.Message);
                    return;
                }
                this.$Message.success("审核成功");
                this.modal_show = false;
                this.init();
            });
        },
        init() {
            let searchData = JSON.parse(JSON.stringify(this.searchform));
            if (searchData.params.AppStatus == 99) {
                searchData.params.AppStatus = undefined;
            }
            if (searchData.params.DownloadSource == 99) {
                searchData.params.DownloadSource = undefined;
            }
            if (searchData.params.AppType == 99) {
                searchData.params.AppType = undefined;
            }
            GameAPI.FindByPage(searchData.page.size, searchData.page.current, searchData.params).then(res => {
                if (res.Code == 0) {
                    // if (res.Data.Data) {
                    this.table.data = res.Data.Data || [];
                    this.$forceUpdate();
                    // }
                    this.searchform.page.total = res.Data.Count;
                }
            });
        },
        handleSubmit() {
            this.$Loading.start();
            this.loading = true;
            this.businessCheck(this.formData.ID, this.formData.CheckStatus);
        },
        //查询游戏名称
        // appGameSearch(value) {
        //   GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        //     this.packageModify.gameList = res.Data;
        //   });
        // },
        //查询游戏包名
        gamePkgNameSearch(value) {
            GameAPI.LikeAppByParams({ params: { PkgName: value } }).then(res => {
                this.packageModify.gameList = res.Data;
            });
        },
        //游戏名
        // changeAppName(val) {
        //   if (val) {
        //     let item = this.packageModify.gameList.filter((v) => v.ID == val);
        //     this.packageModify.PkgName = item[0].PkgName;
        //     this.$refs["packageName"].setQuery(item[0].PkgName);
        //     this.$refs["packageName"].toggleMenu(null, false);
        //   }
        // },
        //包名
        changeValue(val) {
            if (val) {
                this.packageModify.PkgName = val.label;
                let item = this.packageModify.gameList.filter(v => v.ID == val.value);
                this.$refs["AppName"].setQuery(item[0].AppName);
                this.$refs["AppName"].toggleMenu(null, false);
            }
        },
        //确认修改包名
        commitModifyPkgName() {
            if (!this.packageModify.packageName) {
                this.$Message.error("请输入修改游戏包名");
                return;
            }
            GameAPI.editPkgName({
                id: this.packageModify.ID,
                pkgName: this.packageModify.packageName
            }).then(res => {
                if (res.Code == 0) {
                    this.packageModify.packgeModel = false;
                    this.$Modal.success({
                        title: "游戏包名修改成功",
                        width: 500,
                        content: `<p>游戏包名已由${this.packageModify.PkgName}修改为${this.packageModify.packageName}</p>
                                    <p>1、请务必检查游戏资源位、游戏公告、活动是否正常</p>
                                    <p>2、请重新配置推广黑名单、搜索词管理、重点游戏白名单</p>
                                    <p>3、若游戏为黑鲨SDK游戏，务必验证优惠券、支付等功能</p>`
                    });
                    this.init();
                } else {
                    this.packageModify.errorMsg = res.Message || "期望包名已存在/期望包名不可为.shark结尾";
                    this.$Message.error(res.Message || "修改包名失败");
                }
            });
        },
        //小米数据批量导入
        handleUpload(file) {
            console.log(file);
            let nameIndex = file.name.lastIndexOf("."); //取到文件名开始到最后一个点的长度
            let name = file.name.substring(nameIndex + 1);
            if (name != "txt") {
                this.$Message.error("仅支持上传txt格式文件");
                return false;
            }
            let formatFile = new FormData();
            formatFile.append("File", file);
            GameAPI.uploadMiData(formatFile).then(res => {
                if (res.Code == 0) {
                    this.$Message.success("导入成功");
                } else {
                    this.$Message.error(res.Message || "导入失败");
                }
            });
            return false;
        },
        //小米数据批量导出
        handleExport() {
            GameAPI.exportMiData().then(res => {
                let url = res.Data.replace(".", "");
                window.location.href = config.fileBaseUrl + url;
            });
        },
        // sdk 5.5.0新增
        getPersonList() {
            const params = {
                page: 1,
                pageSize: 9999
            };
            commentApi.GetPersonList(params).then(res => {
                if (res.Code == 0) {
                    this.personList = res.Data.List;
                } else {
                    this.$Message.error("获取预警负责人失败");
                }
            });
        }
    },
    mounted() {
        this.table.columns = Tables.RenderColumns(this.table.columns, this);
        this.$on("on-enable", this.enable);
        this.$on("on-delete", this.delete);
        this.$on("on-edit", this.edit);
        this.init();
        this.getPersonList();
        // 注册监听事件
    },
    activated() {
        this.init();
    }
};
</script>
<style lang="less" scoped>
.span-width-one {
    display: inline-block;
    width: 95px;
    text-align: right;
}
.span-width-two {
    display: inline-block;
    width: 150px;
    text-align: right;
}
</style>
