<template>
  <div class="wrap">
    <div style="margin: 10px 0">
      <Button type="primary" @click="showForm(null, 0)">新增</Button>
    </div>

    <!-- Id: 0,
            CreatedAt: 0,
            StartTime: 0,
            EndTime: 0,
            ActivityDayCount: 0,
            Content: "",
            ShowState: 1, -->

    <div class="table-box" style="margin-bottom: 200px">
      <Table border :columns="columns" :data="SignActivityList">

        <template slot="ShowState" slot-scope="{ row }">
          {{ getShowStateString(row.ShowState) }}
        </template>

        <template slot="opt" slot-scope="{ row }">
          <Button
            @click="showForm(row, 1)"
            size="small"
            type="warning"
            class="table-opt"
            >查看</Button
          >
          <Button
            @click="showForm(row, 2)"
            size="small"
            type="primary"
            class="table-opt"
            v-if="row.ShowState == 1 || row.ShowState == 2"
            >编辑</Button
          >
          <Button
            @click="deleteItem(row)"
            size="small"
            type="error"
            v-if="row.ShowState == 1"
            >删除</Button
          >
        </template>
      </Table>



      <Page
        :total="OnePageItemCount * PageSize"
        :current="PageIndex"
        :page-size="OnePageItemCount"
        show-elevator
        show-sizer
        show-total
        @on-change="onPageIndexChange"
        @on-page-size-change="onPageSizeChange"
      />
    </div>

    <Modal
      ref="formShow"
      v-model="formShow"
      @on-ok="submit"
      @on-cancel="cancelSubmit"
    >
      每日登录
      <Form
        ref="dataItemform"
        :model="dataItemform"
        :label-width="160"
        label-position="left"
      >
        <FormItem label="下发游戏:" prop="GameAppId">
          <InputNumber
            v-model="dataItemform.GameAppId"
            v-if="dataItemform.ShowType != 0"
            placeholder="请输入"
            :row="1"
            style="width: 100px"
            :disabled="disabled"
            ref="dataItemform.GameAppId"
          />
          <RadioGroup v-model="dataItemform.ShowType" style="margin: 20px">
            <Radio :label="0" :disabled="disabled">
              <span>所有游戏</span>
            </Radio>
            <Radio :label="1" :disabled="disabled">
              <span>游戏榜单ID</span>
            </Radio>
            <Radio :label="2" :disabled="disabled">
              <span>单个游戏</span>
            </Radio>
          </RadioGroup>
        </FormItem>

        <FormItem label="开始时间：" prop="StartTime">
          <DatePicker
            :disabled="disabled"
            type="datetime"
            placeholder="开始时间"
            v-model="dataItemform.StartTime"
            format="yyyy-MM-dd HH:mm:ss"
          ></DatePicker>
        </FormItem>

        <FormItem label="结束时间" prop="EndTime">
          <DatePicker
            :disabled="disabled"
            type="datetime"
            placeholder="结束时间"
            v-model="dataItemform.EndTime"
            format="yyyy-MM-dd HH:mm:ss"
          ></DatePicker>
        </FormItem>

        <FormItem label="活动标题:">
          <Input
            :disabled="disabled"
            v-model="dataItemform.Title"
            placeholder="请输入"
            :row="1"
            style="width: 200px"
          />
        </FormItem>
        <FormItem label="活动内容:">
          <Input
            :disabled="disabled"
            v-model="dataItemform.Content"
            placeholder="请输入"
            type="textarea"
            :row="4"
            style="width: 400px"
          />
        </FormItem>

        <!-- <FormItem label="优惠券配置:">
          <Input
            v-model="dataItemform.CouponConfig"
            placeholder="请输入"
            type="textarea"
            :row="4"
            style="width: 400px"
          />
        </FormItem> -->

        <form-item label="优惠券配置:" prop="Rules">
          <div v-for="(item, index) in dataItemform.Config" :key="index">
            <Row class="m10">
              <Col :span="5">
                <Col v-if="index == 0">活动天数</Col>
                <Col :span="5">
                  <span style="display: inline-block; min-width: 120px"
                    >{{ index + 1 }}
                  </span>
                </Col>
              </Col>

              <Col :span="10">
                <Col v-if="index == 0">优惠券ID：</Col>
                <Col :span="10">
                  <InputNumber
                    :disabled="disabled"
                    v-model="item['resource_id']"
                    placeholder="请输入优惠券ID"
                    style="display: inline-block; min-width: 120px"
                  ></InputNumber>
                </Col>
              </Col>

              <Col :span="4">
                <Col :span="10" v-if="index == 0">操作</Col>
                <Col :span="24">
                  <Icon
                    class="margin"
                    size="18"
                    color="#2db7f5"
                    type="md-add-circle"
                    @click="!disabled && addInput(index)"
                  />
                  <Icon
                    size="18"
                    color="#5cadff"
                    @click="!disabled && delInput(index)"
                    type="md-trash"
                  />
                </Col>
              </Col>
            </Row>
          </div>
        </form-item>
      </Form>
    </Modal>
  </div>
</template>

<script>
import DailySignApi from "@/api/gamespace/dailySignIn";
import moment from "moment";
export default {
  data() {
    return {
      Next: false,
      PageIndex: 0,
      PageSize: 0,
      OnePageItemCount:10,
      disabled: false,
      pageIndex:1,
      ModalShowType: 0,
      SignActivityList: [],
      columns: [
        { title: "活动ID", key: "Id", minWidth: 100 },
        { title: "创建时间", key: "CreatedAt", minWidth: 100 },
        { title: "开始时间", key: "StartTime", minWidth: 100 },
        { title: "结束时间", key: "EndTime", minWidth: 100 },
        { title: "活动天数", key: "ActivityDayCount", minWidth: 100 },
        { title: "活动主题", key: "Content", minWidth: 100 },
        { title: "状态", slot: "ShowState", minWidth: 100 },

        {
          title: "操作",
          width: 260,
          slot: "opt",
        },
      ],

      formShow: false,
      dataItemform: {
        ActToken: "",
        Id: 0,
        GameAppId:0,
        AppId: 0,
        PkgName: "",
        Title: "",
        Type: 3, //1： 一次性 2：抽奖 3：每日领取活动
        ShowType: 2, //0: 所有游戏 1：榜单游戏 2：单个游戏
        RankId: 0,
        Content: "",
        Config: [
          {
            type: 4,
            resource_id: 0,
          },
          {
            type: 4,
            resource_id: 0,
          },
        ],
        StartTime: "",
        EndTime: "",
        ShowState: 0,
      },
    };
  },

  mounted() {
    this.init();
  },
  methods: {
    init() {
      this.loadList();
    },

    onPageIndexChange(pageIndex) {
      this.pageIndex = pageIndex;
      this.SignActivityList = [];
      this.loadList();
    },
    onPageSizeChange(pageSize) {
      this.pageIndex = 1;
      this.OnePageItemCount = pageSize;
      this.SignActivityList = [];
      this.loadList();
    },

    loadList() {
      var params = { limit: this.OnePageItemCount, page: this.pageIndex, params: { type: 3 } };
      DailySignApi.DailySignActivityList(params).then((res) => {
        if (res.Code === 0) {
          this.Next = res.Data.next;
          this.PageIndex = res.Data.page;
          this.PageSize = res.Data.pageSize;

          var datas = res.Data.data;

          for (let item of datas) {
            var configList = JSON.parse(item.Config);

            var configs = [];
            for (let awardItem of configList.award_item) {
              configs.push({
                type: awardItem.type,
                resource_id: awardItem.resource_id,
              });
            }
            var actItem ={
              ...item,Config:configs,ActivityDayCount: configs.length,
            }
            
            this.SignActivityList.push(actItem);
          }
        }
      });
    },

    getShowStateString(state) {
      if (state == 1) {
        return "未开始";
      } else if (state == 2) {
        return "进行中";
      } else if (state == 3) {
        return "已结束";
      }
      return "";
    },

    deleteItem(row) {
      var params = { id: row.Id };
      DailySignApi.DailySignDelete(params).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("删除成功");
          this.SignActivityList = [];
          this.loadList();
        } else {
          this.$Message.success("删除失败: " + res.Message);
        }
      });
    },

    showForm(row, type) {
      this.ModalShowType = type;
      this.formShow = true;
      if (type == 0) {
        //新增
        this.disabled = false;
        // this.dataItemform.resetFileds();
      } else if (type == 1) {
        //查看
        this.disabled = true;
        // this.dataItemform.AppId = row.AppId;
        // this.dataItemform.PkgName = row.PkgName;
        // this.dataItemform.Title = row.Title;
        // this.dataItemform.Type = row.Type;
        // this.dataItemform.ShowType = row.ShowType;
        // this.dataItemform.Content = row.Content;
        // this.dataItemform.Config = row.Config;
        // this.dataItemform.StartTime = row.StartTime;
        // this.dataItemform.EndTime = row.EndTime;
        // this.dataItemform.ShowState = row.ShowState;
        this.dataItemform = JSON.parse(JSON.stringify(row));

        if (row.ShowType == 1) {
          this.dataItemform.GameAppId = row.RankId;
        } else if (row.ShowType == 2) {
          this.dataItemform.GameAppId = row.AppId;
        } else if (row.ShowType == 0) {
          this.dataItemform.GameAppId = 0;
        }
      } else if (type == 2) {
        //编辑
        this.disabled = false;
        this.dataItemform = JSON.parse(JSON.stringify(row));
        this.dataItemform.StartTime = moment(row.StartTime).format(
          "YYYY-MM-DD HH:mm:ss"
        );
        this.dataItemform.EndTime = moment(row.EndTime).format(
          "YYYY-MM-DD HH:mm:ss"
        );
        this.dataItemform.ShowState = row.ShowState;

        if (row.ShowType == 1) {
          this.dataItemform.GameAppId = row.RankId;
        } else if (row.ShowType == 2) {
          this.dataItemform.GameAppId = row.AppId;
        } else if (row.ShowType == 0) {
          this.dataItemform.GameAppId = 0;
        }
      }
    },
    submit() {
      //   this.updateItem();
      if (this.ModalShowType == 0) {
        //新增
        var AppId = 0;
        var RankId = 0;
        if (this.dataItemform.ShowType == 1) {
          //1：榜单游戏
          RankId = this.dataItemform.GameAppId;
          AppId = 0;
        } else if (this.dataItemform.ShowType == 2) {
          //2：单个游戏
          AppId = this.dataItemform.GameAppId;
          RankId = 0;
        } else if (this.dataItemform.ShowType == 0) {
          //0: 所有游戏
          RankId = 0;
          AppId = 0;
        }

        var configString = JSON.stringify({
          award_item: this.dataItemform.Config,
        });

        var params = {
          AppId: AppId,
          Title: this.dataItemform.Title,
          Type: this.dataItemform.Type,
          ShowType: this.dataItemform.ShowType,
          RankId: RankId,
          Content: this.dataItemform.Content,
          Config: configString,
          StartTime: moment(this.dataItemform.StartTime).format(
            "YYYY-MM-DD HH:mm:ss"
          ),
          EndTime: moment(this.dataItemform.EndTime).format(
            "YYYY-MM-DD HH:mm:ss"
          ),
        };

        DailySignApi.DailySignAddOrUpdate(params).then((res) => {
          if (res.Code === 0) {
            this.$Message.success("添加成功");
            this.SignActivityList = [];
            this.loadList();
          } else {
            // this.$Message.error("添加失败");
            this.$Message.error("添加失败: " + res.Message);
          }
        });
      } else if (this.ModalShowType == 1) {
        //查看
        console.log("查看");
      } else if (this.ModalShowType == 2) {
        //编辑
        var AppId = 0;
        var RankId = 0;
        if (this.dataItemform.ShowType == 1) {
          //1：榜单游戏
          RankId = this.dataItemform.GameAppId;
          AppId = 0;
        } else if (this.dataItemform.ShowType == 2) {
          //2：单个游戏
          AppId = this.dataItemform.GameAppId;
          RankId = 0;
        } else if (this.dataItemform.ShowType == 0) {
          //0: 所有游戏
          RankId = 0;
          AppId = 0;
        }

        var configString = JSON.stringify({
          award_item: this.dataItemform.Config,
        });

        var params = {
          Id: this.dataItemform.Id,
          AppId: AppId,
          Title: this.dataItemform.Title,
          Type: this.dataItemform.Type,
          ShowType: this.dataItemform.ShowType,
          RankId: RankId,
          Content: this.dataItemform.Content,
          Config: configString,
          StartTime: moment(this.dataItemform.StartTime).format(
            "YYYY-MM-DD HH:mm:ss"
          ),
          EndTime: moment(this.dataItemform.EndTime).format(
            "YYYY-MM-DD HH:mm:ss"
          ),
        };

        DailySignApi.DailySignAddOrUpdate(params).then((res) => {
          if (res.Code === 0) {
            this.$Message.success("编辑成功");
            this.SignActivityList = [];
            this.loadList();
          } else {
            this.$Message.error("编辑失败: " + res.Message);
          }
        });
      }
    },
    cancelSubmit() {
      this.$refs["dataItemform"].resetFields();
      //  this.dataItemform['dataItemform'].resetFields();
    },
    addInput(index) {
      var list = this.dataItemform.Config;
      if (list.length >= 30) {
        return;
      }
      var config = { resource_id: 0 ,type:4};
      list.splice(index + 1, 0, config);
    },
    delInput(index) {
      var list = this.dataItemform.Config;
      if (list.length <= 2) {
        return;
      }
      list.splice(index, 1);
    },
  },
};
</script>

<style lang="less" scoped>
.table-opt {
  margin-right: 10px !important;
}
// ivu-modal-wrap{
::v-deep .ivu-modal {
  width: 1000px !important;
}
// }
</style>
