<template>
  <div>
    <Card v-model="visible">
      <h4>{{ isAdd ? "新增公告" : "编辑公告：" + formData.Title }}</h4>
      <Divider></Divider>

      <Form ref="formData" :model="formData" :rules="rules" :label-width="150">
        <FormItem label="公告名称：" prop="Title">
          <Row>
            <i-col :span="10">
              <Input
                type="text"
                v-model="formData.Title"
                placeholder="请输入公告名称"
              ></Input>
            </i-col>
          </Row>
        </FormItem>
        <FormItem label="公告类型：" prop="AnnType">
          <RadioGroup v-model="formData.AnnType" @on-change="annTypeChange">
            <Radio v-for="t in annTypeList" :label="t.value" :key="t.value">
              {{ t.label }}
            </Radio>
          </RadioGroup>
        </FormItem>
        <FormItem label="投放位置：" prop="Placement">
          <RadioGroup v-model="formData.Placement" @on-change="PlacementChange">
            <!-- <Radio
              :label="1"
              v-if="formData.AnnType != 3 && formData.AnnType != 5"
              >发现好游戏</Radio
						>-->
            <Radio
              :label="2"
              v-if="formData.AnnType != 4 && formData.AnnType != 6"
              >游戏SDK</Radio
            >
            <Radio :label="3" v-if="formData.AnnType == 2">开发者平台</Radio>
            <!-- <Radio :label="4" v-if="formData.AnnType == 4">应用商店</Radio> -->
          </RadioGroup>
        </FormItem>
        <FormItem
          v-if="formData.AnnType == 1 || formData.AnnType == 2"
          label="展示用户："
          prop="ShowUserType"
        >
          <RadioGroup v-model="formData.ShowUserType">
            <Radio :label="1">全部用户</Radio>
            <Radio :label="2"
              >仅新用户<span class="tipColor">(第一次登录该游戏)</span></Radio
            >
          </RadioGroup>
        </FormItem>
        <FormItem
          v-if="
            (formData.AnnType == 2 || formData.AnnType == 3) &&
            formData.Placement == 2
          "
          label="是否可跳转："
          prop="IsJump"
        >
          <RadioGroup v-model="formData.IsJump">
            <Radio :label="1">可以</Radio>
            <Radio :label="2">不可以</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem
          label="跳转类型："
          prop="JumpType"
          v-if="
            !(
              formData.IsJump == 2 &&
              formData.Placement == 2 &&
              formData.AnnType == 3
            ) &&
            formData.Placement != 3 &&
            !(formData.AnnType == 2 && formData.Placement == 1)
          "
        >
          <RadioGroup
            v-model="formData.JumpType"
            @on-change="jumpTypeChange"
            v-for="(item, i) in filterJumpList"
            :key="i"
          >
            <Radio :label="item.id">{{ item.label }}</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem
          label="H5跳转链接："
          prop="JumpUrl"
          v-if="
            (formData.Placement == 2 &&
              formData.JumpType == 9 &&
              (formData.AnnType == 1 || formData.AnnType == 3)) ||
            (formData.AnnType == 5 && formData.JumpType == 9)
          "
        >
          <i-col :span="10">
            <Input
              type="text"
              v-model="formData.JumpUrl"
              placeholder="请输入跳转链接"
            />
          </i-col>
        </FormItem>
        <!-- 发现好游戏-H5跳转链接 -->
        <FormItem
          label="H5跳转链接："
          prop="DeepLink"
          v-if="
            formData.Placement == 1 &&
            formData.JumpType == 9 &&
            (formData.AnnType == 1 ||
              formData.AnnType == 4 ||
              formData.AnnType == 6)
          "
        >
          <i-col :span="10">
            <Input
              type="text"
              v-model="formData.DeepLink"
              placeholder="请输入跳转链接"
            />
          </i-col>
        </FormItem>
        <!-- 发现好游戏-论坛帖 -->
        <FormItem
          label="绑定论坛帖："
          prop="DeepLink"
          v-if="formData.JumpType == 12"
        >
          <!-- formData.Placement == 1 &&
            formData.JumpType == 12 &&
					formData.AnnType == 6-->
          <Select
            v-model="formData.JumpTypeID"
            ref="postselect"
            filterable
            remote
            clearable
            placeholder="请输入论坛帖标题"
            :remote-method="getPostList"
            style="width: 400px"
          >
            <Option v-for="item in postList" :value="item.Id" :key="item.Id">
              {{ item.Title }}
            </Option>
          </Select>
        </FormItem>
        <!-- 发现好游戏-重点游戏 -->
        <FormItem
          label="绑定重点游戏："
          prop="JumpTypeID"
          v-if="formData.JumpType == 13"
        >
          <!-- formData.Placement == 1 &&formData.JumpType == 13-->
          <KeyGameSelect
            v-model="formData.JumpTypeID"
            placeholder="请输入重点游戏标题"
            style="width: 300px"
            @on-change="changeKeyGame"
          />
        </FormItem>
        <template v-if="formData.JumpType == 15">
          <FormItem label="绑定活动：">
            <CommonSelect
              v-model="formData.JumpTypeID"
              placeholder="请输入帖子榜单名称"
              :serverData="severData"
            />
          </FormItem>
          <FormItem label="落地页类型：">
            <Selection
              v-model="formData.JumpFloorPageType"
              :clearable="true"
              :dataList="floorList"
              :width="200"
            />
          </FormItem>
        </template>
        <FormItem
          v-if="
            formData.Placement == 2 &&
            formData.JumpType == 1 &&
            formData.AnnType > 2 &&
            formData.AnnType != 5
          "
          label="绑定app："
        >
          <AppSelect
            v-model="formData.JumpTypeID"
            style="width: 200px"
            placeholder="请输入App名称"
            @on-change="appChange"
          ></AppSelect>
        </FormItem>
        <FormItem
          v-if="
            formData.Placement == 2 &&
            (formData.JumpType == 2 || formData.JumpType == 3) &&
            formData.AnnType > 2 &&
            formData.AnnType != 5
          "
          label="绑定跳转活动："
        >
          <ActivitySelect
            v-model="formData.ActivityID"
            :type="activeParams.type"
            @on-change="feedChange"
            placeholder="请输入活动名称"
            style="width: 200px"
          ></ActivitySelect>
        </FormItem>
        <!-- 2021/1/28 add -->
        <template v-if="formData.JumpType == 10">
          <FormItem label="绑定Action包名：">
            <i-col :span="10">
              <Input
                v-model="formData.DeepLinkPkgName"
                placeholder="请填写包名"
              />
            </i-col>
          </FormItem>
          <FormItem label="绑定ActionUrl：">
            <i-col :span="10">
              <Input
                v-model="formData.DeepLink"
                placeholder="请填写ActionUrl"
              />
            </i-col>
          </FormItem>
        </template>
        <!--公告类型为banner公告时需选择-->
        <template
          v-if="
            formData.AnnType == 1 ||
            formData.AnnType == 5 ||
            formData.AnnType == 6
          "
        >
          <FormItem label="Banner：" class="ivu-form-item-required">
            <div
              style="
                display: inline-block;
                margin-right: 20px;
                text-align: center;
              "
            >
              <FormItem prop="ImgUrl">
                <p v-if="formData.Placement == 2 || formData.AnnType == 5">
                  横版
                </p>
                <p
                  v-if="
                    (formData.AnnType == 1 || formData.AnnType == 6) &&
                    formData.Placement == 1
                  "
                >
                  静态图
                </p>
                <UploadImg
                  v-model="formData.ImgUrl"
                  module="gamespace"
                ></UploadImg>
              </FormItem>
            </div>
            <div
              v-if="formData.Placement == 2 || formData.AnnType == 5"
              style="display: inline-block; text-align: center"
            >
              <FormItem prop="ImgUrlVertical">
                <p>竖版</p>
                <UploadImg
                  v-model="formData.ImgUrlVertical"
                  module="gamespace"
                ></UploadImg>
              </FormItem>
            </div>
            <div
              v-if="
                (formData.AnnType == 1 || formData.AnnType == 6) &&
                formData.Placement == 1
              "
              style="display: inline-block; text-align: center"
            >
              <FormItem prop="GifImgUrl">
                <p>gif图</p>
                <UploadImg
                  v-model="formData.GifImgUrl"
                  module="gamespace"
                ></UploadImg>
              </FormItem>
            </div>
          </FormItem>
          <FormItem v-if="formData.JumpType == 1" label="绑定app：">
            <AppSelect
              v-model="formData.JumpTypeID"
              style="width: 200px"
              placeholder="请输入App名称"
              @on-change="appChange"
            ></AppSelect>
          </FormItem>
          <FormItem
            v-if="formData.JumpType == 2 || formData.JumpType == 3"
            label="绑定跳转活动："
          >
            <ActivitySelect
              v-model="formData.ActivityID"
              :type="activeParams.type"
              @on-change="feedChange"
              placeholder="请输入活动名称"
              style="width: 200px"
            ></ActivitySelect>
          </FormItem>
          <template v-if="formData.JumpType == 4">
            <FormItem label="榜单类型：">
              <Select v-model="rankParams.type" clearable style="width: 200px">
                <Option
                  v-for="item in rankTypeList"
                  :value="item.id"
                  :key="item.id"
                  >{{ item.name }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="绑定榜单：">
              <RankSelect
                :rankType="rankParams.type"
                v-model="formData.JumpTypeID"
                placeholder="请输入榜单名称"
                style="width: 200px"
              ></RankSelect>
            </FormItem>
          </template>
          <template v-if="formData.JumpType == 5">
            <FormItem label="绑定DeepLink包名：">
              <i-col :span="5">
                <Input
                  v-model="formData.DeepLinkPkgName"
                  placeholder="请填写包名"
                ></Input>
              </i-col>
            </FormItem>
            <FormItem label="绑定DeepLink：">
              <i-col :span="5">
                <Input
                  v-model="formData.DeepLink"
                  placeholder="请填写DeepLink"
                ></Input>
              </i-col>
            </FormItem>
          </template>
          <FormItem v-if="formData.JumpType == 6" label="绑定专题：">
            <Select
              v-model="formData.JumpTypeID"
              clearable
              filterable
              remote
              :remote-method="handleThematicSearch"
              placeholder="请输入专题名称"
              style="width: 200px"
            >
              <Option v-for="s in resourceList" :value="s.ID" :key="s.ID">
                {{ s.Title }}
              </Option>
            </Select>
          </FormItem>
          <!-- <FormItem label="发现好游戏版本类型：" v-if="formData.AnnType != 5">
            <Select
              v-model="formData.FindGameType"
              style="width: 200px"
              clearable
            >
              <Option v-for="s in findGameTypeList" :value="s.ID" :key="s.ID">{{
                s.Title
              }}</Option>
            </Select>
					</FormItem>-->
          <!-- </template> -->
        </template>

        <!--公告类型为2时需选择-->
        <template v-if="formData.AnnType == 2">
          <FormItem
            v-if="formData.IsJump == 1 && formData.JumpType == 5"
            label="绑定DeepLink："
          >
            <i-col :span="5">
              <Input
                v-model="formData.DeepLink"
                placeholder="请填写DeepLink"
              ></Input>
            </i-col>
          </FormItem>
          <FormItem label="选择文章：">
            <ActivitySelect
              v-model="formData.ResourceID"
              @on-change="getResource"
              :type="activeParams.type"
              placeholder="请输入文章名称"
              style="width: 200px"
            ></ActivitySelect>
          </FormItem>
        </template>
        <!--公告类型为3时需选择-->
        <template v-if="formData.AnnType == 3">
          <FormItem label="公告内容：" prop="Content">
            <Row>
              <i-col :span="10">
                <Input
                  type="text"
                  v-model="formData.Content"
                  placeholder="请输入公告内容"
                ></Input>
              </i-col>
            </Row>
          </FormItem>

          <FormItem
            v-if="formData.IsJump == 1 && formData.JumpType == 5"
            label="绑定DeepLink包名："
          >
            <i-col :span="5">
              <Input
                v-model="formData.DeepLinkPkgName"
                placeholder="请填写包名"
              ></Input>
            </i-col>
          </FormItem>
          <FormItem
            v-if="formData.IsJump == 1 && formData.JumpType == 5"
            label="绑定DeepLink："
          >
            <i-col :span="5">
              <Input
                v-model="formData.DeepLink"
                placeholder="请填写DeepLink"
              ></Input>
            </i-col>
          </FormItem>
          <FormItem label="播放时长：" prop="PlayTime">
            <Row>
              <i-col :span="2">
                <Input v-model="formData.PlayTime" type="number"></Input>
              </i-col>
              <i-col :span="1" align="center">秒</i-col>
            </Row>
          </FormItem>
        </template>
        <!--公告类型为4时需选择-->
        <template v-if="formData.AnnType == 4">
          <FormItem label="Banner：" class="ivu-form-item-required">
            <div
              style="
                display: inline-block;
                margin-right: 20px;
                text-align: center;
              "
            >
              <FormItem prop="ImgUrlVertical">
                <UploadImg
                  v-model="formData.ImgUrlVertical"
                  module="gamespace"
                ></UploadImg>
              </FormItem>
            </div>
          </FormItem>

          <FormItem v-if="formData.JumpType == 1" label="绑定app：">
            <AppSelect
              v-model="formData.JumpTypeID"
              style="width: 200px"
              placeholder="请输入App名称"
              @on-change="appChange"
            ></AppSelect>
          </FormItem>
          <FormItem
            v-if="formData.JumpType == 2 || formData.JumpType == 3"
            label="绑定跳转活动："
          >
            <i-col :span="5">
              <ActivitySelect
                v-model="formData.ActivityID"
                :type="activeParams.type"
                @on-change="feedChange"
                placeholder="请输入活动名称"
                style="width: 200px"
              ></ActivitySelect>
            </i-col>
          </FormItem>
          <template v-if="formData.JumpType == 4">
            <FormItem label="榜单类型：">
              <i-col :span="5">
                <Select v-model="rankParams.type" clearable>
                  <Option
                    v-for="item in rankTypeList"
                    :value="item.id"
                    :key="item.id"
                    >{{ item.name }}</Option
                  >
                </Select>
              </i-col>
            </FormItem>
            <FormItem label="绑定榜单：">
              <i-col :span="5">
                <RankSelect
                  :rankType="rankParams.type"
                  v-model="formData.JumpTypeID"
                  @on-change="getrank"
                  placeholder="请输入榜单名称"
                  style="width: 200px"
                ></RankSelect>
              </i-col>
            </FormItem>
          </template>
          <template v-if="formData.JumpType == 5">
            <FormItem label="绑定DeepLink包名：">
              <i-col :span="5">
                <Input
                  v-model="formData.DeepLinkPkgName"
                  placeholder="请填写包名"
                ></Input>
              </i-col>
            </FormItem>
            <FormItem label="绑定DeepLink：">
              <i-col :span="5">
                <Input
                  v-model="formData.DeepLink"
                  placeholder="请填写DeepLink"
                ></Input>
              </i-col>
            </FormItem>
          </template>
        </template>
        <!-- <FormItem
          label="失效时间："
          prop="ExpiredDate"
          v-if="formData.Placement == 2"
        >
          <DatePicker
            type="datetime"
            :value="formData.ExpiredDate"
            format="yyyy-MM-dd HH:mm:ss"
            placeholder="请选择截止时间"
            style="width: 200px"
            @on-change="(value) => (formData.ExpiredDate = value)"
          ></DatePicker>
				</FormItem>-->
        <!-- 人群定向id -->
        <FormItem v-if="formData.Placement == 2" label="人群定向id：">
          <InputNumber
            :min="0"
            style="width: 200px"
            placeholder="请输入人群包id"
            v-model="formData.CrowdId"
          ></InputNumber>
        </FormItem>
        <FormItem label="机型定向:" v-if="formData.Placement == 2">
          <Select v-model="formData.SupportModel" multiple style="width: 200px">
            <Option
              v-for="item in modelList"
              :value="item.value"
              :key="item.value"
              >{{ item.label }}</Option
            >
          </Select>
        </FormItem>
        <FormItem label="生效周期：" prop="Expired">
          <DateRange
            v-model="formData.Expired"
            @on-change="
              (value) => {
                formData.StartTime = value.start;
                formData.ExpiredDate = value.end;
              }
            "
          />
        </FormItem>
        <FormItem label="展示频率：" prop="ShowFrequency">
          <RadioGroup v-model="formData.ShowFrequency">
            <Radio :label="1">仅展示一次</Radio>
            <Radio :label="2">每次均展示</Radio>
            <Radio :label="3">每天仅展示一次</Radio>
          </RadioGroup>
        </FormItem>
        <!--投放位置为游戏SDK时-->
        <FormItem
          v-if="formData.Placement == 2 && formData.AnnType != 5"
          label="展示范围："
          prop="ShowType"
        >
          <RadioGroup v-model="formData.ShowType">
            <Radio :label="1">全部游戏</Radio>
            <Radio :label="2">选择部分游戏</Radio>
            <Radio :label="3">排除单款游戏</Radio>
            <Radio :label="4">排除部分游戏</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem
          label="榜单id："
          v-if="formData.Placement == 2 && formData.ShowType == 4"
        >
          <InputNumber
            :min="0"
            style="width: 200px"
            placeholder="请输入榜单id"
            v-model="formData.RankId"
          ></InputNumber>
        </FormItem>
        <FormItem
          v-if="
            formData.Placement == 2 &&
            (formData.ShowType == 2 || formData.ShowType == 3)
          "
          label="选择游戏："
          prop="GameIDs"
        >
          <Select
            v-model="formData.GameIDs"
            multiple
            clearable
            filterable
            remote
            :remote-method="handleGamesSearch"
            placeholder="请输入游戏名称"
            style="width: 400px"
          >
            <Option v-for="j in gameList" :value="j.ID" :key="j.ID">
              {{ j.AppName }}
            </Option>
          </Select>
        </FormItem>

        <FormItem label="自动安装：">
          <Checkbox v-model="formData.AutoInstall">是</Checkbox>
        </FormItem>

        <FormItem>
          <Button @click="submitcheck()" type="primary" style="width: 100px"
            >提交</Button
          >
          <Button @click="cancel()" style="margin-left: 40px">取消</Button>
        </FormItem>
      </Form>
    </Card>
  </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";
import UploadImg from "_c/shark-upload/index.vue";
import GameAPI from "@/api/gamespace/game";
import PostApi from "@/api/gameCircle/postManagement";
import ThematicApi from "@/api/gamespace/thematic";
import AnnounceAPI from "@/api/gamespace/announce";
import RankSelect from "_c/rank-select";
import AppSelect from "_c/app-select";
import ActivitySelect from "_c/activity-select";
import KeyGameSelect from "_c/keygame-select";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";
import CommonSelect from "_c/common-select";
import Selection from "_c/Selection";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";
export default {
  name: "edit",
  components: {
    UploadImg,
    RankSelect,
    AppSelect,
    ActivitySelect,
    KeyGameSelect,
    DateRange,
    CommonSelect,
    Selection,
  },
  data() {
    return {
      visible: false,
      isAdd: true,
      activeParams: {
        type: undefined,
      },
      rankParams: {
        type: undefined,
      },
      formData: {
        ID: undefined,
        Content: "",
        Title: "",
        AnnType: 1,
        Placement: 2,
        ImgUrl: "",
        ImgUrlVertical: "", //竖版图片
        ResourceID: undefined,
        JumpType: 1,
        AutoInstall: false,
        JumpTypeID: undefined,
        ShowFrequency: 1,
        ShowType: 1,
        RankId: 0,
        DeepLink: "",
        DeepLinkPkgName: "",
        ExpiredDate: "",
        IsJump: 1,
        PlayTime: undefined,
        GameIDs: [],
        FindGameType: undefined,
        ActivityID: undefined,
        GifImgUrl: "",
        Expired: [], //4.7迭代增加生效周期
        CrowdId: 0, // sdk增加人群定向id
        SupportModel: "ALL", // sdk新增可选机型
        ShowUserType: 1, // sdk 5.6.0新增
      },
      JumpTypeList: [
        { id: 1, label: "App详情" },
        { id: 2, label: "H5活动" },
        { id: 3, label: "文章详情" },
        { id: 4, label: "榜单" },
        { id: 5, label: "DeepLink" },
        { id: 7, label: "GameBar优惠券" },
        { id: 8, label: "GameBar游戏礼包" },
        { id: 9, label: "H5" },
        { id: 10, label: "action" },
        { id: 11, label: "GameBar优惠券-已领" },
        { id: 12, label: "论坛帖" },
        { id: 13, label: "重点游戏宣传" },
        { id: 15, label: "帖子榜单" },
      ],
      rankTypeList: [
        { id: 1, name: "普通榜单" },
        { id: 2, name: "排行榜单" },
        { id: 3, name: "预约榜单" },
        { id: 4, name: "分类榜单" },
        { id: 5, name: "标签榜单" },
        { id: 6, name: "飙升榜单" },
      ],
      // 内容类型
      annTypeList: [
        { value: 1, label: "Banner公告" },
        { value: 2, label: "文章公告" },
        { value: 3, label: "走马灯公告" },
        // { value: 4, label: "开屏公告" },
        { value: 5, label: "SDK退出弹窗" },
        // { value: 6, label: "悬浮球" },
      ],
      findGameTypeList: [
        { ID: 1, Title: "横版" },
        { ID: 2, Title: "竖版" },
      ],
      resourceList: [],
      gameList: [],
      rules: {
        Title: [{ required: true, message: "请填写名称", trigger: "blur" }],
        ImgUrl: [{ required: true, message: "请上传", trigger: "blur" }],
        ImgUrlVertical: [
          { required: true, message: "请上传", trigger: "blur" },
        ],
        ExpiredDate: [
          {
            required: true,
            // type: "date",
            message: "请设置失效时间",
            trigger: "blur",
          },
        ],
        Expired: [
          {
            validator: checkDateRange,
            trigger: "change",
            type: "array",
          },
        ],
      },
      postList: [],
      floorList: [
        { Id: 9, Name: "帖子列表落地页" },
        { Id: 10, Name: "图文资讯落地页" },
        { Id: 11, Name: "内容轮播落地页" },
      ], //4.7迭代新增
      modelList: [],
    };
  },
  async mounted() {
    await this.getPhoneList();
    this.$nextTick(() => {
      this.editInit();
    });
  },
  computed: {
    nowTime() {
      return formatTimes(new Date());
    },
    filterJumpList() {
      let arr = [1, 2, 3, 4, 5, 7, 8, 9];
      let AnnType = this.formData.AnnType;
      let Placement = this.formData.Placement;
      if (
        (AnnType == 1 && Placement == 1) ||
        (AnnType == 4 && Placement == 1)
      ) {
        arr = [1, 2, 3, 4, 5, 9, 10, 13, 15];
      }
      if (AnnType == 4 && Placement == 4) {
        arr = [1, 2, 3, 4, 5];
      }
      if (AnnType == 2 && Placement == 2) {
        arr = [5];
      }
      if (AnnType == 3 && Placement == 2) {
        arr = [1, 2, 3, 5, 7, 8, 9, 11];
      }
      if (AnnType == 1 && Placement == 2) {
        arr.push(11);
      }
      if (AnnType == 6 && Placement == 1) {
        arr = [1, 2, 3, 4, 5, 9, 12, 13, 15];
      }

      return this.JumpTypeList.filter((item) => arr.includes(item.id));
    },
    severData() {
      if (this.formData.JumpType == 15) {
        return {
          likeUrl: "PostRankLike",
          likeData: { status: 1 },
          setUrl: "getPostRank",
          setData: {},
          IdKey: "Id",
          NameKey: "Title",
        };
      }
      return {};
    },
  },
  methods: {
    // sdk5.5.0新增机型筛选
    async getPhoneList() {
      GameAPI.getPhoneModel().then((res) => {
        if (res.Code == 0) {
          this.modelList = res.Data.map((item) => {
            return {
              value: item.Name,
              label: item.Name,
            };
          });
          this.modelList.unshift({
            value: "ALL",
            label: "全部",
          });
        }
      });
    },
    changeKeyGame(value) {
      if (value && value.value) {
        this.formData.JumpUrl = value.value.FeedURL;
      }
    },
    getPostList(value) {
      PostApi.titleLike(value).then((res) => {
        if (res.Code == 0) {
          this.postList = res.Data || [];
        }
      });
    },
    getActivity({ value, index }) {
      if (index >= 0) {
        this.formData.ActivityID = value.value;
        this.formData.JumpTypeID = value.FeedID;
      }
    },
    getResource({ value, index }) {
      if (index >= 0) {
        this.formData.ResourceID = value.value;
        this.formData.JumpTypeID = value.FeedID;
      }
    },
    getrank({ value, index }) {
      if (index == 0) this.rankParams.type = value.RankType;
    },
    editInit() {
      let editData = this.$route.params.editData;
      if (editData) {
        this.isAdd = false;
        editData = JSON.parse(editData);
        editData.Expired = [editData.StartTime, editData.ExpiredDate]; //4.7迭代增加生效周期
        if (
          editData.Placement == 2 &&
          (editData.ShowType == 2 || editData.ShowType == 3)
        ) {
          this.gameList = [];
          GameAPI.GetGames(editData.GameIDs).then((res) => {
            this.gameList = res.Data;
          });
        }
        if (
          [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15].includes(
            editData.JumpType
          )
        ) {
          if (editData.JumpType == 2) {
            this.activeParams.type = 2;
          } else if (editData.JumpType == 3) {
            this.activeParams.type = 1;
          }
          if (editData.AnnType == 2) {
            this.activeParams.type = 1;
          }
          let form = JSON.parse(JSON.stringify(editData));
          this.formData = form;
        } else if (editData.JumpType == 6) {
          ThematicApi.ThematicOne(editData.JumpTypeID).then((res) => {
            let form = JSON.parse(JSON.stringify(editData));
            this.resourceList = [res.Data || {}];
            this.formData = form;
          });
        } else if (editData.JumpType == 12) {
          this.formData = JSON.parse(JSON.stringify(editData));
          //论坛帖数据初始化
          PostApi.getPostList({
            Limit: 10,
            Page: 1,
            PostId: editData.JumpTypeID,
          }).then((res) => {
            if (res.Code == 0) {
              this.postList = res.Data.Data || [];
              this.$refs["postselect"].setQuery(res.Data.Data[0]["Title"]);
              this.$refs["postselect"].toggleMenu(null, false);
            }
          });
        } else {
          this.formData = {};
        }
        if (editData.Placement == 2) {
          if (editData.SupportModel.length === 0) {
            this.formData.SupportModel = ["ALL"];
          } else {
            this.formData.SupportModel = editData.SupportModel;
          }
        }
        if (editData.ShowType != 4) {
          this.formData.RankId = 0;
        }
        this.visible = true;
      }
    },

    annTypeChange(val) {
      if (val == 1) {
        // this.formData.Placement = 1;
        this.formData.JumpType = 1;
        this.formData.ShowFrequency = 2;
        this.formData.ShowType = undefined;
      } else if (val == 2) {
        this.formData.FindGameType = undefined;
        this.rankParams.type = 1;
        // this.formData.Placement = 1;
        this.formData.ShowType = 1;
        this.activeParams.type = 1;
        this.formData.JumpType = 0;
      } else if (val == 3) {
        this.formData.FindGameType = undefined;
        // this.formData.Placement = 2;
        this.formData.JumpType = 1;
        this.formData.IsJump = 1;
        this.formData.ShowType = undefined;
      } else if (val == 4) {
        this.formData.FindGameType = undefined;
        // this.formData.Placement = 1;
        this.formData.JumpType = 1;
        this.formData.ShowFrequency = 2;
        this.formData.ShowType = undefined;
      } else if (val == 5) {
        // this.formData.Placement = 2;
        this.formData.JumpType = 1;
      } else if (val == 6) {
        // this.formData.Placement = 1;
        this.formData.JumpType = 1;
      }
      this.formData.Placement = 2;
    },
    PlacementChange() {
      if (this.formData.AnnType == 1 || this.formData.AnnType == 4) {
        this.formData.JumpType = 1;
      }
    },
    jumpTypeChange(val) {
      if (val == 2) {
        this.activeParams.type = 2;
      } else if (val == 3) {
        this.activeParams.type = 1;
      }
    },

    handleGamesSearch(value) {
      if (!parseInt(value)) {
        GameAPI.LikeApp({ value }).then((res) => {
          this.gameList = res.Data;
        });
      }
    },
    handleGameSearch(value) {
      if (!parseInt(value)) {
        GameAPI.LikeApp({ value }).then((res) => {
          this.resourceList = res.Data;
        });
      }
    },
    feedChange({ value, index }) {
      if (index) {
        this.formData.DeepLink = value.FeedURL;
      }
      this.formData.JumpTypeID = value.FeedID;
    },

    appChange({ value, index }) {
      if (index) this.formData.JumpPkgName = value.PkgName;
    },

    handleRankSearch(value) {
      if (!parseInt(value)) {
        HomeModuleAPI.LikeRank(value).then((res) => {
          this.resourceList = res.Data;
        });
      }
    },
    handleThematicSearch(value) {
      if (!parseInt(value)) {
        ThematicApi.Like(value).then((res) => {
          this.resourceList = res.Data;
        });
      }
    },
    cancel() {
      this.$router.push({
        name: "gamespace_announce",
      });
    },
    submitcheck() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          if (!this.formData.StartTime || !this.formData.ExpiredDate) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitForm();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitForm();
          }
        }
      });
    },
    submitForm() {
      this.formData.JumpTypeID = Number(this.formData.JumpTypeID);
      let params = JSON.parse(JSON.stringify(this.formData));
      console.log(params);
      //现支持生效周期
      params.StartTime = params.StartTime || this.nowTime;
      params.ExpiredDate = params.ExpiredDate || "2099-01-01 00:00:00";
      params.SupportModel.map((item) => {
        if (item == "ALL") {
          params.SupportModel = [];
        }
      });
      if (params.AnnType == 1 || params.AnnType == 5 || params.AnnType == 6) {
        params.ImgUrl = this.formData.ImgUrl;
      } else {
        params.ImgUrl = "";
      }
      if (!params.CrowdId) {
        params.CrowdId = 0;
      }
      if (!params.RankId) {
        params.RankId = 0;
      }
      params.PlayTime = Number(params.PlayTime) || 0;
      this.modelApi(params).then((res) => {
        if (res.Code === 0) {
          this.cancel();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    modelApi(params) {
      if (this.isAdd) {
        return AnnounceAPI.AddAnnounce(params);
      } else {
        return AnnounceAPI.EditAnnounce(params.ID, params);
      }
    },
  },
};
</script>

<style scoped>
.tipColor {
  color: rgba(0, 0, 0, 0.3);
}
</style>
