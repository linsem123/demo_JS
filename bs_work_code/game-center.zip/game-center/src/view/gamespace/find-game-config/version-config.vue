<template>
  <div>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">普通版本</p>
          <Form :model="commonVersionForm" :label-width="80">
            <FormItem label="游戏包名:">
              <Input
                v-model="commonVersionForm.PkgName"
                placeholder="游戏包名"
                style="width: 200px"
                disabled
              ></Input>
            </FormItem>
            <FormItem label="版本号:">
              <Select
                v-model="commonVersionForm.versionCode"
                @on-change="commonVersionCodeChange"
                clearable
                style="width: 200px"
                placeholder="请选择版本"
              >
                <Option
                  v-for="(item, index) in commonVersionCodes"
                  :value="item.VersionCode"
                  :key="index"
                  >{{ item.VersionCode }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="版本名称:">
              <Input
                v-model="commonVersionForm.versionName"
                placeholder="游戏包名"
                style="width: 200px"
                disabled
              ></Input>
            </FormItem>
            <FormItem>
              <Button type="primary" @click="handleCommonSubmit">提交</Button>
            </FormItem>
          </Form>
        </Card>
      </Col>
      <Col span="11" offset="2">
        <Card shadow>
          <p slot="title">MI UI 版本</p>
          <Form :model="miVersionForm" :label-width="80">
            <FormItem label="游戏包名:">
              <Input
                v-model="miVersionForm.PkgName"
                placeholder="游戏包名"
                style="width: 200px"
                disabled
              ></Input>
            </FormItem>
            <FormItem label="版本号:">
              <Select
                v-model="miVersionForm.versionCode"
                @on-change="miVersionCodeChange"
                clearable
                style="width: 200px"
                placeholder="请选择版本"
              >
                <Option
                  v-for="(item, index) in miVersionCodes"
                  :value="item.VersionCode"
                  :key="index"
                  >{{ item.VersionCode }}</Option
                >
              </Select>
            </FormItem>
            <FormItem label="版本名称:">
              <Input
                v-model="miVersionForm.versionName"
                placeholder="游戏包名"
                style="width: 200px"
                disabled
              ></Input>
            </FormItem>
            <FormItem>
              <Button type="primary" @click="handleMiSubmit">提交</Button>
            </FormItem>
          </Form>
        </Card>
      </Col>
    </Row>
    <Row style="background: #eee; padding: 20px">
      <Col span="11">
        <Card :bordered="false">
          <p slot="title">普通版本更新提示</p>
          <updateCard :initdata="comUpdateForm" />
        </Card>
      </Col>
      <Col span="11" offset="2">
        <Card shadow>
          <p slot="title">MIUI版本更新提示</p>
          <updateCard :initdata="miUpdateForm" />
        </Card>
      </Col>
    </Row>
  </div>
</template>

<script>
import GameVersionAPI from "@/api/gamespace/gameversion";
import GameAPI from "@/api/gamespace/game";
import updateCard from "./updateCard.vue";
export default {
  name: "version-config",
  components: { updateCard },
  data() {
    return {
      commonVersionCodes: [],
      miVersionCodes: [],
      commonVersionForm: {
        PkgName: "",
        versionID: "",
        versionCode: undefined,
        versionName: "",
      },
      miVersionForm: {
        PkgName: "",
        versionID: "",
        versionCode: undefined,
        versionName: "",
      },
      // 普通版本更新提示
      comUpdateForm: {},
      miUpdateForm: {},
    };
  },
  methods: {
    init() {
      GameAPI.AppInfo().then((res) => {
        this.commonVersionForm.PkgName = res.Data.CommonVersion.PkgName;
        this.commonVersionForm.versionCode = res.Data.CommonVersion.VersionCode;
        this.commonVersionForm.versionName = res.Data.CommonVersion.VersionName;
        this.commonVersionForm.versionID = res.Data.CommonVersion.ID;
        this.miVersionForm.PkgName = res.Data.MIVersion.PkgName;
        this.miVersionForm.versionCode = res.Data.MIVersion.VersionCode;
        this.miVersionForm.versionID = res.Data.MIVersion.ID;
        this.miVersionForm.versionName = res.Data.MIVersion.VersionName;
      });
      GameVersionAPI.getUpdateConfig({
        Page: 1,
        Limit: 2,
        Params: { PkgName: "com.blackshark.bsamagent" },
      }).then((res) => {
        if (res.Code == 0) {
          let data = res.Data.Data || [];
          data.forEach((val) => {
            val.VersionCode > 10000
              ? (this.miUpdateForm = val)
              : (this.comUpdateForm = val);
          });
        }
      });
    },
    commonVersionCodeChange(value) {
      this.commonVersionForm.versionName = value.VersionName;
    },
    miVersionCodeChange(value) {
      this.miVersionForm.versionName = value.VersionName;
    },
    initCommonVersionCode() {
      GameVersionAPI.FindGameVersionList().then((res) => {
        this.commonVersionCodes = res.Data.Common;
        this.miVersionCodes = res.Data.MI;
        this.init();
      });
    },
    handleCommonSubmit() {
      GameVersionAPI.CheckStatus(this.commonVersionForm.versionID, {
        AppStatus: 1,
        Opinion: "",
      }).then((res) => {
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Message.success("修改成功!");
      });
    },
    handleMiSubmit() {
      GameVersionAPI.CheckStatus(this.miVersionForm.versionID, {
        AppStatus: 1,
        Opinion: "",
      }).then((res) => {
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Message.success("修改成功!");
      });
    },
  },
  created() {
    this.initCommonVersionCode();
  },
};
</script>

<style scoped>
</style>
