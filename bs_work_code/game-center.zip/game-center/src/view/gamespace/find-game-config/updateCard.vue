<template>
  <Form :model="updateForm" :label-width="100">
    <FormItem label="版本名:">
      <Input
        v-model="updateForm.VersionName"
        placeholder="版本名"
        style="width: 200px"
        disabled
      />
    </FormItem>
    <FormItem label="更新弹窗类型:">
      <RadioGroup v-model="updateForm.PopupType" @on-change="changePopup">
        <Radio v-for="item of popupList" :key="item.id" :label="item.id">{{
          item.label
        }}</Radio>
      </RadioGroup>
    </FormItem>
    <FormItem label="展示频率:" v-if="updateForm.PopupType != 3">
      <RadioGroup v-model="updateForm.UpdateRate">
        <Radio
          v-for="item of rateList"
          :key="item.id"
          :label="item.id"
          :disabled="updateForm.PopupType == 2"
          >{{ item.label }}</Radio
        >
      </RadioGroup>
    </FormItem>

    <FormItem>
      <Button type="primary" @click="handleMiSubmit">提交</Button>
    </FormItem>
  </Form>
</template>
<script>
import GameVersionAPI from "@/api/gamespace/gameversion";
export default {
  name: "UpdateCard",
  props: {
    initdata: Object,
  },
  data() {
    return {
      updateForm: {
        VersionName: "",
        PopupType: 3,
        UpdateRate: undefined,
        VersionCode: "",
        PkgName: "com.blackshark.bsamagent",
      },
      rateList: [
        { id: 1, label: "仅展示一次" },
        { id: 2, label: "每次均展示" },
        { id: 3, label: "每天仅一次" },
      ],
      popupList: [
        { id: 1, label: "提示更新弹" },
        { id: 2, label: "强制更新弹" },
        { id: 3, label: "不开启" },
      ],
    };
  },
  watch: {
    initdata: {
      handler(v, o) {
        this.updateForm = JSON.parse(JSON.stringify(v));
      },
      immediate: true,
    },
  },
  methods: {
    changePopup(val) {
      if (val == 1) {
        this.updateForm.UpdateRate = 1;
      } else if (val == 2) {
        this.updateForm.UpdateRate = 2;
      } else if (val == 3) {
        this.updateForm.UpdateRate = undefined;
      }
    },
    handleMiSubmit() {
      GameVersionAPI.setUpdateConfig(this.updateForm).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("提交成功");
        } else {
          this.$Message.error(res.Message || "提交失败");
        }
      });
    },
  },
};
</script>