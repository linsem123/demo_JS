<template>
  <div>
    <Form :inline="true">
      <FormItem>
        <GameSelect
          v-model="page.params.AppId"
          style="width: 200px"
          placeholder="请输入App名称"
          @on-change="selectAction"
        />
      </FormItem>
      <FormItem label="游戏包名：" :label-width="100">
        {{pkgName}}
      </FormItem>
      <FormItem>
        <Button type="primary" @click="handleSearch">查询</Button>
      </FormItem>
    </Form>
    <Card>
      <Table :data="tableData" :loading="tableLoad" :columns="columns">
        <template slot-scope="{ index, row }" slot="Status">
          <i-switch
            v-model="tableData[index].Status"
            :true-value="1"
            :false-value="2"
            @on-change="(val) => changeStatus(val, row)"
          >
            <span :slot="1">ON</span>
            <span :slot="2">OFF</span>
          </i-switch>
        </template>
        <template slot-scope="{ row }" slot="ImportantStatus">
          <span v-if="row.ImportantStatus == 1">生效</span>
          <span v-else>失效</span>
        </template>
        <template slot-scope="{ row }" slot="TemplatePlace">
          {{ PlaceList.find((v) => v.Id == row.TemplatePlace).Name }}
        </template>
        <template slot-scope="{ row }" slot="TemplateType">
          <span v-if="row.TemplateType == 1">类型一</span>
        </template>
        <template slot-scope="{ row }" slot="OnlineStartTime">
          {{ row.OnlineStartTime | dateFilter }}
        </template>
        <template slot-scope="{ row }" slot="OnlineEndTime">
          {{ row.OnlineEndTime | dateFilter }}
        </template>
        <template slot-scope="{ row }" slot="action">
          <Button @click="handleEdit(row)" size="small" type="primary"
            >编辑</Button
          ></template
        >
      </Table>
      <Row style="margin-top: 10px">
        <i-col :span="8">
          <Button @click="addNew" type="primary">新增定制</Button>
        </i-col>
        <i-col :span="16">
          <Page
            :total="page.total"
            :current="page.page"
            :page-size="page.limit"
            :page-size-opts="[10, 20, 40, 80, 100]"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          />
        </i-col>
      </Row>
    </Card>
    <Modal v-model="showModal" :title="formData.ID ? '编辑' : '新增'">
      <Form
        :model="formData"
        :rules="rules"
        ref="formData"
        :label-width="150"
        v-if="showModal"
      >
        <FormItem label="关联游戏：" prop="AppId">
          <GameSelect
            :disabled="!!formData.ID"
            v-model="formData.AppId"
            style="width: 200px"
            placeholder="请输入App名称"
            @on-change="gameSelectAction"
          />
        </FormItem>
        <FormItem label="包名：">
          {{gamePkgName}}
        </FormItem>
        <FormItem label="定制详情页类型：" prop="TemplateType">
          <RadioGroup v-model="formData.TemplateType">
            <Radio :label="1">类型一</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem label="投放位置：" prop="TemplatePlace">
          <Selection
            v-model="formData.TemplatePlace"
            :dataList="PlaceList"
            :clearable="false"
          />
        </FormItem>
        <FormItem label="自动上线时间：" prop="OnlineStartTime">
          <DatePicker
            v-model="formData.OnlineStartTime"
            format="yyyy-MM-dd HH:mm"
            type="datetime"
          />
        </FormItem>
        <FormItem label="自动下线时间：" prop="OnlineEndTime">
          <DatePicker
            v-model="formData.OnlineEndTime"
            format="yyyy-MM-dd HH:mm"
            type="datetime"
          />
        </FormItem>
        <FormItem label="上传背景图：" prop="GameDetailBgImg">
          <UploadImg v-model="formData.GameDetailBgImg" />
        </FormItem>
        <FormItem label="标题焦点色：" prop="GameDetailFocusColors">
          <ColorPicker v-model="formData.GameDetailFocusColors" />
        </FormItem>
        <FormItem label="配置底色：" prop="BackColors">
          <ColorPicker v-model="formData.BackColors" />
        </FormItem>
        <FormItem label="选择H5定制：" prop="ImportantId">
          <Select
            v-model="formData.ImportantId"
            filterable
            remote
            clearable
            placeholder="请输入活动名称"
            :remote-method="getAppList"
            ref="selection"
            @on-change="chengeAppList"
          >
            <Option v-for="item in appList" :value="item.ID" :key="item.ID">{{
              item.Title
            }}</Option>
          </Select>
        </FormItem>
        <template v-if="formData.ImportantId">
          <FormItem label="Tab并存设置：" prop="TagConfig">
            <RadioGroup
              v-model="formData.TagConfig"
              @on-change="changeTagConfig"
            >
              <Radio :label="1">Webview(h5)+简介</Radio>
              <Radio :label="2">仅Webview(h5)</Radio>
            </RadioGroup>
          </FormItem>
          <FormItem label="第一行Tab：" prop="TagFirst">
            <RadioGroup v-model="formData.TagFirst">
              <Radio :label="1">Webview(h5)</Radio>
              <Radio :label="2" :disabled="formData.TagConfig == 2">简介</Radio>
            </RadioGroup>
          </FormItem>
          <FormItem label="Webview Tab名称：" prop="ImportantTitle">
            <Input
              v-model="formData.ImportantTitle"
              type="text"
              placeholder="不配置则默认为游戏/应用名称"
            ></Input>
          </FormItem>
        </template>
      </Form>
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button @click="handleCommit">确认</Button>
      </template>
    </Modal>
  </div>
</template>
<script>
import GameSelect from "_c/app-select";
import UploadImg from "_c/shark-upload";
import KeygameSelect from "_c/keygame-select";
import Selection from "_c/Selection";
import PageApi from "@/api/gamespace/detailPage";
import ActivityAPI from "@/api/gamespace/publicActivity";
import { formatDate } from "@/libs/tools";
export default {
  name: "detailPage",
  components: { GameSelect, UploadImg, KeygameSelect, Selection },
  data() {
    const checkNum = (rule, value, callback) => {
      if (!value) {
        callback("请输入关联游戏");
      }
      callback();
    };
    const checkType = (rule, value, callback) => {
      if (!value) {
        callback("请选择定制详情页类型");
      }
      callback();
    };
    const checkPlace = (rule, value, callback) => {
      if (!value) {
        callback("请选择投放位置");
      }
      callback();
    };
    return {
      tableLoad: false,
      showModal: false,
      tableData: [],
      columns: [
        { key: "AppName", title: "游戏名称" },
        { slot: "TemplateType", title: "详情页类型" },
        { slot: "TemplatePlace", title: "投放位置" },
        { slot: "ImportantStatus", title: "H5定制状态" },
        { slot: "OnlineStartTime", title: "自动上线时间" },
        { slot: "OnlineEndTime", title: "自动下线时间" },
        { slot: "Status", title: "模板状态" },
        { slot: "action", title: "操作" },
      ],
      page: {
        total: 0,
        limit: 10,
        page: 1,
        params: {
          AppId: undefined,
        },
      },
      pkgName:'',
      formData: {
        AppId: undefined,
        TemplateType: 1,
        TemplatePlace: 1,
        OnlineStartTime: "",
        OnlineEndTime: "",
        GameDetailBgImg: "",
        GameDetailFocusColors: "",
        BackColors: "#ffffff",
        ImportantId: undefined,
        ImportantUrl: "",
        Status: 1,
        TagConfig: 1,
        TagFirst: 1,
      },
      rules: {
        AppId: [{ required: true, validator: checkNum, trigger: "change" }],
        TemplateType: [
          {
            required: true,
            validator: checkType,
            trigger: "change",
          },
        ],
        TemplatePlace: [
          {
            required: true,
            validator: checkPlace,
            trigger: "change",
          },
        ],
        OnlineStartTime: [
          {
            required: true,
            message: "请选择自动上线时间",
            trigger: "change",
            type: "date",
          },
        ],
        OnlineEndTime: [
          {
            required: true,
            message: "请选择自动下线时间",
            trigger: "change",
            type: "date",
          },
        ],
        GameDetailBgImg: [
          {
            required: true,
            message: "请上传背景图",
            trigger: "change",
          },
        ],
        GameDetailFocusColors: [
          {
            required: true,
            message: "请选择标题焦点色",
            trigger: "change",
          },
        ],
        BackColors: [
          {
            required: true,
            message: "请选择配置底色",
            trigger: "change",
          },
        ],
      },
      PlaceList: [
        { Id: 1, Name: "游戏中心" },
        { Id: 2, Name: "应用商店" },
        { Id: 3, Name: "全部" },
      ],
      appList: [],
      gamePkgName:''
    };
  },
  filters: {
    dateFilter(value) {
      return formatDate(value, "YYYY-MM-DD HH:mm");
    },
  },
  mounted() {
    this.searchServe();
  },
  methods: {
    selectAction(value){
      if(value.value){
        this.pkgName = value.value.PkgName
      }else{
        this.pkgName = ''
      }
    },
    gameSelectAction(value){
      if(value.value){
        this.gamePkgName = value.value.PkgName
      }else{
        this.gamePkgName = ''
      }
    },
    changeTagConfig(val) {
      if (val == 2) this.formData.TagFirst = 1;
    },
    chengeAppList(value) {
      if (value) {
        this.formData.ImportantUrl = this.appList.filter(
          (v) => v.ID == value
        )[0].FeedURL;
      }
    },
    getAppList(value) {
      PageApi.KeyGameLike(value).then((res) => {
        if (res.Code === 0) {
          let list = res.Data || [];
          this.appList = list.filter(
            (item) => item.Title.toLowerCase().indexOf(value.toLowerCase()) > -1
          );
        }
      });
    },
    changeStatus(val, row) {
      PageApi.SetStatus(row.ID, val).then((res) => {
        this.searchServe();
      });
    },
    handleEdit(row) {
      this.showModal = true;
      this.formData = Object.assign(this.formData, row);
      this.formData.GameDetailFocusColors = row.GameDetailFocusColors[0];
      this.formData.BackColors = row.GameDetailFocusColors[1]
        ? row.GameDetailFocusColors[1]
        : "#ffffff";
      this.formData.OnlineEndTime = new Date(this.formData.OnlineEndTime);
      this.formData.OnlineStartTime = new Date(this.formData.OnlineStartTime);
      if (this.formData.ImportantId) {
        ActivityAPI.KeyGameTemplate(this.formData.ImportantId).then((res) => {
          this.appList =
            [
              {
                ID: res.Data["ID"],
                Title: res.Data["Title"],
                FeedURL: res.Data["FeedURL"],
              },
            ] || [];
          this.$refs["selection"].setQuery(res.Data["Title"]);
          this.$refs["selection"].toggleMenu(null, false);
        });
      }
    },
    addNew() {
      this.showModal = true;
      this.formData = {
        AppId: undefined,
        TemplateType: 1,
        TemplatePlace: 1,
        OnlineStartTime: "",
        OnlineEndTime: "",
        GameDetailBgImg: "",
        GameDetailFocusColors: "",
        BackColors: "#ffffff",
        ImportantId: undefined,
        ImportantUrl: "",
        Status: 1,
        TagConfig: 1,
        TagFirst: 1,
      };
    },
    handleCommit() {
      this.$refs["formData"].validate((valid) => {
        if (valid) {
          let start = new Date(this.formData.OnlineStartTime).getTime();
          let end = new Date(this.formData.OnlineEndTime).getTime();
          if (start >= end) {
            this.$Message.error("自动上线时间不得大于或等于自动下线时间");
            return;
          }
          let params = JSON.parse(JSON.stringify(this.formData));
          params.GameDetailFocusColors = [
            this.formData.GameDetailFocusColors,
            this.formData.BackColors,
          ];
          if (this.formData.ID) {
            PageApi.Edit(params.ID, params).then((res) => {
              if (res.Code == 0) {
                this.searchServe();
                this.showModal = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            PageApi.Add(params).then((res) => {
              if (res.Code == 0) {
                this.searchServe();
                this.showModal = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    onPageChange(page) {
      this.page.page = page;
      this.searchServe();
    },
    onPageSizechange(size) {
      this.page.page = 1;
      this.page.limit = size;
      this.searchServe();
    },
    handleSearch() {
      this.page.page = 1;
      this.searchServe();
    },
    searchServe() {
      this.tableLoad = true;
      PageApi.GetList(this.page)
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.Data;
            this.page.total = res.Data.Count;
          }
        })
        .finally(() => {
          this.tableLoad = false;
        });
    },
  },
};
</script>
<style scoped>
</style>
