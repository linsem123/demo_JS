<template>
  <Card title="机型配置">
    <Table
      border
      highlight-row
      ref="currentRowTable"
      :columns="columns"
      :data="tableData"
      :loading="loading"
      :max-height="600"
    >
      <template slot="action" slot-scope="{ row }">
        <Button type="primary" @click="handleChange(row)" size="small"
          >编辑</Button
        >
      </template>
    </Table>
    <Row style="margin-top: 10px">
      <Col :span="6">
        <Button @click="handleChange()" type="info" shape="circle" icon="md-add"
          >新增</Button
        >
      </Col>
      <Col :span="18" align="right">
        <Page
          show-sizer
          :total="total"
          show-total
          :page-size="pageSize"
          :current="pageIndex"
          @on-change="changePage"
          @on-page-size-change="changePageSize"
        />
      </Col>
    </Row>
    <Modal
      :title="isEdit ? '编辑' : '新增'"
      v-model="show"
      :closable="false"
      :mask-closable="false"
    >
      <Form
        :model="formData"
        :label-width="80"
        :rules="ruleData"
        ref="formData"
      >
        <FormItem label="机型：" prop="Name">
          <Input
            v-model="formData.Name"
            style="width: 200px"
            placeholder="请输入机型"
          />
        </FormItem>
        <FormItem label="描述：">
          <Input
            v-model="formData.Comment"
            style="width: 300px"
            type="textarea"
            placeholder="请输入"
          />
        </FormItem>
      </Form>
      <div slot="footer">
        <Button type="text" size="large" @click="modalCancel">取消</Button>
        <Button type="primary" size="large" @click="addPhone">确定</Button>
      </div>
    </Modal>
  </Card>
</template>
<script>
import PhoneAPI from "@/api/gamespace/phoneModel";
export default {
  data() {
    return {
      loading: false,
      columns: [
        {
          title: "ID",
          key: "ID",
          align: "center",
          minWidth: 100,
        },
        {
          title: "机型",
          key: "Name",
          align: "center",
          minWidth: 200,
        },
        {
          title: "描述",
          key: "Comment",
          minWidth: 100,
          align: "center",
        },

        {
          title: "操作",
          slot: "action",
          align: "center",
          fixed: "right",
          minWidth: 100,
        },
      ],
      formData: {
        Name: "",
        Comment: "",
      },
      ruleData: {
        Name: [{ required: true, trigger: "blur", message: "请输入机型" }],
      },
      tableData: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      isEdit: true,
      show: false,
    };
  },
  mounted() {
    this.searchServer();
  },
  methods: {
    handleChange(row) {
      this.show = true;
      if (row) {
        this.isEdit = true;
        this.formData = Object.assign({}, row);
      } else {
        this.isEdit = false;
      }
    },
    modalCancel() {
      this.show = false;
      this.formData = {
        Name: "",
        Comment: "",
      };
    },
    addPhone() {
      this.$refs["formData"].validate((valid) => {
        if (valid) {
          if (this.isEdit) {
            PhoneAPI.EditPhone(this.formData.ID, {
              Name: this.formData.Name,
              Comment: this.formData.Comment,
            }).then((res) => {
              if (res.Code == 0) {
                this.searchServer();
                this.$Message.success("编辑机型成功");
                this.show = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            PhoneAPI.AddPhone(this.formData).then((res) => {
              if (res.Code == 0) {
                this.searchServer();
                this.$Message.success("新增机型成功");
                this.show = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.searchServer();
    },
    searchServer() {
      PhoneAPI.getPhoneModel({
        Limit: this.pageSize,
        Page: this.pageIndex,
        Params: {},
      }).then((res) => {
        if (res.Code == 0) {
          this.tableData = res.Data.Data;
          this.total = res.Data.Count;
        }
      });
    },
  },
};
</script>
