<!--模块的新增和编辑-->
<template>
  <div>
    <Card>
      <h4>{{ isAdd ? "新增模块" : "编辑模块：" + formData.Name }}</h4>
      <Divider></Divider>

      <Form ref="formData" :model="formData" :rules="rules" :label-width="150">
        <FormItem label="模块名称：" prop="Name">
          <Row>
            <i-col :span="10">
              <Input
                type="text"
                v-model="formData.Name"
                placeholder="请输入模块名称"
              ></Input>
            </i-col>
          </Row>
        </FormItem>
        <FormItem label="模块类型：" prop="ModelType">
          <RadioGroup v-model="formData.ModelType" @on-change="modelTypeChange">
            <Radio
              v-for="t in contentType"
              :label="t.value"
              :key="t.value"
              :disabled="formDisabled.ModelType"
              >{{ t.label }}</Radio
            >
          </RadioGroup>
          <div style="color: red; font-size: 12px">
            提示：单游戏推荐位/活动内容/轮播小图模块适用于APP版本大于等于180，或者大于等于10180
          </div>
        </FormItem>

        <!-- 来源 -->
        <template v-if="showOrigin">
          <FormItem label="数据来源：" prop="DataSource">
            <RadioGroup v-model="formData.DataSource" @on-change="changeOrign">
              <Radio :label="1">运营后台</Radio>
              <Radio :label="2">腾讯</Radio>
            </RadioGroup>
          </FormItem>
        </template>
        <!-- banner规 -->
        <template v-if="hideBanner && !isTencent">
          <!--内容类型为大图、中图时需选择-->
          <FormItem label="banner规则：" prop="BannerRule">
            <RadioGroup v-model="formData.BannerRule">
              <Radio
                v-for="t in bannerList"
                :disabled="formDisabled.BannerRule"
                :label="t.value"
                :key="t.value"
                >{{ t.label }}</Radio
              >
            </RadioGroup>
          </FormItem>
        </template>

        <!--投放内容类型为游戏列表\游戏列表(带图)数据时需选择-->
        <template v-if="formData.ModelType == 5 || formData.ModelType == 19">
          <!-- 来源非腾讯 -->
          <FormItem
            label="上传图片："
            v-if="!isTencent && formData.ModelType == 19"
          >
            <Row>
              <i-col :span="10">
                <UploadImg
                  v-model="formData.ResourceImage"
                  module="gamespace"
                ></UploadImg>
              </i-col>
            </Row>
          </FormItem>
          <FormItem
            label="榜单排序："
            prop="BannerSortType"
            v-if="!(formData.ModelType == 19 && isTencent)"
          >
            <RadioGroup v-model="formData.BannerSortType">
              <Radio :label="2">纵向</Radio>
              <Radio :label="1">横向</Radio>
            </RadioGroup>
          </FormItem>
          <FormItem label="标题类型：" prop="TitleType">
            <RadioGroup v-model="formData.TitleType">
              <Radio :label="1">无标题</Radio>
              <Radio :label="2">单标题</Radio>
              <Radio :label="3">双标题</Radio>
            </RadioGroup>
          </FormItem>
          <template v-if="!isTencent">
            <FormItem label="显示更多：" prop="IsMore">
              <RadioGroup v-model="formData.IsMore">
                <Radio :label="1">是</Radio>
                <Radio :label="0">否</Radio>
              </RadioGroup>
            </FormItem>
            <FormItem
              label="按钮文字："
              prop="MoreTitle"
              v-if="formData.IsMore == 1"
            >
              <Row>
                <i-col :span="10">
                  <Input
                    v-model="formData.MoreTitle"
                    placeholder="定义更多按钮文字"
                  ></Input>
                </i-col>
              </Row>
            </FormItem>

            <FormItem label="榜单类型：">
              <Row>
                <i-col :span="10">
                  <Select v-model="formData.RankType" clearable>
                    <Option
                      v-for="s in rankTypeList"
                      :value="s.id"
                      :key="s.id"
                      >{{ s.name }}</Option
                    >
                  </Select>
                </i-col>
              </Row>
            </FormItem>
          </template>
          <template v-if="isTencent && formData.ModelType == 19">
            <FormItem label="图片跳转类型：">
              <Row>
                <i-col :span="10">
                  <Select
                    v-model="formData.ResourceImageJumpType"
                    clearable
                    :disabled="isTencent"
                  >
                    <Option :value="1">模块合辑</Option>
                  </Select>
                </i-col>
              </Row>
            </FormItem>
            <FormItem label="绑定模块合辑：">
              <Select
                v-model="formData.ResourceImageJumpId"
                clearable
                filterable
                remote
                :remote-method="getModulesList"
                placeholder="请输入合辑名称"
                style="width: 200px"
              >
                <Option v-for="m in modulesList" :value="m.ID" :key="m.ID">{{
                  m.Name
                }}</Option>
              </Select>
            </FormItem>
          </template>
          <!-- 数据来源-腾讯 榜单类型只有 腾讯榜单 -->
          <template v-if="isTencent">
            <FormItem label="榜单类型：">
              <Row>
                <i-col :span="10">
                  <Select
                    v-model="formData.RankType"
                    clearable
                    :disabled="isTencent"
                  >
                    <Option :value="7">腾讯榜单</Option>
                  </Select>
                </i-col>
              </Row>
            </FormItem>
          </template>
          <FormItem label="投放榜单：" prop="ResourceID">
            <Row>
              <i-col :span="10">
                <RankSelect
                  :rankType="formData.RankType"
                  v-model="formData.ResourceID"
                  @on-change="rankChange"
                ></RankSelect>
              </i-col>
            </Row>
          </FormItem>
          <template v-if="formData.TitleType == 3">
            <FormItem label="榜单描述：">
              <Row>
                <i-col :span="10">
                  <Input disabled v-model="formData.ResourceDesc"></Input>
                </i-col>
              </Row>
            </FormItem>
          </template>
          <!-- 数据来源-腾讯 落地页类型： 默认且不可更改 -->
          <FormItem label="落地页类型：" prop="FloorPageType">
            <Row>
              <i-col :span="10">
                <Select
                  v-model="formData.FloorPageType"
                  :disabled="isTencent"
                  clearable
                >
                  <Option v-for="s in selectList" :value="s.Id" :key="s.Id">{{
                    s.Name
                  }}</Option>
                </Select>
              </i-col>
            </Row>
          </FormItem>
        </template>

        <!--投放内容类型为榜单专题时需选择-->
        <template v-if="formData.ModelType == 7">
          <FormItem label="专题排序：" prop="BannerSortType">
            <RadioGroup v-model="formData.BannerSortType">
              <Radio :label="2">纵向</Radio>
              <Radio :label="1">横向</Radio>
            </RadioGroup>
          </FormItem>
        </template>
        <!-- 多小图-28 -->
        <template
          v-if="
            formData.ModelType == 28 ||
            formData.ModelType == 30 ||
            formData.ModelType == 31 ||
            formData.ModelType == 32 ||
            formData.ModelType == 33
          "
        >
          <FormItem label="是否显示模块名称：" prop="IsShowModelTitle">
            <Checkbox v-model="formData.IsShowModelTitle"></Checkbox>
          </FormItem>
        </template>
        <template
          v-if="
            formData.ModelType == 7 ||
            formData.ModelType == 30 ||
            formData.ModelType == 28 ||
            formData.ModelType == 32 ||
            formData.ModelType == 33
          "
        >
          <FormItem label="显示更多：" prop="IsMore">
            <RadioGroup v-model="formData.IsMore">
              <Radio :label="1">是</Radio>
              <Radio :label="0">否</Radio>
            </RadioGroup>
          </FormItem>
        </template>
        <template v-if="showBtnText">
          <FormItem label="按钮文字：" prop="MoreTitle">
            <Row>
              <i-col :span="10">
                <Input
                  v-model="formData.MoreTitle"
                  placeholder="定义更多按钮文字"
                  clearable
                ></Input>
              </i-col>
            </Row>
          </FormItem>
        </template>
        <template v-if="formData.ModelType == 7">
          <FormItem label="投放专题：" prop="ResourceID">
            <Row>
              <i-col :span="10">
                <Select v-model="formData.ResourceID" clearable>
                  <Option v-for="s in thematicList" :value="s.ID" :key="s.ID">{{
                    s.Title
                  }}</Option>
                </Select>
              </i-col>
            </Row>
          </FormItem>
        </template>

        <template v-if="formData.ModelType == 28">
          <FormItem label="展示方式：">
            <RadioGroup v-model="formData.ShowType">
              <Radio :label="1">横滑</Radio>
              <Radio :label="2">平铺</Radio>
            </RadioGroup>
          </FormItem>

          <FormItem label="标题类型：" prop="TitleType">
            <RadioGroup v-model="formData.TitleType">
              <Radio :label="1">无标题</Radio>
              <Radio :label="2">单标题</Radio>
              <Radio :label="3">双标题</Radio>
            </RadioGroup>
          </FormItem>
        </template>
        <!-- 圈子信息流 -->
        <template v-if="formData.ModelType == 29">
          <FormItem label="信息流类型：" prop="ResourceID">
            <Selection
              v-model="formData.ResourceID"
              :dataList="postList"
              style="width: 200px"
            />
          </FormItem>
        </template>
        <!-- 图文资讯-30 -->
        <template v-if="formData.ModelType == 30 || formData.ModelType == 33">
          <FormItem label="榜单类型：" v-if="formData.ModelType == 33">
            <Selection
              v-model="formData.RankType"
              :dataList="postRankList"
              :width="200"
              :clearable="false"
              @on-change="changePostRank"
            />
          </FormItem>
          <FormItem label="绑定榜单：">
            <CommonSelect
              v-model="formData.ResourceID"
              placeholder="请输入帖子榜单名称"
              :serverData="severData"
              style="width: 400px"
              ref="postrank"
            />
          </FormItem>
          <FormItem label="落地页类型：" v-if="formData.ModelType == 30">
            <Selection
              v-model="formData.FloorPageType"
              :clearable="true"
              :dataList="floorList"
              :width="200"
            />
          </FormItem>
        </template>
        <FormItem v-if="formData.ModelType != 3" label="显示数量：">
          <div style="float: left; margin-right: 15px">
            <Radio @on-change="countChange(0)" v-model="count.all">全部</Radio>
          </div>
          <!-- 顶部大卡-数据来源：腾讯 不可自定义数量 -->
          <Col :span="6" v-if="!(isTencent && formData.ModelType == 20)">
            <Row :gutter="10">
              <Col :span="11">
                <InputNumber
                  @on-change="countChange(1)"
                  v-model="count.num"
                  :min="1"
                  :max="9999"
                  placeholder="自定义数量"
                  style="width: 100%"
                ></InputNumber>
              </Col>
            </Row>
          </Col>
        </FormItem>
        <!-- 小图-4 -->
        <FormItem label="元素尺寸是否固定：" v-if="formData.ModelType == 4">
          <RadioGroup v-model="formData.IsFixed" @on-change="changeFixed">
            <Radio :label="1">固定</Radio>
            <Radio :label="2"
              >动态（单元素尺寸根据单行可显示元素数量而定）</Radio
            >
          </RadioGroup>
        </FormItem>
        <FormItem
          label="单行显示元素数量："
          v-if="formData.ModelType == 4 && formData.IsFixed == 2"
        >
          <RadioGroup v-model="formData.LineShowNum">
            <Radio :label="2">2个</Radio>
            <Radio :label="3">3个</Radio>
            <Radio :label="4">4个</Radio>
            <Radio :label="5">5个</Radio>
          </RadioGroup>
          <div style="color: red">
            提示：单行显示元素数量设置及元素动态尺寸仅适用于APP版本大于等于4.9x
          </div>
        </FormItem>
        <FormItem label="支持版本：" prop="version">
          <div style="float: left; margin-right: 15px">
            <Radio @on-change="versionChange(0)" v-model="version.all"
              >全部</Radio
            >
          </div>
          <Col :span="6">
            <Row :gutter="10">
              <Col :span="11">
                <InputNumber
                  @on-change="versionChange(1)"
                  :min="1"
                  :max="9999"
                  style="width: 100%"
                  v-model="version.MinVersion"
                  placeholder="最小版本"
                ></InputNumber>
              </Col>
              <Col :span="2" align="center">-</Col>
              <Col :span="11">
                <InputNumber
                  @on-change="versionChange(1)"
                  :min="1"
                  :max="9999"
                  style="width: 100%"
                  v-model="version.MaxVersion"
                  placeholder="最大版本"
                ></InputNumber>
              </Col>
            </Row>
          </Col>
        </FormItem>
        <FormItem label="MIUI支持版本：" prop="miversion">
          <div style="float: left; margin-right: 15px">
            <Radio @on-change="miVersionChange(0)" v-model="version.miall"
              >全部</Radio
            >
          </div>
          <Col :span="6">
            <Row :gutter="10">
              <Col :span="11">
                <InputNumber
                  @on-change="miVersionChange(1)"
                  style="width: 100%"
                  v-model="version.MiMinVersion"
                  placeholder="最小版本"
                ></InputNumber>
              </Col>
              <Col :span="2" align="center">-</Col>
              <Col :span="11">
                <InputNumber
                  @on-change="miVersionChange(1)"
                  style="width: 100%"
                  v-model="version.MiMaxVersion"
                  placeholder="最大版本"
                ></InputNumber>
              </Col>
            </Row>
          </Col>
        </FormItem>
        <FormItem label="是否过滤机型：">
          <Checkbox v-model="formData.NeedModelFiltration"></Checkbox>
        </FormItem>
        <FormItem
          label="支持机型："
          prop="SupportModel"
          v-if="formData.NeedModelFiltration"
        >
          <SurpotModel v-model="formData.SupportModel" />
        </FormItem>
        <FormItem label="生效周期：" prop="Expired">
          <DateRange
            v-model="formData.Expired"
            @on-change="
              (value) => {
                formData.StartTime = value.start;
                formData.EndTime = value.end;
              }
            "
          />
        </FormItem>
        <FormItem>
          <Button @click="submitcheck()" type="primary" style="width: 100px"
            >提交</Button
          >
          <Button @click="cancel()" style="margin-left: 40px">取消</Button>
        </FormItem>
      </Form>
    </Card>
  </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";
import ThematicApi from "@/api/gamespace/thematic";
import RankSelect from "_c/rank-select";
import UploadImg from "_c/shark-upload/index";
import SurpotModel from "_c/SurpotModel";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import Selection from "_c/Selection";
import CommonSelect from "_c/common-select";
import { formatTimes } from "@/libs/tools";

export default {
  name: "",
  components: {
    RankSelect,
    UploadImg,
    SurpotModel,
    DateRange,
    Selection,
    CommonSelect,
  },
  data() {
    return {
      isAdd: true,
      formData: {
        RankType: undefined,
        Name: "", // 模块名称
        ModelType: 1, //模块类型，内容类型
        DataSource: 1, //数据来源
        ResourceImageJumpType: 1,
        ResourceImageJumpId: 1,
        BannerSortType: 1, // banner排序
        BannerRule: 1, // banner规则
        TitleType: 1,
        IsMore: 1, // 是否显示更多
        MoreTitle: "",
        ShowCount: 3, // 展示个数
        SupportModel: [], // 适配机型
        MinVersion: 0, // 最小支持版本
        MaxVersion: 0, // 最大支持版本
        // status: 1, // 状态
        ResourceID: null, // 绑定榜单Id
        ThematicId: null, //绑定专题类型
        FloorPageType: null, // 落地页类型
        // IsShowAll: 1,
        ResourceDesc: "",
        NeedModelFiltration: false,
        ResourceImage: "",
        Expired: [], //4.7迭代增加生效周期
        IsShowModelTitle: true, //4.7迭代增加是否展示模块标题
        ShowType: 1, //4.7迭代增加展示方式
        IsFixed: 1, //4.9迭代增加
        LineShowNum: 4, //4.9迭代增加
      },

      // 对可能存在disabled状态的控制
      formDisabled: {
        ModelType: false,
        // BannerSortType: true,
        BannerRule: true,
        // ShowCount: false,
      },
      rules: {
        Name: [{ required: true, message: "请输入模块名称", trigger: "blur" }],
        SupportModel: [
          {
            required: true,
            type: "array",
            message: "请设置支持机型",
            trigger: "blur",
          },
        ],
        ResourceID: [
          {
            required: true,
            type: "number",
            message: "请选择",
            trigger: "blur",
          },
        ],
        // ThematicId: [{required: true, type: 'number', message: '请选择', trigger: 'blur'}],
        FloorPageType: [
          {
            required: true,
            type: "number",
            message: "请选择落地页类型",
            trigger: "blur",
          },
        ],
        Expired: [
          {
            validator: checkDateRange,
            trigger: "change",
            type: "array",
          },
        ],
        MoreTitle: [
          {
            required: true,
            message: "请输入按钮文字",
            trigger: "blur",
          },
        ],
      },

      // 内容类型
      contentType: [
        { value: 1, label: "轮播大图" },
        { value: 15, label: "轮播中图" },
        { value: 2, label: "大图" },
        { value: 3, label: "中图" },
        { value: 4, label: "小图" },
        { value: 5, label: "游戏列表" },
        { value: 6, label: "游戏视频" },
        { value: 7, label: "榜单专题" },
        { value: 8, label: "Tab列表" },
        // 新增类型
        { value: 19, label: "游戏列表（带图）" },
        { value: 20, label: "顶部大卡" },
        { value: 21, label: "轮播图2" },
        { value: 22, label: "单游戏推荐位" },
        { value: 23, label: "活动内容" },
        { value: 24, label: "轮播小图" },
        { value: 25, label: "内容轮播图" },
        { value: 26, label: "已关注圈子" }, //4.7迭代新增
        { value: 27, label: "热门圈子" }, //4.7迭代新增
        { value: 28, label: "多小图" }, //4.7迭代新增
        { value: 29, label: "圈子信息流" }, //4.7迭代新增
        { value: 30, label: "图文资讯" }, //4.7迭代新增
        { value: 31, label: "自定义话题" }, //4.9迭代新增
        { value: 32, label: "父模块" }, //4.9迭代新增
        { value: 33, label: "视频贴模块" }, //4.10迭代新增
      ],
      // banner规则
      bannerRules: [
        { value: 1, label: "纯banner" },
        { value: 2, label: "icon在BN上" },
        { value: 3, label: "icon在BN下" },
        { value: 4, label: "标题在BN上" },
        { value: 5, label: "标题在BN下" },
      ],
      // 数量
      count: {
        all: true,
        num: null,
      },

      // 支持版本的交互控制
      version: {
        MinVersion: null,
        MaxVersion: null,
        all: true,
        MiMinVersion: null,
        MiMaxVersion: null,
        miall: true,
      },

      // 内容类型
      // rankTypeList: [
      //   { id: 1, name: "普通榜单" },
      //   { id: 2, name: "排行榜单" },
      //   { id: 3, name: "预约榜单" },
      //   { id: 4, name: "分类榜单" },
      //   { id: 5, name: "标签榜单" },
      //   { id: 6, name: "飙升榜单" },
      //   { id: 9, name: "7天预约榜" },
      // ],

      // 落地页类型
      selectList: [
        { Id: 1, Name: "横版默认落地页" },
        { Id: 2, Name: "横版banner落地页" },
        { Id: 3, Name: "默认落地页" },
        { Id: 4, Name: "视频列表落地页" },
        { Id: 5, Name: "专题落地页" },
        { Id: 6, Name: "分类落地页" },
        { Id: 7, Name: "新游落地页" },
        { Id: 8, Name: "大图落地页" },
        { Id: 9, Name: "帖子列表落地页" },
        { Id: 11, Name: "图文资讯落地页" },
        { Id: 12, Name: "内容轮播落地页" },
      ],

      // floorList: [
      //   { Id: 9, Name: "帖子列表落地页" },
      //   { Id: 10, Name: "图文资讯落地页" },
      //   { Id: 11, Name: "内容轮播落地页" },
      //   { Id: 12, Name: "增量视频帖" },
      //   { Id: 13, Name: "游戏榜单" },
      // ], //4.7迭代新增
      postList: [
        { Id: 2, Name: "全部最新排序" },
        { Id: 3, Name: "关注最新排序" },
      ], //4.7迭代新增
      // 投放专题列表
      thematicList: [],
      modulesList: [], //模块合辑搜索
    };
  },
  mounted() {
    this.editInit();
    this.getThematicList();
  },
  computed: {
    nowTime() {
      return formatTimes(new Date());
    },
    showOrigin() {
      let arr = [5, 19, 20, 21];
      if (arr.includes(this.formData.ModelType)) {
        return true;
      }
      return false;
    },
    isTencent() {
      //来源是否为腾讯
      return this.formData.DataSource == 2 ? true : false;
    },
    hideBanner() {
      //不展示banner规则条件
      return ![5, 7, 8, 19, 26, 27, 29, 28, 30, 31, 32, 33].includes(
        this.formData.ModelType
      );
    },
    showBtnText() {
      //展示更多按钮文字条件
      return (
        (this.formData.ModelType == 7 ||
          this.formData.ModelType == 30 ||
          this.formData.ModelType == 27 ||
          this.formData.ModelType == 28 ||
          this.formData.ModelType == 32 ||
          this.formData.ModelType == 33) &&
        this.formData.IsMore == 1
      );
    },
    bannerList() {
      // if (this.formData.ModelType == 28) {
      //   return this.bannerRules.filter((v) => {
      //     return [1, 5].includes(v.value);
      //   });
      // }
      return this.bannerRules;
    },
    severData() {
      if (this.formData.ModelType == 30 || this.formData.ModelType == 33) {
        return {
          likeUrl: "PostRankLike",
          likeData: { status: 1, type: this.formData.RankType },
          setUrl: "getPostRank",
          setData: {},
          IdKey: "Id",
          NameKey: "Title",
        };
      }
      return {};
    },
    postRankList() {
      return [
        { Id: 1, Name: "普通榜单" },
        { Id: 2, Name: "全量视频帖榜单" }, // 4.10迭代新增
        { Id: 3, Name: "游戏榜单" },
      ];
    },
    floorList() {
      if (this.formData.RankType == 1) {
        if (this.formData.ModelType == 30) {
          return [
            { Id: 9, Name: "帖子列表落地页" },
            { Id: 10, Name: "图文资讯落地页" },
            { Id: 11, Name: "内容轮播落地页" },
          ];
        }
      } else {
        return [
          { Id: 12, Name: "视频帖榜单列表" },
          { Id: 13, Name: "沉浸式播放页" },
        ];
      }
      return [];
    },
    rankTypeList() {
      let arr = [
        { id: 1, name: "普通榜单" },
        { id: 2, name: "排行榜单" },
        { id: 3, name: "预约榜单" },
        { id: 4, name: "分类榜单" },
        { id: 5, name: "标签榜单" },
        { id: 6, name: "飙升榜单" },
      ];
      if (
        !(
          this.formData.ModelType == 5 &&
          this.formData.BannerSortType == 1 &&
          this.formData.TitleType == 3
        )
      ) {
        arr.push({ id: 9, name: "7天预约榜" });
      }
      return arr;
    },
  },
  methods: {
    changePostRank() {
      this.$refs.postrank.clearText();
    },
    //4.9迭代增加 动态尺寸 单行显示元素数量默认参数设为4
    changeFixed(value) {
      if (value == 2 && !this.formData.LineShowNum) {
        this.formData.LineShowNum = 4;
      }
    },
    getThematicList() {
      ThematicApi.GetThematicList(1).then((res) => {
        this.thematicList = res.Data || [];
      });
    },

    // 模块内容类型变化
    modelTypeChange(val) {
      if (val == 1 || val == 24) {
        this.formDisabled.BannerRule = true;
        this.formData.BannerSortType = 1;
        this.formData.BannerRule = 1;
      } else if (val == 2 || val == 6 || val == 22 || val == 23) {
        this.formDisabled.BannerRule = false;
        if (this.formData.BannerSortType == 2) {
          this.formData.ShowCount = 2;
        } else {
          this.formData.ShowCount = 1;
        }
      } else if (val == 3) {
        this.formDisabled.BannerRule = false;
        this.formData.BannerSortType = 1;
        this.formData.ShowCount = 1;
      } else if (val == 4) {
        this.formDisabled.BannerRule = true;
        this.formData.BannerSortType = 1;
        this.formData.BannerRule = 1;
        this.formData.ShowCount = 1;
      } else if (val == 5 || val == 7) {
        this.formDisabled.BannerRule = true;
        this.formData.ShowCount = 3;
      } else if (val == 25) {
        this.formDisabled.BannerRule = true;
        this.formData.BannerRule = 5;
      } else if (val == 27) {
        this.formData.IsMore = 1;
        this.formData.MoreTitle = "更多";
      } else if (val == 28) {
        this.formDisabled.BannerRule = false;
        this.formData.BannerRule = 1;
      } else if (val == 30) {
        this.formData.RankType = 1;
        this.formData.FloorPageType = undefined;
      } else if (val == 33) {
        this.formData.RankType = 1;
        this.formData.FloorPageType = 14;
      }
      if ([26, 27, 29, 30].includes(val)) {
        this.formData.BannerRule = 1;
      }
      if (!this.showOrigin) {
        this.formData.DataSource = 1;
      } else {
        this.changeOrign(this.formData.DataSource);
      }
    },
    //数据来源变化
    changeOrign(val) {
      let bool = val == 2 ? true : false;

      if (
        (this.formData.ModelType == 5 || this.formData.ModelType == 19) &&
        bool
      ) {
        this.formData.FloorPageType = 3;
        this.formData.RankType = 7; // 榜单类型-腾讯榜单
      }
    },
    // banner排序变化
    bannerSortTypeChange(val) {
      console.log(val);
      if (val == 1) {
        this.formData.ShowCount = 1;
      } else {
        this.formData.ShowCount = 2;
      }
    },

    // 显示数量 交互变化
    countChange(val) {
      if (val) {
        this.count.all = false;
      } else {
        this.count.num = null;
      }
    },

    // 支持版本 交互变化
    versionChange(val) {
      console.log(val);
      // 数值范围
      if (val) {
        this.version.all = false;
        if (this.version.MinVersion && this.version.MaxVersion) {
          if (
            this.version.MinVersion >= 10000 ||
            this.version.MaxVersion >= 10000
          ) {
            this.$Message.warning("版本号不能大于10000");
          }
          if (this.version.MinVersion - this.version.MaxVersion > 0) {
            this.$Message.warning("最小版本不能大于最大版本");
          }
        }
      }
      // 全部
      else {
        this.version.MinVersion = null;
        this.version.MaxVersion = null;
      }
    },

    miVersionChange(val) {
      console.log(val);
      // 数值范围
      if (val) {
        this.version.miall = false;
        if (this.version.MiMinVersion && this.version.MiMaxVersion) {
          if (
            this.version.MiMinVersion < 10000 ||
            this.version.MiMaxVersion < 10000
          ) {
            this.$Message.warning("MIUI版本号不能小于10000");
          }
          if (this.version.MiMinVersion - this.version.MiMaxVersion > 0) {
            this.$Message.warning("最小版本不能大于最大版本");
          }
        }
      }
      // 全部
      else {
        this.version.MiMinVersion = null;
        this.version.MiMaxVersion = null;
      }
    },
    getModulesList(name) {
      if (!name) return;
      HomeModuleAPI.moduleTypes(name, 1).then((res) => {
        if (res.Code === 0) {
          this.modulesList = res.Data || [];
        }
      });
    },
    submitcheck() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          if (
            this.formData.ModelType == 28 &&
            this.formData.ShowType == 2 &&
            this.count.num % 2 > 0
          ) {
            this.$Message.error("展示方式为平铺时，显示数量需为偶数");
            return;
          }
          if (!this.formData.StartTime || !this.formData.EndTime) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitForm();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitForm();
          }
        }
      });
    },
    // 提交
    submitForm() {
      var params = Object.assign({}, this.formData);
      params.StartTime = params.StartTime || this.nowTime;
      params.EndTime = params.EndTime || "2099-01-01 00:00:00";
      if (this.version.all) {
        params.MinVersion = 1;
        params.MaxVersion = 9999;
      } else {
        params.MinVersion = Number(this.version.MinVersion || 0);
        params.MaxVersion = Number(this.version.MaxVersion || 0);
      }
      if (this.version.miall) {
        params.MiMinVersion = 10000;
        params.MiMaxVersion = 19999;
      } else {
        params.MiMinVersion = Number(this.version.MiMinVersion || 0);
        params.MiMaxVersion = Number(this.version.MiMaxVersion || 0);
      }
      params.IsMore = !!params.IsMore;
      params.SupportModel = params.SupportModel.join(",");
      if ([5, 7, 19, 27, 28, 30, 32, 33].includes(params.ModelType)) {
        params.BannerRule = null;
      } else if ([29].includes(params.ModelType)) {
        params.BannerRule = null;
        params.IsMore = false;
      } else {
        params.IsMore = false;
        params.ResourceID = null;
        params.FloorPageType = null;
      }
      if (this.count.num) {
        params.ShowCount = this.count.num;
      } else {
        params.ShowCount = 9999;
      }
      if (this.showOrigin && this.isTencent) {
        params.BannerRule = 0;
      }
      if (
        !((params.ModelType == 5 || params.ModelType == 19) && this.isTencent)
      ) {
        params.ResourceImageJumpType = 0;
        params.ResourceImageJumpId = 0;
      }
      if (params.IsFixed == 1) {
        params.LineShowNum = 0;
      }

      // 4.10迭代新增
      // 若模块类型为视频帖模块、榜单类型为普通榜单，提交时，后端查询该榜单前20条是否存在无视频资源的帖子，如存在，弹窗提示
      if(params.ModelType == 33 && params.RankType === 1) {
        HomeModuleAPI.ModelPreEdit(params).then((res) => {
          if (res.Code === 106) {
            setTimeout(() => {
              this.$Modal.confirm({
                title: "提示",
                okText: "确定提交",
                cancelText: "取消",
                loading: true,
                content: `<p>${res.Message}</p>`,
                onOk: () => {
                  this.submitModelApi(params);
                  this.$Modal.remove();
                },
              });
            }, 500);
          } else if (res.Code === 0) {
            this.submitModelApi(params);
          } else {
            this.$Message.error(res.Message);
          }
        });
      } else {
        this.submitModelApi(params);
      }

    },

    submitModelApi(params) {
      this.modelApi(params).then((res) => {
          if (res.Code === 0) {
            this.$Message.success("操作成功");
            this.cancel();
          } else {
            this.$Message.error(res.Message);
          }
      });
    },

    modelApi(params) {
      if (this.isAdd) {
        return HomeModuleAPI.AddModel(params);
      } else {
        return HomeModuleAPI.EditModel(params);
      }
    },

    // 返回
    cancel() {
      this.$router.push({
        name: "gamespace_activity_homemodule",
      });
    },

    editInit() {
      let editData = this.$route.params.editData;
      // 若是编辑状态，则初始化编辑数据
      if (editData) {
        // HomeModuleAPI;
        // 数据初始化
        this.isAdd = false;
        editData = JSON.parse(editData);
        this.formData = Object.assign({}, this.formData, editData);
        this.formData.IsMore = this.formData.IsMore ? 1 : 0;
        this.formData.SupportModel = this.formData.SupportModel.split(",");
        this.formData.Expired = [
          this.formData.StartTime,
          this.formData.EndTime,
        ]; //4.7迭代增加生效周期
        if (this.formData.ShowCount < 9999) {
          this.count.num = this.formData.ShowCount;
          this.count.all = false;
        } else {
          this.count.num = null;
          this.count.all = true;
        }

        if (
          !(
            this.formData.MinVersion == this.formData.MaxVersion &&
            this.formData.MaxVersion == 0
          )
        ) {
          this.version.all = false;
          this.version.MinVersion = this.formData.MinVersion;
          this.version.MaxVersion = this.formData.MaxVersion;
        }
        if (
          !(
            this.formData.MiMinVersion == this.formData.MiMaxVersion &&
            this.formData.MiMaxVersion == 0
          )
        ) {
          this.version.miall = false;
          this.version.MiMinVersion = this.formData.MiMinVersion;
          this.version.MiMaxVersion = this.formData.MiMaxVersion;
        }

        // disabled交互初始化
        this.formDisabled.ModelType = true;
      }
    },

    rankChange({ value }) {
      this.formData.ResourceDesc = value.Desc || "";
    },
  },
};
</script>

<style scoped>
</style>
