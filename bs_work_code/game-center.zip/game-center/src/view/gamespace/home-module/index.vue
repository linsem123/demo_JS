<!--首页模块管理的列表页-->
<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="5">
            <Select
              v-model="searchform.params.id"
              clearable
              filterable
              remote
              :remote-method="handleModelSearch"
              placeholder="请输入模块名称"
            >
              <Option
                v-for="item in modelList"
                :value="item.ID"
                :key="item.ID"
                >{{ item.Name }}</Option
              >
            </Select>
          </Col>
          <Col span="6">
            <Button
              type="success"
              shape="circle"
              icon="ios-search"
              @click="handleClickSearch"
              >搜索</Button
            >
          </Col>
        </Row>
      </div>

      <Table :data="tableData" :columns="columns" border>
        <template slot-scope="{ row }" slot="ModelType">
          {{ row.ModelType | modelTypeFilter }}
        </template>
        <template slot-scope="{ row }" slot="DataSource">
          {{ row.DataSource | DataSourceFilter }}
        </template>
        <template slot-scope="{ row }" slot="ResourceImage">
          <img style="width: 50px" :src="row.ResourceImage" />
        </template>
        <template slot-scope="{ row }" slot="BannerSortType">
          <span v-if="row.BannerSortType == 2">纵向</span>
          <span v-else>横向</span>
        </template>
        <template slot-scope="{ row }" slot="Version">
          <span v-if="row.MinVersion == 1 && row.MaxVersion == 9999">全部</span>
          <span v-else>{{ row.MinVersion }} ~ {{ row.MaxVersion }}</span>
        </template>
        <template slot-scope="{ row }" slot="MiVersion">
          <span v-if="row.MiMinVersion == 10000 && row.MiMaxVersion == 19999"
            >全部</span
          >
          <span v-else>{{ row.MiMinVersion }} ~ {{ row.MiMaxVersion }}</span>
        </template>
        <template slot-scope="{ row }" slot="Status">
          <Tag v-if="row.Status == 1" color="success">上线</Tag>
          <Tag v-else-if="row.Status == 2" color="error">下线</Tag>
          <Tag v-else color="warning">待处理</Tag>
        </template>
        <template slot-scope="{ row }" slot="Expired">
          <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">
            {{ row.StartTime }}～{{ row.EndTime }}
          </span>
        </template>
        <template slot-scope="{ row }" slot="opt">
          <Button
            @click="editTheModule(row)"
            type="primary"
            size="small"
            class="table-opt"
            :disabled="row.DataSource == 2"
            >编辑</Button
          >
          <Button
            @click="elementManage(row)"
            :disabled="[5, 7, 19, 26, 27, 29, 30, 33].includes(row.ModelType)"
            type="info"
            size="small"
            class="table-opt"
            >元素管理</Button
          >
          <Button
            @click="updateStatus(row, 1)"
            type="success"
            v-if="row.Status != 1"
            size="small"
            class="table-opt"
            >上架</Button
          >
          <Button
            @click="updateStatus(row, 2)"
            type="error"
            v-else
            size="small"
            class="table-opt"
            >下架</Button
          >
        </template>
      </Table>

      <Row style="margin-top: 10px">
        <Col :span="6">
          <Button
            @click="editTheModule()"
            type="info"
            shape="circle"
            icon="md-add"
            >新增模块</Button
          >
        </Col>
        <Col :span="18" align="right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </Col>
      </Row>
    </Card>
  </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";

export default {
  name: "gamespace_activity_homemodule",
  data() {
    return {
      searchform: {
        page: {
          total: 0,
          current: 1,
          size: 10,
        },
        params: {
          id: undefined,
        },
      },
      modelList: [],
      tableData: [],
      columns: [
        { title: "ID", key: "ID", align: "center", minWidth: 80 },
        { title: "模块名", key: "Name", align: "center", minWidth: 150 },
        { title: "类型", slot: "ModelType", align: "center", minWidth: 100 },
        {
          title: "数据来源",
          slot: "DataSource",
          align: "center",
          minWidth: 100,
        },
        {
          title: "排列方向",
          slot: "BannerSortType",
          align: "center",
          minWidth: 90,
        },
        { title: "支持版本", slot: "Version", align: "center", minWidth: 90 },
        {
          title: "支持MIUI版本",
          slot: "MiVersion",
          align: "center",
          minWidth: 90,
        },
        {
          title: "支持机型",
          key: "SupportModel",
          align: "center",
          minWidth: 150,
        },
        { title: "图片", slot: "ResourceImage", align: "center", minWidth: 80 },
        { title: "状态", slot: "Status", align: "center", minWidth: 100 },
        { title: "生效周期", slot: "Expired", align: "center", minWidth: 290 },
        {
          title: "操作",
          slot: "opt",
          minWidth: 200,
          align: "center",
          fixed: "right",
        },
      ],
    };
  },
  mounted() {
    this.getModules();
  },
  methods: {
    onPageChange(value) {
      this.searchform.page.current = value;
      this.getModules();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.getModules();
    },
    handleModelSearch(value) {
      if (!value) return;
      HomeModuleAPI.ModelLike(value).then((res) => {
        if (res.Code === 0) {
          this.modelList = res.Data || [];
        }
      });
    },
    handleClickSearch() {
      this.searchform.page.current = 1;
      this.getModules();
    },
    getModules() {
      let params = {
        Page: this.searchform.page.current,
        Limit: this.searchform.page.size,
        Params: {
          ID: this.searchform.params.id,
        },
      };
      HomeModuleAPI.GetModelList(params).then((res) => {
        if (res.Code === 0) {
          this.tableData = res.Data.Data;
          this.searchform.page.total = res.Data.Count;
        }
      });
    },

    // 编辑模块
    editTheModule(item) {
      if (!item) {
        this.$router.push({
          name: "gamespace_activity_homemodule_edit",
          params: {
            id: 0,
          },
        });
      } else {
        this.$router.push({
          name: "gamespace_activity_homemodule_edit",
          params: {
            editData: JSON.stringify(item),
            id: item.ID,
          },
        });
      }
    },

    // 模块元素管理
    elementManage(row) {
      sessionStorage.setItem("ModuleElManage", JSON.stringify(row));
      this.$router.push({
        name: "gamespace_activity_homemodule_elemanage", // :modelType/:modelId
        params: {
          modelType: row.ModelType,
          modelId: row.ID,
        },
        query: {
          titleType: row.TitleType,
          modelType: row.ModelType,
        },
      });
    },

    // 上下架
    updateStatus(row, status) {
      this.$Modal.confirm({
        title: `确定要将 ${row.Name} ${status == 1 ? "上" : "下"}架吗？`,
        onOk: () => {
          HomeModuleAPI.UpdateStatus(row.ID, status).then((res) => {
            if (res.Code === 0) {
              this.$Message.success("操作成功");
              this.getModules();
            } else {
              this.$Message.error(res.Message);
            }
          });
        },
      });
    },
    //校验生效周期状态
    getStatus(row) {
      const now = new Date().getTime();
      const start = new Date(row.StartTime).getTime();
      const end = new Date(row.EndTime).getTime();
      return row.Status == 1 && now > start && now < end;
    },
  },
  filters: {
    modelTypeFilter(val) {
      let contentType = [
        { value: 1, label: "轮播大图" },
        { value: 15, label: "轮播中图" },
        { value: 2, label: "大图" },
        { value: 3, label: "中图" },
        { value: 4, label: "小图" },
        { value: 5, label: "游戏列表" },
        { value: 6, label: "游戏视频" },
        { value: 7, label: "榜单专题" },
        { value: 8, label: "Tab列表" },
        { value: 19, label: "游戏列表（带图）" },
        { value: 20, label: "顶部大卡" },
        { value: 21, label: "轮播图2" },
        { value: 22, label: "单游戏推荐位" },
        { value: 23, label: "活动内容" },
        { value: 24, label: "轮播小图" },
        { value: 25, label: "内容轮播图" },
        { value: 26, label: "已关注圈子" }, //4.7迭代新增
        { value: 27, label: "热门圈子" }, //4.7迭代新增
        { value: 28, label: "多小图" }, //4.7迭代新增
        { value: 29, label: "圈子信息流" }, //4.7迭代新增
        { value: 30, label: "图文资讯" }, //4.7迭代新增
        { value: 31, label: "自定义话题" }, //4.9迭代新增
        { value: 32, label: "父模块" }, //4.9迭代新增
        { value: 33, label: "视频贴模块" }, //4.10迭代新增
      ];
      let res = contentType.filter((item) => {
        return item.value == val;
      });
      return (res[0] && res[0].label) || "未知类型";
    },
    DataSourceFilter(val) {
      let contentType = [
        { value: 1, label: "运营后台" },
        { value: 2, label: "腾讯" },
      ];
      let res = contentType.filter((item) => {
        return item.value == val;
      });
      return (res[0] && res[0].label) || "未知类型";
    },
  },
};
</script>

<style scoped lang="less">
.table-opt {
  margin-right: 5px;
}
</style>
