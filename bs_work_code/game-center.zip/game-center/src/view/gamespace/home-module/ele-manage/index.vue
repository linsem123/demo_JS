<!--模块元素管理主页-->
<template>
  <div>
    <Card>
      <!--公共使用-->
      <div style="margin-bottom: 15px">
        <p>
          当前模块：
          <a @click="showDetail">{{ module.Name }}</a>
        </p>
        <p>模块类型：{{ filterType(module.ModelType) }}</p>
      </div>
      <ElBanners
        v-if="defaultTemplate.includes(Number(templateType))"
        :modelId="templateId"
        :DataSource="module.DataSource"
        ref="tableEle"
        @on-sort="handleSort"
      ></ElBanners>

      <ElVideos
        v-if="templateType == 6"
        :modelId="templateId"
        @on-sort="handleSort"
      ></ElVideos>

      <Modal v-model="visible" title="模块详情">
        <Form :label-width="150" class="detail-form">
          <FormItem label="模块名称：">{{ module.Name }}</FormItem>
          <FormItem label="模块类型：">{{
            filterType(module.ModelType)
          }}</FormItem>
          <FormItem label="banner排序：">{{
            module.BannerSortType == 1 ? "横向" : "纵向"
          }}</FormItem>
          <FormItem label="banner规则：">{{
            filterRule(module.BannerRule)
          }}</FormItem>
          <FormItem label="显示数量：">{{ module.ShowCount }}</FormItem>
          <FormItem label="支持版本："
            >{{ module.MinVersion }} ~ {{ module.MaxVersion }}</FormItem
          >
          <FormItem label="支持机型：">{{ module.SupportModel }}</FormItem>
        </Form>
      </Modal>
    </Card>
  </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";
// 载入各种模块的元素管理的组件
import ElBanners from "./ele-banners.vue";
import ElVideos from "./ele-videos.vue";

export default {
  name: "",
  components: { ElBanners, ElVideos },
  data() {
    return {
      templateType: null,
      templateId: null,
      defaultTemplate: [1, 2, 3, 4, 8, 15, 20, 21, 22, 23, 24, 25, 28, 31, 32], // 轮播大图, 轮播中图，大图，中图，小图，tab，顶部大卡，轮播图2,单游戏推荐位,活动内容，轮播小图,多小图，自定义话题

      module: {},

      // 内容类型
      contentType: [
        { value: 1, label: "轮播大图" },
        { value: 15, label: "轮播中图" },
        { value: 2, label: "大图" },
        { value: 3, label: "中图" },
        { value: 4, label: "小图" },
        { value: 5, label: "游戏列表" },
        { value: 6, label: "游戏视频" },
        { value: 7, label: "榜单专题" },
        { value: 8, label: "Tab列表" },
        { value: 19, label: "游戏列表（带图）" },
        { value: 20, label: "顶部大卡" },
        { value: 21, label: "轮播图2" },
        { value: 22, label: "单游戏推荐位" },
        { value: 23, label: "活动内容" },
        { value: 24, label: "轮播小图" },
        { value: 25, label: "内容轮播图" },
        { value: 26, label: "已关注圈子" }, //4.7迭代新增
        { value: 27, label: "热门圈子" }, //4.7迭代新增
        { value: 28, label: "多小图" }, //4.7迭代新增
        { value: 29, label: "圈子信息流" }, //4.7迭代新增
        { value: 30, label: "图文资讯" }, //4.7迭代新增
        { value: 31, label: "自定义话题" }, //4.9迭代新增
        { value: 32, label: "父模块" }, //4.9迭代新增
      ],
      // banner规则
      bannerRules: [
        { value: 1, label: "纯banner" },
        { value: 2, label: "icon在BN上" },
        { value: 3, label: "icon在BN下" },
        { value: 4, label: "标题在BN上" },
        { value: 5, label: "标题在BN下" },
      ],

      visible: false,
    };
  },
  created() {
    this.templateType = this.$route.params.modelType;
    this.templateId = this.$route.params.modelId;
  },
  mounted() {
    let module = sessionStorage.getItem("ModuleElManage");
    if (module) {
      this.module = JSON.parse(module);
    }
  },
  methods: {
    filterType(val) {
      let res = this.contentType.filter((item) => {
        return item.value == val;
      })[0];
      return (res && res.label) || "未知类型";
    },
    filterRule(val) {
      let res = this.bannerRules.filter((item) => {
        return item.value == val;
      })[0];
      return (res && res.label) || "未知";
    },

    showDetail() {
      this.visible = true;
    },

    handleSort(list) {
      list = list || [];
      list = list.map((l, i) => {
        return { ID: l.ID, Sort: i + 1 };
      });
      HomeModuleAPI.SortEles(this.templateId, { Banners: list }).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("排序成功");
          console;
          this.$refs["tableEle"].getEles();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>

<style scoped>
</style>
