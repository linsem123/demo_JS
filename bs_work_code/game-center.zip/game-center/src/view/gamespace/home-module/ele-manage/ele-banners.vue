<!-- ModelType === 1,2,3,4 8, 15, 20, 21,-->
<template>
    <div>
        <Table :data="tableData" :columns="columns" border draggable @on-drag-drop="handleDrop">
            <template slot-scope="{ row }" slot="src">
                <img :src="row.Url" class="prev-img" alt />
            </template>
            <template slot-scope="{ row }" slot="VerticalUrl">
                <img :src="row.VerticalUrl" class="prev-img" alt />
            </template>
            <template slot-scope="{ row }" slot="Status">
                <Tag v-if="row.Status == 1" color="success">上线</Tag>
                <Tag v-else-if="row.Status == 2" color="error">下线</Tag>
                <Tag v-else color="warning">待处理</Tag>
            </template>
            <template slot-scope="{ row }" slot="Expired">
                <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">{{ row.StartTime }}～{{ row.EndTime }}</span>
            </template>
            <template slot="AnchoringName" slot-scope="{ row }">{{ row.IsAnchoring == 1 ? row.AnchoringName : "" }}</template>
            <template slot-scope="{ row }" slot="Sort">
                <span v-if="row.Sort == 0">未排序</span>
                <span v-else>已排序</span>
            </template>
            <template slot-scope="{ row }" slot="opt">
                <Button @click="editItem(row)" type="primary" size="small" :disabled="DataSource == 2" style="margin-right: 5px">编辑</Button>
                <Button @click="updateStatus(1, row)" type="success" v-show="row.Status != 1" size="small" style="margin-right: 5px">上架</Button>
                <Button @click="updateStatus(2, row)" type="error" v-show="row.Status == 1" size="small" style="margin-right: 5px">下架</Button>
            </template>
        </Table>
        <Row style="margin-top: 10px">
            <Col :span="6">
                <Button @click="editItem()" type="info" shape="circle" icon="md-add" :disabled="DataSource == 2">新增</Button>
            </Col>
        </Row>

        <!--    编辑新增 弹窗-->
        <Modal v-model="visible" width="600" @on-visible-change="visibleChange" :title="formData.ID ? '编辑' : '新增'">
            <Form ref="formData" :model="formData" :rules="rules" :label-width="120">
                <Row>
                    <Col :span="23">
                        <FormItem label="名称：" prop="Name">
                            <Input v-model="formData.Name" placeholder="请填写名称"></Input>
                        </FormItem>
                        <FormItem
                            v-if="
                modelType != 8 &&
                modelType != 22 &&
                modelType != 23 &&
                modelType != 31 &&
                modelType != 32
              "
                            label="图片："
                            class="ivu-form-item-required"
                        >
                            <!-- 顶部大卡-20 只展示竖版图片，24轮播小图只展示横版图片 -->
                            <div style="display: inline-block; width: 120px" v-if="modelType != 20">
                                <FormItem label prop="Url">
                                    <p>横版图片：</p>
                                    <UploadImg v-model="formData.Url" module="gamespace"></UploadImg>
                                </FormItem>
                            </div>
                            <div v-if="showVertical" style="display: inline-block; width: 120px">
                                <FormItem label prop="VerticalUrl">
                                    <p>竖版图片：</p>
                                    <UploadImg v-model="formData.VerticalUrl" module="gamespace"></UploadImg>
                                </FormItem>
                            </div>
                        </FormItem>
                        <!-- 23活动内容 icon图片 非必传 -->
                        <FormItem v-if="modelType == 23" label="图片：">
                            <div style="display: inline-block; width: 120px">
                                <FormItem label prop="IconUrl">
                                    <p>icon图片：</p>
                                    <UploadImg v-model="formData.IconUrl" module="gamespace"></UploadImg>
                                </FormItem>
                            </div>
                        </FormItem>
                        <!-- 23-活动内容 主标题 非必传 -->
                        <FormItem label="主标题：" prop="MainTitle" v-if="modelType == 23 || (modelType == 28 && titleType > 1)">
                            <Input v-model="formData.MainTitle" placeholder="请填写主标题"></Input>
                        </FormItem>
                        <!-- 23-活动内容 副标题 非必传 -->
                        <FormItem label="副标题：" prop="Subtitle" v-if="modelType == 23 || (modelType == 28 && titleType == 3)">
                            <Input v-model="formData.Subtitle" placeholder="请填写副标题"></Input>
                        </FormItem>
                        <FormItem label="描述信息：" prop="Description" v-if="modelType != 32">
                            <Input v-model="formData.Description" placeholder="请填写描述信息" clearable></Input>
                        </FormItem>
                        <!-- 22-单游戏推荐位 图标文案 -->
                        <FormItem label="图标文案：" prop="IconTitle" v-if="modelType == 22">
                            <Input v-model="formData.IconTitle" placeholder="请填写图标文案" :maxlength="4"></Input>
                        </FormItem>
                        <FormItem label="是否开启图标文案：" prop="IsEnable" v-if="modelType == 22">
                            <i-switch v-model="formData.IsEnable" :true-value="1" :false-value="2">
                                <span slot="open">是</span>
                                <span slot="close">否</span>
                            </i-switch>
                        </FormItem>
                        <!-- 自定义话题-31 -->
                        <FormItem v-if="modelType == 31" label="话题类型：" prop="SubjectType" required>
                            <RadioGroup v-model="formData.SubjectType">
                                <Radio v-for="item of SubjectTypeList" :label="item.label" :key="item.label">
                                    {{ item.name }}
                                    <!-- <Icon :type="item.icon" size="16" :color="item.color" /> -->
                                    <img :src="item.icon" style="width: 16px; vertical-align: middle" />
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem v-if="modelType == 31" label="热度持续时间：" prop="IsHot" required>
                            <RadioGroup v-model="formData.IsHot">
                                <Radio :label="0">无热度</Radio>
                                <Radio :label="1">指定时长</Radio>
                                <Input
                                    style="width: 150px"
                                    placeholder="自定义X天，按自然日算"
                                    v-model="formData.HotTime"
                                    @input="
                    formData.HotTime = formData.HotTime.replace(/[^\d]/g, '')
                  "
                                />
                            </RadioGroup>
                        </FormItem>
                        <!-- 跳转类型 -->
                        <FormItem label="绑定跳转类型：" v-if="modelType != 32">
                            <Select v-model="formData.JumpType" @on-change="typeChange">
                                <Option v-for="item in jumpTypeList" :value="item.ID" :key="item.ID">{{ item.Name }}</Option>
                            </Select>
                        </FormItem>
                        <!--根据jumpType显示选择-->
                        <FormItem
                            v-if="
                formData.JumpType == 3 ||
                formData.JumpType == 14 ||
                formData.JumpType == 13 ||
                module.BannerRule == 2 ||
                module.BannerRule == 3
              "
                            label="绑定app："
                        >
                            <AppSelect v-model="formData.AppId" @on-change="appChange"></AppSelect>
                        </FormItem>
                        <FormItem
                            v-if="
                formData.JumpType == 3 ||
                formData.JumpType == 14 ||
                formData.JumpType == 13 ||
                module.BannerRule == 2 ||
                module.BannerRule == 3
              "
                            label="绑定app："
                        >{{ pkgName }}</FormItem>
                        <!--仅轮播且app详情才显示-->
                        <FormItem
                            v-if="
                formData.JumpType == 3 && (modelType == 1 || modelType == 24)
              "
                            label="显示APP的Icon："
                        >
                            <Checkbox v-model="formData.IsBindApp">是</Checkbox>
                        </FormItem>
                        <FormItem
                            v-if="
                formData.JumpType == 1 ||
                formData.JumpType == 2"
                            label="绑定跳转活动："
                        >
                            <ActivitySelect
                                v-model="formData.ActivityID"
                                :type="formData.JumpType"
                                @on-change="feedChange"
                                placeholder="请输入活动名称"
                                clearable
                            ></ActivitySelect>
                        </FormItem>
                        <!-- 4.11迭代-论坛帖-跳转活动搜索列表不走已投放校验 -->
                        <FormItem
                            v-if="formData.JumpType == 11"
                            label="绑定跳转活动："
                        >
                            <CommonSelect
                                v-model="formData.FeedId"
                                placeholder="请输入活动名称"
                                :serverData="activityServerData"
                                :width="400"
                                :showOptionId="true"
                                @on-change="feedChange"
                            />
                        </FormItem>
                        
                        <!-- 榜单跳转类型-4 -->
                        <FormItem v-if="formData.JumpType == 4" label="榜单类型：">
                            <Select v-model="formData.RankType" clearable>
                                <Option v-for="item in rankTypeList" :value="item.id" :key="item.id">{{ item.name }}</Option>
                            </Select>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 4" label="绑定榜单：">
                            <RankSelect :rankType="formData.RankType" @on-change="getrank" v-model="formData.FeedId"></RankSelect>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 4" label="落地页类型：">
                            <Select v-model="formData.FloorPageType" clearable>
                                <Option v-for="item in floorPageList" :value="item.ID" :key="item.ID">{{ item.Name }}</Option>
                            </Select>
                        </FormItem>
                        <!-- DeepLink跳转类型-5 -->
                        <FormItem v-if="formData.JumpType == 5" label="绑定DeepLink包名：">
                            <Input v-model="formData.DeepLinkPkgName" placeholder="请填写包名"></Input>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 5" label="绑定DeepLink：">
                            <Input v-model="formData.DeepLink" placeholder="请填写DeepLink"></Input>
                        </FormItem>

                        <FormItem v-if="formData.JumpType == 6" label="绑定模块合辑：">
                            <Select
                                v-model="formData.FeedId"
                                clearable
                                filterable
                                remote
                                :remote-method="getModulesList"
                                placeholder="请输入合辑名称"
                                :label-in-value="true"
                                ref="selection"
                                @on-change="changeModuleList"
                            >
                                <Option v-for="m in modulesList" :value="m.ID" :key="m.ID">
                                    {{
                                    m.Name
                                    }}
                                </Option>
                            </Select>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 7" label="绑定每日抽奖活动：">
                            <ActivitySelect v-model="formData.ActivityID" :type="2" @on-change="feedChange" placeholder="请输入活动名称"></ActivitySelect>
                        </FormItem>
                        <!-- Action跳转类型-5 -->
                        <FormItem v-if="formData.JumpType == 9" label="绑定Action包名：">
                            <Input v-model="formData.DeepLinkPkgName" placeholder="请填写包名"></Input>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 9" label="绑定ActionUrl：">
                            <Input v-model="formData.DeepLink" placeholder="请填写ActionUrl"></Input>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 10" label="绑定H5Url：">
                            <Input v-model="formData.DeepLink" placeholder="请填写H5Url"></Input>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 12" label="绑定列表：">
                            <Select v-model="formData.FeedId" clearable>
                                <Option v-for="item in PostList" :value="item.ID" :key="item.ID">{{ item.Name }}</Option>
                            </Select>
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 15" label="绑定游戏专题：">
                            <ThematicSelect v-model="formData.ThematicId" />
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 16" label="绑定重点游戏活动：">
                            <KeygameSelect v-model="formData.ImportantId" @on-change="keyGameChange" />
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 20" label="绑定活动：">
                            <Selection v-model="formData.UserProfile" :dataList="UserProfileList" :clearable="false" />
                        </FormItem>
                        <!-- 帖子榜单跳转类型-17 -->
                        <FormItem v-if="formData.JumpType == 17" label="榜单类型：">
                            <Selection v-model="formData.RankType" :dataList="postRankType" :width="200" @on-change="changePostRankType" />
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 17" label="绑定榜单：">
                            <CommonSelect
                                v-model="formData.FeedId"
                                placeholder="请输入帖子榜单名称"
                                :serverData="severData"
                                :width="400"
                                @on-change="changePostRank"
                                ref="postrank"
                            />
                        </FormItem>
                        <FormItem v-if="formData.JumpType == 17" label="落地页类型：">
                            <Selection v-model="formData.FloorPageType" :dataList="floorList" :width="200" />
                        </FormItem>
                        <FormItem v-if="modelType == 32" label="绑定模块名称：" prop="FeedId">
                            <LikeSearch
                                v-model="formData.FeedId"
                                placeholder="请输入模块名称"
                                :serverData="severData"
                                :width="400"
                                @on-change="changeModel"
                                ref="likesearch"
                            />
                        </FormItem>
                        <FormItem v-if="modelType == 32" label="绑定模块ID：">
                            <Input
                                v-model="formData.FeedId"
                                placeholder="请输入模块ID"
                                type="number"
                                clearable
                                @on-blur="getModelServer(false)"
                            />
                        </FormItem>
                        <!-- 模块类型为tab列表-8且跳转类型为模块合辑-6 -->
                        <template v-if="modelType == 8 && formData.JumpType == 6">
                            <FormItem label="上传tab图：">
                                <UploadImg v-model="formData.Url" />
                                <div style="color: red">注：底图配置仅在大于等于4.9的客户端版本上生效</div>
                            </FormItem>
                            <FormItem label="底图顶部是否模糊处理：">
                                <i-switch size="large" v-model="formData.IsFuzzy">
                                    <span slot="open">是</span>
                                    <span slot="close">否</span>
                                </i-switch>
                            </FormItem>
                        </template>

                        <FormItem label="是否过滤机型：">
                            <Checkbox v-model="formData.NeedModelFiltration"></Checkbox>
                        </FormItem>
                        <FormItem label="支持机型：" prop="SupportModel" v-if="formData.NeedModelFiltration">
                            <SurpotModel v-model="formData.SupportModel" />
                        </FormItem>
                        <FormItem label="生效周期：" prop="Expired">
                            <DateRange
                                v-if="visible"
                                v-model="formData.Expired"
                                @on-change="
                  (value) => {
                    formData.StartTime = value.start;
                    formData.EndTime = value.end;
                  }
                "
                            />
                        </FormItem>
                        <template v-if="[1, 2, 4, 21, 24, 25, 28, 30].includes(modelType)">
                            <FormItem label="是否定向人群：">
                                <div style="display: inline-block" @click="hadleToast">
                                    <i-switch size="large" v-model="formData.IsAllocate" :disabled="formData.IsCoverAnchoring == 1">
                                        <span slot="open">是</span>
                                        <span slot="close">否</span>
                                    </i-switch>
                                </div>
                            </FormItem>
                            <FormItem label="定向人群ID：" v-show="formData.IsAllocate" prop="AllocateId">
                                <div style="display: inline-block; width: 100%" @click="hadleToast">
                                    <Input
                                        placeholder="填写数据平台-用户画像-定时任务ID"
                                        :clearable="true"
                                        v-model.trim="formData.AllocateId"
                                        :disabled="formData.IsCoverAnchoring == 1"
                                        @on-keyup="
                      formData.AllocateId = formData.AllocateId
                        ? Number(
                            formData.AllocateId.replace(/[^\d]/g, '')
                          ).toString()
                        : undefined
                    "
                                    />
                                </div>
                            </FormItem>
                            <FormItem label="是否锚定元素：" v-show="formData.IsAllocate">
                                <div style="display: inline-block" @click="hadleToast">
                                    <i-switch size="large" v-model="formData.IsAnchoring" :disabled="formData.IsCoverAnchoring == 1">
                                        <span slot="open">是</span>
                                        <span slot="close">否</span>
                                    </i-switch>
                                </div>
                            </FormItem>
                            <FormItem label="锚定元素名称：" v-show="formData.IsAllocate && formData.IsAnchoring">
                                <div style="display: inline-block; width: 100%" @click="hadleToast">
                                    <Input :value="formData.AnchoringName" disabled v-if="formData.IsCoverAnchoring == 1" />
                                    <Select
                                        v-model="formData.AnchoringId"
                                        filterable
                                        remote
                                        clearable
                                        placeholder="选择需锚定的该模块的元素名称"
                                        :remote-method="getElementList"
                                        ref="eleselect"
                                        v-else
                                    >
                                        <Option v-for="item in elementList" :value="item.Id" :key="item.Id">{{ item.Name }}</Option>
                                    </Select>
                                </div>
                            </FormItem>
                        </template>
                    </Col>
                </Row>
            </Form>
            <template slot="footer">
                <Button @click="visible = false" type="text" size="large">取消</Button>
                <Button @click="submitcheck()" type="primary" size="large">确定</Button>
            </template>
        </Modal>
    </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";
import UploadImg from "_c/shark-upload/index";
// import GameAPI from "@/api/gamespace/game";
// import ActivityApi from "@/api/gamespace/activitylist";
import RankSelect from "_c/rank-select";
import AppSelect from "_c/app-select";
import Selection from "_c/Selection";
import ThematicSelect from "_c/thematic-select";
import ActivitySelect from "_c/activity-select";
import KeygameSelect from "_c/keygame-select";
import FindGameVersion from "../../kanban/find-game-version.vue";
import CommonSelect from "_c/common-select";
import SurpotModel from "_c/SurpotModel";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";
import Fuzzy from "@/api/fuzzy";
import giftImg from "@/assets/images/gift.png";
import announceImg from "@/assets/images/announce.png";
import discussImg from "@/assets/images/discuss.png";
import actImg from "@/assets/images/act.png";
import LikeSearch from "_c/like-search";

export default {
    name: "",
    components: {
        UploadImg,
        RankSelect,
        AppSelect,
        ActivitySelect,
        ThematicSelect,
        KeygameSelect,
        FindGameVersion,
        Selection,
        CommonSelect,
        SurpotModel,
        DateRange,
        LikeSearch
    },
    props: ["modelId", "DataSource"],
    data() {
        const checkHasEle = (rule, value, callback) => {
            if (this.formData.AnchoringId && this.formData.IsAnchoring == 1 && !value) {
                callback("请填写定向人群ID");
            }
            callback();
        };
        const StartUpNum = (rule, value, callback) => {
            if (value && Number(value) <= 0) {
                callback("请输入大于0的数字");
            }
            callback();
        };
        const checkFeedID = (rule, value, callback) => {
            if (Number(value) <= 0) {
                callback("请输入模块名称");
            }
            callback();
        };
        const checkUrl = (rule, value, callback) => {
            if (this.modelType != 4 && this.modelType != 21 && !value) {
                callback("请上传横板图片");
            }
            callback();
        };
        return {
            id: null, // 模块ID
            module: {},
            tableData: [],
            pkgName: "",
            columns: [
                { title: "名称", key: "Name", minWidth: 150 },
                { title: "横版图片", slot: "src", minWidth: 100 },
                { title: "竖版图片", slot: "VerticalUrl", minWidth: 100 },
                { title: "描述信息", key: "Description", minWidth: 100 },
                { title: "状态", slot: "Status", minWidth: 100 },
                { title: "锚定元素名称", slot: "AnchoringName", minWidth: 100 },
                { title: "是否已排序", slot: "Sort", minWidth: 90 },
                { title: "生效周期", slot: "Expired", minWidth: 290 },
                {
                    title: "操作",
                    slot: "opt",
                    width: 150,
                    align: "center",
                    fixed: "right"
                }
            ],

            visible: false,
            formData: {
                RankType: 0,
                Url: "",
                VerticalUrl: "",
                JumpType: undefined,
                FeedId: undefined,
                AppId: undefined,
                AwardUrl: undefined,
                DeepLinkPkgName: undefined,
                Description: "",
                VideoDuration: undefined,
                DeepLink: undefined,
                FloorPageType: undefined,
                IsBindApp: false,
                MainTitle: "",
                Subtitle: "",
                IconUrl: "",
                ThematicId: undefined,
                ImportantId: "",
                IconTitle: "",
                IsEnable: false,
                UserProfile: 1,
                NeedModelFiltration: false,
                SupportModel: [], // 适配机型
                Expired: ["", ""], //4.7迭代增加生效周期
                IsAllocate: false, ////4.8迭代增加
                IsAnchoring: false, ////4.8迭代增加
                SubjectType: 1, //4.9迭代增加
                IsFuzzy: true //4.9迭代增加
            },
            rules: {
                Name: [{ required: true, message: "请填写名称", trigger: "blur" }],
                Url: [{ validator: checkUrl, trigger: "blur" }],
                VerticalUrl: [{ required: true, message: "请上传竖版图片", trigger: "blur" }],
                Expired: [
                    {
                        validator: checkDateRange,
                        trigger: "change",
                        type: "array"
                    }
                ],
                AllocateId: [
                    {
                        validator: StartUpNum,
                        trigger: "change"
                    },
                    {
                        validator: checkHasEle,
                        trigger: "blur"
                    }
                ],
                SubjectType: [
                    {
                        required: true,
                        message: "请选择话题类型",
                        trigger: "change",
                        type: "number"
                    }
                ],
                IsHot: [
                    {
                        required: true,
                        message: "请选择热度持续时间",
                        trigger: "change",
                        type: "number"
                    }
                ],
                FeedId: [
                    {
                        required: true,
                        message: "请输入模块名称",
                        trigger: "blur",
                        type: "number"
                    },
                    {
                        validator: checkFeedID,
                        trigger: "blur"
                    }
                ]
            },

            // 跳转类型
            jumpTypeList: [
                { ID: 3, Name: "App详情" },
                { ID: 1, Name: "图文活动" },
                { ID: 2, Name: "抽奖活动" },
                { ID: 4, Name: "榜单" },
                { ID: 6, Name: "模块合辑" },
                { ID: 5, Name: "DeepLink" },
                { ID: 8, Name: "其他" }, //原积分商城改为其他
                { ID: 9, Name: "action" },
                { ID: 7, Name: "每日抽奖活动-装备箱专用" },
                { ID: 10, Name: "H5活动" },
                { ID: 11, Name: "论坛帖" }
            ],

            floorPageList: [
                { ID: 1, Name: "横版默认落地页" },
                { ID: 2, Name: "横版banner落地页" },
                { ID: 3, Name: "默认落地页" },
                { ID: 4, Name: "视频列表落地页" },
                { ID: 5, Name: "专题落地页" },
                { ID: 6, Name: "分类落地页" },
                { ID: 7, Name: "新游落地页" },
                { ID: 8, Name: "大图落地页" }
            ],
            appList: [],
            feedList: [],
            awardList: [],

            modelType: null,

            modulesList: [],
            PostList: [
                {
                    ID: 3,
                    Name: "关注列表"
                },
                {
                    ID: 2,
                    Name: "广场"
                }
            ],
            UserProfileList: [
                {
                    Id: 1,
                    Name: "安装记录"
                },
                {
                    Id: 2,
                    Name: "游戏更新"
                },
                {
                    Id: 3,
                    Name: "我的预约"
                },
                {
                    Id: 4,
                    Name: "我的优惠券"
                },
                {
                    Id: 5,
                    Name: "消费记录"
                },
                {
                    Id: 6,
                    Name: "中奖记录"
                },
                {
                    Id: 7,
                    Name: "联系我们"
                },
                {
                    Id: 8,
                    Name: "设置"
                },
                {
                    Id: 9,
                    Name: "我的礼包"
                }
            ],
            elementList: [],
            SubjectTypeList: [
                { label: 1, name: "讨论", icon: discussImg },
                { label: 2, name: "公告", icon: announceImg },
                { label: 3, name: "活动", icon: actImg },
                { label: 4, name: "福利", icon: giftImg }
            ],
            postRankType: [
                { Id: 1, Name: "普通榜单" },
                { Id: 2, Name: "全量视频帖榜单" },
                { Id: 3, Name: "游戏榜单" }
            ],
            activityServerData: {
                likeUrl: "LikeActivityFree",
                likeData: {},
                setUrl: "FeedsInfoFree",
                setData: {},
                IdKey: "Id",
                NameKey: "Title"
            }
        };
    },
    watch: {
        modelId() {
            this.init();
        }
    },
    mounted() {
        this.init();
        this.modelType = Number(this.$route.query.modelType);
        this.initJumpType();
    },
    computed: {
        nowTime() {
            return formatTimes(new Date());
        },
        //展示竖版图
        showVertical() {
            return (
                this.modelType != 1 &&
                this.modelType != 2 &&
                this.modelType != 15 &&
                this.modelType != 24 &&
                this.modelType != 25 &&
                this.modelType != 28
            );
        },
        severData() {
            if (this.modelType == 32) {
                return {
                    likeUrl: "LikeModel",
                    likeData: { status: 1 },
                    setUrl: "GetModelById",
                    setData: {},
                    IdKey: "ID",
                    NameKey: "Name"
                };
            } else {
                if (this.formData.JumpType == 17) {
                    return {
                        likeUrl: "PostRankLike",
                        likeData: { status: 1, type: this.formData.RankType },
                        setUrl: "getPostRank",
                        setData: {},
                        IdKey: "Id",
                        NameKey: "Title"
                    };
                }
            }

            return {};
        },
        titleType() {
            return this.$route.query.titleType;
        },
        floorList() {
            if (this.formData.JumpType == 17) {
                if (this.formData.RankType == 1) {
                    return [
                        { Id: 9, Name: "帖子列表落地页" },
                        { Id: 10, Name: "图文资讯落地页" },
                        { Id: 11, Name: "内容轮播落地页" }
                    ];
                } else {
                    return [
                        { Id: 12, Name: "视频帖榜单列表" },
                        { Id: 13, Name: "沉浸式播放页" }
                    ];
                }
            }
            return [];
        },
        rankTypeList() {
            let arr = [
                { id: 1, name: "普通榜单" },
                { id: 2, name: "排行榜单" },
                { id: 3, name: "预约榜单" },
                { id: 4, name: "分类榜单" },
                { id: 5, name: "标签榜单" },
                { id: 6, name: "飙升榜单" }
            ];
            if ([1, 2, 21, 24, 28].includes(this.modelType)) {
                arr.push({ id: 9, name: "7天预约榜" });
            }
            return arr;
        }
    },
    methods: {
        init() {
            this.id = Number(this.modelId);
            let module = sessionStorage.getItem("ModuleElManage");
            if (module) {
                this.module = JSON.parse(module);
            }
            this.getEles();
        },
        //根据模块设置跳转类型
        initJumpType() {
            if (this.modelType == 8) {
                this.jumpTypeList = [
                    {
                        ID: 4,
                        Name: "榜单"
                    },
                    {
                        ID: 6,
                        Name: "模块合辑"
                    },
                    {
                        ID: 12,
                        Name: "帖子列表"
                    }
                ];
            } else if (this.modelType == 22) {
                this.jumpTypeList = [{ ID: 3, Name: "App详情" }];
            } else if (this.modelType == 23) {
                this.jumpTypeList.push({ ID: 15, Name: "游戏专题" }, { ID: 13, Name: "福利tab" }, { ID: 14, Name: "单游戏社区tab" });
            } else if (this.modelType == 4) {
                this.jumpTypeList.push({ ID: 20, Name: "个人中心" });
            }
            if ([1, 15, 21, 23, 24].includes(Number(this.modelType))) {
                this.jumpTypeList.push({ ID: 16, Name: "重点游戏活动" });
            }
            if ([1, 2, 3, 4, 15, 20, 21, 23, 24].includes(Number(this.modelType))) {
                this.jumpTypeList.push({ ID: 21, Name: "积分任务" }, { ID: 22, Name: "积分商城" });
            }
            if ([1, 2, 4, 8, 20, 21, 24, 25, 28, 30, 31].includes(Number(this.modelType))) {
                this.jumpTypeList.push({ ID: 17, Name: "帖子榜单" }); //4.7迭代新增
            }
        },
        getrank({ value, index }) {
            if (index == 0) this.formData.RankType = value.RankType;
            this.formData = Object.assign({}, this.formData);
        },

        // 获取模块内元素列表
        getEles() {
            HomeModuleAPI.GetModuleEles(this.id).then(res => {
                if (res.Code === 0) {
                    this.tableData = res.Data || [];
                } else {
                    this.$Message.warning(res.Message);
                }
            });
        },

        handleDrop(idx1, idx2) {
            let item1 = this.tableData.splice(idx1, 1);
            this.tableData.splice(idx2, 0, item1[0]);

            this.$emit("on-sort", this.tableData);
        },

        typeChange() {
            this.formData.FeedId = undefined;
            this.formData.AppId = undefined;
            if (this.formData.JumpType == 6) {
                if (this.modulesList.length <= 0) {
                    this.getModulesList();
                }
            }
            this.formData.RankType = 1;
        },

        getModulesList(name) {
            if (!name) return;
            HomeModuleAPI.moduleTypes(name, 1).then(res => {
                if (res.Code === 0) {
                    this.modulesList = res.Data || [];
                }
            });
        },
        changeModuleList(value) {
            if (value) {
                console.log(value);
                this.$refs["selection"].setQuery(value.label);
                this.$refs["selection"].toggleMenu(null, false);
            }
        },
        appChange({ value, index }) {
            if (value) {
                this.pkgName = value.PkgName;
            } else {
                this.pkgName = "";
            }
            if (index) {
                this.formData.Description = value.Title;
                this.formData.MainTitle = value.Title;
            }
            this.formData = Object.assign({}, this.formData);
        },
        keyGameChange({ value, index }) {
            if (value) {
                this.formData.DeepLink = value.FeedURL;
            }
        },

        feedChange({ value, index }) {
            if (index) {
                this.formData.AwardUrl = value.FeedURL;
                this.formData.DeepLink = value.FeedURL;
                this.formData.Description = value.Title;
                this.formData.MainTitle = value.Title;
            }
            // this.formData.FeedId = value.FeedID;
            // 4.11迭代论坛帖优化中新增：跳转类型为论坛帖时模糊查询列表无FeedId字段，改用Id字段
            this.formData.FeedId = value.FeedID ? value.FeedID : value.Id;
            this.formData = Object.assign({}, this.formData);
        },

        // 点击编辑
        editItem(item) {
            this.visible = true;
            if (item) {
                if ([0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 15, 13, 14, 16, 17, 20, 21, 22, 25, 31, 32].includes(item.JumpType)) {
                    this.editValue(item);
                } else if (item.JumpType == 6) {
                    HomeModuleAPI.collectionInfo(item.FeedId).then(res => {
                        this.modulesList = [res.Data || {}];
                        this.editValue(item);
                    });
                }
            } else {
                this.formData = {
                    SupportModel: [],
                    Expired: ["", ""], //4.7迭代增加生效周期
                    AnchoringId: undefined,
                    IsAllocate: false,
                    IsAnchoring: false,
                    SubjectType: 1, //4.9迭代增加
                    IsHot: 0, //4.9迭代增加
                    FeedId: undefined,
                    IsFuzzy: true, //4.9迭代增加
                    Url: "", //4.9迭代增加
                    RankType: 0
                };
                if (this.modelType == 32) {
                    this.formData.JumpType = 21;
                    this.$refs.likesearch.clearText();
                }
            }
        },
        editValue(item) {
            this.formData = JSON.parse(JSON.stringify(item));
            this.formData.SupportModel = this.formData.SupportModel.split(",");
            this.formData.Expired = [this.formData.StartTime, this.formData.EndTime]; //4.7迭代增加生效周期
            this.formData.AllocateId = this.formData.AllocateId || "";
            this.formData.IsAllocate = this.formData.IsAllocate == 1 ? true : false;
            this.formData.IsAnchoring = this.formData.IsAnchoring == 1 ? true : false;
            if (this.formData.HotTimestamp == 0) {
                this.formData.IsHot = this.formData.HotTimestamp;
            } else {
                this.formData.IsHot = 1;
                this.formData.HotTime = this.formData.HotTimestamp == -1 ? "" : this.formData.HotTimestamp;
            }
            this.formData.IsFuzzy = this.formData.IsFuzzy == 1 ? true : false;
            if (this.$refs["eleselect"] && this.formData.IsCoverAnchoring != 1) {
                setTimeout(() => {
                    this.$refs["eleselect"].setQuery(this.formData.AnchoringName);
                    this.$refs["eleselect"].toggleMenu(null, false);
                }, 0);
            }
            if (this.modelType == 32) {
                this.getModelServer(true);
            }
        },
        updateStatus(val, row) {
            HomeModuleAPI.UpdateBannerStatus(row.ID, row.ModelId, val).then(res => {
                if (res.Code === 0) {
                    this.$Message.success("更新成功");
                } else {
                    this.$Message.error("更新失败");
                }
                this.getEles();
            });
        },
        submitcheck() {
            this.$refs.formData.validate(valid => {
                if (valid) {
                    if (this.modelType == 4 && this.formData.Name.length > 5) {
                        //小图名称长度1-5
                        this.$Message.error("名称长度限制1-5个字");
                        return;
                    }
                    if (!this.formData.StartTime || !this.formData.EndTime) {
                        this.$Modal.confirm({
                            title: "提示",
                            okText: "确认",
                            cancelText: "取消",
                            loading: true,
                            content: "<p>还未设置生效期，是否继续发布？</p>",
                            onOk: () => {
                                this.submitForm();
                                this.$Modal.remove();
                            }
                        });
                    } else {
                        this.submitForm();
                    }
                }
            });
        },
        // 提交弹出表单
        submitForm() {
            // 执行提交
            let params = JSON.parse(JSON.stringify(this.formData));
            params.ModelId = this.id;
            params.SupportModel = this.formData.SupportModel.join(",");
            params.StartTime = params.StartTime || this.nowTime;
            params.EndTime = params.EndTime || "2099-01-01 00:00:00";
            params.AllocateId = Number(params.AllocateId);
            params.IsAllocate = params.IsAllocate ? 1 : 2;
            params.IsAnchoring = params.IsAnchoring ? 1 : 2;
            if (params.IsHot == 0) {
                params.HotTimestamp = params.IsHot;
            } else {
                params.HotTimestamp = Number(params.HotTime) || -1;
            }
            params.IsFuzzy = params.IsFuzzy ? 1 : 2;

            if (params.JumpType == 3) {
                params.FeedId = params.AppId;
            }
            this.bannerApi(params).then(res => {
                if (res.Code === 0) {
                    this.$Message.success("操作成功");
                    this.visible = false;
                    this.getEles();
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        // 编辑或新增
        bannerApi(params) {
            if (this.formData.ID) {
                return HomeModuleAPI.EditBanner(params);
            } else {
                return HomeModuleAPI.AddBanner(params);
            }
        },

        visibleChange(val) {
            if (!val) {
                this.formData = {
                    Url: "",
                    JumpType: undefined,
                    FeedId: undefined,
                    AppId: undefined,
                    AwardUrl: undefined
                };
            }
        },
        changePostRankType() {
            this.$refs.postrank.clearText();
        },
        changePostRank({ value, index }) {
            if (index) {
                this.formData.Description = value.Title;
                this.formData.MainTitle = value.Title;
            }
        },
        //校验生效周期状态
        getStatus(row) {
            const now = new Date().getTime();
            const start = new Date(row.StartTime).getTime();
            const end = new Date(row.EndTime).getTime();
            return row.Status == 1 && now > start && now < end;
        },
        getElementList(value) {
            HomeModuleAPI.getElementLike(value, this.id, this.formData.ID || 0).then(res => {
                if (res.Code == 0) {
                    this.elementList = res.Data;
                }
            });
        },
        hadleToast() {
            if (this.formData.IsCoverAnchoring == 1) {
                this.$Message.error("该元素已被锚定");
            }
        },
        //isInit-是否调用接口为初始化数据
        getModelServer(isInit) {
            this.formData.FeedId = Number(this.formData.FeedId);
            Fuzzy.GetModelById({
                id: this.formData.FeedId
            }).then(res => {
                if (res.Code == 0) {
                    //数据处理
                    let data = res.Data;
                    if (data.ID > 0) {
                        this.$refs.likesearch.setQuery({
                            id: this.formData.FeedId,
                            title: data.Name
                        });
                        if (!isInit) {
                            this.$set(this.formData, "Name", data.Name);
                        }
                    } else {
                        this.$Message.error("该模块ID无效");
                    }
                }
            });
        },
        changeModel(value) {
            console.log(value);
            if (value) {
                this.$set(this.formData, "Name", value.Name);
            }
        }
    }
};
</script>

<style scoped>
.prev-img {
    display: block;
    height: 40px;
    max-width: 200px;
}
</style>
