<!--视频 ModelType === 6 -->
<template>
  <div>
    <Table
      :data="tableData"
      :columns="columns"
      border
      draggable
      @on-drag-drop="handleDrop"
    >
      <template slot-scope="{ row }" slot="src">
        <div class="preview-box">
          <img :src="row.Url" class="prev-cover" alt="" />
          <Icon @click="prevVideo(row)" type="md-play" size="20" class="icon" />
        </div>
      </template>
      <!-- <template slot-scope="{ row }" slot="Status">
        <i-switch
          @on-change="updateStatus($event, row)"
          :value="row.Status"
          :true-value="1"
          :false-value="0"
          size="large"
        >
          <span slot="open">启用</span>
          <span slot="close">停用</span>
        </i-switch>
      </template> -->
      <template slot-scope="{ row }" slot="Status">
        <Tag v-if="row.Status == 1" color="success">上线</Tag>
        <Tag v-else-if="row.Status == 2" color="error">下线</Tag>
        <Tag v-else color="warning">待处理</Tag>
      </template>
      <template slot-scope="{ row }" slot="Expired">
        <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">
          {{ row.StartTime }}～{{ row.EndTime }}
        </span>
      </template>
      <template slot-scope="{ row }" slot="opt">
        <Button @click="editItem(row)" type="primary" size="small">编辑</Button>
        <Button
          @click="updateStatus(1, row)"
          type="success"
          v-show="row.Status != 1"
          size="small"
          style="margin-left: 5px"
          >上架</Button
        >
        <Button
          @click="updateStatus(2, row)"
          type="error"
          v-show="row.Status == 1"
          size="small"
          style="margin-left: 5px"
          >下架</Button
        >
      </template>
    </Table>
    <Row style="margin-top: 10px">
      <Col :span="6">
        <Button @click="editItem()" type="info" shape="circle" icon="md-add"
          >新增</Button
        >
      </Col>
    </Row>

    <!--    编辑新增 弹窗-->
    <Modal
      v-model="visible"
      width="600"
      @on-visible-change="visibleChange"
      :title="formData.ID ? '编辑' : '新增'"
    >
      <Form ref="formData" :model="formData" :rules="rules" :label-width="120">
        <Row>
          <Col :span="23">
            <FormItem label="名称：" prop="Name">
              <Input v-model="formData.Name" placeholder="请填写名称"></Input>
            </FormItem>
            <!--<FormItem label="封面图片：" prop="Url">
            <SharkUpload v-model="formData.Url" module="gamespace"></SharkUpload>
          </FormItem>
          <FormItem label="视频：" prop="VideoUrl">
            <SharkUpload ref="videoupload"
                         v-model="formData.VideoUrl"
                         type="video"
                         :poster="formData.Url"
                         module="gamespace"
            ></SharkUpload>
          </FormItem>
          <FormItem label="视频时长：" prop="videoDuration">
            <Input v-model="formData.VideoDuration" placeholder="视频时长"></Input>
          </FormItem>-->
            <FormItem label="描述信息：" prop="Description">
              <Input
                v-model="formData.Description"
                placeholder="请填写描述信息"
              ></Input>
            </FormItem>
            <FormItem label="绑定跳转类型：">
              <Select
                disabled
                v-model="formData.JumpType"
                @on-change="typeChange"
              >
                <Option
                  v-for="item in jumpTypeList"
                  :value="item.ID"
                  :key="item.ID"
                  >{{ item.Name }}</Option
                >
              </Select>
            </FormItem>
            <!--根据jumpType显示选择-->
            <FormItem label="绑定app：">
              <Select
                v-model="formData.AppId"
                @on-change="appChange"
                clearable
                filterable
                remote
                :remote-method="handleGameSearch"
                placeholder="请输入游戏名称"
              >
                <Option v-for="j in appList" :value="j.ID" :key="j.ID">{{
                  j.AppName
                }}</Option>
              </Select>
            </FormItem>
            <FormItem label="是否过滤机型：">
              <Checkbox v-model="formData.NeedModelFiltration"></Checkbox>
            </FormItem>
            <FormItem
              label="支持机型："
              prop="SupportModel"
              v-if="formData.NeedModelFiltration"
            >
              <SurpotModel v-model="formData.SupportModel" />
            </FormItem>
            <FormItem label="生效周期：" prop="Expired">
              <DateRange
                v-model="formData.Expired"
                @on-change="
                  (value) => {
                    formData.StartTime = value.start;
                    formData.EndTime = value.end;
                  }
                "
              />
            </FormItem>
          </Col>
        </Row>
      </Form>

      <template slot="footer">
        <Button @click="visible = false" type="text" size="large">取消</Button>
        <Button @click="submitcheck()" type="primary" size="large">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import HomeModuleAPI from "@/api/gamespace/homemodule";
// import UploadImg from '_c/gamespace/upload-img.vue'
import SharkUpload from "_c/shark-upload";
import GameAPI from "@/api/gamespace/game";
import ActivityApi from "@/api/gamespace/activitylist";
import SurpotModel from "_c/SurpotModel";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";

export default {
  name: "",
  components: { SharkUpload, SurpotModel, DateRange },
  props: ["modelId"],
  data() {
    return {
      id: null, // 模块ID
      module: {},

      tableData: [],
      columns: [
        { title: "名称", key: "Name", minWidth: 150 },
        { title: "预览", slot: "src", minWidth: 100 },
        { title: "描述信息", key: "Description", minWidth: 100 },
        { title: "状态", slot: "Status", minWidth: 100 },
        { title: "生效周期", slot: "Expired", minWidth: 290 },
        {
          title: "操作",
          slot: "opt",
          width: 150,
          align: "center",
          fixed: "right",
        },
      ],

      visible: false,
      formData: {
        JumpType: 3,
        FeedId: undefined,
        AppId: undefined,
        AwardUrl: undefined,
        DeepLinkPkgName: undefined,
        Description: "",
        DeepLink: undefined,
        FloorPageType: undefined,
        NeedModelFiltration: false,
        SupportModel: [], // 适配机型
        Expired: [], //4.7迭代增加生效周期
      },
      rules: {
        Name: [{ required: true, message: "请填写名称", trigger: "blur" }],
        Url: [{ required: true, message: "请上传图片", trigger: "blur" }],
        VideoUrl: [{ required: true, message: "请上传视频", trigger: "blur" }],
        Expired: [
          {
            validator: checkDateRange,
            trigger: "change",
            type: "array",
          },
        ],
      },

      // 跳转类型
      jumpTypeList: [
        {
          ID: 3,
          Name: "App详情",
        },
        {
          ID: 1,
          Name: "图文活动",
        },
        {
          ID: 2,
          Name: "抽奖活动",
        },
        {
          ID: 4,
          Name: "榜单",
        },
        {
          ID: 5,
          Name: "DeepLink",
        },
      ],

      floorPageList: [
        {
          ID: 1,
          Name: "横向",
        },
        {
          ID: 2,
          Name: "纵向",
        },
      ],
      appList: [],
      feedList: [],
    };
  },
  watch: {
    modelId() {
      this.init();
    },
  },
  mounted() {
    this.init();
  },
  computed: {
    nowTime() {
      return formatTimes(new Date());
    },
  },
  methods: {
    init() {
      this.id = Number(this.modelId);
      let module = sessionStorage.getItem("ModuleElManage");
      if (module) {
        this.module = JSON.parse(module);
      }
      this.getEles();
    },

    handleGameSearch(value) {
      if (!parseInt(value)) {
        GameAPI.LikeApp({ value }).then((res) => {
          this.appList = res.Data;
        });
      }
    },
    handleActivitySearch(value) {
      if (!parseInt(value)) {
        ActivityApi.LikeActivity(value, this.formData.JumpType).then((res) => {
          this.feedList = res.Data;
        });
      }
    },
    handleRankSearch(value) {
      if (!parseInt(value)) {
        HomeModuleAPI.LikeRank(value).then((res) => {
          this.feedList = res.Data;
        });
      }
    },

    // 获取模块内元素列表
    getEles() {
      HomeModuleAPI.GetModuleEles(this.id).then((res) => {
        if (res.Code === 0) {
          this.tableData = res.Data || [];
        } else {
          this.$Message.warning(res.Message);
        }
      });
    },

    handleDrop(idx1, idx2) {
      let item1 = this.tableData.splice(idx1, 1);
      this.tableData.splice(idx2, 0, item1[0]);
      this.$emit("on-sort", this.tableData);
    },

    getFeeds(feedType, feedID) {
      this.feedList = [];
      ActivityApi.Feeds(feedType).then((res) => {
        this.feedList = res.Data;
      });
    },

    getGames(appID) {
      GameAPI.Get(appID).then((res) => {
        this.appList = [res.Data];
      });
    },

    getRanks(feedID) {
      HomeModuleAPI.GetRankById(feedID).then((res) => {
        this.feedList = [res.Data];
      });
    },

    typeChange() {
      this.formData.FeedId = undefined;
      this.formData.AppId = undefined;
    },

    appChange() {
      this.appList.forEach((v) => {
        if (v.ID == this.formData.AppId) {
          console.log(v);
          this.formData.Description = v.Title;
          this.formData.Url = v.VideoBg;
          this.formData.VerticalUrl = v.VideoBg;
          this.formData.VideoURL = v.VideoURL;
          this.formData.VideoDuration = v.VideoDuration;
        }
      });
    },

    feedChange() {
      this.feedList.forEach((v) => {
        if (v.FeedID == this.formData.FeedId) {
          console.log(v);
          this.formData.AwardUrl = v.FeedURL;
          this.formData.Description = v.Title;
        }
      });
    },

    // 点击编辑
    editItem(item) {
      if (item) {
        if (item.JumpType == 1) {
          ActivityApi.Feeds(1, item.FeedId).then((res) => {
            this.feedList = res.Data;
            this.editValue(item);
          });
        } else if (item.JumpType == 2) {
          ActivityApi.Feeds(2, item.FeedId).then((res) => {
            this.feedList = res.Data;
            this.editValue(item);
          });
        } else if (item.JumpType == 3) {
          this.getGames(item.AppId);
          this.editValue(item);
        } else if (item.JumpType == 4) {
          this.getRanks(item.FeedId);
          this.editValue(item);
        } else {
          this.editValue(item);
        }
      } else {
        this.formData = {
          JumpType: 3,
          SupportModel: [],
          Expired: [], //4.7迭代增加生效周期
        };
      }
      this.visible = true;
    },

    editValue(item) {
      this.formData = JSON.parse(JSON.stringify(item));
      this.formData.SupportModel = this.formData.SupportModel.split(",");
      this.formData.Expired = [this.formData.StartTime, this.formData.EndTime]; //4.7迭代增加生效周期
    },
    updateStatus(val, row) {
      HomeModuleAPI.UpdateBannerStatus(row.ID, row.ModelId, val).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("更新成功");
        } else {
          this.$Message.error("更新失败");
        }
        this.getEles();
      });
    },
    submitcheck() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          if (!this.formData.StartTime || !this.formData.EndTime) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitForm();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitForm();
          }
        }
      });
    },
    // 提交弹出表单
    submitForm() {
      if (this.feedList.length > 0) {
        this.feedList.forEach((v) => {
          if (v.FeedID == this.formData.FeedId) {
            this.formData.AwardUrl = v.FeedURL;
          }
        });
      }
      // 执行提交
      let params = JSON.parse(JSON.stringify(this.formData));
      params.ModelId = this.id;
      params.SupportModel = this.formData.SupportModel.join(",");
      params.StartTime = params.StartTime || this.nowTime;
      params.EndTime = params.EndTime || "2099-01-01 00:00:00";
      this.bannerApi(params).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("操作成功");
          this.visible = false;
          this.getEles();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    // 编辑会新增
    bannerApi(params) {
      if (this.formData.ID) {
        return HomeModuleAPI.EditBanner(params);
      } else {
        return HomeModuleAPI.AddBanner(params);
      }
    },
    visibleChange(val) {
      if (!val) {
        this.formData = {
          JumpType: undefined,
          FeedId: undefined,
          AppId: undefined,
          AwardUrl: undefined,
        };
      }
    },

    prevVideo(row) {
      window.open(row.VideoUrl, "_blank");
    },
    //校验生效周期状态
    getStatus(row) {
      const now = new Date().getTime();
      const start = new Date(row.StartTime).getTime();
      const end = new Date(row.EndTime).getTime();
      return row.Status == 1 && now > start && now < end;
    },
  },
};
</script>

<style scoped lang="less">
.preview-box {
  height: 40px;
  width: 70px;
  position: relative;
  .prev-cover {
    display: block;
    height: 100%;
    width: 100%;
  }
  .icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #19be6b;
    cursor: pointer;
  }
}
</style>
