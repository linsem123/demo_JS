<template>
    <div>
        <Card>
            <Table :loading="table.loading" border ref="selection" :columns="table.columns" :data="table.data">
                <template slot="app" slot-scope="{ row }">
                    <Tag>{{ row.AppName }}</Tag>
                </template>
                <template slot="switch" slot-scope="{ row }">
                    <i-switch v-model="row.IsHighVersionDownload" :true-value="1" :false-value="2"
                        @on-change="(status) => handleAllowDownload(row.Id, status)">
                    </i-switch>
                </template>

                <template slot="opt" slot-scope="{ row }">
                    <template>
                        <Poptip confirm transfer title="你确定要解绑吗？" @on-ok="unbind(row.Id)">
                            <Button type="error" size="small">解绑</Button>
                        </Poptip>
                    </template>
                </template>
            </Table>

            <div style="margin: 10px; overflow: hidden">
                <div style="float: left">
                    <Button type="info" style="margin-right: 15px" shape="circle" icon="md-add"
                        @click="openAdd">绑定应用</Button>
                    <Button type="default" shape="circle" @click="toRankManage">返回云备份管理</Button>
                </div>
                <div style="float: right">
                    <Page :total="searchform.page.total" :current="searchform.page.current"
                        :page-size="searchform.page.size" @on-change="onPageChange"
                        @on-page-size-change="onPageSizechange" show-sizer show-total></Page>
                </div>
            </div>
        </Card>

        <!--绑定应用弹窗-->
        <Modal v-model="visible" title="绑定应用" :loading="loading" @on-ok="handleSubmit">
            <Form :model="insideformScope" ref="insideformScope" :rules="ruleValidate" :label-width="130">
                <FormItem label="请选择应用:" prop="AppID">
                    <Select v-model="insideformScope.AppID" clearable filterable remote
                        :remote-method="handleGameSearch2" placeholder="请输入应用名称" @on-change="selectAction">
                        <Option v-for="item in apps" :value="item.ID" :key="item.ID">{{ item.AppName }}</Option>
                    </Select>
                </FormItem>
                <FormItem label="app包名：">{{ pkgName }}</FormItem>
                <FormItem label="允许高版本下载：">
                    <Checkbox v-model="insideformScope.IsHighVersionDownload"></Checkbox>
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>

<script>
    import CloudBackupAPI from "@/api/gamespace/cloudbackup";
    import GameAPI from "@/api/gamespace/game";

    export default {
        name: "gamespace_rank_app_list",
        data() {
            return {
                searchform: {
                    params: {
                        PoolId: parseInt(this.$route.params.id),
                    },
                    page: {
                        total: 0,
                        current: 1,
                        size: 10,
                    }
                },
                table: {
                    loading: false,
                    data: [],
                    columns: [
                        { title: "应用名称", fixed: "left", width: 200, slot: "app" },
                        {
                            title: "应用包名",
                            width: 250,
                            render: (h, params) => {
                                return h("Tag", { props: {} }, params.row.PkgName);
                            },
                        },
                        {
                            title: "应用类型",
                            width: 200,
                            render: (h, params) => {
                                if (params.row.AppType === 0) {
                                    return h("Tag", { props: { color: "default" } }, "游戏");
                                }
                                if (params.row.AppType === 1) {
                                    return h("Tag", { props: { color: "default" } }, "应用");
                                }
                            }
                        },
                        {
                            title: '是否允许高版本下载',
                            width: 150,
                            slot: 'switch',
                        },
                        {
                            title: "版本信息",
                            width: 200,
                            align: "center",
                            render: (h, params) => {
                                return h("div", [
                                    h("Tag", {}, params.row.VersionName),
                                    h("Tag", {}, params.row.VersionCode),
                                ]);
                            },
                        },
                        {
                            title: '应用下载链接',
                            width: 200,
                            key: 'PkgUrl'
                        },
                        {
                            title: "操作",
                            fixed: "right",
                            width: 150,
                            slot: "opt",
                        },
                    ],
                },

                visible: false,
                loading: true,
                insideformScope: {
                    RankType: 1,
                    AppID: undefined,
                    IsHighVersionDownload: false,
                },
                apps: [],
                ruleValidate: {
                    AppID: [
                        {
                            required: true,
                            message: "请选择游戏",
                            trigger: "blur",
                            type: "number",
                        },
                    ],
                },

                option: "button", // switch: '开关'，button: '按钮执行'
                pkgName: "",
            };
        },
        methods: {
            // 是否允许高版本下载
            handleAllowDownload(id, status) {
                CloudBackupAPI.UpdateApp(id, status).then((res) => {
                    if (res.Code === 0) {
                        this.init();
                        this.$Message.success(`${status === 1 ? "允许" : "禁止"}高版本下载设置成功`);
                    } else {
                        this.init();
                        this.$Message.error(res.Message);
                    }
                }).catch((err) => {
                    console.log(err);
                    this.init();
                    this.$Message.error('操作失败');
                });
            },
            onPageChange(value) {
                this.searchform.page.current = value;
                this.init();
            },
            onPageSizechange(value) {
                this.searchform.page.size = value;
                this.searchform.page.current = 1
                this.init();
            },
            openAdd() {
                this.visible = true;
            },
            closeAdd() {
                this.init();
            },
            // 选择app
            selectAction(value) {
                this.pkgName = "";
                this.apps.forEach((item) => {
                    if (item.ID == value) {
                        this.pkgName = item.PkgName;
                    }
                });
            },
            unbind(id) {
                CloudBackupAPI.UnbindApp(id).then((res) => {
                    if (res.Code === 0) {
                        this.$Message.success("解绑成功");
                        this.init();
                    } else {
                        this.$Message.error(res.Message);
                    }
                }).catch((err) => {
                    console.log(err);
                    this.$Message.error('操作失败');
                });
            },
            init() {
                const params = {
                    Page: this.searchform.page.current,
                    Limit: this.searchform.page.size,
                    Params: this.searchform.params
                }
                CloudBackupAPI.GetRankAppList(params).then((res) => {
                    if (res.Code === 0) {
                        this.table.data = res.Data.Data || [];
                        this.searchform.page.total = res.Data.Count;
                    } else {
                        this.$Message.error(res.Message);
                    }
                });
            },

            toRankManage() {
                this.$router.push({
                    name: "gamespace_cloud_backup_manage",
                    // query: {
                    //     type: this.$route.query.type || 1,
                    // },
                });
            },

            handleGameSearch2(value) {
                GameAPI.LikeApp({ value }).then((res) => {
                    this.apps = res.Data || [];
                });
            },
            handleSubmit() {
                this.$refs["insideformScope"].validate((valid) => {
                    if (valid) {
                        const params = {
                            PoolId: this.searchform.params.PoolId,
                            AppId: this.insideformScope.AppID,
                            IsHighVersionDownload: this.insideformScope.IsHighVersionDownload ? 1 : 2
                        }
                        CloudBackupAPI.BindApp(params).then((res) => {
                            if (res.Code === 0) {
                                this.insideformScope.AppID = undefined;
                                this.$Message.success("绑定成功");
                                this.visible = false;
                                this.init();
                                this.loading = false;
                                this.$nextTick(() => (this.loading = true));
                            } else {
                                this.$Message.error(res.Message);
                                this.loading = false;
                                this.$nextTick(() => (this.loading = true));
                            }
                        });
                    } else {
                        this.loading = false;
                        this.$nextTick(() => (this.loading = true));
                    }
                });
            },
        },
        mounted() {
            // this.table.columns = Tables.RenderColumns(this.table.columns, this);
            this.init();
            //注册监听事件
            // this.option = this.$route.query.option || "button";
            // if (this.$route.query.type == 9) {
            //     this.table.columns = this.table.columns1;
            // }
        },
    };
</script>