<!--礼包榜单-->
<template>
  <Card dis-hover>
    <Row style="margin-bottom: 15px;" :gutter="10">
      <i-col :span="5" :xxl="4">
        <Select v-model="search.PoolID" clearable placeholder="请选择类型">
          <Option :value="1">发现好游戏</Option>
          <Option :value="2">负一屏</Option>
        </Select>
      </i-col>

      <i-col :span="5" :xxl="4">
        <Button @click="init()" type="primary">查询</Button>
      </i-col>
    </Row>

    <Table :data="tableData" :columns="columns" border>
      <template slot="AppName" slot-scope="{row}">
        <Avatar shape="square" :src="row.AppIcon" size="small" style="margin-right: 4px;" />
        <Tag>{{row.AppName}}</Tag>
      </template>

      <template slot="opt" slot-scope="{row}">
        <Poptip
          confirm
          transfer
          title="确定要移除吗？"
          @on-ok="unBind(row)">
          <Button type="error" size="small" style="margin-right: 8px;">移除</Button>
        </Poptip>
<!--        <Button type="primary" size="small" style="margin-right: 8px;">查看</Button>-->
        <Button @click="toTop(row)" type="primary" size="small">置顶</Button>
      </template>
    </Table>


    <div style="margin: 10px 0;overflow: hidden">
      <div style="float: right">
        <Page
          :total="page.total"
          :current="page.current"
          :page-size="page.size"
          :page-size-opts="[10,20,40,80,100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>
    </div>

  </Card>
</template>

<script>
  import GameGiftAPI from "@/api/gamespace/gamegif";

  export default {
    name: '',
    data () {
      return {
        search: {PoolID:1},
        page: {
          current: 1,
          size: 10,
          total: 0
        },

        tableData: [],
        columns: [
          {title: 'AppID', key: 'ID', width: 100},
          {title: 'App名称', slot: 'AppName', minWidth: 160},
          {title: '包名', key: 'PkgName',minWidth: 120},
          {title: '操作', slot: 'opt', width: 180},
        ]

      }
    },
    mounted () {
      this.init()
    },
    methods: {
      onPageChange(value) {
        this.page.current = value;
        this.init();
      },
      onPageSizechange(value) {
        this.page.size = value;
        this.init();
      },

      init() {
        let p = {
          Limit: this.page.size,
          Page: this.page.current,
          Params: this.search
        }
        GameGiftAPI.GiftRankList(p).then(res => {
          if (res.Code === 0) {
            this.page.total = res.Data.Count
            this.tableData = res.Data.Data || []
          }

        })
      },

      unBind(row) {
        GameGiftAPI.UnbindFromRank(row.ID).then(res => {
          if (res.Code === 0) {
            this.$Message.success('移除成功')
            this.init()
          } else {
            this.$Message.error(res.Message)
          }
        })
      },

      toTop(row) {
        GameGiftAPI.TopRank(row.ID).then(res=> {
          if (res.Code === 0) {
            this.$Message.success('置顶成功')
            this.init()
          } else {
            this.$Message.error(res.Message)
          }
        })

      }

    }
  }
</script>

<style scoped>

</style>
