<template>
	<div>
		<Card>
			<div style="margin: 10px">
				<Row :gutter="10">
					<Col span="6">
					<Select
						v-model="searchform.params.id"
						:loading="searchform.appname.loading"
						clearable
						filterable
						remote
						:remote-method="handleGameSearch"
						placeholder="请输入游戏名称"
					>
						<Option
							v-for="item in searchform.appname.data"
							:value="item.ID"
							:key="item.ID"
						>{{ item.AppName }}</Option>
					</Select>
					</Col>
					<Col span="6">
					<Button
						type="success"
						shape="circle"
						icon="ios-search"
						@click="init"
					>搜索</Button>
					</Col>
				</Row>
			</div>

			<Table
				:loading="table.loading"
				border
				ref="selection"
				:columns="table.columns"
				:data="table.data"
			>
			</Table>

			<div style="margin: 10px; overflow: hidden">
				<div style="float: right">
					<Page
						:total="searchform.page.total"
						:current="searchform.page.current"
						:page-size="searchform.page.size"
						@on-change="onPageChange"
						@on-page-size-change="onPageSizechange"
						show-sizer
						show-total
					></Page>
				</div>
			</div>
		</Card>
		<check-status
			ref="checkstatus"
			@onClose="closeCheckStatus"
		/>
		<AddGifModel
			v-if="showgifmodal"
			:currentGame.sync="currentGame"
            :personList.sync="personList"
			@on-close-model="closeModel"
		></AddGifModel>
		<EditGift
			v-if="showgiftEdit"
			:currentGame.sync="currentGame"
            :personList.sync="personList"
			@on-close-model="showgiftEdit = false"
			@on-init="
        showgiftEdit = false;
        init();
      "
		/>
		<SupplyKeys
			v-if="showSupply"
			:currentGame.sync="currentGame"
			@on-close-model="showSupply = false"
			@on-init="
        showSupply = false;
        init();
      "
		/>
	</div>
</template>

<script>
import GameAPI from '@/api/gamespace/game'
import commentApi from '@/api/gamespace/comment'
import GameGiftAPI from '@/api/gamespace/gamegif'
import Tables from '_c/tables'
import CheckStatus from '_c/gamespace/gift/status'
import AddGifModel from '_c/gamespace/game/addgif'
import EditGift from '_c/gamespace/game/EditGift'
import SupplyKeys from '_c/gamespace/game/SupplyKey'
import { formatTimes } from '@/libs/tools'

export default {
	name: 'game',
	components: {
		CheckStatus,
		AddGifModel,
		EditGift,
		SupplyKeys,
	},
	data() {
		return {
			currentGame: null,
			showgifmodal: false,
			showgiftEdit: false, //4.7迭代新增
			showSupply: false, //4.7迭代新增
			gifFile: null,
			searchform: {
				params: { id: undefined },
				page: {
					total: 100,
					current: 1,
					size: 10,
				},
				appname: {
					loading: false,
					data: [],
				},
			},
            personList: [],
			table: {
				loading: false,
				data: [],
				columns: [
					{ title: '礼包ID', width: 80, key: 'ID' },
					{
						title: '游戏名称',
						width: 200,
						render: (h, params) => {
							const div = []
							if (params.row.IconURL !== '') {
								let icon = h('Avatar', {
									props: {
										shape: 'square',
										src: params.row.AppIcon,
										size: 'small',
									},
									style: {
										marginRight: '5px',
									},
								})
								div.push(icon)
							}
							if (params.row.ButtonText !== '') {
								let tag = h('Tag', { props: {} }, params.row.AppName)
								div.push(tag)
							}
							return h('div', div)
						},
					},
					{
						title: '游戏包名',
						minWidth: 250,
						render: (h, params) => {
							return h('Tag', { props: {} }, params.row.PkgName)
						},
					},
					{
						title: '礼包状态',
						width: 100,
						key: 'Status',
						render: (h, params) => {
							if (params.row.GiftStatus === 0) {
								return h('Tag', { props: { color: 'warning' } }, '待处理')
							}
							if (params.row.GiftStatus === 1) {
								return h('Tag', { props: { color: 'success' } }, '上架')
							}
							if (params.row.GiftStatus === 2) {
								return h('Tag', { props: { color: 'error' } }, '下架')
							}
							if (params.row.GiftStatus === 3) {
								return h('Tag', { props: { color: 'primary' } }, '发放完毕')
							}
						},
					},
					{
						title: '礼包标题',
						minWidth: 200,
						key: 'Tags',
						render: (h, params) => {
							return h('Tag', { props: {} }, params.row.Title)
						},
					},
					{
						title: '礼包类型',
						width: 150,
						render: (h, params) => {
							if (params.row.GiftType === 1) {
								return h('Tag', { props: { color: 'primary' } }, '预约礼包')
							} else if (params.row.GiftType === 3) {
								return h('Tag', { props: { color: 'default' } }, '抽奖礼包')
							} else if (params.row.GiftType === 4) {
								return h('Tag', { props: { color: 'primary' } }, '预约下载礼包')
							} else if (params.row.GiftType === 5) {
								return h('Tag', { props: { color: 'primary' } }, '新机活动礼包')
							} else if (params.row.GiftType === 6) {
								return h('Tag', { props: { color: 'primary' } }, 'VIP专属礼包')
							}
							return h('Tag', { props: { color: 'success' } }, '普通礼包')
						},
					},
					{
						title: '可领取最低VIP等级',
						width: 180,
						key: 'Count',
						render: (h, params) => {
							return h('Tag', { props: {} }, params.row.FilterLevel)
						},
					},
					{
						title: '礼包数量',
						width: 180,
						key: 'Count',
						render: (h, params) => {
							return h('Tag', { props: {} }, params.row.Limit + '/' + params.row.Count)
						},
					},
					{
						title: '生效周期',
						width: 300,
						key: 'StartTime',
						render: (h, params) => {
							return h(
								'span',
								{
									props: {},
									attrs: {
										style: `color:${this.getStatus(params.row) ? 'green' : 'red'}`,
									},
								},
								(formatTimes(params.row.StartTime) || '暂无开始时间') + '～' + formatTimes(params.row.ExpiredEnd)
							)
						},
					},
					{
						title: '操作',
						width: 280,
						key: 'handle',
						fixed: 'right',
						button: [
							(h, params, vm) => {
								return h(
									'Button',
									{
										props: {
											type: 'warning',
											size: 'small',
										},
										on: {
											click: () => {
												this.$refs.checkstatus.show(params.row.ID, params.row.Status, params.row.Opinion)
											},
										},
										style: {
											marginRight: '5px',
										},
									},
									'审核发布'
								)
							},
							(h, params, vm) => {
								if (params.row.Count == 0) {
									return h(
										'Button',
										{
											props: {
												type: 'success',
												size: 'small',
											},
											on: {
												click: () => {
													this.showAddGameGif(params)
												},
											},
											style: {
												marginRight: '5px',
											},
										},
										'上传文件'
									)
								}
							},
							(h, params, vm) => {
								if (params.row.GiftStatus == 1 && (params.row.GiftType == 0 || params.row.GiftType == 6)) {
									return h(
										'Button',
										{
											props: {
												type: 'primary',
												size: 'small',
											},
											on: {
												click: () => {
													this.send(params.row)
												},
											},
											style: {
												marginRight: '5px',
											},
										},
										'投放'
									)
								}
							},
							//4.7迭代新增
							(h, params, vm) => {
								return h(
									'Button',
									{
										props: {
											type: 'info',
											size: 'small',
										},
										on: {
											click: () => {
												this.showEditGameGif(params.row)
											},
										},
										style: {
											marginRight: '5px',
										},
									},
									params.row.GiftStatus == 1 ? '查看' : '编辑'
								)
							},
							//4.7迭代新增
							(h, params, vm) => {
								if (params.row.GiftStatus == 2) {
									return h(
										'Button',
										{
											props: {
												type: 'success',
												size: 'small',
											},
											on: {
												click: () => {
													this.currentGame = params.row
													this.showSupply = true
												},
											},
											style: {
												marginRight: '5px',
											},
										},
										'补码'
									)
								}
							},
						],
					},
				],
			},
		}
	},
	methods: {
		showAddGameGif(params) {
			this.currentGame = params.row
			this.currentGame.ShowType = false
			this.showgifmodal = true
		},
		//编辑
		showEditGameGif(params) {
			this.currentGame = params
			this.currentGame.ShowType = params.GiftStatus == 1 ? false : true
			this.showgiftEdit = true
		},
		closeModel() {
			this.init()
			this.showgifmodal = false
		},
		handleGameSearch(value) {
			GameAPI.LikeApp({ value }).then(res => {
				this.searchform.appname.data = res.Data
			})
		},
		onPageChange(value) {
			this.searchform.page.current = value
			this.init()
		},
		onPageSizechange(value) {
			this.searchform.page.size = value
			this.init()
		},
		closeCheckStatus() {
			this.init()
		},
		init() {
			GameGiftAPI.FindByPage(this.searchform.page.size, this.searchform.page.current, this.searchform.params).then(res => {
				if (res.Data.Data) {
					this.table.data = res.Data.Data
				} else {
					this.table.data = []
				}
				this.searchform.page.total = res.Data.Count
			})
		},

		// 投放
		send(row) {
			GameGiftAPI.BindToRank(row.ID).then(res => {
				if (res.Code === 0) {
					this.$Message.success('投放成功')
				} else {
					this.$Message.error(res.Message)
				}
			})
		},
		//校验生效周期状态
		getStatus(row) {
			const now = new Date().getTime()
			const start = new Date(row.StartTime).getTime()
			const end = new Date(row.ExpiredEnd).getTime()
			return row.GiftStatus == 1 && now > start && now < end
		},
        // sdk 5.5.0新增
		getPersonList() {
			const params = {
				page: 1,
				pageSize: 9999,
			}
			commentApi.GetPersonList(params).then(res => {
				if (res.Code == 0) {
					this.personList = res.Data.List
				} else {
					this.$Message.error('获取预警负责人失败')
				}
			})
		},
	},
	mounted() {
		this.table.columns = Tables.RenderColumns(this.table.columns, this)
		this.init()
        this.getPersonList()
		// 注册监听事件
	},
	// activated() {
	//   this.init();
	// }
}
</script>
