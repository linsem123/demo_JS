<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.gametag.loading"
              clearable
              filterable
              remote
              :remote-method="handleTagSearch"
              placeholder="请输入标签"
            >
              <Option
                v-for="item in searchform.gametag.data"
                :value="item.ID"
                :key="item.ID"
              >{{ item.Name }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Select v-model="searchform.params.appType"  placeholder="请选择应用类型" clearable>
              <Option v-for="s in appTypeList" :value="s.ID">{{s.Title}}</Option>
            </Select>
          </Col>
          <!--<Col span="6">-->
            <!--<Select v-model="searchform.params.appType"  placeholder="请选择应用类型" clearable>-->
              <!--<Option v-for="s in appTypeList" :value="s.ID">{{s.Title}}</Option>-->
            <!--</Select>-->
          <!--</Col>-->
          <Col span="6">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
        </Row>
      </div>
      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      ></Table>
      <div style="margin: 10px;overflow: hidden">
        <div style="float: left">
          <Button type="info" shape="circle" icon="plus-round" @click="openAdd">新增</Button>
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>
  </div>
</template>

<script>
import Tables from "_c/tables";
import GameTagAPI from "@/api/gamespace/gametag";
export default {
  name: "list",
  data() {
    return {
      searchform: {
        params: { id: undefined , appType: 0},
        page: {
          total: 100,
          current: 1,
          size: 10
        },
        gametag: {
          loading: false,
          data: []
        }
      },
      table: {
        loading: false,
        data: [],
        columns: [
          { title: "分类", key: "Name" },
          {
            title: "应用类型",
            key: "AppType",
            render: (h, params) => {
              if (params.row.AppType === 0) {
                return h("Tag", { props: { color: "default" } }, "游戏");
              }
              if (params.row.AppType === 1) {
                return h("Tag", { props: { color: "default" } }, "应用");
              }
            }
          },
          {
            title: "创建时间",
            key: "CreatedAt",
            timeformat: true
            // render: Tables.Renders.formatTime
          },
          {
            title: "操作",
            key: "handle",
            options: ["edit"]
            // render:Tables.Renders.handleBtn
          }
        ]
      },
      appTypeList: [
        {ID: 0, Title: '游戏'},
        {ID: 1, Title: '应用'},
      ],
    };
  },
  methods: {
    handleTagSearch(value) {
      GameTagAPI.Like({ value }).then(res => {
        this.searchform.gametag.data = res.Data;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    edit(params) {
      this.$router.push({
        name: "gamespace_gametag_edit",
        params: { id: params.row.ID }
      });
    },
    delete(param) {
      console.log(param);
    },
    init() {
      GameTagAPI.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then(res => {
        if (res.Data.Data){
          this.table.data = res.Data.Data;
        }
        this.searchform.page.total = res.Data.Count;
      });
    },
    openAdd() {
      this.$router.push({
        name: "gamespace_gametag_add"
      });
    },
    closeAdd() {
      this.init();
    }
  },
  mounted() {
    this.table.columns = Tables.RenderColumns(this.table.columns, this);
    this.$on("on-enable", this.enable);
    this.$on("on-delete", this.delete);
    this.$on("on-edit", this.edit);
    this.init();
    //注册监听事件
  },activated() {
     this.init();
  }
};
</script>
