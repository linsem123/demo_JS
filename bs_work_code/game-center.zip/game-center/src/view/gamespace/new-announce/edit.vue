<template>
  <div>
    <Card :title="announceID ? '编辑公告：' + formData.Title : '新增公告'">
      <Form ref="formData" :model="formData" :rules="rules" :label-width="150">
        <FormItem label="公告名称：" prop="Title">
          <Input
            type="text"
            v-model.trim="formData.Title"
            placeholder="请输入公告名称"
            style="width: 400px"
            clearable
          />
        </FormItem>

        <FormItem label="公告类型：" required>
          <RadioGroup v-model="formData.AnnType" @on-change="annTypeChange">
            <Radio
              v-for="item in annTypeList"
              :label="item.value"
              :key="item.value"
              :disabled="
                announceID > 0 &&
                (formData.IsCoverAnchoring == 1 || formData.IsAllocate)
              "
              >{{ item.label }}</Radio
            >
          </RadioGroup>
        </FormItem>

        <FormItem label="跳转类型：" required>
          <RadioGroup v-model="formData.JumpType" @on-change="jumpTypeChange">
            <Radio
              :label="item.id"
              v-for="item of filterJumpList"
              :key="item.id"
              >{{ item.Name }}</Radio
            >
          </RadioGroup>
        </FormItem>

        <!-- DeepLink包名/action包名 -->
        <FormItem
          :label="checkJumpData.PkgLabel"
          v-if="formData.JumpType == 5 || formData.JumpType == 10"
          prop="DeepLinkPkgName"
          key="DeepLinkPkgName"
        >
          <Input
            v-model.trim="formData.DeepLinkPkgName"
            :placeholder="checkJumpData.PkgPlaceholder"
            style="width: 400px"
            clearable
          />
        </FormItem>
        <!-- H5跳转链接/deeplink -->
        <FormItem
          :label="checkJumpData.label"
          v-if="
            formData.JumpType == 5 ||
            formData.JumpType == 9 ||
            formData.JumpType == 10
          "
          prop="DeepLink"
          key="DeepLink"
        >
          <Input
            type="text"
            v-model.trim="formData.DeepLink"
            :placeholder="checkJumpData.placeholder"
            clearable
            style="width: 400px"
          />
        </FormItem>
        <!-- 是否设置兜底DeepLink -->
        <FormItem
          label="是否配置兜底dp："
          v-if="formData.JumpType == 5"
          key="IsConfigBackup"
        >
          <Checkbox v-model="formData.IsConfigBackup"></Checkbox>
        </FormItem>
        <!-- 兜底DeepLink包名 -->
        <FormItem
          label="兜底dp包名："
          v-if="formData.JumpType == 5"
          prop="BackupDeepLinkPkgName"
          key="dpName"
        >
          <Input
            v-model.trim="formData.BackupDeepLinkPkgName"
            placeholder="请输入兜底dp包名"
            style="width: 400px"
            clearable
          />
        </FormItem>
        <!-- 兜底deeplink -->
        <FormItem
          label="兜底dp："
          v-if="formData.JumpType == 5"
          prop="BackupDeepLink"
          key="BackupDeepLink"
        >
          <Input
            type="text"
            v-model.trim="formData.BackupDeepLink"
            placeholder="请输入兜底dp"
            clearable
            style="width: 400px"
          />
        </FormItem>

        <!-- 榜单类型-->
        <FormItem
          label="榜单类型："
          v-if="formData.JumpType == 4 || formData.JumpType == 15"
          key="rankType"
        >
          <Selection
            v-model="rankType"
            :dataList="rankTypeList"
            :width="200"
            :clearable="false"
            @on-change="changeRankType"
          />
        </FormItem>

        <!-- App详情/榜单/帖子榜单-->
        <FormItem
          :label="checkJumpData.label"
          v-if="[1, 4, 12, 13, 15].includes(formData.JumpType)"
          prop="JumpTypeID"
          key="JumpTypeID"
        >
          <CommonSelect
            v-model="formData.JumpTypeID"
            :placeholder="checkJumpData.placeholder"
            :serverData="checkJumpData.serverData"
            style="width: 400px"
            @on-change="changeJumpValue"
            ref="jumpsource"
          />
        </FormItem>
        <FormItem v-if="formData.JumpType == 1" label="app包名">
          {{ pkgName }}
        </FormItem>
        <!-- H5活动/文章详情-->
        <FormItem
          :label="checkJumpData.label"
          v-if="formData.JumpType == 2 || formData.JumpType == 3"
          prop="ActivityID"
          key="ActivityID"
        >
          <CommonSelect
            v-model="formData.ActivityID"
            :placeholder="checkJumpData.placeholder"
            :serverData="checkJumpData.serverData"
            style="width: 400px"
            @on-change="changeActValue"
            ref="actsource"
          />
        </FormItem>
        <!-- 帖子榜单-落地页类型/文章详情-->
        <FormItem
          label="落地页类型："
          v-if="formData.JumpType == 15"
          prop="JumpFloorPageType"
          key="JumpFloorPageType"
        >
          <Selection
            v-model="formData.JumpFloorPageType"
            :clearable="true"
            :dataList="floorList"
            :width="200"
          />
        </FormItem>

        <!-- Banner图片 -->
        <FormItem
          label="banner："
          class="ivu-form-item-required"
          v-if="
            formData.AnnType == 1 ||
            formData.AnnType == 6 ||
            formData.AnnType == 7
          "
          key="GifImgUrl"
        >
          <div
            style="
              display: inline-block;
              margin-right: 20px;
              text-align: center;
            "
            v-if="formData.AnnType == 1"
          >
            <UploadImg v-model="formData.ImgUrl" module="gamespace" />
            <p>静态图</p>
          </div>
          <div style="display: inline-block; text-align: center">
            <FormItem prop="GifImgUrl">
              <UploadImg v-model="formData.GifImgUrl" module="gamespace" />
              <p v-if="formData.AnnType == 1">
                <span style="color: red">*</span>gif图
              </p>
            </FormItem>
          </div>
        </FormItem>
        <FormItem
          label="banner："
          class="ivu-form-item-required"
          prop="ImgUrlVertical"
          v-if="formData.AnnType == 4"
          key="ImgUrlVertical"
        >
          <UploadImg v-model="formData.ImgUrlVertical" module="gamespace" />
        </FormItem>
        <!-- 跳转类型为app且公告类型不为退出弹窗时展示 -->
        <FormItem
          label="自动安装："
          v-if="formData.JumpType == 1 && formData.AnnType != 7"
        >
          <Checkbox v-model="formData.AutoInstall" />
        </FormItem>

        <!-- 公告类型为 首页弹窗时展示-->
        <FormItem
          label="发现好游戏版本类型："
          prop="FindGameType"
          v-if="formData.AnnType == 1"
        >
          <RadioGroup v-model="formData.FindGameType">
            <Radio :label="2">竖版</Radio>
            <Radio :label="1">横版</Radio>
          </RadioGroup>
        </FormItem>

        <!-- 公告类型为 开屏公告/首页弹窗时展示 start-->
        <FormItem
          label="广告文案："
          prop="AnnLogoTitle"
          v-if="formData.AnnType == 1||formData.AnnType == 4"
        >
          <Input
            type="text"
            v-model.trim="formData.AnnLogoTitle"
            placeholder="请输入广告文案"
            style="width: 400px"
            clearable
          />
        </FormItem>
        <FormItem
          label="按钮样式："
          required
          prop="AnnButtonStyle"
          v-if="formData.AnnType == 1||formData.AnnType == 4"
          key="AnnButtonStyle"
        >
          <RadioGroup v-model="formData.AnnButtonStyle">
            <Radio :label="1">扫光</Radio>
            <Radio :label="2">光环+箭头</Radio>
            <Radio :label="3">扫光+光圈</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem
          label="广告标识："
          prop="IsShowAnnLogo"
          v-if="formData.AnnType == 1||formData.AnnType == 4"
        >
          <RadioGroup v-model="formData.IsShowAnnLogo">
            <Radio :label="1">展示</Radio>
            <Radio :label="0">隐藏</Radio>
          </RadioGroup>
        </FormItem>
        <!-- 公告类型为 开屏公告时展示 end-->
        <FormItem label="生效周期：" prop="Expired">
          <DateRange
            v-model="formData.Expired"
            @on-change="
              (value) => {
                formData.StartTime = value.start;
                formData.ExpiredDate = value.end;
              }
            "
          />
        </FormItem>
        <FormItem label="展示频率：" prop="ShowFrequency">
          <RadioGroup v-model="formData.ShowFrequency">
            <Radio :label="index + 1" v-for="(item, index) of frequencyList">{{
              item
            }}</Radio>
          </RadioGroup>
        </FormItem>
        <FormItem label="是否定向人群：">
          <div style="display: inline-block" @click="hadleToast">
            <i-switch
              size="large"
              v-model="formData.IsAllocate"
              :disabled="formData.IsCoverAnchoring == 1"
              @on-change="changeIsAllocate"
            >
              <span slot="open">是</span>
              <span slot="close">否</span>
            </i-switch>
          </div>
          <div
            style="max-width: 400px; margin-top: 10px"
            @click="hadleToast"
            v-show="formData.IsAllocate"
          >
            <Input
              placeholder="填写数据平台-定时任务ID"
              :clearable="true"
              v-model.trim="formData.AllocateId"
              :disabled="formData.IsCoverAnchoring == 1"
              @on-keyup="checkNumber('AllocateId')"
            />
          </div>
        </FormItem>
        <FormItem label="是否锚定公告：" v-show="formData.IsAllocate">
          <div style="display: inline-block" @click="hadleToast">
            <i-switch
              size="large"
              v-model="formData.IsAnchoring"
              :disabled="formData.IsCoverAnchoring == 1"
              @on-change="changeIsAnchoring"
            >
              <span slot="open">是</span>
              <span slot="close">否</span>
            </i-switch>
          </div>
        </FormItem>
        <FormItem
          label="锚定公告ID："
          v-show="formData.IsAllocate && formData.IsAnchoring"
        >
          <div style="display: inline-block; width: 400px" @click="hadleToast">
            <Input
              v-model.trim="formData.AnchoringId"
              placeholder="选择需锚定的公告ID"
              @on-keyup="checkNumber('AnchoringId')"
              @on-blur="getAnnounceByID()"
              clearable
              :disabled="formData.IsCoverAnchoring == 1"
            />
          </div>
        </FormItem>
        <FormItem
          label="锚定公告名称："
          v-show="formData.IsAllocate && formData.IsAnchoring"
        >
          <div style="display: inline-block; width: 400px" @click="hadleToast">
            <Input
              :value="formData.AnchoringName"
              disabled
              v-if="formData.IsCoverAnchoring == 1"
            />
            <LikeSearch
              v-else
              v-model="formData.AnchoringId"
              placeholder="选择需锚定的公告名称"
              :serverData="postServerData"
              ref="LikeSearch"
              clearable
              @on-change="changeAnchoringId"
            />
          </div>
        </FormItem>
        <FormItem>
          <Button @click="submitcheck()" type="primary" style="width: 100px"
            >提交</Button
          >
          <Button @click="cancel()" style="margin-left: 40px">取消</Button>
        </FormItem>
      </Form>
    </Card>
  </div>
</template>

<script>
import UploadImg from "_c/shark-upload/index.vue";
import AnnounceAPI from "@/api/gamespace/announce";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";
import CommonSelect from "_c/common-select";
import Selection from "_c/Selection";
import LikeSearch from "_c/like-search";

export default {
  name: "edit",
  components: {
    UploadImg,
    DateRange,
    CommonSelect,
    Selection,
    LikeSearch,
  },
  data() {
    const checkJumpData = (rule, value, callback) => {
      if (!value) {
        callback("请选择按钮样式");
      }
      callback();
    };
    const checkJumpData1 = (rule, value, callback) => {
      if (!value) {
        callback("请选择落地页类型");
      }
      callback();
    };
    const checkJumpData2 = (rule, value, callback) => {
      if (!value) {
        callback("请选择展示频率");
      }
      callback();
    };
    const checkJumpData3 = (rule, value, callback) => {
      if (!value) {
        callback("请选择绑定资源");
      }
      callback();
    };
    const checkJumpData4 = (rule, value, callback) => {
      if (!value) {
        callback("请选择绑定资源");
      }
      callback();
    };
    const checkBackupDp = (rule, value, callback) => {
      if (this.formData.IsConfigBackup && !value) {
        callback("请输入兜底dp");
      }
      callback();
    };
    const checkBackupDpPkg = (rule, value, callback) => {
      if (this.formData.IsConfigBackup && !value) {
        callback("请输入兜底dp包名");
      }
      callback();
    };

    return {
      pkgName: "",
      announceID: 0, //ID
      rankType: 1,
      formData: {
        ID: undefined,
        Content: "", //描述
        Title: "", //标题
        AnnType: 1, //公告类型
        Placement: 1, //默认为游戏中心
        ImgUrl: "", //静态图/横版
        ImgUrlVertical: "", //竖版图片
        ResourceID: undefined, //文章ID-sdk
        JumpType: 1, //跳转类型
        AutoInstall: false, //自动安装
        JumpTypeID: undefined, //跳转活动ID
        ShowFrequency: 3, //展示频率
        ShowType: undefined, //展示范围-sdk展示该项
        DeepLink: "",
        DeepLinkPkgName: "",
        ExpiredDate: "", //结束时间
        IsJump: 1, //是否可跳转，游戏SDK-展示该项
        PlayTime: undefined, //播放时长-公告类型为走马灯公告-sdk展示
        GameIDs: [], //选择游戏-sdk
        FindGameType: 2, //发现好游戏版本类型
        ActivityID: undefined, //H5活动/文章活动ID
        GifImgUrl: "", //gif图
        Expired: [], //4.7迭代增加生效周期
        AnnLogoTitle: "点击前往详情页或第三方应用", //4.8迭代增加广告文案
        AnnButtonStyle: 1, //4.8迭代增加按钮样式
        IsShowAnnLogo: 1, //4.8迭代增加广告标识
        IsAllocate: false, //
        IsCoverAnchoring: 0, //
        IsAnchoring: false,
        AllocateId: undefined, //定时任务ID
        AnchoringId: undefined,
        IsConfigBackup: false, // 4.10迭代开发
        BackupDeepLink: "", // 4.10迭代开发
        BackupDeepLinkPkgName: "", // 4.10迭代开发
      },
      //跳转类型
      JumpTypeList: [
        {
          id: 1,
          Name: "App详情",
          label: "绑定app：",
          placeholder: "请输入App名称",
          serverData: {
            likeUrl: "gameLike",
            likeData: {},
            setUrl: "getGameList",
            setData: {},
            IdKey: "ID",
            NameKey: "AppName",
          },
        },
        {
          id: 2,
          Name: "H5活动",
          label: "绑定跳转活动：",
          placeholder: "请输入活动名称",
          serverData: {
            likeUrl: "LikeActivity",
            likeData: { type: 2 },
            setUrl: "getActivityByID",
            setData: {},
            IdKey: "ID",
            NameKey: "Title",
          },
        },
        {
          id: 3,
          Name: "文章详情",
          label: "绑定跳转活动：",
          placeholder: "请输入活动名称",
          serverData: {
            likeUrl: "LikeActivity",
            likeData: { type: 1 },
            setUrl: "getActivityByID",
            setData: {},
            IdKey: "ID",
            NameKey: "Title",
          },
        },
        {
          id: 4,
          Name: "榜单",
          label: "绑定榜单：",
          placeholder: "请输入榜单名称",
          serverData: {
            likeUrl: "LikeRank",
            likeData: { type: 1 },
            setUrl: "GetRankById",
            setData: {},
            IdKey: "ID",
            NameKey: "Title",
          },
        },
        {
          id: 5,
          Name: "DeepLink",
          label: "绑定DeepLink：",
          placeholder: "请填写DeepLink",
          PkgLabel: "绑定DeepLink包名：",
          PkgPlaceholder: "请填写包名",
        },
        {
          id: 9,
          Name: "H5",
          label: "H5跳转链接：",
          placeholder: "请输入跳转链接",
        },
        {
          id: 10,
          Name: "action",
          label: "绑定ActionUrl：",
          placeholder: "请填写ActionUrl",
          PkgLabel: "绑定Action包名：",
          PkgPlaceholder: "请填写包名",
        },
        {
          id: 12,
          Name: "论坛帖",
          label: "绑定论坛帖：",
          placeholder: "请输入论坛帖标题",
          serverData: {
            likeUrl: "PostLike",
            likeData: {},
            setUrl: "getPostList",
            setData: { IsTop: false, Limit: 10, Page: 1 },
            IdKey: "Id",
            NameKey: "Title",
          },
        },
        {
          id: 13,
          Name: "重点游戏宣传",
          label: "绑定重点游戏：",
          placeholder: "请输入重点游戏标题",
          serverData: {
            likeUrl: "KeyGameLike",
            likeData: {},
            setUrl: "getKeyGameList",
            setData: {},
            IdKey: "ID",
            NameKey: "Title",
          },
        },
        {
          id: 15,
          Name: "帖子榜单",
          label: "绑定活动：",
          placeholder: "请输入帖子榜单名称",
          serverData: {
            likeUrl: "PostRankLike",
            likeData: { status: 1, type: 1 },
            setUrl: "getPostRank",
            setData: {},
            IdKey: "Id",
            NameKey: "Title",
          },
        },
      ],
      // 内容类型
      annTypeList: [
        { value: 1, label: "首页弹窗" },
        // { value: 2, label: "文章公告" },
        // { value: 3, label: "走马灯公告" },
        { value: 4, label: "开屏公告" },
        { value: 6, label: "悬浮球" },
        { value: 7, label: "退出弹窗" },
      ],
      resourceList: [],
      gameList: [],
      //数据校验
      rules: {
        Title: [{ required: true, message: "请填写公告名称", trigger: "blur" }],
        ImgUrlVertical: [
          { required: true, message: "请上传", trigger: "blur" },
        ],
        GifImgUrl: [{ required: true, message: "请上传", trigger: "blur" }],
        JumpTypeID: [
          {
            required: true,
            trigger: "change",
            message: "请绑定资源",
            type: "number",
          },
          {
            validator: checkJumpData4,
            trigger: "change",
            type: "number",
          },
        ],
        ActivityID: [
          {
            required: true,
            trigger: "change",
            message: "请绑定资源",
            type: "number",
          },
          {
            validator: checkJumpData3,
            trigger: "change",
            type: "number",
          },
        ],
        DeepLink: [{ required: true, message: "请填写", trigger: "blur" }],
        DeepLinkPkgName: [
          { required: true, message: "请填写包名", trigger: "blur" },
        ],
        JumpFloorPageType: [
          {
            required: true,
            trigger: "change",
            message: "请选择落地页类型",
            type: "number",
          },
          {
            validator: checkJumpData1,
            trigger: "change",
            type: "number",
          },
        ],
        AnnButtonStyle: [
          {
            required: true,
            trigger: "change",
            message: "请选择按钮类型",
            type: "number",
          },
          {
            validator: checkJumpData,
            trigger: "change",
            type: "number",
          },
        ],
        AnnLogoTitle: [
          { required: true, message: "请填写广告文案", trigger: "blur" },
        ],
        Expired: [
          {
            validator: checkDateRange,
            trigger: "change",
            type: "array",
          },
        ],
        ShowFrequency: [
          {
            required: true,
            trigger: "change",
            message: "请选择展示频率",
            type: "number",
          },
          {
            validator: checkJumpData2,
            trigger: "change",
            type: "number",
          },
        ],
        FindGameType: [
          {
            required: true,
            trigger: "change",
            message: "请选择发现好游戏版本类型",
            type: "number",
          },
        ],
        IsShowAnnLogo: [
          {
            required: true,
            trigger: "change",
            message: "请选择广告标识",
            type: "number",
          },
        ],
        BackupDeepLink: [{ validator: checkBackupDp, trigger: "blur" }],
        BackupDeepLinkPkgName: [
          { validator: checkBackupDpPkg, trigger: "blur" },
        ],
      },
      frequencyList: ["仅一次", "每次", "每天一次", "每3天一次", "每7天一次"],
    };
  },
  mounted() {
    this.announceID = Number(this.$route.params.id);
    if (this.announceID) {
      //编辑-初始化数据
      this.editInit();
    }
  },
  computed: {
    //选中跳转类型对应数据
    checkJumpData() {
      if (this.formData.JumpType == 4 || this.formData.JumpType == 15) {
        let index = this.JumpTypeList.findIndex(
          (item) => this.formData.JumpType == item.id
        );
        this.JumpTypeList[index].serverData.likeData.type = this.rankType;
      }
      return this.JumpTypeList.find((v) => v.id == this.formData.JumpType);
    },
    //根据公告类型展示跳转类型
    filterJumpList() {
      let arr = [1, 2, 3, 4, 5, 9, 10, 12, 13, 15];
      let AnnType = this.formData.AnnType;

      // if (AnnType == 6) {
      //   arr = [1, 2, 3, 4, 5, 9, 12, 13, 15];
      // }
      return this.JumpTypeList.filter((item) => arr.includes(item.id));
    },
    //生成当前时间
    nowTime() {
      return formatTimes(new Date());
    },
    postServerData() {
      return {
        likeUrl: "GetAnnounce",
        likeData: {
          Id: 0,
          AnnType: this.formData.AnnType,
        },
        IdKey: "Id",
        NameKey: "Title",
        listName: "List",
      };
    },
    rankTypeList() {
      if (this.formData.JumpType == 4) {
        return [
          { Id: 1, Name: "普通榜单" },
          { Id: 2, Name: "排行榜单" },
          { Id: 3, Name: "预约榜单" },
          { Id: 4, Name: "分类榜单" },
          { Id: 5, Name: "标签榜单" },
          { Id: 6, Name: "飙升榜单" },
          { Id: 9, Name: "7天预约榜" },
        ];
      }
      if (this.formData.JumpType == 15) {
        return [
          { Id: 1, Name: "普通榜单" },
          { Id: 2, Name: "全量视频帖榜单" },
          { Id: 3, Name: "游戏榜单" },
        ];
      }
      return [];
    },
    floorList() {
      if (this.formData.JumpType == 15) {
        if (this.rankType == 1) {
          return [
            { Id: 9, Name: "帖子列表落地页" },
            { Id: 10, Name: "图文资讯落地页" },
            { Id: 11, Name: "内容轮播落地页" },
          ];
        } else {
          return [
            { Id: 12, Name: "视频帖榜单列表" },
            { Id: 13, Name: "沉浸式播放页" },
          ];
        }
      }
      return [];
    },
  },
  methods: {
    //选择绑定资源
    changeJumpValue({ value, index }) {
      if (value) {
        this.pkgName = value.PkgName;
      } else {
        this.pkgName = "";
      }
      if (index == 0) {
        if (this.formData.JumpType == 4) {
          this.rankType = value.RankType;
        }
      } else if (index > 0) {
        if (this.formData.JumpType == 1) {
          this.formData.JumpPkgName = value.PkgName;
        } else if (this.formData.JumpType == 13) {
          this.formData.JumpUrl = value.FeedURL;
        }
      }
    },
    //选择绑定H5活动/文章
    changeActValue({ value, index }) {
      if (index) {
        if (this.formData.JumpType == 2 || this.formData.JumpType == 3) {
          this.formData.DeepLink = value.FeedURL;
          this.formData.JumpTypeID = value.FeedID;
        }
      }
    },
    editInit() {
      //调用接口获取数据
      AnnounceAPI.getInitData(this.announceID).then((res) => {
        if (res.Code == 0) {
          let editData = res.Data;
          if (editData instanceof Object && Object.keys(editData).length > 0) {
            if (editData.Placement != 1) {
              //旧数据或数据不兼容的情况
              this.$Message.error("请在旧的【公告管理】编辑");
              return;
            }
            editData.StartTime = formatTimes(editData.StartTime);
            editData.ExpiredDate = formatTimes(editData.ExpiredDate);
            editData.Expired = [editData.StartTime, editData.ExpiredDate]; //4.7迭代增加生效周期
            editData.IsShowAnnLogo = Number(editData.IsShowAnnLogo);
            editData.AllocateId = editData.AllocateId || "";
            editData.AnchoringId = editData.AnchoringId || "";
            editData.IsAllocate = editData.IsAllocate == 1 ? true : false;
            editData.IsAnchoring = editData.IsAnchoring == 1 ? true : false;
            editData.IsConfigBackup =
              editData.IsConfigBackup == 1 ? true : false;
            this.rankType = editData.RankType;
            this.formData = editData;
            this.getAnnounceByID();
          }
        } else {
          this.$Message.error(res.Message || "数据查询失败");
        }
      });
    },

    annTypeChange(val) {
      if (val == 6 && this.formData.JumpType == 10) {
        //悬浮球没有action跳转类型，如果选中跳转类型为action-绑定资源数据初始化
        this.jumpTypeChange();
        this.formData.JumpType = 1;
      }
      this.formData.FindGameType = val == 1 ? 2 : undefined;
    },
    //更改跳转类型绑定的跳转资源初始化
    jumpTypeChange(val) {
      this.$refs["jumpsource"] && this.$refs["jumpsource"].clearText();
      this.$refs["actsource"] && this.$refs["actsource"].clearText();
      this.formData.JumpTypeID = undefined;
      this.formData.ActivityID = undefined;
      this.formData.DeepLink = "";
      this.formData.DeepLinkPkgName = "";
      this.formData.JumpPkgName = "";
      this.formData.JumpUrl = "";
      this.formData.IsConfigBackup = false;
      this.formData.BackupDeepLink = "";
      this.formData.BackupDeepLinkPkgName = "";
      this.rankType = 1; //榜单类型初始化
    },
    //更改榜单类型，绑定榜单资源清空
    changeRankType() {
      this.$refs.jumpsource.clearText();
    },
    modelApi(params) {
      if (this.announceID) {
        return AnnounceAPI.EditAnnounce(params.ID, params);
      } else {
        return AnnounceAPI.AddAnnounce(params);
      }
    },
    submitcheck() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          if (this.formData.IsAllocate && !this.formData.AllocateId) {
            this.$Message.error("请填写大数据人群包");
            return;
          }
          if (this.formData.IsAnchoring && !this.formData.AnchoringId) {
            this.$Message.error("请填写锚定公告");
            return;
          }
          if (!this.formData.StartTime || !this.formData.ExpiredDate) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitForm();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitForm();
          }
        }
      });
    },
    submitForm() {
      let params = JSON.parse(JSON.stringify(this.formData));
      params.JumpTypeID = Number(params.JumpTypeID);
      params.StartTime = params.StartTime || this.nowTime;
      params.ExpiredDate = params.ExpiredDate || "2099-01-01 00:00:00";
      params.IsShowAnnLogo = Boolean(params.IsShowAnnLogo);
      params.IsAllocate = params.IsAllocate ? 1 : 2;
      params.IsAnchoring = params.IsAnchoring ? 1 : 2;
      params.AllocateId = Number(params.AllocateId);
      params.AnchoringId = Number(params.AnchoringId);
      params.IsConfigBackup = params.IsConfigBackup ? 1 : 2;
      params.RankType = this.rankType; //4.10
      this.modelApi(params).then((res) => {
        if (res.Code === 0) {
          this.cancel();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    cancel() {
      this.$router.push({
        name: "new_announce",
      });
    },
    //已被锚定则不允许操作
    hadleToast() {
      if (this.formData.IsCoverAnchoring == 1) {
        this.$Message.error("该公告已被锚定");
      }
    },
    //输入锚定ID同时填写名称
    getAnnounceByID() {
      if (this.formData.AnchoringId) {
        AnnounceAPI.GetAnnounce({
          Id: Number(this.formData.AnchoringId),
          Title: "",
          Anntype: this.formData.AnnType,
        }).then((res) => {
          if (res.Code == 0) {
            let list = res.Data.List || [];
            if (list.length > 0) {
              this.$set(this.formData, "AnchoringName", list[0].Title);
              this.$refs.LikeSearch.setQuery({
                id: Number(this.formData.AnchoringId),
                title: this.formData.AnchoringName,
              });
            } else {
              this.$Message.error("该公告ID无效");
            }
          }
        });
      }
    },
    changeIsAnchoring(value) {
      if (!value) {
        //是否锚定开关关闭，清空已填写内容
        this.formData.AnchoringId = "";
        this.$refs.LikeSearch.clearText();
      }
    },
    //输入只匹配数字
    checkNumber(keyName) {
      this.formData[keyName] = this.formData[keyName]
        ? Number(this.formData[keyName].replace(/[^\d]/g, "")).toString()
        : undefined;
    },
    changeAnchoringId(value) {
      console.log(value);
    },
    changeIsAllocate(value) {
      if (!value) {
        //是否锚定开关关闭，清空已填写内容
        this.formData.IsAnchoring = false;
        this.formData.AnchoringId = "";
        this.$refs.LikeSearch.clearText();
      }
    },
  },
};
</script>

<style scoped>
</style>
