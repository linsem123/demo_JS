<template>
  <div>
    <Card>
      <Table :data="tableData" :columns="columns" border>
        <template slot-scope="{ row }" slot="AnnType">
          {{ annTypeList[row.AnnType] || "未知类型" }}
        </template>
        <template slot-scope="{ row }" slot="ShowFrequency">
          {{ frequencyList[row.ShowFrequency] || "未知类型" }}
        </template>
        <template slot-scope="{ row }" slot="Status">
          <Tag v-if="row.Status == 1" color="success">上线</Tag>
          <Tag v-else-if="row.Status == 2" color="error">下线</Tag>
          <Tag v-else color="warning">待处理</Tag>
        </template>
        <template slot-scope="{ row }" slot="Expired">
          <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">
            {{ timeFormat(row.StartTime) || "暂无开始时间" }}~{{
              timeFormat(row.ExpiredDate)
            }}</span
          >
        </template>

        <template slot-scope="{ row }" slot="IsAllocate">
          {{ row.IsAllocate == 1 ? "已定向" : "未定向" }}
        </template>

        <template slot-scope="{ row }" slot="IsCoverAnchoring">
          {{ row.IsCoverAnchoring == 1 ? "被锚定" : "未锚定" }}
        </template>

        <template slot-scope="{ row }" slot="opt">
          <Button
            @click="edit(row)"
            type="primary"
            size="small"
            class="table-opt"
            >编辑</Button
          >
          <Button
            @click="updateStatus(row.ID, 1)"
            type="success"
            v-if="row.Status != 1"
            size="small"
            class="table-opt"
            >上架</Button
          >
          <Button
            @click="updateStatus(row.ID, 2)"
            type="error"
            v-else
            size="small"
            class="table-opt"
            >下架</Button
          >
        </template>
      </Table>
      <Row style="margin-top: 10px">
        <Col :span="6">
          <Button @click="edit()" type="info" shape="circle" icon="md-add"
            >新增模块</Button
          >
        </Col>
        <Col :span="18" align="right">
          <Page
            :total="page.total"
            :current="page.current"
            :page-size="page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </Col>
      </Row>
    </Card>
  </div>
</template>

<script>
import { formatTimes } from "@/libs/tools";
import AnnounceAPI from "@/api/gamespace/announce";
export default {
  name: "gamespace_announce",
  data() {
    return {
      page: {
        total: 0,
        current: 1,
        size: 10,
      },
      tableData: [],
      annTypeList: [
        "未知类型",
        "首页弹窗",
        "文章公告",
        "走马灯公告",
        "开屏公告",
        "SDK退出弹窗",
        "悬浮球",
        "退出弹窗",
      ],
      frequencyList: [
        "--",
        "仅一次",
        "每次",
        "每天一次",
        "每3天一次",
        "每7天一次",
      ],
      columns: [
        { title: "公告ID", key: "ID", width: 80 },
        { title: "标题", key: "Title", minWidth: 150 },
        { title: "类型", slot: "AnnType", minWidth: 100 },
        { title: "展示频率", slot: "ShowFrequency", minWidth: 100 },
        { title: "状态", slot: "Status", minWidth: 100 },
        { title: "生效周期", slot: "Expired", minWidth: 280 },
        { title: "是否已定向", slot: "IsAllocate", minWidth: 100 },
        { title: "是否被锚定", slot: "IsCoverAnchoring", minWidth: 100 },
        {
          title: "操作",
          slot: "opt",
          minWidth: 130,
          align: "center",
          fixed: "right",
        },
      ],
    };
  },
  mounted() {
    this.init();
  },
  methods: {
    timeFormat(date) {
      return formatTimes(date);
    },
    onPageChange(value) {
      this.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.page.size = value;
      this.init();
    },
    init() {
      AnnounceAPI.getAnnounce({
        Page: this.page.current,
        Limit: this.page.size,
      }).then((res) => {
        if (res.Code === 0) {
          this.tableData = res.Data.Data;
          this.page.total = res.Data.Count;
        }
      });
    },
    //编辑&新增
    edit(value) {
      if (!value) {
        this.$router.push({
          name: "new_announce_edit",
          params: {
            id: 0,
          },
        });
      } else {
        this.$router.push({
          name: "new_announce_edit",
          params: {
            id: value.ID,
          },
        });
      }
    },
    updateStatus(id, status) {
      AnnounceAPI.UpdateStatus(id, status).then((res) => {
        if (res.Code === 0) {
          this.$Message.success("操作成功");
          this.init();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //校验生效周期状态
    getStatus(row) {
      const now = new Date().getTime();
      const start = new Date(row.StartTime).getTime();
      const end = new Date(row.ExpiredDate).getTime();
      return row.Status == 1 && now > start && now < end;
    },
  },
};
</script>

<style scoped>
.table-opt {
  margin-right: 5px;
}
</style>
