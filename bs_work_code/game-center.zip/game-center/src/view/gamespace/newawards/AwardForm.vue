<template>
  <Form ref="formData" :model="formData" :label-width="120" :rules="rules">
    <FormItem label="奖品名称：" prop="Title">
      <Input v-model="formData.Title" placeholder="请填写奖品名称" />
    </FormItem>
    <FormItem label="奖品图片：" prop="URL">
      <UploadImg v-model="formData.URL" :module="'award'" />
    </FormItem>
    <FormItem label="奖品类型：" prop="AwardType">
      <RadioGroup v-model="formData.AwardType" @on-change="changeType">
        <Radio v-for="j in list.AwardTypeList" :label="j.Id" :key="j.Id">{{
          j.Name
        }}</Radio>
      </RadioGroup>
    </FormItem>

    <FormItem label="礼包：" prop="ResourceId" v-if="formData.AwardType == 1">
      <Select
        v-model="formData.ResourceId"
        @on-change="giftChange"
        clearable
        filterable
        remote
        :remote-method="handleGiftSearch"
        placeholder="请输入礼包名称"
        ref="gift"
      >
        <Option v-for="j in giftList" :value="j.ID" :key="j.ID">{{
          j.Title
        }}</Option>
      </Select>
    </FormItem>
    <FormItem label="优惠券：" prop="ResourceId" v-if="formData.AwardType == 4">
      <Select
        v-model="formData.ResourceId"
        @on-change="giftChange"
        clearable
        filterable
        remote
        :remote-method="handleCouponSearch"
        placeholder="请输入优惠券名称"
        ref="coupon"
      >
        <Option v-for="j in giftList" :value="j.ID" :key="j.ID">{{
          j.CouponTitle
        }}</Option>
      </Select>
    </FormItem>
    <FormItem label="积分数：" prop="PointNum" v-if="formData.AwardType == 5">
      <InputNumber
        v-model="formData.PointNum"
        @on-blur="changeNum('PointNum')"
        :min="0"
      />
    </FormItem>

    <FormItem label=" 奖品数量：" prop="Num">
      <InputNumber
        v-model="formData.Num"
        :min="0"
        @on-blur="changeNum('Num')"
        :disabled="formData.AwardType == 4 || formData.AwardType == 1"
      />
    </FormItem>
    <FormItem label="中奖限制：" prop="MaxReceiveNum">
      <InputNumber
        v-model="formData.MaxReceiveNum"
        @on-blur="changeNum('MaxReceiveNum')"
        :min="0"
        :disabled="formData.AwardType == 4 || formData.AwardType == 1"
      />
    </FormItem>
    <FormItem label="使用方法：" prop="Content">
      <Input type="textarea" v-model="formData.Content" />
    </FormItem>
  </Form>
</template>
<script>
import UploadImg from "_c/shark-upload";
import Selection from "_c/Selection.vue";
import AwardAPI from "@/api/gamespace/newawards.js";
import GameGifAPI from "@/api/gamespace/gamegif";
import CouponAPI from "@/api/gamespace/coupon";
export default {
  components: { UploadImg, Selection },
  props: {
    list: Object,
    PollId: Number,
    checkTable: Object,
  },
  watch: {
    checkTable: {
      handler(val, old) {
        if (val && val.ID) {
          this.formData = JSON.parse(JSON.stringify(this.checkTable));
          if (this.formData.AwardType == 1) {
            GameGifAPI.GiftsByType(3).then((res) => {
              this.giftList = res.Data || [];
              let label = this.giftList.filter(
                (v) => v.ID == this.checkTable.ResourceId
              )[0].Title;
              this.$refs["gift"].setQuery(label);
              this.$refs["gift"].toggleMenu(null, false);
            });
          }
          if (this.formData.AwardType == 4) {
            CouponAPI.couponDetail(this.formData.ResourceId).then((res) => {
              this.giftList = [res.Data] || [];
              this.$refs["coupon"].setQuery(res.Data.CouponTitle);
              this.$refs["coupon"].toggleMenu(null, false);
            });
          }
        } else {
          this.reset();
        }
      },
      immediate: true,
    },
  },
  data() {
    const ResourceValue = (rule, value, callback) => {
      if (!this.formData.ResourceId) {
        if (this.formData.AwardType == 1) {
          callback("请输入礼包名称");
        } else if (this.formData.AwardType == 4) {
          callback("请输入优惠券名称");
        }
      }
      callback();
    };
    return {
      formData: {
        Title: "",
        URL: "",
        Content: "",
        AwardType: 2,
        MaxReceiveNum: 0,
        Num: 0,
        ResourceId: undefined,
        PointNum: 0,
      },
      rules: {
        Title: [{ required: true, message: "请填写奖品名称", trigger: "blur" }],
        URL: [{ required: true, message: "请上传封面图", trigger: "blur" }],
        ResourceId: [
          {
            validator: ResourceValue,
            trigger: "change",
            type: "number",
          },
        ],
      },
      giftList: [],
      loading: false,
    };
  },
  methods: {
    changeNum(name) {
      let val = this.formData[name];
      if (val < 0) {
        this.formData[name] = Number(val.toString().replace("-", ""));
      }
    },
    changeType() {
      this.giftList = [];
      this.formData.ResourceId = undefined;
    },
    giftChange() {
      this.giftList.forEach((v) => {
        if (v.ID == this.formData.ResourceId) {
          this.formData.Num = v.Count || v.CouponTotalCount;
          this.formData.MaxReceiveNum = v.MaxReceiveCount;
          this.formData.Content = v.Instruction || "";
        }
      });
    },
    handleGiftSearch(value) {
      GameGifAPI.LikeGift({ value }).then((res) => {
        this.giftList = res.Data;
      });
    },
    handleCouponSearch(value) {
      CouponAPI.couponLike(value, 8).then((res) => {
        this.giftList = res.Data;
      });
    },
    commit() {
      this.$refs["formData"].validate((valid) => {
        if (valid) {
          if (this.loading) {
            this.$Message.error("提交中,请勿重复操作");
            return;
          }
          this.loading = true;
          if (this.formData.ID) {
            //编辑
            AwardAPI.EditAward({
              PoolID: this.PollId,
              ...this.formData,
            })
              .then((res) => {
                if (res.Code == 0) {
                  this.$emit("change-award");
                } else {
                  this.$Message.error(res.Message);
                }
              })
              .finally(() => {
                this.loading = false;
              });
          } else {
            //新增
            AwardAPI.AddAward({ PoolID: this.PollId, ...this.formData })
              .then((res) => {
                if (res.Code == 0) {
                  this.$emit("change-award");
                  this.reset();
                } else {
                  this.$Message.error(res.Message);
                }
              })
              .finally(() => {
                this.loading = false;
              });
          }
        }
      });
    },
    reset() {
      this.formData = {
        Title: "",
        URL: "",
        Content: "",
        AwardType: 2,
        ResourceId: undefined,
        MaxReceiveNum: 0,
        Num: 0,
        PointNum: 0,
      };
    },
  },
};
</script>