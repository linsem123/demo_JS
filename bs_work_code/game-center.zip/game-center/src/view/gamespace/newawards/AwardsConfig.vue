<template>
  <Table :data="tableData" border :columns="columns">
    <template slot-scope="{ row }" slot="AwardType">
      {{ findName(row.AwardType, list.AwardTypeList) }}
    </template>
    <template slot-scope="{ row }" slot="Rate">
      {{ row.Rate / 10000 }}%
    </template>
    <template slot-scope="{ row }" slot="Num">
      {{ row.Num - row.LimitCount }}/ {{ row.Num }}
    </template>
    <template slot-scope="{ row }" slot="IsMustWin">
      {{ row.IsMustWin ? "是" : "否" }}
    </template>
    <template slot-scope="{ row }" slot="IsDefault">
      {{ row.IsDefault ? "是" : "否" }}
    </template>
    <template slot-scope="{ row }" slot="action">
      <Button
        size="small"
        type="primary"
        @click="handelEdit(row)"
        :disabled="status == 1"
        >编辑</Button
      >
    </template>
  </Table>
</template>
<script>
export default {
  name: "AwardsConfig",
  props: {
    AwardsTable: Array,
    list: Object,
    status: Number,
  },
  watch: {
    AwardsTable: {
      handler(val, old) {
        this.tableData = JSON.parse(JSON.stringify(this.AwardsTable));
      },
      immediate: true,
    },
  },
  data() {
    return {
      tableData: [],
      columns: [
        {
          title: "奖品ID",
          key: "ID",
          width: 80,
          align: "center",
        },
        {
          title: "奖品名称",
          key: "Title",
          width: 100,
          align: "center",
        },
        {
          title: `奖品数量（已领取/总量）`,
          slot: "Num",
          width: 120,
          align: "center",
        },
        {
          title: "奖品类型",
          slot: "AwardType",
          width: 100,
          align: "center",
        },
        {
          title: "中奖概率",
          slot: "Rate",
          width: 80,
          align: "center",
        },
        {
          title: "中奖限制",
          key: "MaxReceiveNum",
          width: 80,
          align: "center",
        },
        {
          title: "抽几次必中",
          key: "MustWinCount",
          width: 80,
          align: "center",
        },
        {
          title: "是否为必中奖品",
          slot: "IsMustWin",
          width: 80,
          align: "center",
        },
        {
          title: "是否为兜底奖品",
          slot: "IsDefault",
          width: 80,
          align: "center",
        },
        {
          title: "操作",
          slot: "action",
          width: 100,
          fixed: "right",
          align: "center",
        },
      ],
    };
  },
  methods: {
    //根据ID找出对应名称
    findName(ID, list) {
      let index = list.findIndex((v) => v.Id == ID);
      if (index > -1) {
        return list[index].Name;
      }
      return "--";
    },
    handelEdit(row) {
      this.$emit("edit-award", row);
    },
  },
};
</script>