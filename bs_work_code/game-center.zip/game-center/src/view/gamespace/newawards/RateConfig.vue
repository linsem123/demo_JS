<template>
  <div>
    <span style="color: red; font-size: 18px">注：1,000,000</span>
    <Table :data="tableData" border :columns="columns">
      <template slot-scope="{ index }" slot="Rate">
        <InputNumber v-model="tableData[index].Rate" />
      </template>
      <template slot-scope="{ index }" slot="percent">
        {{ tableData[index].Rate / 10000 }}%
      </template>
    </Table>
  </div>
</template>
<script>
import AwardAPI from "@/api/gamespace/newawards.js";
export default {
  name: "AwardSpecial",
  props: {
    AwardsTable: Array,
    PoolId: Number,
  },
  mounted() {},
  watch: {
    AwardsTable: {
      handler(val, old) {
        this.tableData = JSON.parse(JSON.stringify(this.AwardsTable));
      },
      immediate: true,
    },
  },

  data() {
    return {
      tableData: [],
      columns: [
        {
          title: "ID",
          key: "ID",
          align: "center",
        },
        {
          title: "奖品名称",
          key: "Title",
          align: "center",
        },
        {
          title: "中奖概率",
          slot: "Rate",
          align: "center",
        },
        {
          title: "概率（%）",
          slot: "percent",
          align: "center",
        },
      ],
    };
  },
  methods: {
    commit() {
      if (this.tableData.some((v) => v.Rate != 0 && !v.Rate)) {
        this.$Message.error("概率有未填项");
        return;
      }
      let rate = this.tableData
        .map((v) => v.Rate)
        .reduce((a, b) => {
          return a + b;
        });
      if (rate != 1000000) {
        this.$Message.error("相加等于1000000");
        return;
      }
      let filterArr = [];
      this.tableData.forEach((now, index) => {
        let i = this.AwardsTable.findIndex(
          (origin) => origin.ID == now.ID && origin.Rate != now.Rate
        );
        if (i == index) {
          filterArr.push({
            Id: now.ID,
            Rate: now.Rate,
          });
        }
      });
      AwardAPI.SetRate({ PoolID: this.PoolId, Rate: filterArr }).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("成功！");
          this.$emit("change-special");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>