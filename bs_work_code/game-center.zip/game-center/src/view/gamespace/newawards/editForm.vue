<template>
  <Form ref="formData" :model="formData" :label-width="120" :rules="rules">
    <FormItem label="活动标题：" prop="Title">
      <Input v-model="formData.Title" placeholder="请填写活动标题" />
    </FormItem>
    <FormItem label="上传大图" prop="BigBg">
      <UploadImg v-model="formData.BigBg" module="award" />
    </FormItem>
    <FormItem label="上传中图：" prop="MidBg">
      <UploadImg v-model="formData.MidBg" module="award"></UploadImg>
    </FormItem>
    <FormItem label="截止时间：" prop="ExpiredEnd">
      <DatePicker
        v-model="formData.ExpiredEnd"
        type="datetime"
        format="yyyy-MM-dd HH:mm"
      ></DatePicker>
    </FormItem>
    <FormItem label="抽奖类型：" prop="PoolType">
      <Selection
        v-model="formData.PoolType"
        :dataList="filterTypeList"
        :clearable="false"
      />
    </FormItem>
    <FormItem
      label="启动游戏时长："
      prop="StartUpTime"
      v-if="formData.PoolType == 4"
    >
      <InputNumber v-model="formData.StartUpTime" :precision="0" /> 秒
    </FormItem>
    <FormItem label="投放位置：" prop="Placement">
      <Selection
        v-model="formData.Placement"
        :dataList="list.PlaceList"
        :clearable="false"
        @on-change="changePlacement"
      />
    </FormItem>
    <FormItem
      label="抽奖周期："
      prop="ActionCycle"
      v-if="formData.PoolType == 4"
    >
      <Selection
        v-model="formData.ActionCycle"
        :dataList="list.ActionList"
        :clearable="false"
      />
    </FormItem>
  </Form>
</template>
<script>
import UploadImg from "_c/shark-upload";
import Selection from "_c/Selection.vue";
import AwardAPI from "@/api/gamespace/newawards.js";
export default {
  components: { UploadImg, Selection },
  props: {
    list: Object,
    Id: Number,
    checkTable: Object,
  },
  watch: {
    Id(newVal, oldVal) {
      if (newVal && newVal != oldVal) {
        this.formData = JSON.parse(JSON.stringify(this.checkTable));
        this.formData.ExpiredEnd = new Date(this.formData.ExpiredEnd);
      } else {
        this.formData = {
          Title: "",
          BigBg: "",
          MidBg: "",
          ExpiredEnd: "",
          PoolType: 1,
          Placement: 1,
          StartUpTime: 1,
          ActionCycle: 1,
        };
      }
    },
  },
  data() {
    const StartUpNum = (rule, value, callback) => {
      if (Number(value) <= 0) {
        callback("请输入大于0的数字");
      }
      callback();
    };
    return {
      formData: {
        Title: "",
        BigBg: "",
        MidBg: "",
        ExpiredEnd: "",
        PoolType: 1,
        Placement: 1,
        StartUpTime: 1,
        ActionCycle: 1,
      },
      rules: {
        Title: [{ required: true, message: "请填写活动标题", trigger: "blur" }],
        BigBg: [{ required: true, message: "请上传大图", trigger: "blur" }],
        MidBg: [
          {
            required: true,
            message: "请上传中图",
            trigger: "change",
          },
        ],
        ExpiredEnd: [
          {
            required: true,
            message: "请选择截止时间",
            trigger: "blur",
            type: "date",
          },
        ],
        StartUpTime: [
          { required: true, validator: StartUpNum, trigger: "blur" },
        ],
      },
    };
  },
  computed: {
    filterTypeList() {
      if (this.formData.Placement == 2) {
        return this.list.TypeList.filter((v) => {
          return [2].includes(v.Id);
        });
      }
      // if (this.formData.Placement == 3) {
      //   return this.list.TypeList.filter((v) => {
      //     return [1, 2, 3].includes(v.Id);
      //   });
      // }
      return this.list.TypeList;
    },
  },
  methods: {
    changePlacement(val) {
      if (val == 2) {
        this.formData.PoolType = 2;
      }
    },
    commit() {
      this.$refs["formData"].validate((valid) => {
        if (valid) {
          if (this.Id) {
            //编辑
            AwardAPI.EditPool(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$emit("change-act");
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            //新增
            AwardAPI.AddPool(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$emit("change-act");
                this.formData = {
                  Title: "",
                  BigBg: "",
                  ExpiredEnd: "",
                  PoolType: 1,
                  Placement: 1,
                  StartUpTime: 1,
                  ActionCycle: 1,
                };
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
  },
};
</script>