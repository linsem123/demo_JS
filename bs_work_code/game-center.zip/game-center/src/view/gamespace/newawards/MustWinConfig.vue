<template>
  <Table :data="tableData" border :columns="columns">
    <template slot-scope="{ index }" slot="IsMustWin">
      <i-switch
        v-model="tableData[index].IsMustWin"
        :before-change="() => handleBeforeChange(index, 'IsMustWin')"
        @on-change="(value) => heandleChange(value, index)"
      ></i-switch>
    </template>
    <template slot-scope="{ row, index }" slot="MustWinCount">
      <InputNumber
        v-model="tableData[index].MustWinCount"
        :disabled="!row.IsMustWin"
      />
    </template>
  </Table>
</template>
<script>
import AwardAPI from "@/api/gamespace/newawards.js";
export default {
  name: "MustWinConfig",
  props: {
    AwardsTable: Array,
    PoolId: Number,
  },
  mounted() {},
  watch: {
    AwardsTable: {
      handler(val, old) {
        this.tableData = JSON.parse(JSON.stringify(this.AwardsTable));
      },
      immediate: true,
    },
  },

  data() {
    return {
      tableData: [],
      columns: [
        {
          title: "ID",
          key: "ID",
          align: "center",
        },
        {
          title: "奖品名称",
          key: "Title",
          align: "center",
        },
        {
          title: "是否为必中奖品",
          slot: "IsMustWin",
          align: "center",
        },
        {
          title: "抽几次必中",
          slot: "MustWinCount",
          align: "center",
        },
      ],
    };
  },
  methods: {
    handleBeforeChange(index, name) {
      if (!this.tableData[index][name]) {
        let len = 0;
        this.tableData.forEach((v) => {
          if (v[name]) {
            len += 1;
          }
        });
        console.log(len);
        if (len > 0) {
          if (name == "IsDefault") {
            this.$Message.error("兜底奖品最多只能有一个");
          } else {
            this.$Message.error("必中奖品最多只能有一个");
          }
          return new Promise((resolve, reject) => {
            reject();
          });
        }
      }
      return new Promise((resolve) => {
        resolve();
      });
    },
    heandleChange(value, index) {
      if (!value) {
        this.tableData[index].MustWinCount = 0;
      }
    },
    commit() {
      let Items = [];
      this.tableData.forEach((now, index) => {
        let i = this.AwardsTable.findIndex(
          (origin) =>
            origin.ID == now.ID &&
            (origin.IsMustWin != now.IsMustWin ||
              origin.MustWinCount != now.MustWinCount)
        );
        if (i == index) {
          Items.push({
            Id: now.ID,
            Status: now.IsMustWin,
            N: now.MustWinCount,
          });
        }
      });
      AwardAPI.SetMustWin({ PoolID: this.PoolId, Items }).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("成功！");
          this.$emit("change-special");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>