<template>
    <div>
        <Card>
            <Row :gutter="10" style="margin: 10px">
                <Col span="6">
                    <Select
                        v-model="searchform.Params.id"
                        filterable
                        remote
                        :remote-method="handleDeveloperSearch"
                        placeholder="请输入标题"
                        clearable
                    >
                        <Option v-for="(item, index) of TitleList" :key="index" :value="item.ID">{{ item.Title }}</Option>
                    </Select>
                </Col>
                <Col span="6">
                    <Button type="success" shape="circle" icon="ios-search" @click="handleSearch">搜索</Button>
                </Col>

                <Col span="6" align="right">
                    <Button @click="handleDownload" type="primary" icon="md-download">导出</Button>
                </Col>
            </Row>
            <Table
                :loading="table.loading"
                border
                ref="selection"
                :columns="table.columns"
                :data="table.data"
                @on-selection-change="selectionChange"
            >
                <template slot-scope="{ row }" slot="Type">{{ findName(row.PoolType, list.TypeList) }}</template>
                <template slot-scope="{ row }" slot="Cycle">{{ findName(row.ActionCycle, list.ActionList) }}</template>
                <template slot-scope="{ row }" slot="Status">{{ findName(row.Status, list.StatusList) }}</template>
                <template slot-scope="{ row }" slot="Place">{{ findName(row.Placement, list.PlaceList) }}</template>
                <template slot-scope="{ row }" slot="End">
                    {{
                    row.ExpiredEnd | timeFormat
                    }}
                </template>
                <template slot-scope="{ row }" slot="Start">{{ row.CreatedAt | timeFormat }}</template>
                <template slot-scope="{ row }" slot="action">
                    <Button type="primary" size="small" :disabled="row.Status == 1" @click="editPool(row)" style="margin-right: 5px">编辑</Button>
                    <Button type="warning" size="small" @click="AwardsConfig(row)" style="margin-right: 5px">奖品管理</Button>
                    <!-- :disabled="row.Status == 1" -->
                    <Button type="info" size="small" @click="TemplateConfig(row)" style="margin-right: 5px" :disabled="row.Status == 1">配置模板</Button>
                    <Button type="info" size="small" @click="handleCopy(row)" v-show="row.Status == 1">复制链接</Button>
                    <Button type="success" size="small" @click="handleUpdate(row.ID, 1)" v-show="row.Status != 1">上架</Button>
                    <Button type="error" size="small" @click="handleUpdate(row.ID, 2)" style="margin: 5px" v-show="row.Status == 1">下架</Button>
                    <Button type="warning" size="small" style="margin: 5px" @click="handleUpdate(row.ID, 3)" v-show="row.Status == 1">冻结</Button>
                    <Button type="info" size="small" style="margin: 5px" @click="handleCopyAward(row)">复制奖池</Button>
                </template>
            </Table>
            <div style="margin: 10px; overflow: hidden">
                <div style="float: left">
                    <Button type="info" shape="circle" icon="plus-round" @click="addNewPool">新增奖池</Button>
                </div>
                <div style="float: right">
                    <Page
                        :total="searchform.total"
                        :current="searchform.Page"
                        :page-size="searchform.Limit"
                        :page-size-opts="[10, 20, 40, 80, 100]"
                        @on-change="onPageChange"
                        @on-page-size-change="onPageSizechange"
                        show-sizer
                        show-total
                    ></Page>
                </div>
            </div>
        </Card>
        <Modal v-model="showPool" :title="checkedId ? '编辑奖池' : '新增奖池'">
            <editForm :Id="checkedId" ref="editForm" :list="list" :checkTable="checkTable" @change-act="changeAct" />
            <template slot="footer">
                <Button @click="showPool = false">取消</Button>
                <Button @click="handleSubmit('editForm')" type="primary">确定</Button>
            </template>
        </Modal>
        <Modal v-model="showAward" title="奖品管理" :width="930" :z-index="888">
            <Row style="margin-bottom: 10px">
                <Button @click="handleSpecial('RateConfig')" type="primary" :disabled="checkTable.Status == 1">配置概率</Button>
                <Button
                    @click="handleSpecial('DefaultConfig')"
                    type="primary"
                    style="margin-left: 10px"
                    :disabled="checkTable.Status == 1"
                >配置兜底</Button>
                <Button
                    @click="handleSpecial('MustWinConfig')"
                    type="primary"
                    style="margin-left: 10px"
                    :disabled="checkTable.Status == 1"
                >配置必中</Button>
            </Row>
            <AwardsConfig :status="checkTable.Status" :AwardsTable="AwardsTable" :list="list" @edit-award="editAward" />
            <template slot="footer">
                <Button @click="showAward = false">取消</Button>
                <Button @click="editAward()" type="primary" :disabled="AwardsTable.length > 7">新增奖品</Button>
            </template>
        </Modal>
        <Modal v-model="showAwardAdd" :title="checkTable.ID ? '编辑奖品' : '新增奖品'" :z-index="999">
            <AwardForm :list="list" :PollId="checkedId" :checkTable="checkedAwards" ref="AwardForm" @change-award="changeAward" />
            <template slot="footer">
                <Button @click="showAwardAdd = false">取消</Button>
                <Button @click="handleSubmit('AwardForm')" type="primary">确定</Button>
            </template>
        </Modal>
        <Modal v-model="showSpecial" title="编辑" :z-index="999" :width="600">
            <component
                :is="currentTabComponent"
                ref="AwardSpecial"
                :AwardsTable="AwardsTable"
                :PoolId="checkedId"
                @change-special="changeSpecial"
            ></component>
            <template slot="footer">
                <Button @click="showSpecial = false">取消</Button>
                <Button @click="handleSubmit('AwardSpecial')" type="primary">确定</Button>
            </template>
        </Modal>
    </div>
</template>
<script>
import { formatTime } from "@/libs/tools";
import editForm from "./editForm";
import AwardsConfig from "./AwardsConfig";
import AwardForm from "./AwardForm";
import AwardSpecial from "./AwardSpecial";
import RateConfig from "./RateConfig";
import DefaultConfig from "./DefaultConfig";
import MustWinConfig from "./MustWinConfig";
import AwardAPI from "@/api/gamespace/newawards.js";
import AwardsPoolAPI from "@/api/gamespace/awardspool";
import config from "@/config/index";
export default {
    name: "newawards",
    components: {
        editForm,
        AwardsConfig,
        AwardForm,
        AwardSpecial,
        RateConfig,
        DefaultConfig,
        MustWinConfig
    },
    data() {
        return {
            searchform: {
                Params: {
                    // Title: "",
                    id: undefined
                },
                total: 0,
                Page: 1,
                Limit: 10
            },
            table: {
                loading: false,
                columns: [
                    { type: "selection", width: 50 },
                    { title: "活动ID", key: "ID", width: 80, align: "center" },
                    { title: "活动标题", key: "Title", minWidth: 150 },
                    { title: "抽奖类型", slot: "Type", minWidth: 150 },
                    { title: "抽奖周期", slot: "Cycle", minWidth: 150 },
                    { title: "活动状态", slot: "Status", minWidth: 150 },
                    { title: "活动创建时间", slot: "Start", minWidth: 150 },
                    { title: "活动结束时间", slot: "End", minWidth: 150 },
                    { title: "参与人数（按账号）", key: "Count", minWidth: 150 },
                    { title: "投放位置", slot: "Place", minWidth: 150 },
                    {
                        title: "操作",
                        slot: "action",
                        width: 300,
                        align: "center",
                        fixed: "right"
                    }
                ],

                data: []
            },
            list: {
                TypeList: [
                    {
                        Id: 1,
                        Name: "单游戏抽奖"
                    },
                    {
                        Id: 3,
                        Name: "多游戏抽奖"
                    },
                    {
                        Id: 2,
                        Name: "每日抽奖"
                    },
                    {
                        Id: 4,
                        Name: "启动抽奖"
                    }
                ],
                PlaceList: [
                    {
                        Id: 1,
                        Name: "发现好游戏"
                    },
                    {
                        Id: 2,
                        Name: "黑鲨装备箱"
                    },
                    {
                        Id: 3,
                        Name: "应用商店"
                    }
                ],
                ActionList: [
                    { Id: 1, Name: "一次性" },
                    { Id: 2, Name: "每天" },
                    { Id: 3, Name: "每月" }
                ],
                StatusList: [
                    { Id: 0, Name: "待处理", color: "black" },
                    { Id: 1, Name: "上架", color: "green" },
                    { Id: 2, Name: "下架", color: "red" },
                    { Id: 3, Name: "冻结", color: "orange" }
                ],
                AwardTypeList: [
                    { Id: 2, Name: "真实奖品" },
                    { Id: 1, Name: "礼包" },
                    { Id: 4, Name: "优惠券" },
                    { Id: 5, Name: "积分" },
                    { Id: 3, Name: "谢谢参与" }
                ]
            },
            checkedId: undefined,
            checkTable: {},
            showPool: false,
            showAward: false,
            showAwardAdd: false,
            AwardsTable: [],
            checkedAwards: {},
            PollId: undefined,
            showSpecial: false,
            currentTabComponent: "RateConfig",
            TitleList: [],
            selection: []
        };
    },
    filters: {
        timeFormat(value) {
            return formatTime(value);
        }
    },
    mounted() {
        this.searchServer();
    },
    methods: {
        handleDeveloperSearch(value) {
            AwardAPI.getTitle(value).then(res => {
                if (res.Code == 0) {
                    this.TitleList = res.Data || [];
                }
            });
        },
        //根据ID找出对应名称
        findName(ID, list) {
            let index = list.findIndex(v => v.Id == ID);
            if (index > -1) {
                return list[index].Name;
            }
            return "--";
        },

        //新增活动
        addNewPool() {
            this.showPool = true;
            this.checkedId = undefined;
        },
        //编辑活动
        editPool(row) {
            this.showPool = true;
            this.checkedId = row.ID;
            this.checkTable = JSON.parse(JSON.stringify(row));
        },

        // 活动回调
        changeAct() {
            this.showPool = false;
            this.searchServer();
        },

        //奖品管理
        AwardsConfig(row) {
            this.showAward = true;
            this.checkTable = JSON.parse(JSON.stringify(row));
            this.checkedId = row.ID;
            this.getAwardList();
        },
        //查询奖品
        getAwardList() {
            AwardAPI.AwardList(this.checkedId).then(res => {
                if (res.Code == 0) {
                    this.AwardsTable = res.Data || [];
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        //添加/编辑奖品
        editAward(row) {
            this.showAwardAdd = true;
            this.checkedAwards = row;
        },
        changeAward() {
            this.showAwardAdd = false;
            this.getAwardList();
        },

        //特殊配置
        handleSpecial(name) {
            this.currentTabComponent = name;
            this.showSpecial = true;
        },
        changeSpecial() {
            this.showSpecial = false;
            this.getAwardList();
        },
        // 提交
        handleSubmit(name) {
            this.$refs[name].commit();
        },
        //配置模板
        TemplateConfig(row) {
            this.$router.push({
                name: "newawards_template",
                params: {
                    id: row.ID,
                    title: encodeURI(row.Title)
                },
                query: { poolType: row.PoolType, placement: row.Placement }
            });
        },
        //复制链接
        handleCopy(row) {
            var input = document.createElement("input");
            input.setAttribute("id", "copyInput");
            input.setAttribute("value", row.FeedURL);
            document.getElementsByTagName("body")[0].appendChild(input);
            input.select();
            document.execCommand("Copy");
            document.getElementById("copyInput").remove();
            this.$Message.success("复制成功");
        },
        //状态
        handleUpdate(ID, type) {
            AwardAPI.Upstate(ID, type).then(res => {
                if (res.Code == 0) {
                    this.searchServer();
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        onPageChange(value) {
            this.searchform.Page = value;
            this.searchServer();
        },
        onPageSizechange(value) {
            this.searchform.Limit = value;
            this.searchform.Page = 1;
            this.searchServer();
        },
        handleSearch() {
            this.searchform.Page = 1;
            this.searchServer();
        },
        searchServer() {
            AwardAPI.FindByPage(this.searchform).then(res => {
                if (res.Code == 0) {
                    this.table.data = res.Data.Data || [];
                    this.searchform.total = res.Data.Count;
                } else {
                    this.$Message.error(res.Message);
                }
            });
        },
        //勾选
        selectionChange(sel) {
            this.selection = sel.map(s => {
                return s.ID;
            });
        },
        handleDownload() {
            if (this.selection.length === 0) {
                this.$Message.error("请勾选要导出的数据");
            } else {
                AwardsPoolAPI.exportList({ Ids: this.selection }).then(res => {
                    if (res.Code === 0) {
                        let url = res.Data;
                        url = url.replace(".", "");
                        console.log(config.fileBaseUrl + url);
                        window.location.href = config.fileBaseUrl + url;
                    } else {
                        this.$Message.error(res.Message);
                    }
                });
            }
        },
        handleCopyAward(row) {
            this.$Modal.confirm({
                title: "提示",
                okText: "确认",
                cancelText: "取消",
                loading: true,
                content: "<p>是否复制奖池“" + row.Title + "”？</p>",
                onOk: () => {
                    let userData = sessionStorage.getItem("userData");
                    userData = JSON.parse(userData);
                    AwardAPI.copyAward({
                        awardPoolId: row.ID,
                        userName: userData.userName
                    }).then(res => {
                        if (res.Code == 0) {
                            this.$Message.success("复制奖池成功");
                            this.searchServer();
                        } else {
                            this.$Message.error(res.Message || "复制奖池失败");
                        }
                    });
                    this.$Modal.remove();
                }
            });
        }
    }
};
</script>