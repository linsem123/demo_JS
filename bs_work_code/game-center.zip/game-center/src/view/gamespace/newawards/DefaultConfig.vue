<template>
  <Table :data="tableData" border :columns="columns">
    <template slot-scope="{ index }" slot="IsDefault">
      <i-switch
        v-model="tableData[index].IsDefault"
        :before-change="() => handleBeforeChange(index, 'IsDefault')"
      ></i-switch>
    </template>
  </Table>
</template>
<script>
import AwardAPI from "@/api/gamespace/newawards.js";
export default {
  name: "DefaultConfig",
  props: {
    AwardsTable: Array,
    PoolId: Number,
  },
  mounted() {},
  watch: {
    AwardsTable: {
      handler(val, old) {
        this.tableData = JSON.parse(JSON.stringify(this.AwardsTable));
      },
      immediate: true,
    },
  },

  data() {
    return {
      tableData: [],
      columns: [
        {
          title: "ID",
          key: "ID",
          align: "center",
        },
        {
          title: "奖品名称",
          key: "Title",
          align: "center",
        },
        {
          title: "是否为兜底奖品",
          slot: "IsDefault",
          align: "center",
        },
      ],
    };
  },
  methods: {
    handleBeforeChange(index, name) {
      if (!this.tableData[index][name]) {
        let len = 0;
        this.tableData.forEach((v) => {
          if (v[name]) {
            len += 1;
          }
        });
        console.log(len);
        if (len > 0) {
          if (name == "IsDefault") {
            this.$Message.error("兜底奖品最多只能有一个");
          } else {
            this.$Message.error("必中奖品最多只能有一个");
          }
          return new Promise((resolve, reject) => {
            reject();
          });
        }
      }
      return new Promise((resolve) => {
        resolve();
      });
    },

    commit() {
      if (this.tableData.every((v) => !v.IsDefault)) {
        this.$Message.error("至少选择一个兜底奖品");
        return;
      }
      let Items = [];
      this.tableData.forEach((now, index) => {
        let i = this.AwardsTable.findIndex(
          (origin) => origin.ID == now.ID && origin.IsDefault != now.IsDefault
        );
        if (i == index) {
          Items.push({
            Id: now.ID,
            Status: now.IsDefault,
          });
        }
      });
      AwardAPI.SetDefault({ PoolID: this.PoolId, Items }).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("成功！");
          this.$emit("change-special");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>