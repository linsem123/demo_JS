<template>
  <Table :data="tableData" border :columns="columns">
    <template slot-scope="{ index }" slot="Rate">
      <InputNumber v-model="tableData[index].Rate" />
    </template>
    <template slot-scope="{ index }" slot="IsDefault">
      <i-switch
        v-model="tableData[index].IsDefault"
        :before-change="() => handleBeforeChange(index, 'IsDefault')"
      ></i-switch>
    </template>
    <template slot-scope="{ index }" slot="IsMustWin">
      <i-switch
        v-model="tableData[index].IsMustWin"
        :before-change="() => handleBeforeChange(index, 'IsMustWin')"
        @on-change="(value) => heandleChange(value, index)"
      ></i-switch>
    </template>
    <template slot-scope="{ row, index }" slot="MustWinCount">
      <InputNumber
        v-model="tableData[index].MustWinCount"
        :disabled="!row.IsMustWin"
      />
    </template>
  </Table>
</template>
<script>
export default {
  name: "AwardSpecial",
  props: {
    AwardsTable: Array,
  },
  mounted() {},
  watch: {
    AwardsTable: {
      handler(val, old) {
        this.tableData = JSON.parse(JSON.stringify(this.AwardsTable));
      },
      immediate: true,
    },
  },

  data() {
    return {
      tableData: [],
      columns: [
        {
          title: "中奖概率",
          slot: "Rate",
          align: "center",
        },
        {
          title: "是否为兜底奖品",
          slot: "IsDefault",
          align: "center",
        },
        {
          title: "是否为必中奖品",
          slot: "IsMustWin",
          align: "center",
        },
        {
          title: "抽几次必中",
          slot: "MustWinCount",
          align: "center",
        },
      ],
    };
  },
  methods: {
    handleBeforeChange(index, name) {
      if (!this.tableData[index][name]) {
        let len = 0;
        this.tableData.forEach((v) => {
          if (v[name]) {
            len += 1;
          }
        });
        console.log(len);
        if (len > 0) {
          if (name == "IsDefault") {
            this.$Message.error("兜底奖品最多只能有一个");
          } else {
            this.$Message.error("必中奖品最多只能有一个");
          }
          return new Promise((resolve, reject) => {
            reject();
          });
        }
      }
      return new Promise((resolve) => {
        resolve();
      });
    },
    heandleChange(value, index) {
      if (!value) {
        this.tableData[index].MustWinCount = 0;
      }
    },
    commit() {
      let rate = this.tableData.reduce((a, b) => a.Rate + b.Rate);
      console.log(rate);
      if (rate != 10000) {
        this.$Message.error("相加等于10000");
        return;
      }
      this.$emit("change-special");
    },
  },
};
</script>