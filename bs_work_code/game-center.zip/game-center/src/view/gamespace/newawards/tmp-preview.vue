<template>
  <div class="pbody">
    <div class="back">
      <div class="back-inner">
        <div class="backbtn">
          <div class="arrow-btn"></div>
        </div>
        <div class="backtitle">
          <div id="marquee">{{ value.Title }}</div>
        </div>
      </div>
    </div>

    <div class="vir-dom" :style="{ backgroundColor: value.BgColor }">
      <div class="main cl">
        <div class="main_kv">
          <img :src="value.KvBg" alt />
          <div
            v-show="value.PoolType == 1"
            class="install"
            :style="{
              color: `${value['SubmitColor']}`,
              background: `${value['SubmitBgColor']}`,
              'border-color': `${value['SubmitBgColor']}`,
            }"
          >
            安装
          </div>
          <div
            class="transition-dom"
            :style="{
              background:
                'linear-gradient(to top ,' + value.BgColor + ', rgba(0,0,0,0))',
            }"
          ></div>
        </div>
        <div class="main_luck">
          <!--        抽奖转盘-->
          <div class="luck-box" :style="{ backgroundColor: value.AwardColor }">
            <ul class="luck" id="luck">
              <li class="luck1">
                <img :src="awardsList[0] && awardsList[0].URL" alt />
              </li>
              <li class="luck2">
                <img :src="awardsList[1] && awardsList[1].URL" alt />
              </li>
              <li class="luck3">
                <img :src="awardsList[2] && awardsList[2].URL" alt />
              </li>
              <li class="luck4">
                <img :src="awardsList[7] && awardsList[7].URL" alt />
              </li>
              <li
                class="start1 start luck_start_btn"
                href="javascript:void(0);"
                :style="{ background: value.StartColor }"
              >
                <!--                <img :src="value.StartDrawButton" alt="">-->
                <div>
                  <img
                    src="https://cdn-market.blackshark.com/award/1594975885911-go.png"
                    class="go-img"
                    alt
                  />
                  <p>
                    剩余次数：
                    <span id="leftTimes">0</span>
                  </p>
                </div>
              </li>
              <li class="luck5">
                <img :src="awardsList[3] && awardsList[3].URL" alt />
              </li>
              <li class="luck6">
                <img :src="awardsList[6] && awardsList[6].URL" alt />
              </li>
              <li class="luck7">
                <img :src="awardsList[5] && awardsList[5].URL" alt />
              </li>
              <li class="luck8">
                <img :src="awardsList[4] && awardsList[4].URL" alt />
              </li>
            </ul>
            <!--中奖记录-->
            <div class="result-wrap">
              <span
                class="btn-show"
                :style="{
                  background: value.PrizeBgColor,
                  color: value.PrizeTitleColor,
                }"
              >
                查看中奖记录
                <div
                  class="arrow-btn show-arrow"
                  :style="{ borderColor: value.PrizeTitleColor }"
                ></div>
                <!--                  <img class="show-arrow" src="https://cdn-market.blackshark.com/award/1594978244132-合并形状.png" alt="" />-->
              </span>
              <div class="res-list" :style="{ background: value.PrizeBgColor }">
                <table style="width: 100%">
                  <tr>
                    <td style="width: 40px">
                      <img
                        class="prize-img"
                        :src="awardsList[1] && awardsList[1].URL"
                        alt
                      />
                    </td>
                    <td>
                      <span
                        class="prize-name"
                        :style="{ color: value.PrizeNameColor }"
                        >{{ awardsList[1] && awardsList[1].Title }}</span
                      >
                    </td>
                    <td style="width: 80px">
                      <span
                        class="prize-btn"
                        :style="{
                          color: value.BtnText,
                          background: value.BtnBg,
                        }"
                        >查看</span
                      >
                    </td>
                  </tr>
                </table>
              </div>
            </div>
          </div>

          <!--        多游戏抽奖列表-->
          <div class="games-out" v-if="value.PoolType == 3">
            <div
              class="games-box"
              :style="{ backgroundColor: value.AwardColor }"
              v-show="appList.length > 0"
            >
              <p class="box-title" :style="{ color: value.AppListTitleColor }">
                赢取更多抽奖机会
              </p>
              <div class="table-wrap">
                <table cellspacing="0" cellpadding="0">
                  <tr v-for="app in appList">
                    <td style="width: 62px">
                      <img class="appicon" :src="app.AppIcon" alt />
                    </td>
                    <td>
                      <span
                        class="appname"
                        :style="{ color: value.AppNameColor }"
                        >{{ app.AppName }}</span
                      >
                      <span
                        class="appcontent"
                        :style="{ color: value.AppDescColor }"
                        >{{ app.Content }}</span
                      >
                    </td>
                    <td style="width: 80px">
                      <span
                        class="game-install-btn"
                        :style="{ backgroundColor: value.SubmitBgColor }"
                      >
                        <span :style="{ color: value.SubmitColor }">安装</span>
                      </span>
                    </td>
                  </tr>
                </table>
              </div>
            </div>
          </div>

          <!--        规则描述-->
          <div class="rule_box">
            <div class="rules" :style="{ backgroundColor: value.AwardColor }">
              <p class="rule_title" :style="{ color: value.RuleTitleColor }">
                {{ value.RuleTitle }}
              </p>
              <div class="rule_content" :style="{ color: value.RuleColor }">
                {{ value.RuleContent }}
              </div>
            </div>

            <div class="to-result">我是有底线的</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import AwardAPI from "@/api/gamespace/newawards.js";
import GameAPI from "@/api/gamespace/game";

export default {
  name: "",
  props: ["value"],
  watch: {
    "value.AppID"(v, o) {
      if (v > 0) this.getGameData([v]);
    },
    "value.AppIDs"(val, old) {
      if (val != old) {
        this.getGameData(val);
      }
    },
  },
  data() {
    return {
      awardsList: [],
      appList: [],
    };
  },
  mounted() {
    this.getPoolAwards();
  },
  methods: {
    getPoolAwards() {
      AwardAPI.AwardList(this.value.PoolID).then((res) => {
        if (res.Code === 0) this.awardsList = res.Data;
      });
    },
    getGameData(ids) {
      ids = ids || [];
      // let games = [];
      // ids.forEach((id) => {
      //   if (!id) return;
      //   GameAPI.Get(id).then((res) => {
      //     games.push(res.Data);
      //   });
      // });
      // this.appList = games;

      GameAPI.GetGames(ids).then((res) => {
        this.appList = res.Data;
      });
    },
  },
};
</script>

<style scoped lang="less">
.result-wrap {
  padding-bottom: 1px;
  .btn-show {
    display: block;
    margin: 0 auto 20px;
    text-align: center;
    width: 140px;
    height: 32px;
    line-height: 32px;
    border-radius: 20px;
    background: rgba(255, 255, 255, 0.5);
    color: rgba(0, 0, 0, 0.4);
    font-size: 14px;
    &.open .show-arrow {
      transform: rotateX(0deg);
    }
  }
  .show-arrow {
    width: 15px;
    transform: rotateZ(-90deg);
  }
  .res-list {
    background: rgba(255, 255, 255, 0.5);
    padding: 8px 8px 0;
    margin: 0px 20px 20px;
    border-radius: 10px;
    table td {
      padding-bottom: 10px;
    }
    .prize-img {
      width: 40px;
      height: 40px;
      border-radius: 6px;
      display: block;
    }
    .prize-name {
      padding: 0 10px;
      font-size: 16px;
    }
    .prize-btn {
      display: block;
      margin: auto;
      width: 80px;
      height: 34px;
      line-height: 34px;
      border-radius: 20px;
      text-align: center;
      background: #8799a9;
      color: #fff;
      font-size: 16px;
    }
  }
}
.pbody {
  transform: scale(1);
  border: 1px solid #ccc;
  width: 400px;
  .vir-dom {
    background: #131314;
    position: relative;
    height: 700px;
    overflow: auto;
    &::-webkit-scrollbar {
      /*滚动条整体样式*/
      width: 2px; /*高宽分别对应横竖滚动条的尺寸*/
      height: 1px;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 2px;
      -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      background: #999;
    }
    &::-webkit-scrollbar-track {
      /*滚动条里面轨道*/
      -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      border-radius: 10px;
      background: #ededed;
    }
  }
}
a {
  text-decoration: none;
}
ul,
li,
p,
h1,
h2,
h3,
h4,
h5,
dl,
dt,
dd,
body {
  padding: 0;
  margin: 0;
}
ul,
li {
  list-style: none;
}
img {
  border: 0;
}

.cl:after {
  content: "";
  display: block;
  height: 0;
  clear: both;
  visibility: hidden;
}
.cl {
  zoom: 1;
}
.luck {
  margin: 10px auto 0;
  overflow: hidden;
}
.luck li {
  width: 10%;
  float: left;
  font-size: 16px;
  text-align: center;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
/*.luck li:after{content:"";position:absolute;width:100%;height:100%;border-right:1px solid #666;border-top:1px solid #666;top:-1px;left:-1px;}*/
.start {
  width: 100%;
  display: block;
  float: left;
  text-align: center;
  font-size: 20px;
  color: #fff;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
}
.choose {
  border-color: #00c03c !important;
}
.tiger {
  height: 80px;
}
.tiger li {
  width: 20%;
  height: auto;
  border-bottom: 0;
}
.tiger li:first-child {
  margin-left: -1px;
}
.tiger li img {
  display: block;
  width: 100%;
}

.rule_box {
  width: 380px;
  margin: 0 auto;
}
.rules {
  background: #1c1c1f;
  border-radius: 6px;
  padding: 0 15px 20px;
  .rule_title {
    font-size: 16px;
    color: #00c03c;
    letter-spacing: 1.2px;
    text-align: center;
    line-height: 44px;
    border-bottom: 0.5px solid rgba(255, 255, 255, 0.2);
  }
  .rule_content {
    padding-top: 10px;
    font-size: 14px;
    color: rgba(255, 255, 255, 0.8);
    letter-spacing: 0.4px;
    text-align: justify;
    line-height: 24px;
    white-space: pre-line;
  }
}
.arrow-btn {
  display: inline-block;
  vertical-align: middle;
  position: relative;
  width: 20px;
  height: 20px;
  border-color: #222;
  &::before,
  &::after {
    content: "";
    display: block;
    border-top: 2px solid;
    border-color: inherit;
    width: 12.5px;
    height: 0px;
    position: absolute;
    left: 3px;
    border-radius: 1px;
  }
  &::before {
    transform: rotateZ(-45deg);
    top: 5.4px;
  }
  &::after {
    transform: rotateZ(45deg);
    top: 13px;
  }
}
.back {
  position: fixed;
  z-index: 120;
  background: #fff;
  left: 0;
  top: 0;
  width: 100%;
  padding-top: 8px;
  padding-bottom: 8px;
  box-sizing: border-box;
  transform: rotate(0);
  color: #000;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  .back-inner {
    width: 380px;
    margin: auto;
  }
  .backbtn {
    float: left;
    width: 34px;
    height: 34px;
    text-align: center;
    .arrow-btn {
      margin: 6px 6px 0 0;
    }
  }
  .backtitle {
    overflow: hidden;
    width: 340px;
    height: 34px;
    line-height: 34px;
    font-size: 18px;
    font-weight: 500;
  }
}
.start {
  width: 108px !important;
  height: 100px !important;
  border-radius: 8px;
  border: 3px solid transparent;
  box-sizing: border-box;
  letter-spacing: 0;
  text-align: center;
  line-height: 26px;
  box-sizing: border-box;
  overflow: hidden;
  display: table;
  > div {
    text-align: center;
    color: rgba(255, 255, 255, 0.5);
    display: table-cell;
    vertical-align: middle;
    width: 100%;
    padding-top: 5px;
    img {
      border-radius: 8px;
      display: block;
      width: 96%;
      margin: auto;
    }
    p {
      line-height: 14px;
      font-size: 14px;
      margin-top: 14px;
    }
  }
}
.luckmodal {
  display: none;
  position: fixed;
  left: 0;
  top: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  .close {
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    z-index: 50;
  }
  .lucktips {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 370px;
    height: 298px;
    background: #262729;
    margin-top: -149px;
    margin-left: -185px;
    border-radius: 6px;
    z-index: 100;
    .luckimg {
      height: 172px;
      background: #2f3133;
      .luckmess {
        position: absolute;
        top: 24px;
        left: 0;
        width: 100%;
        text-align: center;
        font-size: 20px;
        color: #ffda44;
        line-height: 24px;
      }
      img {
        width: 100%;
      }
    }
    .luckbtn {
      .luckmore {
        padding-top: 16px;
        font-size: 12px;
        color: rgba(255, 255, 255, 0.6);
        text-align: center;
        padding-bottom: 24px;
      }
      .luckdetails {
        width: 160px;
        height: 36px;
        background: #00c03c;
        border-radius: 18px;
        text-align: center;
        margin: 0 auto;
        color: #fff;
        font-size: 15px;
        display: block;
        line-height: 36px;
      }
    }
  }
}

.games-out {
  width: 380px;
  margin: 20px auto 0;
  .limitcount {
    text-align: center;
    margin: 10px 0 18px;
  }
  .games-box {
    padding: 20px 20px 5px;
    border-radius: 6px;
    .box-title {
      font-size: 18px;
      text-align: center;
      font-weight: 500;
      margin-bottom: 20px;
    }
    table {
      width: 100%;
      td {
        padding-bottom: 15px;
      }
    }
    .appicon {
      width: 62px;
      height: 62px;
      display: block;
    }
    .appname {
      display: block;
      font-size: 18px;
      line-height: 26px;
      padding: 0 10px;
    }
    /*198px*/
    .appcontent {
      display: block;
      padding: 0 10px;
      width: 160px;
      font-size: 12px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .game-install-btn {
      display: block;
      height: 34px;
      line-height: 34px;
      width: 80px;
      font-size: 16px;
      border-radius: 17px;
      text-align: center;
    }
  }
}

/* 竖屏 */
.main {
  margin: 50px auto 0;
  width: 100%;
  .main_kv {
    position: relative;
    img {
      width: 100%;
    }
    .install {
      color: #ffffff;
      border-color: #38383d;
      &:before,
      &:after {
        content: "";
        display: inline-block;
        height: 0px;
        width: 0px;
        border-top: 20px solid transparent;
        border-bottom: 20px solid transparent;
        position: absolute;
        top: 0;
      }
      &:before {
        border-right: 12px solid transparent;
        border-right-color: inherit;
        left: -12px;
      }
      &:after {
        border-left: 12px solid transparent;
        border-left-color: inherit;
        right: -12px;
      }
    }
    .transition-dom {
      width: 100%;
      height: 100px;
      position: absolute;
      bottom: 0;
      left: 0;
      z-index: 98;
    }
  }
  .main_luck {
    // padding:0 20/40rem 30/40rem;
    .luck-box {
      width: 380px;
      border-radius: 10px;
      margin: 0 auto;
      background: #1c1c1f;
    }
    .luck {
      width: 380px;
      height: 356px !important;
      border-radius: 6px;
      padding: 20px 0 0 18px;
      box-sizing: border-box;
      margin: 0 auto;
      li {
        width: 108px !important;
        height: 100px;
        // background: #2A2A2E;
        border-radius: 8px;
        border: 3px solid transparent;
        box-sizing: border-box;
        overflow: hidden;
        &:nth-child(3n + 3),
        &:nth-child(3n + 2) {
          margin-left: 9px;
        }
        &:nth-child(n + 4) {
          margin-top: 9px;
        }
        img {
          width: 100%;
        }
      }
    }
    .rules {
      margin-top: 20px;
    }
    .rule_box {
      margin-bottom: 80px;
      position: relative;
    }
  }
  .install {
    width: 120px;
    -webkit-transform: translateX(-50%);
    transform: translateX(-50%);
    left: 50%;
    height: 40px;
    line-height: 40px;
    text-align: center;
    background: #38383d;
    color: #fff;
    font-size: 14px;
    letter-spacing: 0.6px;
    margin: auto;
    position: absolute;
    bottom: 20px;
    z-index: 99;
  }
  .to-result {
    width: 380px;
    height: 40px;
    line-height: 40px;
    position: absolute;
    bottom: -40px;
    left: 0;
    text-align: center;
    font-size: 14px;
    color: #fff;
  }
}

#LoadingBar {
  left: 50%;
}
.main_kv {
  margin-bottom: 30/40rem;
  height: 410px;
  overflow: hidden;
  img {
    height: 100%;
    width: auto !important;
  }
}
</style>
