<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.developer.loading"
              clearable
              filterable
              remote
              :remote-method="handleNameSearch"
              placeholder="请输入游戏组"
            >
              <Option
                v-for="item in searchform.developer.data"
                :value="item.ID"
                :key="item.ID"
              >{{ item.Name }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
        </Row>
      </div>
      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      ></Table>
      <div style="margin: 10px;overflow: hidden">
        <div style="float: left">
          <Button type="info" shape="circle" icon="plus-round" @click="openAdd">新增</Button>
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>
  </div>
</template>

<script>
import Tables from "_c/tables";
import DeveloperAPI from "@/api/gamespace/developer";
export default {
  name: "developer",
  data() {
    return {
      searchform: {
        params: { id: undefined },
        page: {
          total: 100,
          current: 1,
          size: 10
        },
        developer: {
          loading: false,
          data: []
        }
      },
      table: {
        loading: false,
        data: [],
        columns: [
          { title: "开发者信息", key: "Name" },
           { title: "开发者简称", key: "Provider" },
          { title: "是否启用", key: "Enable", enable: true },
          {
            title: "创建时间",
            key: "CreatedAt",
            timeformat: true
            // render: Tables.Renders.formatTime
          },
          {
            title: "操作",
            key: "handle",
            options: ["edit", "enable"]
            // render:Tables.Renders.handleBtn
          }
        ]
      }
    };
  },
  methods: {
    handleNameSearch(value) {
      DeveloperAPI.Like({ value }).then(res => {
        this.searchform.developer.data = res.Data;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    edit(params) {
      this.$router.push({
        name: "gamespace_developer_edit",
        params: { id: params.row.ID }
      });
    },
    enable(param) {
      DeveloperAPI.Enable(param.row.ID, !param.row.Enable).then(res => {
        this.init();
      });
    },
    delete(param) {
      console.log(param);
    },
    init() {
      DeveloperAPI.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then(res => {
       if (res.Data.Data){
          this.table.data = res.Data.Data;
        }
        this.searchform.page.total = res.Data.Count;
      });
    },
    openAdd() {
      this.$router.push({
        name: "gamespace_developer_add"
      });
    },
    closeAdd() {
      this.init();
    }
  },
  mounted() {
    this.table.columns = Tables.RenderColumns(this.table.columns, this);
    this.$on("on-enable", this.enable);
    this.$on("on-delete", this.delete);
    this.$on("on-edit", this.edit);
    this.init();
    //注册监听事件
  },activated() {
     this.init();
  }
};
</script>