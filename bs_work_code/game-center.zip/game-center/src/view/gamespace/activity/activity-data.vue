<template>
  <div>
    <Card>
      <Form
        ref="formValidate"
        :model="formData"
        :rules="ruleValidate"
        :inline="true"
        style="position: relative"
      >
        <FormItem prop="AppName">
          <Select
            v-model="formData.AppId"
            clearable
            filterable
            remote
            :remote-method="handleGameSearch"
            placeholder="请输入游戏名称"
            ref="AppName"
            @on-change="changeAppName"
          >
            <Option v-for="item in gameList" :value="item.ID" :key="item.ID">{{
              item.AppName
            }}</Option>
          </Select>
        </FormItem>
        <FormItem prop="packageName">
          <Select
            v-model="formData.AppId"
            clearable
            filterable
            remote
            :remote-method="handleGamePkgNameSearch"
            placeholder="请输入游戏包名"
            ref="packageName"
            @on-change="changeValue"
          >
            <Option v-for="item in gameList" :value="item.ID" :key="item.ID">{{
              item.PkgName
            }}</Option>
          </Select>
        </FormItem>
        <FormItem label="活动标题" :label-width="65">
          <Select
            v-model="formData.Id"
            clearable
            filterable
            remote
            :remote-method="handleSearch"
            placeholder="请输入活动标题"
          >
            <Option
              v-for="item in activityData"
              :value="item.ID"
              :key="item.ID"
              >{{ item.Title }}</Option
            >
          </Select>
        </FormItem>
        <FormItem label="活动类型" prop="FeedType" :label-width="65">
          <Selection
            v-model="formData.FeedType"
            :dataList="feedTypeList"
            style="width: 120px"
          />
        </FormItem>
        <Button
          type="success"
          shape="circle"
          icon="ios-search"
          @click="toSearch"
          style="margin-right: 15px"
          >搜索</Button
        >
      </Form>

      <Table border :loading="loading" :columns="columns" :data="tableList">
        <template slot-scope="{ row }" slot="FeedType">
          {{ feedTypeList.filter((v) => v.Id == row.FeedType)[0].Name }}
        </template>
        <template slot-scope="{ row }" slot="ExpiredEnd">
          {{ timeFormat(row.ExpiredEnd) }}
        </template>
        <template slot-scope="{ row }" slot="BigBg">
          <img :src="row.BigBg" alt="" style="height: 40px; display: block" />
        </template>
      </Table>
      <Page
        show-sizer
        :total="total"
        sta
        show-total
        :page-size="pageSize"
        :current="pageIndex"
        @on-change="changePage"
        @on-page-size-change="changePageSize"
      />
    </Card>
  </div>
</template>

<script>
import ActivityApi from "@/api/gamespace/activitylist";
import GameAPI from "@/api/gamespace/game";
import { formatTime } from "@/libs/tools";
import Selection from "_c/Selection.vue";

export default {
  name: "gamespace_activity_data",
  components: { Selection },
  data() {
    return {
      formData: {
        AppId: undefined,
        FeedType: undefined,
        Id: undefined,
      },
      ruleValidate: {},
      feedTypeList: [
        // 活动类型
        { Id: 1, Name: "图文活动" },
        { Id: 2, Name: "抽奖活动" },
        { Id: 3, Name: "论坛帖活动" },
        { Id: 5, Name: "重点游戏活动" },
      ],
      columns: [
        { title: "信息流ID", key: "ID", width: 85 },
        { title: "活动标题", key: "Title" },
        { title: "活动类型", slot: "FeedType" },
        { title: "活动截止时间", slot: "ExpiredEnd" },
        { title: "活动大图", slot: "BigBg" },
      ],
      tableList: [],
      activityData: [],
      loading: false,
      gameList: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
    };
  },
  methods: {
    timeFormat(date) {
      return formatTime(date);
    },
    //游戏名
    changeAppName(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["packageName"].setQuery(item[0].PkgName);
        this.$refs["packageName"].toggleMenu(null, false);
      }
    },
    //包名
    changeValue(val) {
      if (val) {
        let item = this.gameList.filter((v) => v.ID == val);
        this.$refs["AppName"].setQuery(item[0].AppName);
        this.$refs["AppName"].toggleMenu(null, false);
      }
    },
    //查询游戏名称
    handleGameSearch(value) {
      GameAPI.LikeAppByParams({ params: { AppName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    //查询游戏包名
    handleGamePkgNameSearch(value) {
      GameAPI.LikeAppByParams({ params: { PkgName: value } }).then((res) => {
        this.gameList = res.Data;
      });
    },
    //活动标题
    handleSearch(val) {
      ActivityApi.QueryByFeedType(val).then((res) => {
        if (res.Code === 0) {
          this.activityData = res.Data;
        }
      });
    },
    //搜索
    toSearch() {
      this.getActivityList();
    },
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.getActivityList();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.getActivityList();
    },
    getActivityList() {
      this.loading = true;
      let data = {
        Page: this.pageIndex,
        Limit: this.pageSize,
        Params: { ...this.formData },
      };
      ActivityApi.GetDataList(data)
        .then((res) => {
          if (res.Code === 0) {
            this.tableList = res.Data.Data;
            this.total = res.Data.Count;
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>
