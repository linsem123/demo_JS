<template>
  <div>
    <Card>
      <Row :gutter="10" style="margin-bottom: 15px">
        <Col :span="12">
          榜单类型：
          <RadioGroup
            v-model="category"
            type="button"
            @on-change="getActivityList"
          >
            <Radio v-for="c in categoryList" :label="c.id" :key="c.id">
              {{ c.name }}
            </Radio>
          </RadioGroup>
        </Col>
      </Row>

      <Table border :columns="columns" :data="tableList">
        <template slot-scope="{ row }" slot="FeedType">
          {{ feedTypeList.filter((v) => v.id == row.FeedType)[0].name }}
        </template>
        <template slot-scope="{ row }" slot="Category">
          <span v-show="row.Category === 1">
            <Icon type="md-images" size="14" />
            {{ categoryList[0].name }}</span
          >
          <span v-show="row.Category === 2">
            <Icon type="ios-list-box-outline" size="14" />
            {{ categoryList[1].name }}</span
          >
        </template>
        <template slot-scope="{ row }" slot="Expired">
          <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">
            {{ row.StartTime }}~{{ row.EndTime }}
          </span>
        </template>
        <template slot-scope="{ row }" slot="ExpiredEnd">
          {{ timeFormat(row.ExpiredEnd) }}
        </template>
        <template slot-scope="{ row }" slot="BigBg">
          <img :src="row.BigBg" alt="" style="height: 40px; display: block" />
        </template>
        <template slot-scope="{ row }" slot="opt">
          <Button
            size="small"
            @click="modifyBind(row)"
            type="primary"
            style="margin-right: 5px"
            >编辑</Button
          >
          <Button
            size="small"
            @click="setTop(row)"
            type="primary"
            style="margin-right: 5px"
            >置顶</Button
          >
          <Button size="small" @click="unBind(row)" type="error">解绑</Button>
        </template>
      </Table>

      <div style="margin: 10px; overflow: hidden">
        <div style="float: left">
          <Button type="info" shape="circle" icon="plus-round" @click="bindList"
            >绑定榜单</Button
          >
        </div>
      </div>
    </Card>

    <!--绑定榜单的弹窗-->
    <Modal v-model="bindVisible" title="绑定榜单" :width="600">
      <Form :model="bindForm" :label-width="120" :rules="rules" ref="bindform">
        <FormItem label="榜单类型：">
          <RadioGroup v-model="bindForm.Category">
            <Radio v-for="c in categoryList" :label="c.id" :key="c.id">
              {{ c.name }}
            </Radio>
          </RadioGroup>
        </FormItem>
        <FormItem label="活动：">
          <i-col :span="21">
            <Select
              v-model="bindForm.id"
              clearable
              filterable
              remote
              :remote-method="handleSearch"
              @on-clear="bindActivities.data = []"
              :loading="bindActivities.loading"
              placeholder="请输入活动标题"
            >
              <Option
                v-for="item in bindActivities.data"
                :value="item.ID"
                :key="item.ID"
                >{{ item.Title }}</Option
              >
            </Select>
          </i-col>
        </FormItem>
        <FormItem label="生效周期：" prop="Expired">
          <DateRange
            v-model="bindForm.Expired"
            @on-change="
              (value) => {
                bindForm.StartTime = value.start;
                bindForm.EndTime = value.end;
              }
            "
          />
        </FormItem>
        <FormItem label="是否过滤机型：">
          <Checkbox v-model="bindForm.NeedModelFiltration"></Checkbox>
        </FormItem>
        <FormItem label="选择机型：" v-if="bindForm.NeedModelFiltration">
          <SurpotModel v-model="bindForm.SupportModel" />
        </FormItem>
      </Form>
      <template slot="footer">
        <Button size="large" type="text" @click="bindVisible = false"
          >取消</Button
        >
        <Button size="large" type="primary" @click="submitBind">确定</Button>
      </template>
    </Modal>
    <!--编辑榜单的弹窗 4.7迭代新增-->
    <Modal v-model="showEdit" title="编辑榜单" :width="600">
      <Form :model="editForm" :label-width="120" :rules="rules" ref="editform">
        <FormItem label="活动标题："> {{ editForm.Title }}</FormItem>
        <FormItem label="生效周期：" prop="Expired">
          <DateRange
            v-model="editForm.Expired"
            @on-change="
              (value) => {
                editForm.StartTime = value.start;
                editForm.EndTime = value.end;
              }
            "
          />
        </FormItem>
      </Form>
      <template slot="footer">
        <Button size="large" type="text" @click="showEdit = false">取消</Button>
        <Button size="large" type="primary" @click="submitModufy">确定</Button>
      </template>
    </Modal>
  </div>
</template>

<script>
import ActivityApi from "@/api/gamespace/activitylist";
import SurpotModel from "_c/SurpotModel";
import { formatTime } from "@/libs/tools";
import DateRange from "_c/DateRange.vue";
import { checkDateRange } from "@/libs/checkForm.js";
import { formatTimes } from "@/libs/tools";

export default {
  name: "gamespace_activity_list",
  components: { SurpotModel, DateRange },
  data() {
    return {
      category: 2, // 1：轮播图，2：列表
      categoryList: [
        // 榜单类型
        { id: 1, name: "轮播图" },
        { id: 2, name: "列表" },
      ],
      feedTypeList: [
        // 活动类型
        { id: 1, name: "图文活动" },
        { id: 2, name: "抽奖活动" },
        { id: 3, name: "论坛帖活动" },
        { id: 5, name: "重点游戏活动" },
      ],
      columns: [
        { title: "信息流ID", key: "ID", width: 85 },
        { title: "活动标题", key: "Title", width: 150 },
        { title: "活动类型", slot: "FeedType", minWidth: 100 },
        { title: "榜单类型", slot: "Category", minWidth: 100 },
        { title: "生效周期", slot: "Expired", width: 270 },
        { title: "活动截止日期", slot: "ExpiredEnd", width: 150 },
        { title: "活动大图", slot: "BigBg", minWidth: 100 },
        {
          title: "操作",
          slot: "opt",
          fixed: "right",
          align: "center",
          width: 180,
        },
      ],
      tableList: [],

      bindVisible: false,
      bindActivities: { loading: false, data: [] },
      bindForm: {
        Category: 2,
        id: null,
        NeedModelFiltration: false,
        SupportModel: [],
        Expired: [], //4.7迭代新增
        StartTime: "",
        EndTime: "",
      },
      rules: {
        Expired: [
          {
            validator: checkDateRange,
            trigger: "change",
            type: "array",
          },
        ],
      },
      showEdit: false, //4.7迭代新增
      editForm: { Expired: [] }, //4.7迭代新增
    };
  },
  mounted() {
    this.getActivityList();
  },
  computed: {
    nowTime() {
      return formatTimes(new Date());
    },
  },
  methods: {
    timeFormat(date) {
      return formatTime(date);
    },
    getActivityList(category) {
      let this_ = this;
      ActivityApi.GetList(category || this.category).then((res) => {
        if (res.Code === 0) {
          this_.tableList = res.Data;
        }
      });
    },

    handleSearch(val) {
      let this_ = this;
      this_.bindActivities.loading = true;
      ActivityApi.QueryByFeedType(val).then((res) => {
        if (res.Code === 0) {
          this_.bindActivities.data = res.Data;
          this_.bindActivities.loading = false;
        }
      });
    },
    bindList() {
      this.bindVisible = true;
    },
    submitBind() {
      if (!this.bindForm.id) {
        this.$Message.warning("请设置要绑定的活动");
        return false;
      }
      this.$refs.bindform.validate((valid) => {
        if (valid) {
          if (!this.bindForm.StartTime || !this.bindForm.EndTime) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitAdd();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitAdd();
          }
        }
      });
    },
    submitAdd() {
      ActivityApi.SaveBind(this.bindForm.Category, this.bindForm.id, {
        NeedModelFiltration: this.bindForm.NeedModelFiltration,
        SupportModel: this.bindForm.SupportModel.join(","),
        StartTime: this.bindForm.StartTime || this.nowTime,
        EndTime: this.bindForm.EndTime || "2099-01-01 00:00:00",
      }).then((res) => {
        if (res.Code === 0) {
          this.bindVisible = false;
          this.getActivityList();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    unBind(item) {
      let this_ = this;
      this.$Modal.confirm({
        title: "提示",
        content: "确定将 <b>" + item.Title + "</b> 解绑吗？",
        onOk: () => {
          ActivityApi.UnBind(item.ID, item.Category).then((res) => {
            if (res.Code === 0) {
              this_.$Message.success("解绑成功");
              this_.getActivityList();
            }
          });
        },
      });
    },

    setTop(item) {
      let this_ = this;
      this.$Modal.confirm({
        title: "提示",
        content: "确定将 <b>" + item.Title + "</b> 置顶吗？",
        onOk: () => {
          ActivityApi.SetTop(item.ID, item.Category).then((res) => {
            if (res.Code === 0) {
              this_.$Message.success("置顶成功！");
              this.getActivityList();
            }
          });
        },
      });
    },
    getStatus(row) {
      const now = new Date().getTime();
      const start = new Date(row.StartTime).getTime();
      const end = new Date(row.EndTime).getTime();
      const actEnd = new Date(row.ExpiredEnd).getTime();
      return now > start && now < end && now < actEnd;
    },
    modifyBind(row) {
      this.showEdit = true;
      this.editForm = row;
      this.editForm.Expired = [row.StartTime, row.EndTime];
    },
    submitModufy() {
      this.$refs.editform.validate((valid) => {
        if (valid) {
          if (!this.editForm.StartTime || !this.editForm.EndTime) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.doModify();
                this.$Modal.remove();
              },
            });
          } else {
            this.doModify();
          }
        }
      });
    },
    doModify() {
      ActivityApi.editRank({
        ...this.editForm,
        StartTime: this.editForm.StartTime || this.nowTime,
        EndTime: this.editForm.EndTime || "2099-01-01 00:00:00",
      }).then((res) => {
        if (res.Code === 0) {
          this.showEdit = false;
          this.getActivityList();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
  },
};
</script>

<style scoped>
.ivu-radio-group-button .ivu-radio-wrapper-checked {
  background: #2d8cf0;
  border-color: #2d8cf0;
  color: #fff;
  -webkit-box-shadow: -1px 0 0 0 #2d8cf0;
  box-shadow: -1px 0 0 0 #2d8cf0;
  z-index: 1;
}
</style>
