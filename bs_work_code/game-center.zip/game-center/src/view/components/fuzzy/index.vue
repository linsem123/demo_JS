<template>
  <div>
    <Row>
      <Col :span="data.span||24">
        <Select
          v-model="value"
          filterable
          remote
          clearable
          :remote-method="remoteMethod"
          :loading="loading"
          :disabled="Boolean(istrue)"
          @on-change="selectFunc"
          :placeholder="data.placeholder||'please enter ...'"
        >
          <Option
            v-for="(option, index) in options"
            :value="option.value"
            :key="index"
          >{{option.label}}</Option>
        </Select>
      </Col>
    </Row>
  </div>
</template>

<script>
import "./index.less";
import api from "@/api/fuzzy";

export default {
  name: "Fuzzy",
  data() {
    return {
      value: "",
      loading: false,
      list: [],
      istrue: false,
      options: [],
      isremote: true,
    };
  },
  model: {
    prop: "modelValue",
    event: "valueChange",
  },
  props: ["data", "isClear", "getone"],
  watch: {
    data: {
      handler(v, o) {
        this.options = [];
        this.value = null;
        if (v.value) {
          this.getOne(v.value);
        }
      },
      immediate: true,
    },
    getone(v, o) {
      if (v) {
        this.getOne(v);
      }
    },
    modelValue(v, o) {
      console.log("fuzzy", v);
      if (!v) {
        this.value = null;
      }
    },
    isClear(val, old) {
      if (val) {
        this.value = "";
      }
    },
  },
  methods: {
    selectFunc(q) {
      console.log(q)
      this.$emit("valueChange", q);
      this.options.forEach((item) => {
        if (q == item.value) {
          console.log(item)
          this.$emit("on-change", item);
          //  this.$emit(, item);
        }
      });
    },
    remoteMethod(query) {
      if (!this.isremote) {
        query = this.options[0]["label"];
      }
      this.options = [];
      if (query !== "") {
        this.loading = true;
        setTimeout(() => {
          this.loading = false;
          let params={text:query}
          api[`${this.data.searchurl}`](params).then((res) => {
            console.log(res);
            if (res.data.Code === 0) {
              this.list = res.data.Data.list || [];
              const list = this.list.map((item) => {
                let obj = {
                  value: item[`${this.data.valueField}` || "Id"],
                  label: item[`${this.data.labelField}` || "Name"],
                };
                if (this.data.bompn) obj.ProjectId = item.ProjectId;
                obj.ProjectName = item.ProjectName;
                obj.InnerProjectId = item.InnerProjectId;
                obj.InnerProjectName = item.InnerProjectName;
                obj.Conf = item.Conf;
                obj.SaleArea = item.SaleArea;
                obj.bompn = true;
                obj.pn = item.PN;
                obj.MarketingName = item.MarketingName;
                return obj;
              });
              // console.log(list);
              this.options = list.filter(
                (item) =>
                  item.label.toLowerCase().indexOf(query.toLowerCase()) > -1
              );
              console.log(this.options)
              if (!this.isremote) {
                this.value = Number(this.options[0]["value"]);
                this.isremote = true;
              }
            } else {
              this.$Message.error("数据查询失败，请重试！");
            }
          });
        }, 20);
      } else {
        this.options = [];
      }
    },
    getOne(id) {
      this.isremote = false;
      if (!this.data.showUrl) return;
      api[`${this.data.showUrl}`](Number(id)).then((res) => {
        console.log(res);
        if (res.Code === 0) {
          this.list = res.Data || [];
          this.options = [
            {
              value: this.list[
                `${this.data.valueField}` || `${this.data.valueField}` || "Id"
              ],
              label: this.list[
                `${this.data.labelField}` || `${this.data.labelField}` || "Name"
              ],
            },
          ];
          if (this.data.bompn) this.options[0].ProjectId = this.list.ProjectId;
          this.options[0].ProjectName = this.list.ProjectName;
          this.options[0].InnerProjectId = this.list.InnerProjectId;
          this.options[0].InnerProjectName = this.list.InnerProjectName;
          this.options[0].bompn = true;
          if (this.options.length > 0)
            this.value = Number(this.options[0]["value"]);
        } else {
          this.$Message.error("数据查询失败，请重试！");
        }
      });
    },
  },
};
</script>

<style>
</style>
