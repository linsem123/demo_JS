import Fuzzy from './index.vue'
export default Fuzzy