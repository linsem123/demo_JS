<template>
  <Card>
    <div style="margin-bottom: 10px">
      <LikeSearch
        v-model="searchForm.Params.AppId"
        placeholder="请输入游戏名称"
        :serverData="gameServerData"
        style="width: 200px; margin-right: 10px"
        clearable
      />
      <Button type="primary" @click="handleSearch">查询</Button>
    </div>
    <Table border :data="tableData" :columns="columns" :loading="loading">
      <template slot="BackgroundImage" slot-scope="{ row }">
        <img
          :src="row.BackgroundImage"
          v-if="row.BackgroundImage"
          style="width: 40px; height: 40px"
        />
      </template>
      <template slot="Expired" slot-scope="{ row }">
        <span :style="'color:' + (getStatus(row) ? 'green' : 'red')">
          {{ row.StartTime }}~{{ row.EndTime }}</span
        >
      </template>
      <template slot="action" slot-scope="{ row }">
        <Button
          type="primary"
          size="small"
          @click="handleEdit(row)"
          style="margin-right: 5px"
          >编辑</Button
        >
        <Button
          type="error"
          size="small"
          @click="handleChangeBind(row, 2)"
          style="margin-right: 5px"
          v-show="row.State == 1"
          >解绑</Button
        >
        <Button
          type="primary"
          size="small"
          @click="handleChangeBind(row, 1)"
          style="margin-right: 5px"
          v-show="row.State != 1"
          >绑定</Button
        >
      </template>
    </Table>
    <div style="margin: 10px; overflow: hidden">
      <div style="float: left">
        <Button type="info" shape="circle" icon="plus-round" @click="handleAdd"
          >绑定攻略站</Button
        >
      </div>
      <div style="float: right">
        <Page
          :total="searchForm.total"
          :current="searchForm.Page"
          :page-size="searchForm.Limit"
          :page-size-opts="[10, 20, 40, 80, 100]"
          @on-change="onPageChange"
          @on-page-size-change="onPageSizechange"
          show-sizer
          show-total
        ></Page>
      </div>
    </div>
    <Modal v-model="showModal" :title="formData.ID ? '编辑' : '新增'">
      <Form :model="formData" :rules="rules" :label-width="110" ref="formData">
        <FormItem label="关联游戏：" prop="AppId">
          <span v-if="formData.ID">{{ formData.AppName }}</span>
          <CommonSelect
            v-model="formData.AppId"
            placeholder="请输入游戏名称"
            :serverData="gameServerData"
            clearable
            v-else
          />
        </FormItem>
        <FormItem label="攻略站名称：" prop="Name">
          <Input placeholder="请填写名称" v-model="formData.Name" clearable />
        </FormItem>
        <FormItem label="描述信息：" prop="Description">
          <Input
            placeholder="请填写描述信息"
            v-model="formData.Description"
            clearable
          />
        </FormItem>
        <FormItem label="绑定合辑名称：" prop="CollectionId">
          <LikeSearch
            v-model="formData.CollectionId"
            placeholder="请输入合辑名称"
            :serverData="postServerData"
            ref="LikeSearch"
            clearable
          />
        </FormItem>
        <FormItem label="绑定合辑页ID：">
          <Input
            v-model="formData.CollectionId"
            style="width: 300px"
            clearable
            type="number"
            @input="
              formData.CollectionId = formData.CollectionId.replace(
                /[^\d]/g,
                ''
              )
            "
            @on-blur="getModelById"
            @on-change="changeCollection"
          />
        </FormItem>
        <FormItem label="入口底图：" prop="BackgroundImage">
          <UploadImg v-model="formData.BackgroundImage"></UploadImg>
        </FormItem>
        <FormItem label="投放位置：" prop="Place">
          <Select v-model="formData.Place" :disabled="true" multiple>
            <Option :value="1">圈子主页</Option>
            <Option :value="2">游戏详情页社区tab</Option>
          </Select>
        </FormItem>
        <FormItem label="生效周期：" prop="Expired">
          <DateRange
            v-model="formData.Expired"
            @on-change="
              (value) => {
                formData.StartTime = value.start;
                formData.EndTime = value.end;
              }
            "
          />
        </FormItem>
      </Form>
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button @click="handleCommit" type="primary">确认</Button>
      </template>
    </Modal>
  </Card>
</template>
<script>
import LikeSearch from "_c/like-search";
import CommonSelect from "_c/common-select";
import API from "@/api/gameCircle/strategyStation.js";
import gameApi from "@/api/fuzzy.js";
import UploadImg from "_c/shark-upload/index.vue";
import DateRange from "_c/DateRange.vue";
import { formatTimes } from "@/libs/tools";
export default {
  name: "strategyStation",
  components: { LikeSearch, CommonSelect, UploadImg, DateRange },
  data() {
    const checkNum = (rule, value, callback) => {
      console.log(Number(value));
      if (!Number(value)) {
        callback("请输入合辑名称");
      }
      callback();
    };
    return {
      searchForm: {
        Params: { AppId: undefined },
        Limit: 10,
        total: 0,
        Page: 1,
      },
      gameServerData: {
        likeUrl: "gameLike",
        likeData: {},
        IdKey: "ID",
        NameKey: "AppName",
      },
      postServerData: {
        likeUrl: "ModelLike",
        likeData: {
          type: 1,
        },
        IdKey: "ID",
        NameKey: "Name",
      },
      gameServerData: {
        likeUrl: "gameLike",
        likeData: {},
        setUrl: "getGameList",
        setData: {},
        IdKey: "ID",
        NameKey: "AppName",
      },
      loading: false,
      tableData: [],
      columns: [
        { title: "攻略站ID", key: "ID", width: 80, align: "center" },
        { title: "攻略站名称", key: "Name", minWidth: 150 },
        { title: "描述信息", key: "Description", minWidth: 150 },
        { title: "关联游戏", key: "AppName", minWidth: 150 },
        { title: "绑定合辑名称", key: "CollectionName", minWidth: 150 },
        { title: "入口底图", slot: "BackgroundImage", width: 70 },
        { title: "生效周期", slot: "Expired", minWidth: 150 },
        {
          title: "操作",
          slot: "action",
          width: 150,
          align: "center",
          fixed: "right",
        },
      ],
      showModal: false,
      formData: {
        AppId: undefined,
        Name: "",
        Description: "",
        CollectionId: undefined,
        BackgroundImage: "",
        Place: [1, 2],
        Expired: [],
        StartTime: "",
        EndTime: "",
      },
      rules: {
        AppId: [
          {
            required: true,
            message: "请输入游戏名称",
            trigger: "change",
            type: "number",
          },
        ],
        Name: [
          {
            required: true,
            message: "请输入攻略站名称",
            trigger: "blur",
          },
        ],
        Description: [
          {
            required: true,
            message: "请输入描述信息",
            trigger: "blur",
          },
        ],
        CollectionId: [
          {
            required: true,
            message: "请输入合辑名称",
          },
          {
            validator: checkNum,
            trigger: "change",
          },
        ],
        Place: [
          {
            required: true,
            message: "请选择投放位置",
            trigger: "change",
            type: "array",
          },
        ],
        BackgroundImage: [
          {
            required: true,
            message: "请上传图片",
            trigger: "change",
          },
        ],
      },
    };
  },
  mounted() {
    this.searchServer();
  },
  computed: {
    nowTime() {
      return formatTimes(new Date());
    },
  },
  methods: {
    timeFormat(date) {
      return formatTimes(date);
    },
    handleSearch() {
      this.searchForm.Page = 1;
      this.searchServer();
    },
    onPageChange(value) {
      this.searchForm.Page = value;
      this.searchServer();
    },
    onPageSizechange(value) {
      this.searchForm.Limit = value;
      this.searchForm.Page = 1;
      this.searchServer();
    },
    searchServer() {
      this.loading = true;
      API.getList(this.searchForm)
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.Data || [];
            this.searchForm.total = res.Data.Count;
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    handleAdd() {
      this.showModal = true;
      this.formData = {
        AppId: undefined,
        Name: "",
        Description: "",
        CollectionId: undefined,
        BackgroundImage: "",
        Place: [1, 2],
        Expired: [],
        StartTime: "",
        EndTime: "",
        State: 1,
      };
      this.$refs.LikeSearch.clearText();
    },
    handleEdit(row) {
      this.showModal = true;
      this.formData = JSON.parse(JSON.stringify(row));
      this.formData.Place = this.formData.Place.split(",").map(Number);
      this.formData.Expired = [this.formData.StartTime, this.formData.EndTime];
      this.getModelById();
    },
    handleChangeBind(row, state) {
      if (state == 1) {
        this.changeStateServer(row, state);
      } else {
        this.$Modal.confirm({
          title: "提示",
          okText: "确认",
          cancelText: "取消",
          loading: true,
          content: "<p>确定将“" + row.Name + "”解绑吗？</p>",
          onOk: () => {
            this.changeStateServer(row, state);
            this.$Modal.remove();
          },
        });
      }
    },
    changeStateServer(row, state) {
      API.changeState(row.ID, state).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("操作成功");
          this.searchServer();
        } else {
          this.$Message.error(res.Message || "操作失败");
        }
      });
    },
    handleCommit() {
      this.$refs.formData.validate((valid) => {
        if (valid) {
          if (!this.formData.StartTime || !this.formData.EndTime) {
            this.$Modal.confirm({
              title: "提示",
              okText: "确认",
              cancelText: "取消",
              loading: true,
              content: "<p>还未设置生效期，是否继续发布？</p>",
              onOk: () => {
                this.submitForm();
                this.$Modal.remove();
              },
            });
          } else {
            this.submitForm();
          }
        } else {
          this.$Message.error("有未填写内容");
        }
      });
    },
    submitForm() {
      let params = JSON.parse(JSON.stringify(this.formData));
      params.Place = params.Place.join(",");
      params.StartTime = params.StartTime || this.nowTime;
      params.EndTime = params.EndTime || "2099-01-01 00:00:00";
      if (params.ID) {
        API.Edit(params).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("编辑成功");
            this.searchServer();
            this.showModal = false;
          } else {
            this.$Message.error(res.Message || "编辑失败");
          }
        });
      } else {
        API.Add(params).then((res) => {
          if (res.Code == 0) {
            this.$Message.success("新增成功");
            this.searchServer();
            this.showModal = false;
          } else {
            this.$Message.error(res.Message || "新增失败");
          }
        });
      }
    },
    getModelById() {
      this.formData.CollectionId = Number(this.formData.CollectionId);
      if (this.formData.CollectionId) {
        gameApi.ModelById({ id: this.formData.CollectionId }).then((res) => {
          if (res.Code == 0) {
            let data = res.Data || {};
            if (!data.ID) {
              this.$Message.error("该合辑页ID无效");
            }
            this.$refs.LikeSearch.setQuery({
              id: this.formData.CollectionId,
              title: data.Name,
            });
          } else {
            this.$Message.error(res.Message || "编辑失败");
          }
        });
      }
    },
    changeCollection() {
      if (!this.formData.CollectionId) {
        this.$refs.LikeSearch.clearText();
      }
    },
    //校验生效周期状态
    getStatus(row) {
      const now = new Date().getTime();
      const start = new Date(row.StartTime).getTime();
      const end = new Date(row.EndTime).getTime();
      return row.State == 1 && now > start && now < end;
    },
    // getStatus(row) {
    //   const now = new Date().getTime();
    //   const start = new Date(row.StartTime).getTime();
    //   const end = new Date(row.EndTime).getTime();
    //   const actEnd = new Date(row.ExpiredEnd).getTime();
    //   return now > start && now < end && now < actEnd;
    // },
  },
};
</script>