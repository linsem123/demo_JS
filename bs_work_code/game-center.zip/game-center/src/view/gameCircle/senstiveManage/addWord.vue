<template>
    <div class="set_forbiddon_box">
        <Form :model="formData"
              :rules="ruleValidate"
              ref="formValidate"
              :label-width="70">
            <FormItem label="屏蔽词" prop="Word">
                <Input v-model="formData.Word" placeholder="请输入屏蔽词" style="width:200px"/>
            </FormItem>
            <FormItem label="类型" prop="Type">
               <RadioGroup v-model="formData.Type">
                    <Radio :label="1" style="margin-right:15px">通用</Radio>
                    <Radio :label="2" style="margin-right:15px">昵称保护</Radio>
                </RadioGroup>
            </FormItem>
             
        </Form>
        <div style="margin:30px 0;display:flex;justify-content:center">
            <Button  style="margin-right:40px" @click="handelClickCancel">取消</Button>
            <Button type="primary" @click="commit">确定</Button>
        </div>
    </div>
</template>
<script>
import Senstive from "@/api/gameCircle/senstiveManage";                                                      
export default {
    data(){
        return {
            formData:{
                Type:undefined,
                Word:""
            },
            ruleValidate:{
                Word:[{ required: true, message: '请输入屏蔽词', trigger: 'change'}],
                Type:[{ required: true, message: '请选择类型', trigger: 'change',type:'number'}]
            },
        }
    },
    methods:{
        handelClickCancel(){
            this.clear()
            this.$emit('closeAddModal')
        },
        commit(){
            this.$refs['formValidate'].validate((valid) => {
                if (valid) {
                    Senstive.addWord({
                        ...this.formData
                    }).then(res=>{
                        if(res.Code == 0){
                            this.$Message.success('新增成功')
                            this.$emit('closeAddModal',true)
                            this.clear()
                        }else{
                            this.$Message.error(res.Message)
                        }
                    })
                }
            })
        },
        clear(){
            for(let key in this.formData){
                this.formData[key]=""
            }
        },

    }
    
}
</script>
<style lang="less" scoped>
.set_forbiddon_box{
    margin: 0 30px;
}
</style>