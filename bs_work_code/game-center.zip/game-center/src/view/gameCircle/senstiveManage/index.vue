<template>
  <div>
    <Card>
      <Form
        ref="formValidate"
        :model="formData"
        :rules="ruleValidate"
        :inline="true"
        style="position: relative"
      >
        <FormItem prop="Word">
          <dirtySelect v-model="formData.Id" :width="200" />
        </FormItem>
        <FormItem label="类型" prop="Type" :label-width="65">
          <Selection v-model="formData.Type" :dataList="TypeList" />
        </FormItem>
        <Button type="primary" @click="toSearch" style="margin: 0 50px 0 20px"
          >查询</Button
        >
        <Button
          type="primary"
          @click="toCreate"
          style="position: absolute; right: 0"
          >新增</Button
        >
      </Form>
      <Table
        border
        highlight-row
        ref="currentRowTable"
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :max-height="600"
      >
        <template slot-scope="{ row }" slot="action">
          <Button
            type="error"
            size="small"
            style="margin-right: 5px"
            @click="delWord(row)"
            >删除</Button
          >
        </template>
      </Table>
      <Page
        show-sizer
        :total="total"
        sta
        show-total
        :page-size="pageSize"
        :current="pageIndex"
        @on-change="changePage"
        @on-page-size-change="changePageSize"
      />
    </Card>
    <Modal v-model="showAdd" title="新增" :width="400" footer-hide>
      <addWord @closeAddModal="closeAddModal" v-if="showAdd" />
    </Modal>
  </div>
</template>
<script>
import Senstive from "@/api/gameCircle/senstiveManage";
import Selection from "_c/Selection.vue";
import dirtySelect from "@/view/gameCircle/components/dirtySelect";
import addWord from "./addWord";
import common from "@/view/gameCircle/pubFunc/common";
export default {
  name: "senstiveManage",
  data() {
    return {
      loading: false,
      showAdd: false,
      formData: {
        Id: undefined,
        Type: undefined,
      },
      ruleValidate: {},
      columns: [
        {
          title: "屏蔽词",
          key: "Word",
          align: "center",
          minWidth: 200,
        },
        {
          title: "类型",
          key: "TypeText",
          minWidth: 100,
          align: "center",
        },
        {
          title: "操作",
          slot: "action",
          align: "center",
          minWidth: 150,
        },
      ],
      tableData: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      TypeList: [
        {
          Id: 1,
          Name: "通用",
        },
        {
          Id: 2,
          Name: "昵称保护",
        },
      ],
      checkedTable: {},
    };
  },
  components: {
    dirtySelect,
    Selection,
    addWord,
  },
  mounted() {
    this.searchServer();
  },
  methods: {
    //删除屏蔽词
    delWord(row) {
      Senstive.deleteWord(row.Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("删除成功");
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
      //  this.checkedTable = row
    },
    closeAddModal(isUpdate) {
      if (isUpdate) this.searchServer();
      else this.showAdd = false;
    },
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.searchServer();
    },
    //新增
    toCreate() {
      this.showAdd = true;
    },
    //查询
    toSearch() {
      this.pageIndex = 1;
      this.searchServer();
    },
    searchServer() {
      let { Id, Type, Page, Limit } = {
        ...this.formData,
        Page: this.pageIndex,
        Limit: this.pageSize,
      };
      this.loading = true;
      Senstive.getWordList({ Id, Type, Page, Limit })
        .then((res) => {
          if (res.Code == 0) {
            //数据处理
            this.tableData = res.Data.Data.map((v) => {
              v.TypeText = v.Type
                ? this.TypeList.filter((type) => type.Id == v.Type)[0].Name
                : "--";
              return v;
            });
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>