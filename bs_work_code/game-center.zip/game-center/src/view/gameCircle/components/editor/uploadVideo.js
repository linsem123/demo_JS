import wangEditor from "wangeditor";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";
import axios from "@/libs/api.request";
import baseurl from "@/api/gamespace/base";
const { $, BtnMenu, DropListMenu, PanelMenu, DropList, Panel, Tooltip } =
  wangEditor;
//上传图片自定义barBtn
// 第一，菜单 class ，Button 菜单继承 BtnMenu class
// class UploadVideo extends BtnMenu {
var ProgressNum = 0; //上传进度
class UploadVideo extends PanelMenu {
  constructor(editor) {
    const $elem = wangEditor.$(
      `<div class="w-e-menu" data-title="视频">
            <i class="w-e-icon-play">
            </div>`
    );
    super($elem, editor);
  }
  // 菜单点击事件
  clickHandler() {
    const conf = uploadAlert(this.editor);
    const panel = new Panel(this, conf);
    panel.create();
  }
  // 菜单是否被激活（如果不需要，这个函数可以空着）
  // 1. 激活是什么？光标放在一段加粗、下划线的文本时，菜单栏里的 B 和 U 被激活，如下图
  // 2. 什么时候执行这个函数？每次编辑器区域的选区变化（如鼠标操作、键盘操作等），都会触发各个菜单的 tryChangeActive 函数，重新计算菜单的激活状态
  tryChangeActive() {
    //     // 激活菜单
    //     // 1. 菜单 DOM 节点会增加一个 .w-e-active 的 css class
    //     // 2. this.this.isActive === true
    //     this.active()
    //     // // 取消激活菜单
    //     // // 1. 菜单 DOM 节点会删掉 .w-e-active
    //     // 2. this.this.isActive === false
    //     // this.unActive()
  }
}
const uploadAlert = function (editor) {
  const config = editor.config;
  const [uploadVideo, inputVideo, videoProgress] = [
    "upload-video",
    "input-video",
    "video-progress",
  ];
  const videoMultipleAttr =
    config.videoIsmultiple === 1 ? "" : 'multiple="multiple"';
  const acceptsVideo = config.VideoAccepts.map((item) => `video/${item}`).join(
    ","
  );
  // const baseUrl = config.uploadBaseUrl

  // let imageList = []
  let videoList = [];
  let videoImgList = [];
  //校验格式
  // function checkFileAccept(type="image",fileList){
  //     let accept = type == "image" ? acceptsImg:acceptsVideo
  //     for (let i = 0; i < fileList.length; i++) {
  //         if(!accept.includes(fileList[i].type)){
  //             return false
  //         }
  //     }
  //     return true
  // }
  function GetSts() {
    return axios.request({
      url: baseurl + "game/sts",
      method: "get",
    });
  }
  //上传文件至服务器
  function uploadToserver(type, file) {
    return new Promise((resolve, reject) => {
      let cos = new COS({
        getAuthorization: function (options, callback) {
          GetSts()
            .then((data) => {
              callback({
                TmpSecretId: data.Data.credentials.tmpSecretId,
                TmpSecretKey: data.Data.credentials.tmpSecretKey,
                XCosSecurityToken: data.Data.credentials.sessionToken,
                ExpiredTime: data.Data.expiredTime,
              });
            })
            .catch((error) => {
              setProgressNum(0);
              ProgressNum = 0;
              alert("上传失败");
              reject();
            });
        },
      });
      let key = "game" + "/" + new Date().getTime(); //game?
      // let key = 'game' + '/' + new Date().getTime() + '-' + file.name //game?
      cos.sliceUploadFile(
        {
          Bucket: cosconfig.bucket /* 必须 */,
          Region:
            cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
          Key: key,
          Body: file /* 必须 */,
          onProgress: function (progressData) {
            if (progressData.percent * 100 > 1) {
              ProgressNum = Math.floor(progressData.percent * 100);
              setProgressNum(ProgressNum);
            }
            /* 非必须 */
            // console.log(JSON.stringify(progressData));
          },
        },
        function (err, data) {
          if (err) {
            console.error(err);
            setProgressNum(0);
            ProgressNum = 0;
            alert("上传失败");
            reject();
            return;
          }
          if (type == "video") {
            videoList.push({
              url: cosconfig.exporturl + "/" + key,
            });
          } else if (type == "videoImg") {
            videoImgList.push({
              url: cosconfig.exporturl + "/" + key,
            });
          }
          resolve();
        }
      );
    });
  }
  // 视频截图
  async function captureImage(videoFile) {
    var src = URL.createObjectURL(videoFile);
    let video = document.createElement("video");
    video.controls = "controls";
    video.autoplay = true;
    video.muted = true;
    let source = document.createElement("source");
    source.src = src;
    source.type = "video/mp4";
    video.appendChild(source);
    let fileData;
    return new Promise((resolve) => {
      video.addEventListener("loadeddata", () => {
        var canvas = document.createElement("canvas");
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas
          .getContext("2d")
          .drawImage(video, 0, 0, canvas.width, canvas.height);
        let imgsrc = canvas.toDataURL("image/png");
        fileData = dataURLtoFile(imgsrc);
        resolve(fileData);
      });
    });
    // fileData
  }
  //base64转file
  function dataURLtoFile(dataurl) {
    //base64转为file
    var arr = dataurl.split(","),
      mime = arr[0].match(/:(.*?);/)[1],
      bstr = window.atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n),
      filename = new Date().getTime() + ".png";
    //window.atob 解码使用 base-64 编码的字符串
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, { type: mime });
  }
  //插入video
  function insertVideo(src, type, poster, $eleHtml) {
    if ($eleHtml.includes("<br>")) {
      editor.cmd.do(
        "insertHTML",
        `<p><br></p><video poster="${poster}" controls="controls" name="media"><source src="${src}" type="${type}"></video><p><br></p>`
      );
    } else {
      editor.cmd.do(
        "insertHTML",
        `<video poster="${poster}" controls="controls" name="media"><source src="${src}" type="${type}"></video><p><br></p>`
      );
    }
  }
  let tabsConf = [
    {
      // tab 的标题
      title: editor.i18next.t("menus.panelMenus.link.上传视频"),
      // 模板
      tpl: `<div class="w-e-up-img-container">
                    <div id="${uploadVideo}" class="w-e-up-btn">
                        <i class="w-e-icon-upload2"></i>
                    </div>
                    <div id="${videoProgress}">
                        上传进度：<span id="ProgressNum">${ProgressNum}</span>%
                    </div>
                    <div style="display:none;">
                        <input id="${inputVideo}" type="file" accept="${acceptsVideo}" ${videoMultipleAttr}/>
                    </div>
                </div>`,
      events: [
        {
          selector: "#" + uploadVideo,
          type: "click",
          fn: () => {
            const $file = $("#" + inputVideo);
            const fileElem = $file.elems[0];
            if (fileElem) {
              console.log("video:" + ProgressNum);
              if (ProgressNum > 0 && ProgressNum < 100) {
                alert("视频上传中，请等待上传完成！");
              } else {
                fileElem.click();
              }
            } else {
              // 返回 true 可关闭 panel
              return true;
            }
          },
        },
        // 选择完毕
        {
          selector: "#" + inputVideo,
          type: "change",
          fn: async () => {
            // debugger
            let $eleHtml =
              editor.selection.getSelectionContainerElem().elems[0].innerHTML;
            const $file = $("#" + inputVideo);
            const fileElem = $file.elems[0];
            if (!fileElem) {
              // 返回 true 可关闭 panel
              return true;
            }
            let fileList = fileElem.files; //文件
            if(fileList[0].size / 1024 / 1024 > 500) {
                alert("视频大小不能超过500MB！");
                return;
            }
            videoList = [];
            videoImgList = [];
            ProgressNum = 1;
            setProgressNum(ProgressNum);
            for (let i = 0; i < fileList.length; i++) {
              let videoImg = "";
              await captureImage(fileList[i]).then((res) => {
                videoImg = res;
              });
              await uploadToserver("video", fileList[i]);
              await uploadToserver("videoImg", videoImg);
              insertVideo(
                videoList[i].url,
                fileList[i].type,
                videoImgList[i].url,
                $eleHtml
              );
            }
            setProgressNum(100);
            ProgressNum = 0;
            return true;
            // 返回 true 可关闭 panel
          },
        },
      ],
    },
  ];
  function setProgressNum(num) {
    if (document.getElementById("ProgressNum")) {
      document.getElementById("ProgressNum").innerHTML = num;
    }
  }
  const conf = {
    width: 300,
    height: 0,
    tabs: tabsConf,
  };

  return conf;
};
export default UploadVideo;
