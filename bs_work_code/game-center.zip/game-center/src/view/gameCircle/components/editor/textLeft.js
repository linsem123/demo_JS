import wangEditor from 'wangeditor'
const { $, BtnMenu, DropListMenu, PanelMenu, DropList, Panel, Tooltip } = wangEditor
//上传图片自定义barBtn
// 第一，菜单 class ，Button 菜单继承 BtnMenu class
class textCenter extends BtnMenu {
    constructor(editor) {
        const $elem = wangEditor.$(
            `<div class="w-e-menu" data-title="左对齐">
            <i class="w-e-icon-paragraph-left">
            </div>`
        )
        super($elem, editor)
    }
    // 菜单点击事件
    clickHandler(value) {
        this.command(value)
        // const panel = new Panel(this, conf)
        // panel.create()
    }
    // 菜单是否被激活（如果不需要，这个函数可以空着）
    // 1. 激活是什么？光标放在一段加粗、下划线的文本时，菜单栏里的 B 和 U 被激活，如下图
    // 2. 什么时候执行这个函数？每次编辑器区域的选区变化（如鼠标操作、键盘操作等），都会触发各个菜单的 tryChangeActive 函数，重新计算菜单的激活状态
    tryChangeActive() {
        //     // 激活菜单
        //     // 1. 菜单 DOM 节点会增加一个 .w-e-active 的 css class
        //     // 2. this.this.isActive === true
        //     this.active()
        //     // // 取消激活菜单
        //     // // 1. 菜单 DOM 节点会删掉 .w-e-active
        //     // // 2. this.this.isActive === false
        //     // this.unActive()
    }
    command(value) {
        const editor = this.editor
        const selection = editor.selection
        const $selectionElem = selection.getSelectionContainerElem()
        // 保存选区
        selection.saveRange()
        // 定义对齐方式的type
        // type justifyType = {
        //     [key: string]: string
        // }
        // 数据项
        const justifyCenter = 'left',
            // 获取顶级元素
            $elems = editor.selection.getSelectionRangeTopNodes(editor)
        // 选区等于textElem时表示选择了多个段落

        if ($selectionElem && editor.$textElem.equal($selectionElem)) {
            // 获取在css中对应style的值
            // const justifyValue = justifyClass[value]
            $elems.forEach((el) => {
                console.log(el)
                el.css('text-align', justifyCenter)
            })
        } else {
            // if (editor.cmd.queryCommandState('justifyCenter')){
            //     editor.cmd.do('JustifyLeft', value)
            // }else{
            editor.cmd.do('JustifyLeft', value)
            // }
        }


        //恢复选区
        selection.restoreSelection()
    }
    /**
    * 尝试改变菜单激活（高亮）状态
    * 默认左对齐,若选择其他对其方式对active进行高亮否则unActive
    * ?考虑优化的话 是否可以对具体选中的进行高亮
    */
    tryChangeActive() {
        // const editor = this.editor
        // // let isjustify = ['justifyCenter'].some(e => editor.cmd.queryCommandState(e))
        // if (editor.cmd.queryCommandState('justifyCenter')) {
        //     this.active()
        // } else {
        //     this.unActive()
        // }
    }

}


export default textCenter