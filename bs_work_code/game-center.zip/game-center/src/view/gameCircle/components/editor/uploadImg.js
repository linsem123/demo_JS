import wangEditor from "wangeditor";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";
import axios from "@/libs/api.request";
import baseurl from "@/api/gamespace/base";
const { $, BtnMenu, DropListMenu, PanelMenu, DropList, Panel, Tooltip } =
  wangEditor;
var ProgressNum = 0; //上传进度
//上传图片自定义barBtn
// 第一，菜单 class ，Button 菜单继承 BtnMenu class
class UploadImg extends PanelMenu {
  constructor(editor) {
    const $elem = wangEditor.$(
      `<div class="w-e-menu" data-title="图片">
            <i class="w-e-icon-image">
            </div>`
    );
    super($elem, editor);
  }
  // 菜单点击事件
  clickHandler() {
    const conf = uploadAlert(this.editor);
    const panel = new Panel(this, conf);
    panel.create();
  }
  // 菜单是否被激活（如果不需要，这个函数可以空着）
  // 1. 激活是什么？光标放在一段加粗、下划线的文本时，菜单栏里的 B 和 U 被激活，如下图
  // 2. 什么时候执行这个函数？每次编辑器区域的选区变化（如鼠标操作、键盘操作等），都会触发各个菜单的 tryChangeActive 函数，重新计算菜单的激活状态
  tryChangeActive() {
    //     // 激活菜单
    //     // 1. 菜单 DOM 节点会增加一个 .w-e-active 的 css class
    //     // 2. this.this.isActive === true
    //     this.active()
    //     // // 取消激活菜单
    //     // // 1. 菜单 DOM 节点会删掉 .w-e-active
    //     // // 2. this.this.isActive === false
    //     // this.unActive()
  }
}
const uploadAlert = function (editor) {
  const config = editor.config;
  const [uplodeImg, inputImg, imgProgress] = [
    "upload-img",
    "input-img",
    "img-progress",
  ];
  const imgMultipleAttr =
    config.imgIsmultiple === 1 ? "" : 'multiple="multiple"';
  const acceptsImg = config.ImgAccepts.map((item) => `image/${item}`).join(",");

  // const baseUrl = config.uploadBaseUrl

  let imageList = [];
  function GetSts() {
    return axios.request({
      url: baseurl + "game/sts",
      method: "get",
    });
  }
  //上传文件至服务器
  function uploadToserver(type, file) {
    return new Promise((resolve, reject) => {
      let cos = new COS({
        getAuthorization: function (options, callback) {
          GetSts().then((data) => {
            callback({
              TmpSecretId: data.Data.credentials.tmpSecretId,
              TmpSecretKey: data.Data.credentials.tmpSecretKey,
              XCosSecurityToken: data.Data.credentials.sessionToken,
              ExpiredTime: data.Data.expiredTime,
            });
          });
        },
      });
      let key = "game" + "/" + new Date().getTime(); //game?
      // let key = 'game' + '/' + new Date().getTime() + '-' + file.name //game?
      cos.sliceUploadFile(
        {
          Bucket: cosconfig.bucket /* 必须 */,
          Region:
            cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
          Key: key,
          Body: file /* 必须 */,
          onProgress: function (progressData) {
            // that.uploadpercent = progressData.percent * 100
            /* 非必须 */
            // console.log(JSON.stringify(progressData));
          },
        },
        function (err, data) {
          if (err) {
            console.error(err);
            alert("图片上传失败");
            reject();
            return;
          }
          if (type == "image") {
            imageList.push({
              url: cosconfig.exporturl + "/" + key,
            });
          }
          resolve();
        }
      );
    });
  }

  //插入图片
  function insertImg(src) {
    editor.cmd.do(
      "insertHTML",
      `<p><img src="${src}" style="max-width:100%;display:block"/></p>`
    );
  }
  let tabsConf = [
    {
      // tab 的标题
      title: editor.i18next.t("menus.panelMenus.link.上传图片"),
      // 模板
      tpl: `<div class="w-e-up-img-container">
                    <div id="${uplodeImg}" class="w-e-up-btn">
                        <i class="w-e-icon-upload2"></i>
                    </div>
                    <div id="${imgProgress}">
                        上传进度：<span id="imgProgressNum">${ProgressNum}</span>%
                    </div>
                    <div style="display:none;">
                        <input id="${inputImg}" type="file" ${imgMultipleAttr} accept="${acceptsImg}"/>
                    </div>
                </div>`,
      events: [
        {
          selector: "#" + uplodeImg,
          type: "click",
          fn: () => {
            const $file = $("#" + inputImg);
            const fileElem = $file.elems[0];
            if (fileElem) {
              if (ProgressNum > 0 && ProgressNum < 100) {
                alert("图片上传中，请等待上传完成！");
              } else {
                fileElem.click();
              }
            } else {
              // 返回 true 可关闭 panel
              return true;
            }
          },
        },
        // 选择图片完毕
        {
          selector: "#" + inputImg,
          type: "change",
          fn: async () => {
            const $file = $("#" + inputImg);
            const fileElem = $file.elems[0];
            if (!fileElem) {
              // 返回 true 可关闭 panel
              return true;
            }

            let fileList = fileElem.files; //图片是个list
            //上传图片至服务器
            imageList = [];
            ProgressNum = 1;
            setProgressNum(ProgressNum);
            for (let i = 0; i < fileList.length; i++) {
              await uploadToserver("image", fileList[i]);
              ProgressNum = (((i + 1) / fileList.length) * 100).toFixed(0);
              setProgressNum(ProgressNum);
              insertImg(imageList[i].url);
            }
            ProgressNum = 0;
            return true;
            // 返回 true 可关闭 panel
          },
        },
      ],
    },
  ];
  function setProgressNum(num) {
    if (document.getElementById("imgProgressNum")) {
      document.getElementById("imgProgressNum").innerHTML = num;
    }
  }
  const conf = {
    width: 300,
    height: 0,
    tabs: tabsConf,
  };
  return conf;
};
export default UploadImg;
