<template>
  <div class="home">
    <div v-if="menus.includes('fontSize')">选中字号大小：{{ fontSize }}</div>
    <div ref="editor"></div>
  </div>
</template>

<script>
// 引入 wangEditor
import wangEditor from "wangeditor";
import AppToHtmlJson from "@/view/gameCircle/pubFunc/AppToHtmlJson.js";
import common from "@/view/gameCircle/pubFunc/common.js";
import uploadImg from "./uploadImg";
import UploadVideo from "./uploadVideo";
import TextCenter from "./textCenter";
import TextLeft from "./textLeft";
export default {
  props: {
    editHeight: {
      default: 300,
    },
    menus: {
      type: Array,
      // default:()=>['uploadImgMenuKey','uploadVideoMenuKey',]
      default: () => [
        "bold",
        "italic",
        "underline",
        "fontSize",
        "foreColor",
        "textCenterMenuKey",
        "textLeftMenuKey",
        "link",
        "uploadImgMenuKey",
        "uploadVideoMenuKey",
      ],
    },
    canAt: {
      //是否可@用户
      type: Boolean,
      default: true,
    },
    filterPaste: {
      default: "text", //text-仅支持粘贴文字 allStyle-仅支持粘贴编辑器支持的样式
      type: String,
    },
  },
  data() {
    return {
      editor: null,
      editorData: "",
      jsonData: [],
      unionidList: [],
      fontSize: "",
      fontSizeArr: ["", "13", "16", "18", "20", "22", "24", "32"],
    };
  },
  mounted() {
    this.initEditor();
    // let editorEle = document.getElementsByClassName("w-e-text")[0];
    // editorEle.addEventListener("keydown", (event) => this.handleKeyDown(event));
  },
  methods: {
    getEditoJsonData() {
      // 通过代码获取编辑器Json内容
      this.jsonData = this.editor.txt.getJSON();
      // console.log(this.jsonData)
      return this.jsonData;
    },
    getEditorHTMLData() {
      // 通过代码获取编辑器HTML内容
      return this.editor.txt.html();
    },
    setEditorData(jsonData) {
      // 通过代码设置编辑器内容
      let bb = AppToHtmlJson.AppToHtmlJson(jsonData);
      // console.log(bb)
      this.editor.txt.setJSON(bb);
      //光标移动到最后
      const $linkElem = this.editor.selection.getSelectionContainerElem();
      let a =
        $linkElem.elems[0].children[$linkElem.elems[0].children.length - 1];
      this.editor.selection.moveCursor(a, false);
    },
    clearEditor() {
      this.editor.txt.clear();
    },
    //初始化编辑器配置
    initEditor() {
      const editor = new wangEditor(this.$refs.editor);
      // 配置 onchange 回调函数，将数据同步到 vue 中
      editor.config.onchange = (newHtml) => {
        this.editorData = newHtml;
      };
      // const menuKey = 'uploadImgMenuKey' // 菜单 key ，各个菜单不能重复
      editor.menus.extend("uploadImgMenuKey", uploadImg);
      editor.menus.extend("uploadVideoMenuKey", UploadVideo);
      editor.menus.extend("textCenterMenuKey", TextCenter);
      editor.menus.extend("textLeftMenuKey", TextLeft);

      // 将菜单加入到 editor.config.menus 中
      editor.config.menus = editor.config.menus.concat([
        "uploadImgMenuKey",
        "uploadVideoMenuKey",
        "textCenterMenuKey",
        "textLeftMenuKey",
      ]);
      //配置图片/视频上传格式
      editor.config.ImgAccepts = [
        "jpg",
        "JPG",
        "jpeg",
        "JPEG",
        "png",
        "PNG",
        "gif",
        "GIF",
      ];
      editor.config.VideoAccepts = ["mp4", "avi", "mpg", "mpeg"];
      //配置图片/视频是否可多选
      editor.config.imgIsmultiple = 10;
      editor.config.videoIsmultiple = 1;

      //上传图片/视频baseurl
      editor.config.uploadBaseUrl =
        "https://jsonplaceholder.typicode.com/posts/"; // 配置服务器端地址

      // 配置字体
      editor.config.fontSizes = {
        "x-small": { name: "13px", value: "1" },
        small: { name: "16px", value: "2" },
        normal: { name: "18px", value: "3" },
        large: { name: "20px", value: "4" },
        "x-large": { name: "22px", value: "5" },
        "xx-large": { name: "24px", value: "6" },
        "xxx-large": { name: "32px", value: "7" },
      };

      //设置z-index
      editor.config.zIndex = 200;
      editor.config.height = this.editHeight;
      //选区操作自动触发onSelectionChange 函数执行
      if (this.menus.includes("fontSize")) {
        editor.config.onSelectionChange = () => {
          const $Elem =
            this.editor.selection.getSelectionContainerElem().elems[0];
          this.fontSize = "";
          if ($Elem) {
            if ($Elem.nodeName.toLowerCase() == "font") {
              this.fontSize = this.fontSizeArr[$Elem.size];
            }
          }
        };
      }
      //监听键盘输入@
      editor.txt.eventHooks.keyupEvents.push(this.quoteUserEvent);
      //监听删除键backSpace down
      editor.txt.eventHooks.deleteDownEvents.push(this.backSpaceDown);
      //监听点击a标签事件
      editor.txt.eventHooks.linkClickEvents.push(this.linkTourl);
      //自定义菜单
      editor.config.menus = this.menus;
      //自定义字号
      //粘贴过滤
      editor.config.pasteFilterStyle = false;
      editor.config.pasteTextHandle = (pasteStr) => {
        if (this.filterPaste == "text") {
          // 评论及回复对粘贴的文本进行处理，只提取文字
          let str = pasteStr.replace(/\<[^>]*\>(([^<])*)/g, function () {
            return arguments[1];
          });
          return str;
        } else if (this.filterPaste == "allStyle") {
          let str = pasteStr
            .replace(/\<span/g, "<font")
            .replace(/\<\/span/g, "</font")
            .replace(/\<strong/g, "<b")
            .replace(/\<\/strong/g, "</b")
            // .replace(/\<(h[1-6]|section|ul|div)/g, "<p")
            // .replace(/\<\/(h[1-6]|section|ul|div)/g, "</p")
            .replace(/\<(h[1-6]|ul|div)/g, "<p")
            .replace(/\<\/(h[1-6]|ul|div)/g, "</p")
            .replace(/\<(button|\/button).*?>/g, "")
            .replace(
              /<(?!img|p|\/p|font|\/font|div|\/div|b|\/b|u|\/u|i|\/i|a|\/a|section|\/section|br).*?>/g,
              ""
            );

          let accepts = [
            "color",
            "text-align",
            "font-size",
            "font-weight",
            "font-style",
            "text-decoration",
          ];

          let str2 = str.replace(
            /(style=\"?([^\"]*)\")/g,
            (...inlineStyles) => {
              const acceptsFinds = [];
              inlineStyles[2]
                .split(";")
                .filter((style) => !!style)
                .forEach((style) => {
                  let styleArr = style.split(":").map((v) => v.trim());
                  // 提取编辑器支持的样式
                  if (accepts.includes(styleArr[0])) {
                    if (styleArr[0] == "font-size") {
                      let size = styleArr[1]
                        .replace(/!.*/, "")
                        .replace(/[A-Za-z]*|(%?)/g, "");
                      let unit = styleArr[1]
                        .replace(/!.*/, "")
                        .replace(/[^A-Za-z|%]/g, "");
                      if (unit != "px" && unit != "em") {
                        switch (unit) {
                          case "pt":
                            size = ((4 / 3) * Number(size)).toFixed(0);
                            break;
                          case "rem":
                            size = (16 * Number(size)).toFixed(0);
                            break;
                          case "vw":
                            let ScreenWidth = document.body.clientWidth / 100;
                            size = (ScreenWidth * Number(size)).toFixed(0);
                            break;
                          default:
                            size = 15;
                        }
                        style = `font-size: ${size}px`;
                      }
                      style = style + "!important";
                      acceptsFinds.push(style);
                    } else if (styleArr[0] == "color") {
                      let color = styleArr[1].replace(/!.*/, "").trim();
                      if (color.includes("rgb")) {
                        let rgbArr = color
                          .match(/[^\(\)]+(?=\))/g)[0]
                          .split(",");
                        color = this.rgbToHexColor(rgbArr);
                      }
                      style = `color: ${color}!important`;
                      acceptsFinds.push(style);
                    } else if (styleArr[0] == "font-weight") {
                      if (
                        (styleArr[1] > "400" && styleArr[1] < "800") ||
                        styleArr[1] == "bold"
                      ) {
                        acceptsFinds.push(style);
                      }
                    } else if (styleArr[0] == "font-style") {
                      if (styleArr[1] == "italic" || styleArr[1] == "oblique") {
                        acceptsFinds.push(style);
                      }
                    } else if (styleArr[0] == "text-decoration") {
                      if (styleArr[1] == "underline") {
                        acceptsFinds.push(style);
                      }
                    } else {
                      acceptsFinds.push(style);
                    }
                  }
                });
              return acceptsFinds ? `style="${acceptsFinds.join(";")}"` : "";
            }
          );
          return str2;
        }
      };
      // 创建编辑器
      editor.create();
      this.editor = editor;
    },
    //keydow 监听function
    // handleKeyDown(event) {
    //   if (
    //     event.returnValue &&
    //     (event.code == "KeyB" || event.code == "KeyI" || event.code == "KeyU")
    //   ) {
    //     event.preventDefault();
    //   }
    // },
    //监听键盘事件
    quoteUserEvent(event) {
      //监听键盘输入@
      if (this.canAt && event.shiftKey && event.code == "Digit2") {
        document.getElementsByClassName("w-e-text")[0].blur(); //编辑器失焦
        this.editor.selection.saveRange();
        this.$emit("quoteUserEvent");
      }
    },
    backSpaceDown() {
      const $linkElem = this.editor.selection.getSelectionContainerElem();
      //判断删除是否为@用户
      if (this.isUnionId($linkElem)) {
        // event.preventDefault()
        //光标移动到标签结束处
        this.editor.selection.createRangeByElem($linkElem);
        this.editor.selection.restoreSelection();
      }
    },
    //a标签点击跳转链接
    linkTourl(event) {
      let href = "";
      let $attributes = event.elems[0].attributes;
      //获取href
      for (let key in $attributes) {
        if ($attributes[key].name == "href") href = $attributes[key].value;
      }
      //如果href不为空跳转链接
      if (href) {
        window.open(href, "_target");
      }
    },
    //判断是否为@用户
    isUnionId($linkElem) {
      let flag = false;
      let $attributes = $linkElem.elems[0].attributes;
      //是否有unionId属性
      for (let key in $attributes) {
        if ($attributes[key].name == "unionid") flag = true;
      }
      return flag;
    },
    //插入@用户标签
    setQuoteUser(user) {
      if (user.NickName) {
        this.editor.selection.restoreSelection();
        this.editor.history.revoke(); //返回上一步，相当于去掉输入的@改为选择的用户
        //根据内容宽度设置input宽度
        let inwidth = common.getTextWidth(`@${user.NickName}`);
        // this.editor.cmd.do('insertHTML', `<p><a unionId=${this.user.id} style="color:green!important" href="">&nbsp;@${this.user.name}&nbsp;</a></p>`)
        this.editor.cmd.do(
          "insertHTML",
          `<p><input unionId=${user.UnionId} value="@${user.NickName}" style="font-size:15px!important;color:green!important;border:none;background:white;width:${inwidth}px" class="input_union_id" readonly="readonly" disabled="disabled"/></p>`
        );
      }
    },
    //rgb/rgba转换为16进制
    rgbToHexColor(rgbArray) {
      if (rgbArray.length > 2) {
        let strHex = "#";
        for (let i = 0; i < 3; i++) {
          let hex = Number(rgbArray[i]).toString(16);
          if (hex == 0) {
            hex += "0";
          }
          strHex += hex;
        }
        //补位#
        return strHex;
      } else {
        return "#000000";
      }
    },
  },
  beforeDestroy() {
    // 调用销毁 API 对当前编辑器实例进行销毁
    this.editor.destroy();
    this.editor = null;
  },
};
</script>

<style lang="less" scoped>
.home {
  width: 90%;
  // margin: auto;
  position: relative;
  .btn {
    position: absolute;
    right: 0;
    top: 0;
    padding: 5px 10px;
    cursor: pointer;
  }
  h3 {
    margin: 30px 0 15px;
  }
}
/deep/ .w-e-text-container img {
  display: block;
  max-width: 100%;
  margin: auto;
}
/deep/ .w-e-text-container video {
  display: block;
  max-width: 100%;
}
/deep/ .w-e-text {
  padding: 10px;
  color: #000;
}
//隐藏a标签downtool
/deep/ .w-e-text-container .w-e-tooltip-down {
  display: none;
}
/deep/ .w-e-text p {
  margin: 0;
  line-height: 2;
  font-size: 15px !important;
  font[size="1"] {
    font-size: 13px !important;
  }
  font[size="2"] {
    font-size: 16px !important;
  }
  font[size="3"] {
    font-size: 18px !important;
  }
  font[size="4"] {
    font-size: 20px !important;
  }
  font[size="5"] {
    font-size: 22px !important;
  }
  font[size="6"] {
    font-size: 24px !important;
  }
  font[size="7"] {
    font-size: 32px !important;
  }
}
/deep/ .w-e-text input {
  border-width: initial;
  border-style: none;
  border-color: initial;
  background: white;
  width: 48px;
  font-size: 15px !important;
  color: green !important;
}
.load_dialog {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background-color: rgba(0, 0, 0, 0.1);
  z-index: 2000;
}
</style>