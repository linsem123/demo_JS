<template>
    <div>
        <Input search placeholder="请输入..."  v-model="keyword" @on-search="getUserList"/>
        <div class="table_box" @click.stop="()=>{}">
            <i-table 
                border 
                highlight-row 
                ref="currentRowTable" 
                :columns="columns4" 
                :data="data1"
                :max-height="500"
                :loading="loading"
                @on-row-click="seleced"
            />
        </div>
    </div>
</template>
<script>
import Post from "@/api/gameCircle/postManagement";
export default {
    name:'userList',
    data(){
        return{
            keyword:"",
            loading:false,
            columns4: [
                    {
                        title: '昵称',
                        key: 'NickName'
                    },
                ],
            data1: []
        }
    },
    methods:{
        getUserList(){
            if(this.keyword){
                this.loading = true
                Post.userLikeByNickName(this.keyword).then(res=>{
                    this.data1 = res.Data
                }).finally(()=>{
                    this.loading = false
                })
            }
            
        },
        seleced(data){
            // console.log(event)
            // event.stopPropagation()
            this.$emit("selectUser",data)
        }
    }
}
</script>
<style scoped lang="less">
.table_box{
    margin: 20px auto;
}
</style>