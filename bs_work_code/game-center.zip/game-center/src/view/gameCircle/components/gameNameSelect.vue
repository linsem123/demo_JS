<template>
  <Select
    :value="value"
    :multiple="multiple"
    clearable
    filterable
    remote
    @on-clear="onClear"
    @on-change="updateVal"
    :remote-method="handleGamesSearch"
    :placeholder="placeholder"
    :style="'width:' + width + 'px'"
  >
    <Option v-for="j in gameList" :value="j.ID" :key="j.ID">{{j.AppName+j.PkgName}}</Option>
  </Select>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
export default {
  props: {
    value: {
      default: () => [],
    },
    width: {
      type: Number,
      default: 400,
    },
    multiple: {
      default: true,
    },
    placeholder: {
      default: "请输入游戏名称",
    },
  },
  data() {
    return {
      gameList: [],
    };
  },
  mounted() {
    this.editInit();
  },
  methods: {
    editInit() {
      // if(this.value || (this.multiple&&this.value.length>0)){
      //      this.gameList = []
      //     GameAPI.GetGames(this.value).then(res => {
      //         this.gameList = res.Data;
      //          this.$refs['selection'].setQuery(res.Data["AppName"])
      //         this.$refs['selection'].toggleMenu(null, false);
      //     });
      // }
    },
    handleGamesSearch(value) {
      // if (!parseInt(value)) {
      GameAPI.LikeApp({ value }).then((res) => {
        this.gameList = res.Data;
      });
      // }
    },
    onClear(){
      this.$emit("input", 0);
    },
    updateVal(value) {
      // this.$emit("input", value);
      this.gameList.forEach(item=>{
        if(item.ID==value){
          this.$emit("input", value,item);
        }
      })
    },
  },
};
</script>
<style lang="less" scoped>
</style>