<template>
  <Select
    :value="value"
    clearable
    filterable
    remote
    :multiple="multiple"
    :remote-method="getUser"
    placeholder="请输入标题"
    @on-change="updateVal"
    :style="'width:' + width + 'px'"
  >
    <Option v-for="j in titleList" :value="j.Id" :key="j.Id">{{
      j.Title
    }}</Option>
  </Select>
</template>
<script>
import Post from "@/api/gameCircle/postManagement";
export default {
  props: {
    value: {
      default: "",
    },
    width: {
      type: Number,
      default: 400,
    },
    multiple: {
      default: false,
    },
  },
  data() {
    return {
      titleList: [],
    };
  },
  methods: {
    getUser(value) {
      Post.titleLike(value).then((res) => {
        this.titleList = res.Data;
      });
    },
    updateVal(value) {
      this.$emit("input", value);
    },
  },
};
</script>
<style lang="less" scoped>
</style>