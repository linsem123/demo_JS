<template>
    <div style="position:absolute;z-index:999;top:0;right:0;left:0;bottom:0;background:white;opacity:0.7;">
        <Spin size="large" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)"></Spin>
    </div>
</template>

