<template>
  <div class="preview_box">
    <div class="preview_scroll_content">
      <h2>{{ title }}</h2>
      <div v-html="htmlData" class="preview_html"></div>
      <wangEditor ref="editorPanel" filterPaste="allStyle" v-show="false" />
    </div>
  </div>
</template>
<script>
import htmJsonToApp from "@/view/gameCircle/pubFunc/htmJsonToApp.js";
import wangEditor from "@/view/gameCircle/components/editor/wangEditor";
export default {
  props: {
    htmlJson: Array,
    title: String,
  },
  data() {
    return {
      htmlData: "",
    };
  },
  components: {
    wangEditor,
  },
  mounted() {
    let Content = htmJsonToApp.getEditorData(this.htmlJson);
    this.$refs.editorPanel.setEditorData(Content);
    this.htmlData = this.$refs["editorPanel"].getEditorHTMLData();
  },
};
</script>
<style lang="less" scoped>
.preview_box {
  width: 375px;
  height: 644px;
  overflow-y: auto;
  margin: auto;
  font-size: 15px;
  color: #000000;
  .preview_scroll_content {
    width: 100%;
    height: 100%;
  }
}
/deep/ .preview_html {
  font[size="1"] {
    font-size: 13px !important;
  }
  font[size="2"] {
    font-size: 16px !important;
  }
  font[size="3"] {
    font-size: 18px !important;
  }
  font[size="4"] {
    font-size: 20px !important;
  }
  font[size="5"] {
    font-size: 22px !important;
  }
  font[size="6"] {
    font-size: 24px !important;
  }
  font[size="7"] {
    font-size: 32px !important;
  }
}
/deep/ .preview_html video {
  max-width: 100%;
}
/deep/ .preview_html img {
  max-width: 100%;
  margin: auto;
  display: block;
}
</style>