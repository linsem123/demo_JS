<template>
    <Select 
        :value="value"
        clearable
        filterable
        remote
        :multiple="multiple"
        :remote-method="getContent"
        placeholder="请输入评论内容"
        @on-change="updateVal"
        :style="'width:' +width+'px'">
        <Option v-for="j in contentList" :value="j.Id" :key="j.Id">{{j.Content}}</Option>
    </Select>
</template>
<script>
import Discuss from "@/api/gameCircle/discussManage";
export default {
    props:{
        value:{
            default:''
        },
        width:{
            type:Number,
            default:400
        },
        multiple:{
            default:false
        }
    },
    data(){
        return{
            contentList:[]
        }
    },
    methods:{
        getContent(value){
            if (!parseInt(value)) {
                 Discuss.contentLike(value).then(res=>{
                    this.contentList = res.Data
                })
            }
        },
        updateVal(value){
            this.$emit('input',value)
        }
    }
}
</script>
<style lang="less" scoped>

</style>