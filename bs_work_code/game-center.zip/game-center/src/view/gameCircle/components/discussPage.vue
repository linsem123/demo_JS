<template>
       <div>
            <div class="edit_box">
                <Form ref="formValidate"
                    :model="formData"
                    :label-width="80"
                    :rules="ruleValidate">
                    <FormItem label="绑定账号" prop="UnionId">
                        <tagList :tagList="accountList" v-model="formData.UnionId"/>
                    </FormItem>
                    <FormItem label="标题" v-if="discusstype">
                        {{checkedTable.Title}}
                    </FormItem>
                    <FormItem label="评论" v-else>
                        {{checkedTable.Content}}
                    </FormItem>
                    <wangEditor 
                        @quoteUserEvent="quoteUserEvent" 
                        ref="editorPanel" 
                        :editHeight="200"
                        :menus="menus"
                        :canAt="canAt"
                        style="margin:auto"
                    />
                </Form>
                <div style="margin:30px 0;display:flex;justify-content:center">
                    <Button  style="margin-right:40px" @click="handelClickCancel">取消</Button>
                    <Button type="primary" @click="commitDiscuss">确定</Button>
                </div>
               
            </div>
            <Modal
                v-model="showModal"
                title="用户列表"
                @on-ok="ok"
                >
                <user-list @selectUser="selectUser"/>
            </Modal>
           
        </div>
        
</template>
<script>
import htmJsonToApp from '@/view/gameCircle/pubFunc/htmJsonToApp.js'
import Post from "@/api/gameCircle/postManagement";
import Discuss from "@/api/gameCircle/discussManage";
import wangEditor from '@/view/gameCircle/components/editor/wangEditor'
import tagList from '@/view/gameCircle/components/tagList'
import userList from '@/view/gameCircle/components/userList'
export default {
    props:{
        checkedTable:{
            //选中操作table的row
            type:Object,
            default:()=>{
               return { Title:'', Content:''}
            }
        },
        menus:{
            //编辑器toolbar菜单
            type:Array,
            default:()=>['uploadImgMenuKey']
        },
        discusstype:{
            //true-评论 false-回复
            type:Boolean,
            default:true
        },
        canAt:{//是否可@用户
            type:Boolean,
            default:true
        }
    },
    data(){
        return{
            showModal:false,
            showPreview:false,
            htmlJson:"",
            accountList:[],//绑定账号列表
            user:{},
            formData:{
                UnionId:'', //绑定账号
            },
            ruleValidate:{
                UnionId: [
                    { required: true, message: '请选择关联账号', trigger: 'change' }
                ],
            }
        }
    },
    components:{ 
        wangEditor,
        tagList,
        userList
    },
    created(){
        //绑定账号查询
       Post.getAccount({}).then(res => {
           if(res.Code == 0 && res.Data){
                res.Data.forEach(v=>{
                    let item = {}
                    item.UserId = v.UserId
                    item.Id = v.UnionId
                    item.Name = v.NickName
                    this.accountList.push(item)
                })
           }
        })
    },
    methods:{
        quoteUserEvent(){
            this.showModal = true;
        },
        //选择@用户
        ok(){
            this.$refs.editorPanel.setQuoteUser(this.user);
        },
        selectUser(data){
            this.user = data
        },
        //取消评论
        handelClickCancel(){
            this.clearData()
            
        },
        //发布评论/回复
        commitDiscuss(){
            this.$refs['formValidate'].validate((valid) => {
                if (valid) {
                    let jsonData = this.$refs['editorPanel'].getEditoJsonData();
                    let Content = htmJsonToApp.getEditorData(jsonData);
                    let ContentStr = ''//评论文字提出来
                    let ImageUrl  = []//评论图片提出来
                    Content.forEach(item=>{
                        if(item.type == 1){
                            item.inputStr.forEach(text => {
                            ContentStr += text.textStr
                        })
                        }
                        if(item.type == 2){
                            ImageUrl.push(item.imagePath)
                        }
                    })
                    if(ImageUrl.length>1){
                        this.$Message.error("评论只允许上传一张图片")
                        return;
                    }
                     let data = {}
                    if(this.discusstype){
                        //评论
                        let PostId = this.checkedTable.Id
                        let AtunionIds = htmJsonToApp.getAtunionIds()
                         data = {
                            PostId, //帖子Id
                            UnionId:this.formData.UnionId,//楼主Id
                            AtUnionIds:AtunionIds, //@用户Id
                            Content:JSON.stringify(Content),
                            ImageUrl:ImageUrl.join(","),
                            ContentStr
                        }
                        this.discussServer(data)
                    }else{
                        // debugger;
                        let CommentId = this.checkedTable.root?this.checkedTable.Id:this.checkedTable.CommentId
                        data = {
                            CommentId,//评论Id
                            UnionId: this.formData.UnionId,//回复的用户Id
                            Content:ContentStr,
                            ImageUrl:'',
                            AtUnionId:this.checkedTable.UnionId//被回复的用户Id
                        }
                        this.displyServer(data)
                    }
                   
                } 
            })
        },
       //评论
       discussServer(data){
           Discuss.addDiscuss(data).then(res=>{
               if(res.Code == 0){
                   this.$Message.success("评论成功")
                   this.clearData()
               }else{
                    this.$Message.error(res.Message)
               }
           })
       },
        //回复
       displyServer(data){
           Discuss.addReplay(data).then(res=>{
               if(res.Code == 0){
                   this.$Message.success("回复成功")
                   this.clearData(false)
               }else{
                    this.$Message.error(res.Message)
               }
           })
       },
       //清空已输入
       clearData(isClose=true){
           this.$refs['editorPanel'].clearEditor()
           this.formData.UnionId=""
           this.$emit('closeDiscuss', {row:this.checkedTable,discusstype:this.discusstype,isClose})
       }
    }
}
</script>
<style lang="less" scoped>
// .edit_box{
//     padding:20px;
// }
.button_group_flex{
    display: flex;
    justify-content: center;
}
/deep/ .ivu-btn{
    margin:0 10px;
}
</style>

