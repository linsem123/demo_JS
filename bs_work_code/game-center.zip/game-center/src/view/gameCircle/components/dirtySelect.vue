<template>
    <Select 
        :value="value"
        clearable
        filterable
        remote
        :multiple="multiple"
        :remote-method="getUser"
        placeholder="请输入屏蔽词"
        @on-change="updateVal"
        :style="'width:' +width+'px'">
        <Option v-for="j in titleList" :value="j.Id" :key="j.Id">{{j.Word}}</Option>
    </Select>
</template>
<script>
import Senstive from "@/api/gameCircle/senstiveManage";  
export default {
    props:{
        value:{
            default:''
        },
        width:{
            type:Number,
            default:400
        },
        multiple:{
            default:false
        }
    },
    data(){
        return{
            titleList:[]
        }
    },
    methods:{
        getUser(value){
            if (!parseInt(value)) {
                 Senstive.getWordLike(value).then(res=>{
                    this.titleList = res.Data
                })
            }
        },
        updateVal(value){
            this.$emit('input',value)
        }
    }
}
</script>
<style lang="less" scoped>

</style>