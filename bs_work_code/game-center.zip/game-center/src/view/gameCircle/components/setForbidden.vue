<template>
    <div class="set_forbiddon_box">
        <Form :model="formData"
              :rules="ruleValidate"
              ref="formValidate">
            <FormItem label="禁言类型">
                <RadioGroup v-model="formData.type">
                    <Radio label="1" style="margin-right:15px">账号</Radio>
                    <!-- <Radio label="2" style="margin-right:15px">IMEI</Radio>
                    <Radio label="3">账号+IMEI</Radio> -->
                </RadioGroup>
            </FormItem>
            <FormItem label="禁言周期">
                <RadioGroup v-model="formData.Cycle" @on-change="changeCycle">
                    <Radio :label="1" style="margin-right:15px">永久</Radio>
                    <Radio :label="2">自定义</Radio>
                </RadioGroup>
                <div style="margin-left:60px" v-if="formData.Cycle == 2">
                    <DatePicker v-model="formData.dateValue" type="datetimerange"  placeholder="选择日期" style="width: 300px" @on-change="changeDate"></DatePicker>
                    <!-- <DatePicker v-model="formData.dateValue" type="date" placeholder="请选择日期" style="width: 200px"></DatePicker> -->
                </div>
            </FormItem>
             <FormItem label="禁言原因">
                 <Input type="textarea" style="width:500px" :rows="4" v-model="formData.Reason"/>
             </FormItem>
        </Form>
        <div style="margin:30px 0;display:flex;justify-content:center">
            <Button  style="margin-right:40px" @click="handelClickCancel">取消</Button>
            <Button type="primary" @click="commit">确定</Button>
        </div>
    </div>
</template>
<script>
import User from "@/api/gameCircle/userManage";
import common from '@/view/gameCircle/pubFunc/common';
export default {
    props:{
        checkedTable:Object,
        idModify:Boolean//true-修改，false-新增

    },
    data(){
        return {
            formData:{
                type:'1',
                dateValue:'',
                Cycle:1,
                Reason:'',
                EndDate:undefined,
                StartDate:undefined
            },
            ruleValidate:{}
            
        }
    },
    mounted(){
        if(this.idModify){ 
            this.formData = {...this.checkedTable}
            this.formData.dateValue = [this.formData.StartDate,this.formData.EndDate]
            this.formData.type = '1'
        }
    },
    methods:{
        //选择时间
        changeDate(value){
            this.formData.StartDate = value[0]
            this.formData.EndDate = value[1]
        },
        //
        changeCycle(value){
            if(value == 1){
                this.formData.dateValue=[]
                 this.formData.StartDate = undefined
                 this.formData.EndDate = undefined
            }
        },
        //取消
        handelClickCancel(){
            this.clear()
            this.$emit('closeForbidden',false)
        },
        //保存
        commit(){
                if (this.formData.Cycle == 2 && !this.formData.StartDate) {
                    this.$Message.error('请选择禁言时间')
                }else{
                    this.idModify? this.modifyServer():this.addServer()
                }
        },
        //新增禁言
        addServer(){
            let {UserId,UnionId,Reason,StartDate,EndDate,Cycle} = {...this.checkedTable,...this.formData}
           if(Cycle == 2){
                StartDate = common.toDate(StartDate)
                EndDate = common.toDate(EndDate)
             }
            User.setForbiddon({UserId,UnionId,Reason,StartDate,EndDate,Cycle}).then(res=>{
                if(res.Code == 0){
                    this.$Message.success('禁言成功');
                    this.clear()
                    this.$emit('closeForbidden')
                }else{
                    this.$Message.error(res.Message)
                }
            })
        },
        //修改禁言信息
        modifyServer(){
             let {UserId,UnionId,Reason,StartDate,EndDate,Cycle} = {...this.checkedTable,...this.formData}
             if(Cycle == 2){
                StartDate = common.toDate(StartDate)
                EndDate = common.toDate(EndDate)
             }
            User.modifyForbiddon({UserId,UnionId,Reason,StartDate,EndDate,Cycle},this.checkedTable.Id).then(res=>{
                if(res.Code == 0){
                    this.$Message.success('修改成功');
                    this.clear()
                    this.$emit('closeForbidden',true)
                }else{
                    this.$Message.error(res.Message)
                }
            })
        },
        //清空 
        clear(){
            for(let key in this.formData){
                this.formData[key]=""
            }
            this.formData.type = '1'
            this.formData.Cycle = 1
        }
    }
}
</script>
<style lang="less" scoped>
.set_forbiddon_box{
    margin: 0 30px;
}
</style>