<template>
  <div class="tag_list_box">
    <span
      v-for="(item, index) of tagList"
      :class="['tag_nomal', hasData(item.Id) ? 'tag_checked' : 'tag_unchecked']"
      :key="index"
      @click="getClickEle(item)"
    >
      {{ item.Name }}
    </span>
  </div>
</template>
<script>
export default {
  props: {
    value: { default: "" },
    tagList: Array,
    multiple: {
      type: Boolean,
      default: false,
    }, //是否可多选
    trigger: {
      type: Boolean,
      default: false,
    }, //是否可取消选择
  },

  methods: {
    getClickEle(item) {
      if (this.hasData(item.Id)) {
        if (this.trigger) {
          if (this.multiple) {
            let list = this.value;
            list.splice(this.value.indexOf(item.Id), 1);
            this.$emit("input", list);
          } else {
            this.$emit("input", "");
          }
        }
      } else {
        if (this.multiple) {
          let list = this.value;
          list.push(item.Id);
          this.$emit("input", list);
        } else {
          this.$emit("input", item.Id);
        }
      }
    },
    hasData(ID) {
      if (this.multiple) {
        return this.value.includes(ID);
      } else {
        return this.value == ID;
      }
    },
  },
};
</script>
<style lang="less" scoped>
.tag_list_box {
  .tag_nomal {
    display: inline-block;
    height: 32px;
    line-height: 30px;
    margin: 0 5px;
    padding: 0 15px;
    font-size: 12px;
    cursor: pointer;
    .input_hidden {
      opacity: 0;
      width: 0;
      height: 0;
    }
  }
  .tag_unchecked {
    border: 1px solid #dcdee2;
    background: #fff;
    color: #515a6e;
  }
  .tag_checked {
    background: #fff;
    border: 1px solid #2d8cf0;
    color: #2d8cf0;
  }
}
</style>