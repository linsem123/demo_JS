<template>
  <div class="preview_box">
    <div class="margin_top_type">
      <span class="label_span">关联游戏：</span>{{ checkedTable.AppName }}
    </div>
    <div class="margin_top_type">
      <span class="label_span">标题：</span>{{ checkedTable.Title }}
    </div>
    <div class="margin_top_type">
      <span class="label_span">标签：</span>{{ checkedTable.Tags | tagName }}
    </div>
    <div class="margin_top_type">
      <span class="label_span">楼主：</span>{{ checkedTable.UserName }}
      <span class="label_span">发帖时间：</span>{{ createTime }}
    </div>
    <div class="margin_top_type" v-if="checkedTable.IsCron == 1">
      <span class="label_span">定时发布时间：</span
      >{{ checkedTable.CronPubTime }}
    </div>
    <div class="preview_scroll_content">
      <div v-html="checkedTable.Content" class="preview_html"></div>
    </div>
    <wangEditor v-show="false" ref="editorPanel" />
  </div>
</template>
<script>
import wangEditor from "@/view/gameCircle/components/editor/wangEditor";
import common from "@/view/gameCircle/pubFunc/common";
export default {
  props: {
    checkedTable: {
      type: Object,
      default: () => {
        return {
          Title: "",
          UserName: "",
          CreatedAt: "",
          Content: "",
          AppName: "",
        };
      },
    },
  },
  filters: {
    tagName(value) {
      if (value) {
        return value.map((v) => v.Name).join(",");
      }
      return "";
    },
  },
  components: {
    wangEditor,
  },
  computed: {
    createTime() {
      return common.formatDate(this.checkedTable.CreatedAt, true);
    },
  },
};
</script>
<style lang="less" scoped>
.preview_box {
  margin: auto;
  padding: 0 30px;
  font-size: 14px;
  .preview_scroll_content {
    width: 100%;
    max-height: 400px;
    overflow-y: auto;
    font-size: 15px;
    color: #000;
    border: 1px solid #eee;
    padding: 10px;
    padding-bottom: 150px;
    margin-top: 10px;
    .preview_html {
      width: 100%;
      height: 100%;
    }
  }
  .label_span {
    padding-right: 5px;
  }
  .margin_top_type {
    margin-top: 10px;
  }
}
/deep/ .preview_html img {
  max-width: 100%;
  margin: auto;
  display: block;
}
/deep/ .preview_html video {
  max-width: 100%;
}
/deep/ .preview_html {
  font[size="1"] {
    font-size: 13px !important;
  }
  font[size="2"] {
    font-size: 16px !important;
  }
  font[size="3"] {
    font-size: 18px !important;
  }
  font[size="4"] {
    font-size: 20px !important;
  }
  font[size="5"] {
    font-size: 22px !important;
  }
  font[size="6"] {
    font-size: 24px !important;
  }
  font[size="7"] {
    font-size: 32px !important;
  }
}
</style>