<template>
  <Select
    :value="value"
    clearable
    filterable
    remote
    :multiple="multiple"
    :remote-method="getUser"
    placeholder="请输入黑鲨帐号ID"
    @on-change="updateVal"
    :style="'width:' + width + 'px'"
  >
    <Option v-for="j in userList" :value="j.UnionId" :key="j.UnionId">{{
      j.NickName
    }}</Option>
  </Select>
</template>
<script>
import WhiteApi from "@/api/gameCircle/whiteList.js";
export default {
  props: {
    value: {
      default: "",
    },
    width: {
      type: Number,
      default: 400,
    },
    multiple: {
      default: false,
    },
  },
  data() {
    return {
      userList: [],
    };
  },
  methods: {
    getUser(value) {
      if (!parseInt(value)) {
        WhiteApi.LikeHsID(value).then((res) => {
          this.userList = res.Data;
        });
      }
    },
    updateVal(value) {
      this.$emit("input", value); //返回的是UnionId
    },
  },
};
</script>
<style lang="less" scoped>
</style>