<template>
    <div>
        <div class="demo-upload-list" v-for="(item,index) in uploadList" :key="index">
            <img :src="item" @click="handleChange" />
            <div class="demo-upload-list-cover" v-if="multiple">
                <Icon type="ios-eye-outline" @click.native="handleView(item)"></Icon>
                <Icon type="ios-trash-outline" @click.native="handleRemove(item)"></Icon>
            </div>
        </div>
        <Upload
            v-show="multiple || (!multiple && uploadList.length<1)"
            ref="upload"
            :show-upload-list="false"
            :format="format"
            :before-upload="handleBeforeUpload"
            :multiple="multiple"
            type="drag"
            action="#"
            style="display: inline-block;width:58px;"
        >
            <div style="width: 58px;height:58px;line-height: 58px;">
                <Icon type="ios-camera" size="20"></Icon>
            </div>
        </Upload>
        <Modal title="View Image" v-model="visible">
            <img :src="'https://o5wwk8baw.qnssl.com/' + imgName + '/large'" v-if="visible" style="width: 100%" />
        </Modal>
    </div>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
import { AssertVideo } from "@/libs/tools";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";
export default {
    model: {
        // 默认返回数据为数组
        prop: "uploadList",
        event: "uploadImage"
    },
    props: {
        uploadList: Array,
        format: {
            type: Array,
            default: function () {
                return ["jpg", "JPG", "jpeg", "JPEG", "png", "PNG", "gif", "GIF"];
            }
        }
    },
    data() {
        return {
            ImgUrl: "",
            imgName: "",
            visible: false,
            // uploadList: [],
            multiple: false
        };
    },
    methods: {
        //预览
        handleView(name) {
            this.imgName = name;
            this.visible = true;
        },
        //删除
        handleRemove(file) {
            const fileList = this.$refs.upload.fileList;
            this.$refs.upload.fileList.splice(fileList.indexOf(file), 1);
        },
        handleFormatError(name) {
            this.$Notice.warning({
                title: "图片格式错误",
                desc: file.name + " 格式错误"
            });
        },
        // handleMaxSize (file) {
        //     this.$Notice.warning({
        //         title: 'Exceeding file size limit',
        //         desc: 'File  ' + file.name + ' is too large, no more than 2M.'
        //     });
        // },
        handleChange() {
            if (!this.multiple) {
                this.$refs["upload"].$refs["input"].click();
            }
        },
        handleBeforeUpload(file) {
            const t = AssertVideo(file.name);
            if (t != "img") {
                this.handleFormatError(file);
                this.$refs.uploadicon.clearFiles();
                return false;
            }
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            //   let key = "pkg" + "/" + this.insideformScope.PkgName + "/" + file.name;
            let key = "game" + "/" + new Date().getTime();
            // let key = 'game'+ '/' + new Date().getTime() + '-' + file.name
            let that = this;
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        that.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        // console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        that.$Message.warning(err);
                        return;
                    }
                    //   console.log(data);
                    that.ImgUrl = cosconfig.exporturl + "/" + key;
                    if (!that.multiple) {
                        let uploadList = [that.ImgUrl];
                        that.$emit("uploadImage", uploadList);
                    } else {
                        let uploadList = that.uploadList;
                        uploadList.push(that.ImgUrl);
                        that.$emit("uploadImage", uploadList);
                    }
                }
            );
            return false;
        }
    }
};
</script>
<style>
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
}
.demo-upload-list img {
    width: 100%;
    height: 100%;
}
.demo-upload-list-cover {
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.6);
}
.demo-upload-list:hover .demo-upload-list-cover {
    display: block;
}
.demo-upload-list-cover i {
    color: #fff;
    font-size: 20px;
    cursor: pointer;
    margin: 0 2px;
}
</style>
