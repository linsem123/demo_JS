<template>
  <Card>
    <Form :model="searchData" :inline="true" style="position: relative">
      <FormItem prop="AppId">
        <gameNameSelect
          v-model="searchData.AppId"
          :width="200"
          :multiple="false"
        />
      </FormItem>
      <Button type="primary" @click="toSearch" style="margin-right: 50px"
        >查询</Button
      >
    </Form>
    <Table
      border
      highlight-row
      :columns="columns"
      :data="tableData"
      :loading="loading"
      :draggable="searchData.Page == 1 && tableData.length > 1"
      @on-drag-drop="dragDrop"
    >
      <template slot-scope="{ row }" slot="Status">
        {{
          (statusList.find((v) => v.Id == row.Status) &&
            statusList.find((v) => v.Id == row.Status).Name) ||
          ""
        }}
      </template>
      <template slot-scope="{ row }" slot="IsShowForum">
        {{ row.IsShowForum ? "否" : "是" }}
      </template>

      <template slot-scope="{ row }" slot="CreatedAt">
        {{ row.CreatedAt | fomatTime }}
      </template>
      <template slot-scope="{ row }" slot="action">
        <Button
          type="primary"
          size="small"
          @click="handleUpdate(row.Id)"
          style="margin-right: 5px"
          >置顶</Button
        >
        <Button
          type="success"
          size="small"
          style="margin-right: 5px"
          @click="handleModify(row)"
          >编辑</Button
        >
        <Button type="error" size="small" @click="handleDel(row)">删除</Button>
      </template>
    </Table>
    <Row style="margin-top: 10px">
      <Col span="8">
        <Button type="primary" @click="handleModify()">新增</Button>
      </Col>
      <Col span="16">
        <Page
          show-sizer
          :total="total"
          show-total
          :page-size="searchData.Limit"
          :current="searchData.Page"
          @on-change="changePage"
          @on-page-size-change="changePageSize"
          style="float: right"
        />
      </Col>
    </Row>
    <Modal v-model="showModal" title="新增">
      <Form
        :model="formData"
        :rules="ruleValidate"
        ref="formValidate"
        :label-width="100"
      >
        <FormItem label="绑定游戏：" prop="PkgName" v-if="isAdd">
          <AppSelect
            v-model="formData.AppId"
            @on-change="handleChange"
            clearable
          />
          包名：{{ formData.PkgName }}
        </FormItem>
        <FormItem label="绑定游戏：" v-if="!isAdd">
          {{ formData.AppName }}
        </FormItem>
        <FormItem label="上传封面图：" prop="Url">
          <span style="color: red">(图片尺寸：304*438)</span>
          <Upload v-model="formData.Url" />
        </FormItem>
      </Form>
      <template slot="footer">
        <Button @click="showModal = false">取消</Button>
        <Button @click="handleSubmit" type="primary">确定</Button>
      </template>
    </Modal>
  </Card>
</template>
<script>
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect";
import AppSelect from "_c/app-select";
import Upload from "_c/shark-upload";
import coverApi from "@/api/gameCircle/coverManage";
import common from "@/view/gameCircle/pubFunc/common";
export default {
  name: "CoverManage",
  data() {
    return {
      loading: false,
      searchData: {
        Page: 1,
        Limit: 10,
        AppId: undefined,
      },
      columns: [
        {
          title: "游戏名称",
          key: "AppName",
          align: "center",
        },
        {
          title: "游戏状态",
          align: "center",
          slot: "Status",
        },
        {
          title: "当前是否已开启子论坛",
          slot: "IsShowForum",
          align: "center",
        },
        {
          title: "封面创建日期",
          slot: "CreatedAt",
          align: "center",
        },
        {
          title: "操作",
          align: "center",
          slot: "action",
          minWidth: 100,
        },
      ],
      tableData: [],
      total: 0,
      formData: {
        AppId: undefined,
        PkgName: "",
        Url: "",
      },
      ruleValidate: {
        PkgName: [{ required: true, message: "请绑定游戏", trigger: "change" }],
        Url: [{ required: true, message: "请上传封面图", trigger: "change" }],
      },
      statusList: [
        {
          Id: 0,
          Name: "待处理",
        },
        {
          Id: 1,
          Name: "上架",
        },
        {
          Id: 2,
          Name: "下架",
        },
        {
          Id: 3,
          Name: "预约",
        },
      ],
      showModal: false,
      isAdd: true,
    };
  },
  components: {
    gameNameSelect,
    AppSelect,
    Upload,
  },
  mounted() {
    this.searchServer();
  },
  filters: {
    fomatTime(value) {
      return common.formatDate(value, true);
    },
  },
  methods: {
    //删除
    handleDel(row) {
      if (!row.IsShowForum) {
        this.$Modal.warning({
          title: "提示",
          content: "当前游戏已开启子论坛，无法删除封面图",
        });
        return;
      }
      coverApi.Delete(row.Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("删除成功");
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    handleChange({ value }) {
      if (value) {
        this.formData.AppId = value.value;
        this.formData.PkgName = value.PkgName;
      } else {
        this.formData.AppId = undefined;
        this.formData.PkgName = "";
      }
    },
    //新增/编辑
    handleModify(row) {
      this.showModal = true;
      if (row) {
        this.isAdd = false;
        this.formData = row;
      } else {
        this.isAdd = true;
        this.formData = {
          AppId: undefined,
          PkgName: "",
          Url: "",
        };
      }
    },
    //置顶
    handleUpdate(Id) {
      coverApi.Top(Id).then((res) => {
        if (res.Code == 0) {
          this.searchServer();
          this.$Message.success("置顶成功");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //拖拽排序
    dragDrop(idx1, idx2) {
      let item1 = this.tableData.splice(idx1, 1);
      this.tableData.splice(idx2, 0, item1[0]);
      let Ids = this.tableData.map((v) => v.Id).reverse();

      //调用接口
      coverApi.Sort({ Ids }).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("排序成功");
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //保存
    handleSubmit() {
      this.$refs.formValidate.validate((valid) => {
        if (valid) {
          if (this.isAdd) {
            coverApi.Add(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("保存成功");
                this.searchServer();
                this.showModal = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          } else {
            coverApi.Edit(this.formData).then((res) => {
              if (res.Code == 0) {
                this.$Message.success("保存成功");
                this.searchServer();
                this.showModal = false;
              } else {
                this.$Message.error(res.Message);
              }
            });
          }
        }
      });
    },
    //改页数
    changePage(page) {
      this.searchData.Page = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.searchData.Limit = pageSize;
      this.searchData.Page = 1;
      this.searchServer();
    },
    //查询
    toSearch() {
      this.searchData.Page = 1;
      this.searchServer();
    },
    searchServer() {
      this.loading = true;
      coverApi
        .getList(this.searchData)
        .then((res) => {
          if (res.Code == 0) {
            //数据处理
            this.tableData = res.Data.Data || [];
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
</style>