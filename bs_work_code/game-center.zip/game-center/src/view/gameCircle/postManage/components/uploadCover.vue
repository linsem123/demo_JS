<template>
    <div>
        <Form ref="formValidate" :model="formData" :rules="ruleValidate" :label-width="80">
            <FormItem label="封面图片" prop="uploadList">
                <uploadImg v-model="formData.uploadList" />
            </FormItem>
            <FormItem label="过期时间" prop="ExpiredEnd">
                <DatePicker v-model="formData.ExpiredEnd" type="date" placeholder="选择日期" style="width: 200px" :options="options"></DatePicker>
            </FormItem>
        </Form>
        <div style="margin-top:30px;margin-bottom:10px;display:flex;justify-content:center">
            <Button style="margin-right:40px" @click="cancel">取消</Button>
            <Button type="primary" @click="toCreate">确认</Button>
        </div>
    </div>
</template>
<script>
import Post from "@/api/gameCircle/postManagement";
// import uploadImg from '@/view/gameCircle/components/uploadImg'
import uploadImg from "_c/shark-upload";
export default {
    props: {
        checkedTable: Object
    },
    components: {
        uploadImg
    },
    data() {
        return {
            formData: {
                uploadList: "",
                ExpiredEnd: ""
            },
            ruleValidate: {
                uploadList: [{ required: true, message: "请上传封面图片", trigger: "change" }],
                ExpiredEnd: [{ required: true, message: "请上选择过期时间", trigger: "change", type: "date" }]
            },
            options: {
                disabledDate(date) {
                    return date && date.valueOf() < Date.now();
                }
            }
        };
    },
    methods: {
        cancel() {
            this.$emit("closeExtension");
            this.clear();
        },
        toCreate() {
            this.$refs["formValidate"].validate(valid => {
                if (valid) {
                    let ImgUrl = this.formData.uploadList,
                        ExpiredEnd = Math.round(new Date(this.formData.ExpiredEnd).getTime() / 1000),
                        PostId = this.checkedTable.Id,
                        Title = this.checkedTable.Title,
                        AppIds = this.checkedTable.AppId ? [this.checkedTable.AppId] : [];
                    Post.feedPost({ ImgUrl, ExpiredEnd, PostId, Title, AppIds }).then(res => {
                        if (res.Code == 0) {
                            this.$Message.success("投放成功");
                            this.clear();
                            this.$emit("closeExtension", true);
                        } else {
                            this.$Message.error(res.Message);
                        }
                    });
                }
            });
        },
        clear() {
            this.formData.uploadList = "";
            this.formData.ExpiredEnd = "";
        }
    }
};
</script>
