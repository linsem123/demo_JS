<template>
  <Card style="position: relative">
    <p slot="title"><Icon type="information-circled"></Icon>编辑帖</p>
    <div class="edit_box">
      <Form
        ref="formValidate"
        :model="formData"
        :label-width="100"
        :rules="ruleValidate"
      >
        <FormItem label="关联游戏">
          {{ formData.AppName }}
        </FormItem>
        <FormItem label="标题" prop="Title">
          <Input
            v-model="formData.Title"
            style="width: 400px"
            placeholder="请输入标题"
          />
        </FormItem>
        <FormItem label="标签" prop="TagId">
          <tagList
            :tagList="tagList"
            v-model="formData.TagId"
            :trigger="true"
          />
        </FormItem>
        <FormItem>
          <span style="padding-right: 20px">楼主：{{ formData.UserName }}</span>
          <span>发帖时间：{{ formData.CreatedAt }}</span>
        </FormItem>
        <FormItem label="是否定时发布" prop="IsCron">
          <Checkbox v-model="formData.IsCron"></Checkbox>
        </FormItem>
        <FormItem
          label="定时发布时间"
          prop="CronPubTime"
          v-if="formData.IsCron"
        >
          <DatePicker
            type="datetime"
            format="yyyy-MM-dd HH:mm:ss"
            :value="formData.CronPubTime"
            @on-change="(value) => (formData.CronPubTime = value)"
            :options="option"
          />
        </FormItem>
        <FormItem>
          <wangEditor
            @quoteUserEvent="quoteUserEvent"
            ref="editorPanel"
            filterPaste="allStyle"
          />
        </FormItem>
      </Form>
      <div class="button_group_flex">
        <Button type="primary" @click="doSubmit">发布</Button>
        <Button type="primary" @click="preview">预览</Button>
        <Button type="primary" @click="cancel">取消</Button>
      </div>
    </div>
    <Modal v-model="showModal" title="用户列表" @on-ok="ok">
      <user-list @selectUser="selectUser" />
    </Modal>
    <Modal v-model="showPreview" title="预览" footer-hide :width="400">
      <previewPage
        :htmlJson="htmlJson"
        :title="formData.Title"
        v-if="showPreview"
      />
    </Modal>
    <PageLoading v-show="loading" />
  </Card>
</template>
<script>
import htmJsonToApp from "@/view/gameCircle/pubFunc/htmJsonToApp.js";
import Post from "@/api/gameCircle/postManagement";
import wangEditor from "@/view/gameCircle/components/editor/wangEditor";
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect";
import tagList from "@/view/gameCircle/components/tagList";
import previewPage from "@/view/gameCircle/components/previewPage";
import userList from "@/view/gameCircle/components/userList";
import PageLoading from "@/view/gameCircle/components/PageLoading";
import common from "@/view/gameCircle/pubFunc/common";
export default {
  name: "gameCircle_editpost",
  data() {
    const timeRule = (rule, value, callback) => {
      if (new Date().getTime() > new Date(value).getTime()) {
        callback("定时发布时间不得早于当前时间");
      }
      callback();
    };
    return {
      loading: false,
      showModal: false,
      showPreview: false,
      htmlJson: [],
      tagList: [], //标签列表
      user: {},
      up: "",
      time: "",
      postId: "",
      formData: {
        UnionId: "", //绑定账号
        AppIds: "", //关联游戏
        AppName: "",
        Title: "",
        Tags: "", //标签
        Content: "",
        UnionId: "",
        AtUnionIds: [], //@用户李斯特
        TagId: "",
        CreatedAt: "",
        UserName: "",
        IsCron: false,
        CronPubTime: "",
      },
      ruleValidate: {
        Title: [{ required: true, message: "请输入标题", trigger: "change" }],
        CronPubTime: [
          { required: true, message: "请选择定时发布时间", trigger: "change" },
          { validator: timeRule, trigger: "change" },
        ],
      },
      option: {
        disabledDate(date) {
          return date && date.valueOf() < Date.now() - 24 * 60 * 60 * 1000;
        },
      },
    };
  },
  components: {
    wangEditor,
    gameNameSelect,
    tagList,
    previewPage,
    userList,
    PageLoading,
  },
  async mounted() {
    this.postId = this.$route.params.id;
    this.loading = true;
    await Post.getTagList({}).then((res) => {
      this.tagList = res.Data;
    });
    Post.postDetails(this.postId)
      .then((res) => {
        if (res.Code == 0) {
          this.formData = { ...res.Data };
          // this.formData.TagId = this.formData.Tags.map(v=>v.Id)
          this.formData.TagId =
            this.formData.Tags && this.formData.Tags.length > 0
              ? this.formData.Tags[0].Id
              : "";
          this.formData.IsCron = this.formData.IsCron == 1 ? true : false;
          this.formData.CreatedAt = common.formatDate(
            this.formData.CreatedAt,
            true
          );
          this.formData = Object.assign({}, this.formData);
          this.formData.AtUnionIds = this.formData.AtUnionIds || [];
          let content = this.formData.Content
            ? JSON.parse(this.formData.Content)
            : [];
          this.$refs.editorPanel.setEditorData(content);
        } else {
          this.$Message.error(res.Message);
        }
      })
      .finally(() => {
        this.loading = false;
      });
  },
  filters: {
    AppIdsStr(value) {
      return value.join(",");
    },
  },
  methods: {
    quoteUserEvent() {
      this.showModal = true;
    },
    //选择@用户
    ok() {
      this.$refs.editorPanel.setQuoteUser(this.user);
    },
    selectUser(data) {
      this.user = data;
    },
    doSubmit() {
      this.$refs["formValidate"].validate((valid) => {
        if (valid) {
          this.$Modal.confirm({
            title: "提示",
            okText: "确认发布",
            cancelText: "取消",
            loading: true,
            content: "<p>请检查并确认排版是否无误。</p>",
            onOk: () => {
              this.publish();
            },
            onCancel: () => {
              this.$Modal.remove();
            },
          });
        }
      });
    },
    //发布
    publish() {
      this.loading = true;
      let jsonData = this.$refs["editorPanel"].getEditoJsonData();
      let Content = htmJsonToApp.getEditorData(jsonData);
      console.log(Content);
      let AtunionIds = htmJsonToApp.getAtunionIds();
      let ImgUrls = htmJsonToApp.getImgUrls();
      let VideoUrls = htmJsonToApp.getVideoUrls();
      let Tags = this.tagList.filter((v) => {
        delete v.CreatedAt;
        return this.formData.TagId == v.Id;
      });
      let NewAtUnionIds = AtunionIds.filter(
        (v) => !this.formData.AtUnionIds.includes(v)
      );
      let data = {
        UnionId: this.formData.UnionId,
        AppIds: this.formData.AppIds,
        AtUnionIds: AtunionIds,
        ImgUrls: ImgUrls,
        VideoUrls: VideoUrls,
        Title: this.formData.Title,
        Content: JSON.stringify(Content),
        Tags,
        NewAtUnionIds,
        CronPubTime: this.formData.CronPubTime,
        IsCron: this.formData.IsCron ? 1 : 2,
      };
      Post.editPost(this.$route.params.id, data)
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success("发布成功");
            this.$Modal.remove();
            this.$router.push({ name: "postManage" });
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    //预览
    preview() {
      this.htmlJson = this.$refs["editorPanel"].getEditoJsonData();
      this.showPreview = true;
    },
    //取消
    cancel() {
      this.$router.push({ name: "postManage" });
    },
  },
};
</script>
<style lang="less" scoped>
.edit_box {
  padding: 20px;
}
.button_group_flex {
  display: flex;
  justify-content: center;
}
/deep/ .ivu-btn {
  margin: 0 10px;
}
</style>

