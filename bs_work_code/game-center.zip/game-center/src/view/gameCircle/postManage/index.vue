<template>
  <div>
    <Card>
      <Form
        ref="formValidate"
        :model="formData"
        :rules="ruleValidate"
        :inline="true"
        style="position: relative"
      >
        <FormItem prop="PostId">
          <gameTitleSelect v-model="formData.PostId" :width="200" />
        </FormItem>
        <FormItem prop="AppId">
          <gameNameSelect
            v-model="formData.AppId"
            :width="200"
            :multiple="false"
          />
        </FormItem>
        <FormItem prop="UnionId">
          <gameUserSelect v-model="formData.UnionId" :width="200" />
        </FormItem>
        <FormItem prop="Time">
          <DatePicker
            v-model="formData.Time"
            type="daterange"
            :options="options"
            placeholder="选择日期"
            style="width: 200px"
            @on-change="changeDate"
          ></DatePicker>
        </FormItem>
        <FormItem label="帖子状态" prop="Status" :label-width="65">
          <Selection v-model="formData.Status" :dataList="statusList" />
        </FormItem>
        <FormItem label="是否置顶" prop="IsTop" :label-width="65">
          <Checkbox v-model="formData.IsTop" />
        </FormItem>
        <FormItem label="帖子类型" :label-width="65">
          <Selection v-model="formData.ForumType" :dataList="contentTypeList" />
        </FormItem>
        <FormItem label="发布来源" :label-width="65">
          <Selection v-model="formData.ForumFrom" :dataList="publishOrign" />
        </FormItem>
        <Button type="primary" @click="toSearch" style="margin-right: 50px"
          >查询</Button
        >

        <div style="float: right">
            <Button
            type="primary"
            @click="toCreate(1)"
            style="margin-right: 5px"
            >发视频帖</Button
            >
            <Button
            type="primary"
            @click="toCreate(0)"
            >发图文帖</Button
            >
        </div>
      </Form>
      <Table
        border
        highlight-row
        ref="currentRowTable"
        :columns="columns"
        :data="tableData"
        :loading="loading"
        :height="550"
      >
        <template slot-scope="{ row, index }" slot="ForumType">
          {{ getNamebyId("contentTypeList", row.ForumType) }}
        </template>
        <template slot-scope="{ row, index }" slot="ForumFrom">
          {{ getNamebyId("publishOrign", row.ForumFrom) }}
        </template>
        <template slot-scope="{ row, index }" slot="SheildSwitch">
          <i-switch
            size="large"
            v-model="row.IsShowComment"
            @on-change="(status) => handleSheild(status, row.Id, index)"
          >
            <span slot="open">开启</span>
            <span slot="close">关闭</span>
          </i-switch>
        </template>
        <template slot-scope="{ row, index }" slot="ProhibitSwitch">
          <i-switch
            size="large"
            v-model="row.IsAllowComment"
            @on-change="(status) => handleProhibit(status, row.Id, index)"
          >
            <span slot="open">开启</span>
            <span slot="close">关闭</span>
          </i-switch>
        </template>
        <template slot-scope="{ row, index }" slot="Status">
          <span>{{ row.statusText }}</span>
          <Button
            type="primary"
            v-if="row.Status == 1 || row.Status == 2"
            size="small"
            style="margin-left: 10px"
            @click="statusChange(index)"
            :loading="statusLoading"
            >{{ row.Status | btnText }}</Button
          >
        </template>
        <template slot-scope="{ row, index }" slot="video">
          <div
            class="play-btn"
            @click="handlePlay(row)"
            v-if="row.ForumType == 2"
          >
            <Icon
              type="ios-play"
              color="#fff"
              size="30"
              style="margin-left: 5px"
            />
          </div>
          <!-- <video
            :src="row.Abstract"
            style="width: 100px"
            v-if="row.Abstract"
          ></video> -->
        </template>

        <template slot-scope="{ row, index }" slot="menu">
          <Button
            type="primary"
            size="small"
            style="margin-right: 5px"
            @click="details(index)"
            >详情</Button
          >
          <Button
            type="primary"
            size="small"
            style="margin-right: 5px"
            @click="discuss(index)"
            >评论</Button
          >
          <Dropdown
            :trigger="row.ForumFrom == 4 ? 'custom' : 'hover'"
            :placement="index > 4 ? 'top' : 'bottom'"
            :visible="false"
          >
            <Button type="primary" size="small" :disabled="row.ForumFrom == 4">
              操作菜单
              <Icon type="ios-arrow-down"></Icon>
            </Button>
            <DropdownMenu slot="list">
              <DropdownItem>
                <Button
                  type="primary"
                  size="small"
                  style="margin-right: 5px"
                  @click="editPost(index)"
                  >编辑</Button
                ></DropdownItem
              >
              <DropdownItem
                ><Button
                  type="primary"
                  size="small"
                  style="margin-right: 5px"
                  @click="unOverhead(row)"
                  v-if="row.Sort > 0"
                  >取消置顶</Button
                >
                <Button
                  type="success"
                  size="small"
                  style="margin-right: 5px"
                  @click="overhead(index)"
                  v-else
                  >置顶</Button
                ></DropdownItem
              >
              <DropdownItem>
                <Button
                  type="error"
                  size="small"
                  style="margin-right: 5px"
                  @click="Forbidden(row)"
                  >禁言</Button
                ></DropdownItem
              >
              <DropdownItem>
                <Button
                  type="primary"
                  size="small"
                  style="margin-right: 5px"
                  @click="cancelOverheadChild(index)"
                  v-if="row.SubSort > 0"
                  >取消子论坛置顶</Button
                >
                <Button
                  type="success"
                  size="small"
                  style="margin-right: 5px"
                  @click="overheadChild(index)"
                  v-else
                  >子论坛置顶</Button
                >
              </DropdownItem>
              <DropdownItem>
                <Button type="success" size="small" @click="extension(row)"
                  >投放</Button
                >
              </DropdownItem>
              <DropdownItem>
                <Button type="primary" size="small" @click="addPostType(row)"
                  >添加分类</Button
                >
              </DropdownItem>
              <DropdownItem>
                <Button
                  type="primary"
                  size="small"
                  @click="addRecommend(row.Id)"
                  :disabled="row.Status == 2"
                  >推荐</Button
                >
              </DropdownItem>
            </DropdownMenu>
          </Dropdown>
        </template>
      </Table>
      <Page
        show-sizer
        :total="total"
        show-total
        :page-size="pageSize"
        :current="pageIndex"
        @on-change="changePage"
        @on-page-size-change="changePageSize"
      />
    </Card>
    <Modal v-model="showDiscuss" title="评论" :width="700" footer-hide>
      <discussPage
        :checkedTable="checkedTable"
        @closeDiscuss="showDiscuss = false"
      />
    </Modal>
    <Modal v-model="showDetail" title="查看" :width="700" footer-hide>
      <detailPage v-if="showDetail" :checkedTable="checkedTable" />
    </Modal>
    <Modal
      v-model="showForbidden"
      title="禁言设置"
      :width="700"
      footer-hide
      :closable="false"
    >
      <setForbidden
        :checkedTable="checkedTable"
        @closeForbidden="showForbidden = false"
        :idModify="false"
      />
    </Modal>
    <Modal
      v-model="showExtension"
      title="上传封面"
      :width="400"
      footer-hide
      :closable="false"
    >
      <uploadCover
        :checkedTable="checkedTable"
        @closeExtension="closeExtension"
      />
    </Modal>
    <Modal v-model="showPostType" title="分类标签" :closable="false">
      <tagList
        :tagList="postTypeList"
        v-model="postType"
        :trigger="true"
        :multiple="true"
      />
      <template slot="footer">
        <Button @click="cancelPostType">取消</Button>
        <Button type="primary" @click="commitPostType">确定</Button>
      </template>
    </Modal>
    <wangEditor v-show="false" ref="editorPanel" />
  </div>
</template>
<script>
import Post from "@/api/gameCircle/postManagement";
import Tags from "@/api/gameCircle/tagsManage";
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect";
import gameUserSelect from "@/view/gameCircle/components/gameUserSelect";
import gameTitleSelect from "@/view/gameCircle/components/gameTitleSelect";
import discussPage from "@/view/gameCircle/components/discussPage";
import Selection from "_c/Selection.vue";
import detailPage from "@/view/gameCircle/components/detailPage";
import wangEditor from "@/view/gameCircle/components/editor/wangEditor";
import setForbidden from "@/view/gameCircle/components/setForbidden";
import uploadCover from "./components/uploadCover";
import tagList from "@/view/gameCircle/components/tagList";
import common from "@/view/gameCircle/pubFunc/common";
import recommendApi from "@/api/gameCircle/recommendPost";
export default {
  name: "postManage",
  data() {
    return {
      loading: false,
      statusLoading: false,
      showDiscuss: false,
      showDetail: false,
      showForbidden: false,
      showExtension: false,
      showPostType: false,
      formData: {
        Time: "",
        PostId: undefined,
        UnionId: undefined,
        AppId: undefined,
        status: undefined,
        StartAt: undefined,
        EndAt: undefined,
        IsTop: false,
        ForumType: undefined,
        ForumFrom: undefined,
      },
      ruleValidate: {},
      options: {
        disabledDate(date) {
          return date && date.valueOf() > Date.now();
        },
      },
      columns: [
        {
          title: "ID",
          key: "Id",
          align: "center",
          minWidth: 100,
        },
        {
          title: "标题",
          key: "Title",
          align: "center",
          minWidth: 200,
        },
        {
          title: "用户",
          key: "UserName",
          minWidth: 100,
          align: "center",
        },
        {
          title: "IMEI",
          key: "IMEI",
          minWidth: 150,
          align: "center",
        },
        {
          title: "发帖时间",
          key: "creatTime",
          align: "center",
          minWidth: 150,
        },
        {
          title: "浏览量",
          key: "ViewCount",
          align: "center",
          minWidth: 100,
        },
        {
          title: "点赞数",
          key: "LikeCount",
          align: "center",
          minWidth: 100,
        },
        {
          title: "评论数",
          key: "CommentCount",
          align: "center",
          minWidth: 100,
        },
        {
          title: "视频时长(s)",
          key: "VideoTimeLength",
          align: "center",
          minWidth: 100,
        },
        {
          title: "击杀次数",
          key: "KillCount",
          align: "center",
          minWidth: 100,
        },
        {
          title: "帖子类型",
          slot: "ForumType",
          align: "center",
          minWidth: 100,
        },
        {
          title: "发布来源",
          slot: "ForumFrom",
          align: "center",
          minWidth: 100,
        },
        {
          title: "关联游戏",
          key: "GameNamesStr",
          align: "center",
          minWidth: 200,
        },
        {
          title: "屏蔽评论",
          slot: "SheildSwitch",
          align: "center",
          minWidth: 120,
        },
        {
          title: "禁止评论",
          slot: "ProhibitSwitch",
          align: "center",
          minWidth: 120,
        },
        {
          title: "状态",
          slot: "Status",
          align: "center",
          minWidth: 120,
        },
        {
          title: "查看视频",
          slot: "video",
          align: "center",
          minWidth: 90,
        },
        {
          title: "操作",
          slot: "menu",
          align: "center",
          fixed: "right",
          minWidth: 240,
        },
      ],
      tableData: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      statusList: [
        {
          Id: 1,
          Name: "展示",
        },
        {
          Id: 2,
          Name: "隐藏",
        },
        {
          Id: 3,
          Name: "删除",
        },
      ],
      checkedTable: {},
      postTypeList: [],
      postType: [],
      contentTypeList: [
        {
          Id: 1,
          Name: "图文帖",
        },
        {
          Id: 2,
          Name: "视频帖",
        }, 
      ], //帖子类型
      publishOrign: [
        {
          Id: 1,
          Name: "用户发布",
        },
        {
          Id: 2,
          Name: "运营后台",
        },
        {
          Id: 3,
          Name: "开放平台",
        },
        {
          Id: 4,
          Name: "黑鲨时刻",
        },
      ], // 发布来源
    };
  },
  components: {
    gameNameSelect,
    gameUserSelect,
    gameTitleSelect,
    Selection,
    discussPage,
    detailPage,
    setForbidden,
    wangEditor,
    uploadCover,
    tagList,
  },
  filters: {
    btnText(Status) {
      //状态显示-按钮为隐藏
      //状态隐藏-按钮为显示
      //状态删除 -不展示按钮
      if (Status == 1) return "隐藏";
      if (Status == 2) return "显示";
      return "";
    },
  },
  mounted() {
    this.searchServer();
    Tags.getPostType({}).then((res) => {
      if (res.Code == 0) {
        let list = res.Data || [];
        list.forEach((v) => {
          v.Name = v.Title;
          this.postTypeList.push(v);
        });
      }
    });
  },
  methods: {
    //通过ID返回name
    getNamebyId(listName, id) {
      let find = this.$data[listName].find((v) => v.Id == id);
      return find ? find.Name : "";
    },
    //推荐帖子
    addRecommend(Id) {
      recommendApi.Add(Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("推荐成功!");
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //状态
    statusChange(index) {
      this.statusLoading = true;
      let Status;
      if (this.tableData[index].Status == 1) {
        Status = 2;
      }
      if (this.tableData[index].Status == 2) {
        Status = 1;
      }
      Post.postStatus({
        Ids: [this.tableData[index].Id],
        Status: Status,
      })
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success("更改状态成功");
            this.searchServer();
          } else {
            this.$$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.statusLoading = false;
        });
    },
    //屏蔽评论
    handleSheild(status, Id, index) {
      let statusNum = status ? "1" : "0";
      Post.ShowComment(Id, statusNum)
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success(`${status ? "开启" : "关闭"}屏蔽评论成功`);
          } else {
            this.$Message.error(res.Message);
            this.tableData[index].Sheild = !status;
          }
        })
        .catch();
    },
    //禁止评论
    handleProhibit(status, Id, index) {
      let statusNum = status ? "1" : "0";
      Post.AllowComment(Id, statusNum)
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success(`${status ? "开启" : "关闭"}禁止评论成功`);
          } else {
            this.$Message.error(res.Message);
            this.tableData[index].Prohibit = !status;
          }
        })
        .catch();
    },
    //编辑
    editPost(index) {
      let Id = this.tableData[index].Id;
      this.$router.push({ name: "gameCircle_editpost", params: { id: Id } });
    },
    //详情
    details(index) {
      let postId = this.tableData[index].Id;
      Post.postDetails(postId).then((res) => {
        if (res.Code == 0) {
          let content = JSON.parse(res.Data.Content);
          this.$refs.editorPanel.setEditorData(content);
          res.Data.Content = this.$refs.editorPanel.getEditorHTMLData();
          this.$refs.editorPanel.clearEditor();
          this.checkedTable = Object.assign({}, res.Data);
          this.showDetail = true;
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //评论
    discuss(index) {
      this.checkedTable = this.tableData[index];
      this.showDiscuss = true;
    },
    //禁言
    Forbidden(row) {
      this.checkedTable = row;
      this.showForbidden = true;
    },
    //选择日期
    changeDate(value) {
      this.formData.StartAt = value[0];
      this.formData.EndAt = value[1];
    },
    //顶置
    overhead(index) {
      let Id = this.tableData[index].Id;
      Post.overheadPost(Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("置顶成功");
          this.pageIndex = 1;
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //取消置顶
    unOverhead(row) {
      Post.unOverheadPost(row.Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("取消置顶成功");
          this.pageIndex = 1;
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //顶置子论坛
    overheadChild(index) {
      let Id = this.tableData[index].Id;
      let appId = this.tableData[index].AppId;
      Post.overheadPostChild(Id, appId).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("子论坛顶置成功");
          this.pageIndex = 1;
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //取消子论坛置顶
    cancelOverheadChild(index) {
      let Id = this.tableData[index].Id;
      let appId = this.tableData[index].AppId;
      Post.cancelOverheadChild(Id, appId).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("取消子论坛顶置成功");
          this.pageIndex = 1;
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //推广
    extension(row) {
      this.checkedTable = row;
      this.showExtension = true;
    },
    //添加帖子分类
    addPostType(row) {
      Post.getPostType(row.Id).then((res) => {
        if (res.Code == 0) {
          let list = res.Data || [];
          this.postType = list.map((v) => {
            return v.Id;
          });
        }
      });
      this.checkedTable = row;
      this.showPostType = true;
    },
    cancelPostType() {
      this.showPostType = false;
    },
    commitPostType() {
      Post.setPostType(this.checkedTable.Id, { Ids: this.postType })
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success("帖子添加分类成功");
          }
        })
        .finally(() => {
          this.showPostType = false;
        });
    },
    closeExtension(value) {
      this.showExtension = false;
    },
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.searchServer();
    },
    //发帖
    toCreate(type) {
      this.$router.push({ 
        name: "gameCircle_createpost",
        query: { ForumType: type }
    });
    },
    //查询
    toSearch() {
      this.pageIndex = 1;
      this.searchServer();
    },
    searchServer() {
      let StartAt = this.formData.StartAt
        ? common.toDate(this.formData.StartAt)
        : undefined;
      let EndAt = this.formData.EndAt
        ? common.toDate(this.formData.EndAt)
        : undefined;
      let {
        PostId,
        UnionId,
        AppId,
        Status,
        IsTop,
        ForumType,
        ForumFrom,
        Page,
        Limit,
      } = {
        ...this.formData,
        Page: this.pageIndex,
        Limit: this.pageSize,
      };
      this.loading = true;
      Post.getPostList({
        PostId,
        UnionId,
        AppId,
        Status,
        IsTop,
        StartAt,
        EndAt,
        ForumType,
        ForumFrom,
        Page,
        Limit,
      })
        .then((res) => {
          if (res.Code == 0) {
            //数据处理
            this.tableData = res.Data.Data.map((v) => {
              v.statusText = this.statusList.filter(
                (item) => item.Id == v.Status
              )[0].Name;
              v.GameNamesStr = v.GameNames.join(",");
              v.creatTime = common.formatDate(v.CreatedAt, true);
              return v;
            });
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    handlePlay(row) {
      let data = JSON.parse(row.Abstract)[0];
      this.$Modal.info({
        render: (h) => {
          return h("div", [
            h("h3", { attrs: { style: "margin-bottom:10px" } }, "视频预览"),
            h(
              "video",
              {
                attrs: {
                  controls: "controls",
                  poster: data.imagePath,
                  style: "width:100%",
                },
              },
              [
                h("source", {
                  attrs: {
                    src: data.videoPath,
                  },
                }),
              ]
            ),
          ]);
        },
      });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
.play-btn {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #2d8cf0;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>