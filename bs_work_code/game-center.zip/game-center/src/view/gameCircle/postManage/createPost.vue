<template>
    <Card>
        <p slot="title">
            <Icon type="information-circled"></Icon>
            {{ formData.ForumType == 1 ? '发视频帖' : '发图文帖' }}
        </p>
        <div class="edit_box">
            <Form ref="formValidate" :model="formData" :label-width="100" :rules="ruleValidate">
                <FormItem label="绑定账号" prop="UnionId">
                    <Select v-model="formData.UnionId" filterable remote clearable placeholder="请输入帐号"
                        :remote-method="getAccountList" style="width: 400px">
                        <Option v-for="item in accountList" :value="item.UnionId" :key="item.UnionId">{{ item.NickName }}</Option>
                    </Select>
                </FormItem>
                <FormItem label="关联游戏">
                    <gameNameSelect v-model="formData.GameIDs" :multiple="false" @input="selectAction" />
                </FormItem>
                <FormItem label="app包名">
                    {{pkgName}}
                </FormItem>
                <FormItem label="标题" prop="title">
                    <Input v-model="formData.title" style="width: 400px" placeholder="请输入标题" />
                </FormItem>
                <FormItem label="标签" prop="tagId">
                    <tagList :tagList="tagList" v-model="formData.tagId" :trigger="true" />
                </FormItem>
                <FormItem label="是否定时发布" prop="IsCron">
                    <Checkbox v-model="formData.IsCron"></Checkbox>
                </FormItem>
                <FormItem label="定时发布时间" prop="CronPubTime" v-if="formData.IsCron">
                    <DatePicker type="datetime" format="yyyy-MM-dd HH:mm:ss" :value="formData.CronPubTime"
                        @on-change="(value) => (formData.CronPubTime = value)" :options="option" />
                </FormItem>

                <div v-if="formData.ForumType == 1" style="margin-left: 100px; color: red">( 视频帖仅支持添加一个视频 )</div>

                <FormItem>
                    <wangEditor @quoteUserEvent="quoteUserEvent" ref="editorPanel" filterPaste="allStyle" />
                </FormItem>
            </Form>
            <div class="button_group_flex">
                <Button type="primary" @click="doSubmit" @loading="publishLoading">发布</Button>
                <Button type="primary" @click="preview">预览</Button>
                <Button type="primary" @click="cancel">取消</Button>
            </div>
        </div>
        <Modal v-model="showModal" title="用户列表" @on-ok="ok">
            <user-list @selectUser="selectUser" />
        </Modal>
        <Modal v-model="showPreview" title="预览" footer-hide :width="400">
            <previewPage :htmlJson="htmlJson" :title="formData.title" v-if="showPreview" />
        </Modal>
    </Card>
</template>
<script>
    import htmJsonToApp from "@/view/gameCircle/pubFunc/htmJsonToApp.js";
    import Post from "@/api/gameCircle/postManagement";
    import wangEditor from "@/view/gameCircle/components/editor/wangEditor";
    import gameNameSelect from "@/view/gameCircle/components/gameNameSelect";
    import tagList from "@/view/gameCircle/components/tagList";
    import previewPage from "@/view/gameCircle/components/previewPage";
    import userList from "@/view/gameCircle/components/userList";
    export default {
        name: "gameCircle_createpost",
        data() {
            const timeRule = (rule, value, callback) => {
                if (new Date().getTime() > new Date(value).getTime()) {
                    callback("定时发布时间不得早于当前时间");
                }
                callback();
            };
            return {
                pkgName: '',
                showModal: false,
                showPreview: false,
                publishLoading: false,
                htmlJson: [],
                accountList: [], //绑定账号列表
                tagList: [], //标签列表
                user: {},
                formData: {
                    ForumType: this.$route.query.ForumType || 0,  // 4.11迭代新增 0 图文帖，1 视频帖
                    UnionId: "", //绑定账号
                    GameIDs: "", //关联游戏
                    title: "",
                    tagId: "", //标签
                    CronPubTime: "",
                    IsCron: false,
                },
                ruleValidate: {
                    UnionId: [
                        { required: true, message: "请选择关联账号", trigger: "change" },
                    ],
                    title: [{ required: true, message: "请输入标题", trigger: "change" }],
                    CronPubTime: [
                        { required: true, message: "请选择定时发布时间", trigger: "change" },
                        { validator: timeRule, trigger: "change" },
                    ],
                },
                option: {
                    disabledDate(date) {
                        return date && date.valueOf() < Date.now() - 24 * 60 * 60 * 1000;
                    },
                },
            };
        },
        components: {
            wangEditor,
            gameNameSelect,
            tagList,
            previewPage,
            userList,
        },
        created() {
            Post.getTagList({}).then((res) => {
                this.tagList = res.Data;
            });
        },
        methods: {
            selectAction(value, obj) {
                if (obj) {
                    this.pkgName = obj.PkgName
                } else {
                    this.pkgName = ''
                }
            },
            quoteUserEvent() {
                this.showModal = true;
            },
            getAccountList(name) {
                Post.likeAccount(name).then((res) => {
                    if (res.Code == 0) {
                        this.accountList = res.Data || [];
                    }
                });
            },
            //选择@用户
            ok() {
                this.$refs.editorPanel.setQuoteUser(this.user);
            },
            selectUser(data) {
                this.user = data;
            },
            doSubmit() {
                this.$refs["formValidate"].validate((valid) => {
                    if (valid) {
                        // 4.11迭代添加
                        let jsonData = this.$refs["editorPanel"].getEditoJsonData();
                        let Content = htmJsonToApp.getEditorData(jsonData);
                        let VideoUrls = htmJsonToApp.getVideoUrls() || [];
                        // console.log(this.formData.ForumType, VideoUrls)
                        if (this.formData.ForumType == 1 && VideoUrls.length > 1) {
                            this.$Message.error("视频帖仅支持添加一个视频！");
                            return;
                        }

                        this.$Modal.confirm({
                            title: "提示",
                            okText: "确认发布",
                            cancelText: "取消",
                            loading: true,
                            content: "<p>请检查并确认排版是否无误。</p>",
                            onOk: () => {
                                this.publish();
                            },
                            onCancel: () => {
                                this.$Modal.remove();
                            },
                        });
                    }
                });
            },
            //发布
            publish() {
                let jsonData = this.$refs["editorPanel"].getEditoJsonData();
                let Content = htmJsonToApp.getEditorData(jsonData);
                console.log(Content);
                let AtunionIds = htmJsonToApp.getAtunionIds();
                let ImgUrls = htmJsonToApp.getImgUrls();
                let VideoUrls = htmJsonToApp.getVideoUrls();
                let Tags = this.tagList.filter((v) => {
                    return this.formData.tagId == v.Id;
                });

                let data = {
                    ForumType: JSON.parse(this.formData.ForumType),
                    UnionId: this.formData.UnionId,
                    AppIds: this.formData.GameIDs ? [this.formData.GameIDs] : [],
                    AtUnionIds: AtunionIds,
                    ImgUrls: ImgUrls,
                    VideoUrls: VideoUrls,
                    Title: this.formData.title,
                    Content: JSON.stringify(Content),
                    Tags,
                    CronPubTime: this.formData.CronPubTime,
                    IsCron: this.formData.IsCron ? 1 : 2,
                };
                Post.publish(data).then((res) => {
                    if (res.Code == 0) {
                        this.$Message.success("发布成功");
                        this.$Modal.remove();
                        this.$router.push({ name: "postManage" });
                    } else {
                        this.$Message.error(res.Message);
                    }
                });
                // .finally(() => {
                //   // this.publishLoading = false;
                // });
            },
            //预览
            preview() {
                this.htmlJson = this.$refs["editorPanel"].getEditoJsonData();
                this.showPreview = true;
            },
            //取消
            cancel() {
                this.$router.push({ name: "postManage" });
            },
        },
    };
</script>
<style lang="less" scoped>
    .edit_box {
        padding: 20px;
    }

    .button_group_flex {
        display: flex;
        justify-content: center;
    }

    /deep/ .ivu-btn {
        margin: 0 10px;
    }
</style>