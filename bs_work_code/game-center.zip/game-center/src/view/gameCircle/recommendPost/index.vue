<template>
  <Card>
    <Form :model="searchData" :inline="true" style="position: relative">
      <FormItem prop="AppId">
        <gameNameSelect
          v-model="searchData.AppId"
          :width="200"
          :multiple="false"
        />
      </FormItem>
      <Button type="primary" @click="toSearch" style="margin-right: 50px"
        >查询</Button
      >
    </Form>
    <Table
      border
      highlight-row
      :columns="columns"
      :data="tableData"
      :loading="loading"
    >
      <template slot-scope="{ row }" slot="Status">
        {{ row.Status == 1 ? "上架" : "下架" }}
      </template>

      <template slot-scope="{ row }" slot="menu">
        <Button
          type="success"
          size="small"
          style="margin-right: 5px"
          @click="handleUpdate(row.Id, 1)"
          v-show="row.Status != 1"
          >上架</Button
        >
        <Button
          type="error"
          size="small"
          style="margin-right: 5px"
          v-show="row.Status == 1"
          @click="handleUpdate(row.Id, 2)"
          >下架</Button
        >
        <Button type="success" size="small" @click="overhead(row.Id)"
          >置顶</Button
        >
      </template>
    </Table>
    <Page
      show-sizer
      :total="total"
      show-total
      :page-size="searchData.Limit"
      :current="searchData.Page"
      @on-change="changePage"
      @on-page-size-change="changePageSize"
    />
  </Card>
</template>
<script>
import gameNameSelect from "@/view/gameCircle/components/gameNameSelect";
import recommendApi from "@/api/gameCircle/recommendPost";
export default {
  name: "Recommend",
  data() {
    return {
      loading: false,
      searchData: {
        Page: 1,
        Limit: 10,
        AppId: undefined,
      },
      columns: [
        {
          title: "ID",
          key: "Id",
        },
        {
          title: "帖子ID",
          key: "postId",
        },
        {
          title: "标题",
          key: "title",
        },
        {
          title: "标签",
          key: "tag",
        },
        {
          title: "状态",
          slot: "Status",
        },
        {
          title: "操作",
          slot: "menu",
        },
      ],
      tableData: [],
      total: 0,
    };
  },
  components: {
    gameNameSelect,
  },
  mounted() {
    this.searchServer();
  },
  methods: {
    //更新状态
    handleUpdate(Id, status) {
      recommendApi
        .Update(Id, status)
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success("更新状态成功");
            this.searchServer();
          } else {
            this.$Message.error(res.Message);
          }
        })
        .catch();
    },
    //顶置
    overhead(Id) {
      recommendApi.Top(Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("顶置成功");
          this.searchData.Page = 1;
          this.searchServer();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //改页数
    changePage(page) {
      this.searchData.Page = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.searchData.Limit = pageSize;
      this.searchData.Page = 1;
      this.searchServer();
    },
    //查询
    toSearch() {
      this.searchData.Page = 1;
      this.searchServer();
    },
    searchServer() {
      this.loading = true;
      recommendApi
        .getList(this.searchData)
        .then((res) => {
          if (res.Code == 0) {
            //数据处理
            this.tableData = res.Data.Data || [];
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>