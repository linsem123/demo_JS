<template>
  <Card>
    <Form :model="formData" :inline="true" style="position: relative">
      <FormItem prop="HsID">
        <Input
          v-model="formData.HsID"
          style="width: 300px"
          placeholder="请输入黑鲨帐号ID"
          :clearable="true"
        />
      </FormItem>
      <FormItem prop="UnionId">
        <gameUserSelect
          v-model="formData.UnionId"
          style="width: 300px"
          placeholder="请输入游戏中心昵称"
        />
      </FormItem>
      <Button type="primary" @click="toSearch" style="margin-right: 50px"
        >查询</Button
      >
      <Button
        type="success"
        @click="showAddModal = true"
        style="position: absolute; right: 0"
        icon="md-add"
        >新增</Button
      >
    </Form>
    <Table
      border
      highlight-row
      ref="currentRowTable"
      :columns="columns"
      :data="tableData"
      :loading="loading"
    >
      <template slot-scope="{ row }" slot="PCAddTime">
        {{ row.PCAddTime | filertTime }}
      </template>
      <template slot-scope="{ row }" slot="action">
        <Button type="error" size="small" @click="hedleDelete(row.Id)"
          >删除</Button
        >
      </template>
    </Table>
    <Page
      show-sizer
      :total="page.total"
      show-total
      :page-size="page.limit"
      :current="page.page"
      @on-change="changePage"
      @on-page-size-change="changePageSize"
    />
    <Modal v-model="showAddModal" title="新增">
      <Form
        ref="formValidate"
        :model="addData"
        style="position: relative"
        :rules="rules"
        :label-width="100"
      >
        <FormItem label="黑鲨帐号ID：" prop="HsID">
          <Input
            v-model="addData.HsID"
            placeholder="请输入黑鲨帐号ID"
            :clearable="true"
          />
        </FormItem>
        <FormItem label="备注说明：" prop="Description">
          <Input
            v-model="addData.Description"
            type="textarea"
            :rows="3"
            placeholder="请输入备注说明"
          />
        </FormItem>
      </Form>
      <template slot="footer">
        <Button @click="showAddModal = false">取消</Button>
        <Button type="primary" @click="handleCommit" @loading="submitLoading"
          >确定</Button
        >
      </template>
    </Modal>
  </Card>
</template>
<script>
import gameUserSelect from "../components/gameUserSelect.vue";
import WhiteApi from "@/api/gameCircle/whiteList.js";
import common from "@/view/gameCircle/pubFunc/common";
export default {
  name: "whiteList",
  components: {
    gameUserSelect,
  },
  data() {
    return {
      formData: {
        HsID: "",
        UnionId: "",
      },
      columns: [
        {
          key: "HsID",
          title: "黑鲨帐号ID",
        },
        {
          key: "NickName",
          title: "游戏中心昵称",
        },
        {
          key: "Description",
          title: "备注信息",
        },
        {
          slot: "PCAddTime",
          title: "添加时间",
        },
        {
          slot: "action",
          title: "操作",
        },
      ],
      tableData: [],
      loading: false,
      submitLoading: false,
      page: {
        total: 0,
        limit: 10,
        page: 1,
      },
      showAddModal: false,
      addData: {
        UnionID: "",
        Describe: "",
      },
      rules: {
        HsID: [
          {
            required: true,
            message: "请输入黑鲨帐号ID",
            trigger: "blur",
          },
        ],
      },
    };
  },
  mounted() {
    this.searchServer();
  },
  filters: {
    filertTime(val) {
      if (val) {
        return common.formatDate(val, true);
      }
      return "";
    },
  },
  methods: {
    //删除
    hedleDelete(ID) {
      WhiteApi.Delete(ID).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("删除成功！");
          this.searchServer();
        } else {
          this.$Message.success(res.Message);
        }
      });
    },
    //提交新增
    handleCommit() {
      this.$refs.formValidate.validate((valide) => {
        if (valide) {
          this.submitLoading = true;
          WhiteApi.Create(this.addData)
            .then((res) => {
              if (res.Code == 0) {
                this.$Message.success("新增成功！");
                this.showAddModal = false;
                this.$refs.formValidate.resetFields();
                this.searchServer();
              } else {
                this.$Message.success(res.Message);
              }
            })
            .finally(() => {
              this.submitLoading = false;
            });
        }
      });
    },
    //改页数
    changePage(page) {
      this.page.page = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.page.limit = pageSize;
      this.page.page = 1;
      this.searchServer();
    },
    toSearch() {
      this.page.page = 1;
      this.searchServer();
    },
    searchServer() {
      this.loading = true;
      const keys = Object.keys(this.formData);
      for (let key in this.formData) {
        this.formData[key] = this.formData[key]
          ? this.formData[key].trim()
          : undefined;
      }
      WhiteApi.getWhiteList({ ...this.page, params: this.formData })
        .then((res) => {
          if (res.Code == 0) {
            this.tableData = res.Data.Data || [];
            this.page.total = res.Data.Count;
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
</style>