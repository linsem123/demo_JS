import common from './common'
const styleType = ['p', 'b', 'i', 'strike', 'u', 'input', 'color', 'text-align', 'size', 'a']
// const fontSize = ['','10','13','16','18','24','32','48'] 
const fontSize = ['', '13', '16', '18', '20', '22', '24', '32']
let jsonData = [];
const AppToHtmlJson = function (data) {
    let textIndex = undefined
    jsonData = []
    data.forEach(root => {
        initPJson(root)
        //如果是文本就遍历
        if (root.type == 1) {
            root.inputStr.forEach(child => {
                if ((child.styleType.length == 1 && child.styleType[0] == 0) || child.styleType.length == 0) {
                    //普通样式text直接放入p标签的children
                    jsonData[jsonData.length - 1].children.push(...checkP(child.textStr))
                } else if (child.styleType.length == 1 && child.styleType[0] == 7) {
                    ////只有居中样式text直接放入p标签的children,p标签添加居中样式
                    if (textIndex != jsonData.length - 1) {
                        textIndex = jsonData.length - 1
                        jsonData[jsonData.length - 1].attrs.push({
                            name: 'style',
                            value: 'text-align:center;'
                        })
                    }
                    jsonData[jsonData.length - 1].children.push(...checkP(child.textStr))
                } else {
                    if (child.styleType.includes(7)) {
                        //p标签添加居中样式
                        if (textIndex != jsonData.length - 1) {
                            textIndex = jsonData.length - 1
                            jsonData[jsonData.length - 1].attrs.push({
                                name: 'style',
                                value: 'text-align:center;'
                            })
                        }
                        let alignIndex = []
                        child.styleType.forEach((style, index) => {
                            if (style == 7) {
                                alignIndex.push(index)
                            }
                        })
                        child.styleType = child.styleType.filter(num => num != 7)
                        child.value = child.value.filter((num, index) => !alignIndex.includes(index))
                    }
                    let childItem = styleTypeFunc(child, 0)
                    jsonData[jsonData.length - 1].children.push(childItem)
                }
            })
        }
    });
    // console.log(jsonData)
    return jsonData
}

//将单个\n处理成标签p
function checkP(textStr) {
    let treeArr = [];
    let brItem = {
        attrs: [],
        children: [],
        tag: 'br'
    }
    if (textStr == '\n' || textStr == '↵') {
        //单个inputstr只有一个\n
        // if(isBr) treeArr.push(brItem)
        treeArr.push(brItem)
    } else {
        //文字中间的\n处理为换行
        let arr = textStr.split("\n")
        if (arr.length > 1) {
            for (let i = 0; i < arr.length; i++) {
                if (arr[i]) treeArr.push(arr[i])
                if (i == arr.length - 1) treeArr.push(brItem)
            }
        } else {
            treeArr.push(textStr)
        }
    }
    return treeArr
}
const styleTypeFunc = function (child, index) {
    // console.log(index)
    let obj = {
        attrs: [],
        children: [],
        tag: "font"
    }
    let attrs = []
    let tag = styleType[child.styleType[index]] || "font"
    //特殊处理@用户
    if (child.styleType[index] == 5) {
        let inwidth = common.getTextWidth(child.textStr)
        attrs.push({
            name: 'unionid',
            value: child.value[index]
        }, {
            name: 'value',
            value: child.textStr
        }, {
            name: 'style',
            value: `width:${inwidth}px;border:none;color:green;background:white`
        }, {
            name: 'disabled',
            value: 'disabled'
        }, {
            name: 'readonly',
            value: 'readonly'
        })
    }
    //超链接
    if (child.styleType[index] == 9) {
        // console.log(child)
        let href = child.value[index]
        attrs.push({
            name: 'href',
            value: href
        })
    }
    //特殊处理样式 
    if (child.styleType[index] == 6 || child.styleType[index] == 8) {
        //颜色、字号
        tag = 'font'
        if (child.value) {
            let value = child.value[index]
            let name = styleType[child.styleType[index]]
            if (child.styleType[index] == 8 && fontSize.indexOf(value) > -1) {
                //字号是编辑器可选的添加属性size
                value = fontSize.indexOf(value)
            } else if (child.styleType[index] == 8 && fontSize.indexOf(value) < 0) {
                //字号不是编辑器可选的就通过style的font-size添加
                name = 'style'
                value = `font-size:${value}px`
            }
            if (child.styleType[index] == 6) {
                name = 'style'
                value = `color:${value}`
            }

            attrs.push({
                name: name,
                value: value
            })
        }
    }

    if (index == child.styleType.length - 1 || child.styleType.length == 0) {
        //children结束放入text
        obj = {
            attrs,
            children: [],
            tag: tag
        }
        if (child.styleType[index] != 5) {
            // obj.children.push(...checkP(child.textStr,isBr))//p标签结束加换行
            obj.children.push(...checkP(child.textStr))//p标签结束加换行
        }

    } else if (index < child.styleType.length - 1) {
        let i = index + 1
        obj = {
            attrs,
            children: [styleTypeFunc(child, i)],
            tag: tag
        }
    }
    //color-size两个属性都有放在一个标签上
    if (tag == 'font' && index + 1 < child.styleType.length && (child.styleType[index + 1] == 6 || child.styleType[index + 1] == 8)) {
        let index1 = obj.children[0].attrs.findIndex(v => v.name == 'style')
        let index2 = obj.attrs.findIndex(v => v.name == 'style')
        if (index2 > -1 && index1 > -1) {
            obj.children[0].attrs[index1].value = obj.children[0].attrs[index1].value + ';' + obj.attrs[index2].value
            obj.attrs.splice(index2, 1)
        }
        obj.children[0].attrs = obj.children[0].attrs.concat(obj.attrs)
        obj = obj.children[0]
    }
    return obj
}
const initPJson = function (root) {
    //图片特殊处理
    if (root.type == 2) {
        jsonData.push({
            attrs: [],
            children: [{
                attrs: [{
                    name: 'src',
                    value: root.imagePath,
                },
                {
                    name: 'referrer',
                    value: "no-referrer|origin|unsafe-url",
                }],
                children: [],
                tag: 'img'
            }],
            tag: 'p'
        })
    } else if (root.type == 3) {
        //视频特殊处理
        let splitArr = root.videoPath.split('.')
        let videoType = splitArr[splitArr.length - 1]
        jsonData.push({
            attrs: [],
            children: [{
                attrs: [{
                    name: 'poster',
                    value: root.imagePath
                }, {
                    name: 'name',
                    value: 'media'
                }, {
                    name: 'controls',
                    value: 'controls'
                }],
                children: [{
                    attrs: [{
                        name: 'src',
                        value: root.videoPath
                    }, {
                        name: 'type',
                        value: 'video/' + videoType
                    }],
                    children: [],
                    tag: 'source',
                }],
                tag: 'video'
            }],
            tag: 'p'
        })
    } else {
        //inputStr对应p标签
        jsonData.push({
            attrs: [],
            children: [],
            tag: 'p'
        })
    }

}
export default {
    AppToHtmlJson
}