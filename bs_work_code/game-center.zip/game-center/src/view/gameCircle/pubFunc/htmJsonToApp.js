const styleTypeMap = {
  p: 0,
  b: 1,
  i: 2,
  strike: 3,
  u: 4,
  color: 6,
  size: 8,
  a: 9,
};
const includeArr = ['p', 'b', 'i', 'strike', 'u', 'font', 'a', 'div', 'section']
// const fontSize = ['', '10', '13', '16', '18', '24', '32', '48'] // 字号
const fontSize = ['', '13', '16', '18', '20', '22', '24', '32']
const type = {
  img: 2,
  video: 3
}
let flatMapData = [];
let plaintTextList = [];
let AtunionIds = [];
let ImgUrls = []//总图片
let VideoUrls = [] // 总video
//生成style数组和value数组且一一对应的数组
const deepFindPlaintext = function (tag) {
  let styleType = [];
  let value = [];
  if (tag.id === 'ROOT') {
    return;
  }
  const parent = flatMapData.find(v => v.id === tag.parentId);//获取父标签
  if (parent && includeArr.includes(parent.tag)) {
    let parentStyle = deepFindPlaintext(parent)////获取父标签样式
    if (tag.tag == 'input' && tag.attrs.some(v => v.name == 'unionid')) {
      //@用户特殊处理
      styleType.push(5)
      let union = tag.attrs.filter(attr => attr.name == 'unionid')[0].value//获取unionid
      value.push(union)
    } else {
      //处理样式，如果是粘贴的每个标签上都可能有样式
      let styleName = parent.attrs.find(v => v.name == "style") || {}
      if (styleName.value) {
        //存在样式属性，将可支持样式转为key-value的对象
        let obj = styleToObj(styleName.value, ['text-align', 'color', 'font-size', "font-weight", "font-style", "text-decoration"])
        if (parent.tag == 'p' || parent.tag == 'div' || parent.tag == 'section') {
          //p标签上和div标签为块级标签居中样式有效
          if (obj['text-align']) {
            if (obj['text-align'] == "center") {
              styleType.push(7);
              value.push(null)
            } else {
              const alignIndex = parentStyle.styleType.findIndex(v => v == 7);
              if (alignIndex > -1) {
                //当前标签存在font-size，父标签的font-size设置无效
                parentStyle.styleType.splice(alignIndex, 1)
                parentStyle.value.splice(alignIndex, 1)

              }
            }
          }
        }
        if (obj['font-size']) {
          let size = obj['font-size'].replace(/!.*/, "").replace(/[A-Za-z]*|(%?)/g, '').trim()
          //父标签有font-size样式
          const sizeIndex = parentStyle.styleType.findIndex(v => v == 8);
          if (obj['font-size'].includes('em')) {
            //根据父标签font-size计算，font-size单位转换为px，父标签未设置font-size则默认为15px
            size = sizeIndex > -1 ? Number(parentStyle.value[sizeIndex]) * Number(size) : "15"
          }
          if (sizeIndex > -1) {
            //当前标签存在font-size，父标签的font-size设置无效
            parentStyle.styleType.splice(sizeIndex, 1)
            parentStyle.value.splice(sizeIndex, 1)
          }
          styleType.push(8)
          value.push(size)
        }
        if (obj['color']) {
          const colorIndex = parentStyle.styleType.findIndex(v => v == 6);
          if (colorIndex > -1) {
            //当前标签存在font-size，父标签的font-size设置无效
            parentStyle.styleType.splice(colorIndex, 1)
            parentStyle.value.splice(colorIndex, 1)
          }
          let color = obj['color'].replace(/!.*/, "").trim();
          if (color.includes("rgb")) {
            let rgbArr = color
              .match(/[^\(\)]+(?=\))/g)[0]
              .split(",");
            color = rgbToHexColor(rgbArr);
          }
          styleType.push(6)
          value.push(color)
        }
        if (obj['font-weight']) {
          styleType.push(1);
          value.push(null)
        }
        if (obj['font-style']) {
          styleType.push(2);
          value.push(null)
        }
        if (obj['text-decoration']) {
          styleType.push(3);
          value.push(null)
        }
      }
      if (parent.tag == 'font') {
        //标签上文字样式-字号属性size、颜色属性color
        parent.attrs.forEach(v => {
          if (styleTypeMap[v.name]) {
            styleType.push(styleTypeMap[v.name])
            if (v.name == 'size') {
              //字号
              value.push(fontSize[v.value])
            } else {
              //颜色
              value.push(v.value)
            }
          }
        })
      } else if (parent.tag == 'a') {
        //超链接
        styleType.push(styleTypeMap[parent.tag]);
        let href = parent.attrs.find(v => v.name == "href") || { name: 'href', value: '' }
        value.push(href.value)
      } else {
        styleTypeMap[parent.tag] != undefined ? styleType.push(styleTypeMap[parent.tag]) : '';
        styleTypeMap[parent.tag] != undefined ? value.push(null) : ''//null占位
      }
    }
    styleType = styleType.concat(parentStyle.styleType);
    value = value.concat(parentStyle.value)

    //0为默认样式，如果不只有默认样式去掉0和value的null占位
    if (styleType.length > 1 && styleType.includes(0)) {
      for (let i in styleType) {
        if (styleType[i] == 0) {
          styleType.splice(i, 1)
          value.splice(i, 1)

        }
      }
    }
  }
  return { styleType, value };
}
/**
* @param styleValue style
* @param key 样式属性
* @description style样式生成key:value对象，并返回传入key值的对象
*/
const styleToObj = function (styleValue, keys) {
  let arr = styleValue.split(';')
  let obj = {}
  for (let i = 0; i < arr.length; i++) {
    let valueArr = arr[i].split(":")
    if (keys.includes(valueArr[0].trim())) {
      obj[valueArr[0].trim()] = valueArr[1].trim()
    }
  }
  return obj
}
//处理为一维数组
const flatMapDataFunc = function (arr) {
  if (!arr.length) return;
  arr.forEach(v => {
    if (v.children && v.children.length) flatMapDataFunc(v.children);
    v.children && delete v.children;
    flatMapData.push(v);
  })
}
//遍历数组生成parentId和id
const generatedAllDataID = function (arr) {
  if (!arr.length) return;
  return arr.map(v => {
    if (v.children && v.children.length) {
      const parentId = v.id;
      v.children = generatedTagId(v.children, 'SUB_TAG', parentId);
      generatedAllDataID(v.children);
    }
    return v;
  })
}
//数组成员添加parantID和id
const generatedTagId = function (arr, tagIdPre, tagParentId) {
  return arr.map((v, i) => {
    if (typeof v !== 'object') {
      return {
        plainValue: v,
        id: Symbol(`${tagIdPre}_${i}`),
        parentId: tagParentId
      }
    }
    return {
      ...v,
      id: Symbol(`${tagIdPre}_${i}`),
      parentId: tagParentId
    }
  })
}
/**
* @param jsonData
* @description 将富文本编辑器的JSON格式dom树转为App可接收格式
*/
const getEditorData = function (jsonData) {
  // console.log(jsonData)
  let firstLayer = generatedTagId(jsonData, 'FIRST_LAYER', 'ROOT');
  // generated all id,parentId and id
  let generatedLayer = generatedAllDataID(firstLayer);
  // console.log(generatedLayer)
  flatMapData = []; // clear
  plaintTextList = []; // clear
  AtunionIds = [] // 总@用户
  ImgUrls = []//总图片
  VideoUrls = [] // 总video
  flatMapDataFunc(generatedLayer);
  let tagArr = ['img', 'video', 'br', 'input', 'source', 'p', 'div']
  //抻平为一维数组
  let flatMapDataFIlter = flatMapData.filter(v => v.plainValue != undefined || tagArr.includes(v.tag))
  flatMapDataFIlter.forEach((v, i) => {
    let item = {}
    let styleArr = Object.assign({}, deepFindPlaintext(v))
    let value = []
    if (plaintTextList.length > 0 && (v.tag == 'p' || v.tag == 'div' || v.tag == 'section')) {
      plaintTextList.push({
        inputStr: [],
        type: 1,
      })
    }
    if (v.plainValue != undefined || v.tag == 'input' || v.tag == 'br') {
      if (plaintTextList.length < 1 || !plaintTextList[plaintTextList.length - 1].inputStr) {
        //非图片视频，且无inputStr，先生成inputStr
        plaintTextList.push({
          inputStr: [],
          type: 1,
        })
      }
      //文本、@用户、换行
      //@用户特殊处理
      if (styleArr.styleType.includes(5) && v.tag == 'input') {
        let union = v.attrs.filter(attr => attr.name == 'unionid')[0].value
        AtunionIds.push(union)
        value.push(union)
        item = {
          textStr: v.attrs.filter(attr => attr.name == 'value')[0].value,
          styleType: styleArr.styleType,
          value
        };
      }
      //仅为文本 特殊符号<>"
      if (v.plainValue != undefined) {
        item = {
          textStr: v.plainValue.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/<br\/>/g, ""),
          styleType: styleArr.styleType,
          value: styleArr.value
        }
      }
      if (v.tag == 'br') {
        //换行特殊处理br转换为\n
        item = {
          textStr: "\n",
          styleType: styleArr.styleType,
          value: styleArr.value
        };
      }
      if (!(v.tag == 'br' && flatMapDataFIlter[i + 1] && flatMapDataFIlter[i + 1].tag == 'p' && flatMapDataFIlter[i - 1] && flatMapDataFIlter[i - 1].tag != 'p')) {
        plaintTextList[plaintTextList.length - 1].inputStr.push(item)
      }
    } else if (v.tag == 'img') {
      //图片
      let imagePath = v.attrs.filter(v => v.name == 'src')[0].value
      item = {
        imagePath: imagePath,
        type: type[v.tag],
      }
      plaintTextList.push(item);
      ImgUrls.push(imagePath)
    } else if (v.tag == 'video') {
      //视频
      let videoPath = flatMapDataFIlter[i - 1].tag == 'source' && flatMapDataFIlter[i - 1].attrs ? flatMapDataFIlter[i - 1].attrs.filter(v => v.name == 'src')[0].value : ''
      let posterAttr = v.attrs.filter(v => v.name == 'poster')
      let imagePath = posterAttr.length > 0 ? posterAttr[0].value : ''
      item = {
        videoPath: videoPath,
        imagePath: imagePath,
        type: type[v.tag],
      }
      plaintTextList.push(item);
      VideoUrls.push({
        VideoUrl: videoPath,
        ImgUrl: imagePath
      })
    }

  })
  plaintTextList = plaintTextList.filter(v => v.type > 1 || (v.type == 1 && v.inputStr != false))
  // console.log(plaintTextList)
  return plaintTextList
}
//获取@用户unionId的list
const getAtunionIds = () => {
  return AtunionIds
}
//获取图片url的list
const getImgUrls = () => {
  return ImgUrls
}
//获取图片url的list
const getVideoUrls = () => {
  return VideoUrls
}
//rgb/rgba转换为16进制
const rgbToHexColor = (rgbArray) => {
  if (rgbArray.length > 2) {
    let strHex = "#";
    for (let i = 0; i < 3; i++) {
      let hex = Number(rgbArray[i]).toString(16);
      if (hex == 0) {
        hex += "0";
      }
      strHex += hex;
    }
    //补位#
    return strHex;
  } else {
    return "#000000";
  }
}
export default {
  deepFindPlaintext,
  flatMapDataFunc,
  generatedAllDataID,
  generatedTagId,
  getEditorData,
  getAtunionIds,
  getImgUrls,
  getVideoUrls
}