//创建div标签获得文字宽度
const getTextWidth = function (text) {
	let doc = document.createElement("div")
	// let doc = document.getElementById("get_value_width")
	doc.style.display = 'inline'
	doc.style.visibility = 'hidden'
	doc.style.fontSize = '15px'
	doc.innerHTML = text
	document.body.appendChild(doc)
	let inwidth = doc.clientWidth || doc.offsetWidth;
	document.body.removeChild(doc)
	return inwidth
}
//yyyy-mm-dd 转为 Date类型
const toDate = (date) => {
	return new Date(date.replace(/-/g, '/'));
}
//Data数据转为 yyyy-mm-dd hh:mm:ss
const formatDate = (date, time) => {
	if (date) {
		var datetime = new Date(date);
		var year = datetime.getFullYear();
		var month = datetime.getMonth() + 1;
		var date = datetime.getDate();
		var hour = datetime.getHours();
		/*对月 日 时 分 秒 小于10的时候的处理  --小于 10 时前面加 0*/
		if (month <= 9) {
			month = "0" + month;
		}
		if (date <= 9) {
			date = "0" + date
		}
		if (hour <= 9) {
			hour = "0" + hour;
		}
		var minute = datetime.getMinutes();
		if (minute <= 9) {
			minute = "0" + minute;
		}
		var second = datetime.getSeconds();
		if (second <= 9) {
			second = "0" + second;
		}
		if (time) return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
		else return year + "-" + month + "-" + date
	}
	return ''
}
export default {
	getTextWidth,
	toDate,
	formatDate
}