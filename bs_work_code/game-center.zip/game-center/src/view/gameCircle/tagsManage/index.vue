<template>
  <div>
    <tagsTab
      v-for="(item, index) of tagsTabList"
      :key="index"
      :index="index"
      :tagData="item"
      @addTagServe="addTagServe"
      @delTagServe="delTagServe"
      style="margin-bottom: 20px"
    />
    <Card class="margin_bottom">
      <div>
        <span>是否开启视频发布：</span>
        <i-switch
          :loading="config.videoLoading"
          @on-change="
            (value) => changeStatus(value, 3, 'videoLoading', 'isVideoPublish')
          "
          v-model="config.isVideoPublish"
        />
      </div>
    </Card>
    <Card class="margin_bottom">
      <div>
        <span>是否开启全局禁言：</span>
        <i-switch
          :loading="config.loading"
          @on-change="(value) => changeStatus(value, 1, 'loading', 'status')"
          v-model="config.status"
        />
      </div>
    </Card>
    <Card title="消息中心管理员配置" class="margin_bottocm">
      <div class="info_config_box">
        <acountInfo
          class="info_config_item"
          :initData="sysyemInfo"
          placeholder="请输入系统通知管理员昵称"
          @commitInfo="commitSystem"
        >
          <template v-slot:title>
            <div style="padding-bottom: 10px">系统通知</div>
          </template>
        </acountInfo>
        <acountInfo
          class="info_config_item"
          :initData="assistantInfo"
          placeholder="请输入福利助手管理员昵称"
          @commitInfo="commitAssistant"
        >
          <template v-slot:title>
            <div style="padding-bottom: 10px">福利助手</div>
          </template>
        </acountInfo>
      </div>
    </Card>
  </div>
</template>
<script>
import tagsTab from "./tagsTab";
import acountInfo from "./acountInfo";
import Post from "@/api/gameCircle/postManagement";
import Tags from "@/api/gameCircle/tagsManage";
export default {
  name: "tagsManage",
  data() {
    return {
      tagsTabList: [
        {
          title: "用户标签管理",
          placeholder: "用户标签",
          tagList: [],
          delServer: "deleteUserTag",
          addServer: "addUserTag",
          searchServe: "searchUser",
        },
        {
          title: "论坛帖标签管理",
          placeholder: "论坛帖标签",
          tagList: [],
          delServer: "deletePostTag",
          addServer: "addPostTag",
          searchServe: "searchTag",
        },
        {
          title: "发帖管理员管理",
          placeholder: "发帖管理员",
          tagList: [],
          delServer: "deleteAdminTag",
          addServer: "addAdminTag",
          searchServe: "searchAccount",
        },
        {
          title: "论坛帖分类标签管理",
          placeholder: "论坛帖分类标签",
          tagList: [],
          delServer: "deletePostType",
          addServer: "addPostType",
          searchServe: "searchPostType",
        },
      ],
      sysyemInfo: {}, //系统通知
      assistantInfo: {}, //福利助手
      config: {
        status: false,
        loading: false,
        isVideoPublish: false, //4.9迭代增加
        videoLoading: false, //4.9迭代增加
      },
      configList: [
        {
          id: 1,
          valueName: "status",
        },
        {
          id: 3,
          valueName: "isVideoPublish",
        },
      ],
    };
  },
  components: {
    tagsTab,
    acountInfo,
  },
  mounted() {
    this.searchUser(); //查询用户标签
    this.searchAccount(); //查询管理员账户
    this.searchTag(); //查询帖子标签
    this.searchPostType(); //查询帖子分类标签
    this.initStatus(); //全局禁言初始化
    this.configFetch();
  },
  methods: {
    //查询用户标签
    searchUser() {
      Tags.getUserTag({}).then((res) => {
        this.tagsTabList[0].tagList = res.Data;
      });
    },
    //查询帖子标签
    searchTag() {
      Post.getTagList({}).then((res) => {
        this.tagsTabList[1].tagList = res.Data;
      });
    },
    //查询管理员账户
    searchAccount() {
      this.tagsTabList[2].tagList = [];
      Post.getAccount({}).then((res) => {
        if (res.Code == 0 && res.Data) {
          res.Data.forEach((v) => {
            let item = {};
            item.UserId = v.UserId;
            item.Id = v.UnionId;
            item.Name = v.NickName;
            this.tagsTabList[2].tagList.push(item);
          });
        }
      });
    },
    //查询帖子分类标签
    searchPostType() {
      this.tagsTabList[3].tagList = [];
      Tags.getPostType({}).then((res) => {
        if (res.Code == 0) {
          let list = res.Data || [];
          list.forEach((v) => {
            v.Name = v.Title;
            this.tagsTabList[3].tagList.push(v);
          });
        }
      });
    },
    //全局禁言初始化
    initStatus() {
      this.configList.forEach((v) => {
        Tags.configStatus(v.id).then((res) => {
          this.config[v.valueName] = res.Data.SwitchStatus == 1 ? false : true;
        });
      });
    },
    configFetch() {
      //查询消息中心管理员配置
      Tags.configFetch().then((res) => {
        this.sysyemInfo = res.Data["2"];
        this.assistantInfo = res.Data["1"];
      });
    },
    //添加标签
    addTagServe(value) {
      let data = {};
      if (value.index == 2) {
        data.UnionId = value.Name;
      } else if (value.index == 3) {
        data.title = value.Name;
      } else {
        data.Name = value.Name;
      }
      let item = this.tagsTabList[value.index];
      Tags[item.addServer](data).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("添加成功");
          this[item.searchServe]();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //删除标签
    delTagServe(value) {
      console.log(value);
      let item = this.tagsTabList[value.index];
      let Id = item.tagList[value.tagIndex].Id;
      Tags[item.delServer](Id).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("删除成功");
          this[item.searchServe]();
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //全局禁言
    changeStatus(value, id, loadName, valueName) {
      let status = value ? 2 : 1; //1-false 2-true
      this.config[loadName] = true;
      Tags.setStatus(id, status)
        .then((res) => {
          if (res.Code != 0) {
            this.config[valueName] = !value;
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.config[loadName] = false;
        });
    },
    //系统通知
    commitSystem(data) {
      this.configModifyServe(2, data);
    },
    commitAssistant(data) {
      this.configModifyServe(1, data);
    },
    configModifyServe(type, data) {
      Tags.configModify({
        IconType: type,
        Title: data.Title,
        ImgUrl: data.ImgUrl,
      }).then(() => {
        this.configFetch();
      });
    },
  },
};
</script>
<style lang="less" scoped>
.info_config_box {
  display: flex;
  .info_config_item {
    width: 50%;
    padding-left: 10px;
  }
}
.margin_bottom {
  margin-bottom: 15px;
}
</style>