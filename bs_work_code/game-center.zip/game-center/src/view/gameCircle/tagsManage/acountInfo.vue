<template>
    <div>
        <slot name="title"></slot>
        <Form ref="formValidate" :model="formData" :rules="ruleValidate">
            <FormItem label="昵称" prop="Title">
                <Input :placeholder="placeholder" v-model="formData.Title" :disabled="disabled" style="width:250px" />
            </FormItem>
            <FormItem label="头像" prop="ImgUrl">
                <div class="demo-upload-list" v-if="formData.ImgUrl">
                    <img :src="formData.ImgUrl" @click="handleUpload" />
                </div>
                <Upload
                    v-show="!formData.ImgUrl"
                    ref="uploadicon"
                    :show-upload-list="false"
                    :format="['jpg','jpeg','png']"
                    :before-upload="handleIconBeforeUpload"
                    type="drag"
                    multiple
                    :action="uploadurl"
                    style="display: inline-block;width:58px;"
                    :disabled="disabled"
                >
                    <div style="width: 58px;height:58px;line-height: 58px;">
                        <Icon type="ios-camera" size="20"></Icon>
                    </div>
                </Upload>
            </FormItem>
            <Button type="primary" style="margin-right:15px" @click="commit">确认</Button>
            <Button @click="modify" v-if="disabled">修改</Button>
            <Button @click="cancel" v-else>取消</Button>
        </Form>
    </div>
</template>
<script>
import GameAPI from "@/api/gamespace/game";
import { AssertVideo } from "@/libs/tools";
import COS from "cos-js-sdk-v5";
import cosconfig from "@/libs/cosconfig";
import UploadImg from "_c/shark-upload";
export default {
    props: {
        placeholder: {
            type: String,
            default: "请输入"
        },
        initData: Object
    },
    components: { UploadImg },
    data() {
        return {
            disabled: true, //是否可修改
            formData: {
                Title: "",
                ImgUrl: ""
            },
            ruleValidate: {},
            uploadurl: ""
        };
    },
    mounted() {
        this.uploadurl = GameAPI.UploadURL();
    },
    methods: {
        commit() {
            if (!this.formData.Title) {
                this.$Message.error(this.placeholder);
                return;
            }
            this.disabled = true;
            this.$emit("commitInfo", this.formData);
        },
        modify() {
            this.disabled = false;
        },
        cancel() {
            this.disabled = true;
            this.formData = Object.assign({}, this.initData);
        },
        handleUpload() {
            if (!this.disabled) {
                this.$refs["uploadicon"].$refs["input"].click();
            }
        },
        handleIconBeforeUpload(file) {
            const t = AssertVideo(file.name);
            if (t != "img") {
                this.handleFormatError(file);
                this.$refs.uploadicon.clearFiles();
                return false;
            }
            let cos = new COS({
                getAuthorization: function (options, callback) {
                    GameAPI.GetSts().then(data => {
                        callback({
                            TmpSecretId: data.Data.credentials.tmpSecretId,
                            TmpSecretKey: data.Data.credentials.tmpSecretKey,
                            XCosSecurityToken: data.Data.credentials.sessionToken,
                            ExpiredTime: data.Data.expiredTime
                        });
                    });
                }
            });
            // let key = "game" + "/" + new Date().getTime() + "-" + file.name;
            let key = "game" + "/" + new Date().getTime();
            let that = this;
            cos.sliceUploadFile(
                {
                    Bucket: cosconfig.bucket /* 必须 */,
                    Region: cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                    Key: key,
                    Body: file /* 必须 */,
                    onProgress: function (progressData) {
                        that.uploadpercent = progressData.percent * 100;
                        /* 非必须 */
                        // console.log(JSON.stringify(progressData));
                    }
                },
                function (err, data) {
                    if (err) {
                        this.$Message.warning(err);
                        return;
                    }
                    //   console.log(data);
                    that.formData.ImgUrl = cosconfig.exporturl + "/" + key;
                }
            );
            return false;
        },
        handleFormatError(file) {
            this.$Notice.warning({
                title: "图片格式错误",
                desc: file.name + " 格式错误"
            });
        }
    },
    watch: {
        initData() {
            this.formData = Object.assign({}, this.initData);
        }
    }
};
</script>
<style lang="less" scoped>
.demo-upload-list {
    display: inline-block;
    width: 60px;
    height: 60px;
    text-align: center;
    line-height: 60px;
    border: 1px solid transparent;
    border-radius: 4px;
    overflow: hidden;
    background: #fff;
    position: relative;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
    margin-right: 4px;
    img {
        width: 100%;
        height: 100%;
    }
}
</style>