<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>{{ tagData.title }}
    </p>
    <div>
      <gameUserSelect v-if="index == 2" v-model="UnionId" :width="200" />
      <Input
        v-else
        v-model="tagName"
        style="width: 200px"
        :placeholder="'请输入' + tagData.placeholder"
      />
      <Button type="primary" style="margin-left: 20px" @click="addTag"
        >添加</Button
      >
    </div>
    <div class="tag_box">
      <div v-if="tagData.tagList.length > 0">
        <Tag
          v-for="(item, index) of tagData.tagList"
          :key="index"
          type="dot"
          closable
          color="primary"
          @on-close="deleteTag"
          :name="item.Id"
          >{{ item.Name }}</Tag
        >
      </div>
      <div v-else class="no_tags">暂无标签</div>
    </div>
  </Card>
</template>
<script>
import gameUserSelect from "@/view/gameCircle/components/gameUserSelect";
export default {
  props: {
    tagData: Object,
    index: Number,
  },
  components: {
    gameUserSelect,
  },
  data() {
    return {
      tagName: "",
      UnionId: "",
    };
  },
  methods: {
    deleteTag(event, name) {
      console.log(name);
      let tagIndex = this.tagData.tagList.findIndex((v) => v.Id == name);
      this.$emit("delTagServe", { tagIndex, index: this.index });
    },
    addTag() {
      if (this.tagName || this.UnionId) {
        this.$emit("addTagServe", {
          Name: this.index == 2 ? this.UnionId : this.tagName,
          index: this.index,
        });
      }
    },
  },
};
</script>
<style lang="less" scoped>
.tag_box {
  width: 100%;
  height: 100%;
  border: 1px solid #eee;
  padding: 20px;
  margin: 20px 0;
  .no_tags {
    text-align: center;
  }
}
</style>