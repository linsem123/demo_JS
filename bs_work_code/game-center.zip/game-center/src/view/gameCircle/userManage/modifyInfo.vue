<template>
    <div class="set_forbiddon_box">
        <Form :model="formData"
              :rules="ruleValidate"
              ref="formValidate"
              :label-width="60"
        >
            <FormItem label="用户昵称" prop="NickName">
                <Input style="width:200px;" v-model="formData.NickName"/>
            </FormItem>
             <FormItem label="头像">
                 <div class="demo-upload-list">
                 <img :src="formData.HeadImg" @click="changeHeadImg" style="width:100%;height:100%"/>
                 <!-- <div class="demo-upload-list-cover">
                    <Icon type="ios-eye-outline" @click.native="handleView"></Icon>
                    <Icon type="ios-cloud-upload-outline" @click.native="changeHeadImg"></Icon>
                </div> -->
                 </div>
                 <input ref="upload" @change="uploadImg" accept="image/*" type="file" style="display:none"/>
            </FormItem>
            <FormItem label="签名" prop="Description">
                <Input type="textarea" style="width:350px" :rows="2" v-model="formData.Description"/>
             </FormItem>
             <FormItem label="用户标签">
                 <tagList :tagList="tagList" v-model="formData.TagId" :trigger="true"/>
             </FormItem>
        </Form>
        <div style="margin:30px 0;display:flex;justify-content:center">
            <Button  style="margin-right:40px" @click="handelClickCancel">取消</Button>
            <Button type="primary" @click="commit">保存</Button>
        </div>
    </div>
</template>
<script>
import User from "@/api/gameCircle/userManage";
import tagList from '@/view/gameCircle/components/tagList'

import COS from 'cos-js-sdk-v5'
import cosconfig from '@/libs/cosconfig'
import axios from '@/libs/api.request'
import baseurl from '@/api/gamespace/base'

export default {
    props:{
        checkedTable:Object,
        tagList:Array
    },
    data(){
        const Descriptionlen = (rule, value, callback)=>{
            if(value.length>20){
                return callback(new Error('最多可输入20个字符'));;
            }else{
                callback()
            }
        }
        const NickNamelen = (rule, value, callback)=>{
            if(value.length>16){
                return callback(new Error('最多可输入16个字符'));;
            }else{
                callback()
            }
        }
        return {
            formData:{
                NickName:'',
                HeadImg:'',
                Tag:'',
                Description:'',
                TagId:''
            },
            ruleValidate:{
                Description:[{validator:Descriptionlen,trigger:'blur'}],
                NickName:[{validator:NickNamelen,trigger:'blur'}]
            },
            
            
        }
    },
    components:{
        tagList
    },
    mounted(){
        this.formData = {...this.checkedTable,TagId:this.checkedTable.Tag.Id}
        this.formData = Object.assign({},this.formData)
    },
    methods:{
        //改头像
        changeHeadImg(){
            this.$refs['upload'].click()
        },
        GetSts() {
            return axios.request({
                url: baseurl + 'game/sts',
                method: 'get'
            })
        },
        // 上传图片
        uploadImg(){
           let accepts=['jpg', 'JPG', 'jpeg', 'JPEG', 'png', 'PNG',]
            let file = this.$refs['upload'].files[0]
            // console.log(file)
            let type = file.type
            if(!accepts.some(v=> `image/${v}` == type)){
                this.$Message.error('不支持上传此格式图片')
                return;
            }
             let cos = new COS({
                getAuthorization: (options, callback) => {
                  this.GetSts().then(data => {
                    callback({
                      TmpSecretId: data.Data.credentials.tmpSecretId,
                      TmpSecretKey: data.Data.credentials.tmpSecretKey,
                      XCosSecurityToken: data.Data.credentials.sessionToken,
                      ExpiredTime: data.Data.expiredTime
                    })
                  })
                }
            })
            let key = 'game'+ '/' + new Date().getTime() + '-' + file.name //game?
            let _this = this
            cos.sliceUploadFile(
                {
                  Bucket: cosconfig.bucket /* 必须 */,
                  Region:
                    cosconfig.region /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                  Key: key,
                  Body: file /* 必须 */,
                  onProgress: function(progressData) {
                    // that.uploadpercent = progressData.percent * 100
                    /* 非必须 */
                    // console.log(JSON.stringify(progressData));
                  }
                },
                function(err, data) {
                  if (err) {
                    console.error(err)
                    this.$Message.error('上传失败')
                    return
                  }
                   _this.formData.HeadImg = cosconfig.exporturl + '/' + key
                }
            )

        },
        handleView(){},
        handelClickCancel(){
            this.clear()
            this.$emit('closeModifyUser')
        },
        commit(){
             this.$refs['formValidate'].validate((valid) => {
                if (valid) {
                    // debugger
                    let { NickName,HeadImg, Description,UserId,UnionId,Tag} = {...this.formData}
                    if(this.formData.TagId){
                        let TagName = this.tagList.filter(v=> v.Id == this.formData.TagId)[0].Name
                        Tag = {
                            Id:this.formData.TagId,
                            Name: TagName
                        }
                    }else{
                        Tag = {
                            Id:0,
                            Name: ''
                        }
                    }
                    User.saveUserModify({ NickName,HeadImg, Description,UserId,UnionId,Tag}).then(res=>{
                        if(res.Code == 0){
                            this.$Message.success('保存成功');
                            this.clear()
                            this.$emit('closeModifyUser',true)
                        }else{
                            this.$Message.error(res.Message)
                        }
                    })
                }
             })
        },
        clear(){
            for(let key in this.formData){
                this.formData[key]=""
            }
        }
    }
}
</script>
<style lang="less" scoped>
.set_forbiddon_box{
    margin: 0 20px;
}
.demo-upload-list{
    display: inline-block;
        width: 60px;
        height: 60px;
        text-align: center;
        line-height: 60px;
        border: 1px solid transparent;
        border-radius: 4px;
        overflow: hidden;
        background: #fff;
        position: relative;
        box-shadow: 0 1px 1px rgba(0,0,0,.2);
        margin-right: 4px;
}
.demo-upload-list-cover{
    display: none;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0,0,0,.6);
}
</style>