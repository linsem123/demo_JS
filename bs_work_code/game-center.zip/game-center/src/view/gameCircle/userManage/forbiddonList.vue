<template>
    <div>
        <Card>
            <Form ref="formValidate"
                :model="formData"
                :rules="ruleValidate"
                :inline="true"
                >
                <FormItem  prop="UserId">
                    <UserIdSelect v-model="formData.UserId" :width="200"/>
                </FormItem>
                 <FormItem  prop="Cycle" label="禁言类型" :label-width="80">
                     <Select v-model="formData.Cycle"
                        clearable
                        placeholder="请选择"
                        style="width:80px"
                        >
                        <Option :value="1">永久</Option>
                        <Option :value="2">自定义</Option>
                     </Select>
                </FormItem>
                <Button type="primary" @click="toSearch" >查询</Button>
            </Form>
            <Table
                border 
                highlight-row 
                ref="currentRowTable" 
                :columns="columns" 
                :data="tableData"
                :loading="loading"
                :max-height="600"
            >
                <template slot-scope="{ row }" slot="action">
                    <Button type="success" size="small" style="margin-right: 5px" @click="unForbidden(row)">解禁</Button>
                    <Button type="primary" size="small" style="margin-right: 5px" @click="modifyInfo(row)">修改</Button>
                </template>
            </Table>
            <Page show-sizer 
            :total="total" sta
            show-total 
            :page-size="pageSize" 
            :current="pageIndex" 
            @on-change="changePage"
            @on-page-size-change="changePageSize"/>
        </Card>
         <Modal
            v-model="showForbidden"
            title="禁言设置"
            :width="700"
            footer-hide
            :closable="false"
            >
            <setForbidden v-if='showForbidden' :checkedTable="checkedTable" @closeForbidden="closeForbidden" :idModify="true"/>
        </Modal>
    </div>
</template>
<script>
import User from "@/api/gameCircle/userManage";
import Post from "@/api/gameCircle/postManagement";
import UserIdSelect from '@/view/gameCircle/components/UserIdSelect'
import setForbidden from '@/view/gameCircle/components/setForbidden'
import modifyInfo from './modifyInfo'
import common from '@/view/gameCircle/pubFunc/common'
export default {
    name:"forbiddonList",
    data(){
        return{
            loading:false,
            showForbidden:false,
            // showModify:false,
            formData:{
                UserId:undefined,
                Cycle:undefined
            },
            ruleValidate:{},
            columns: [
                {
                    title: '用户昵称',
                    key: 'NickName',
                    align: 'center',
                    minWidth:150
                },
                 {
                    title: '禁言时间',
                    key: 'StartDate',
                    align: 'center',
                    minWidth:150
                },
                {
                    title: '解禁时间',
                    key:'EndDate',
                    align: 'center',
                    minWidth:150
                },
                 {
                    title: '禁言类型',
                    key:'CycleText',
                    align: 'center',
                    minWidth:100
                },
                 {
                    title: '禁言原因',
                    key:'Reason',
                    align: 'center',
                    minWidth:200
                },
                {
                    title: '操作',
                    slot:'action',
                    align: 'center',
                    minWidth:170
                },
            ],
            tableData: [],
            total:0,
            pageIndex:1,
            pageSize:10,
            checkedTable:{}
        }
    },
    components:{
        UserIdSelect,
        setForbidden,
        modifyInfo
    },
    mounted(){
        this.searchServer()
    },
    methods:{
        //解禁
        unForbidden(row){
             this.$Modal.confirm({
                title: '解除禁言',
                content: '<p>确定解除禁言？</p>',
                loading: true,
                onOk: () => {
                    User.delForbiddon(row.UnionId).then(res=>{
                        if(res.Code == 0){
                            this.$Message.success('解禁成功')
                            this.searchServer()
                        }else{
                            this.$Message.error(res.Message)
                        }
                    }).finally(()=>{
                        this.$Modal.remove();
                    })
                },
                onCancel: () => {
                }
            });
        },
        //修改禁言
        modifyInfo(row){
            this.checkedTable = row
            this.showForbidden = true
        },
        closeForbidden(isUpdate){
            if(isUpdate) this.searchServer()
            this.showForbidden=false
        },
        //改页数
        changePage(page){
            this.pageIndex = page
            this.searchServer()
        },
        //改分页条数
        changePageSize(pageSize){
            this.pageSize = pageSize
            this.pageIndex = 1
            this.searchServer()
        },
        //查询
        toSearch(){
           this.pageIndex = 1;
           this.searchServer();
        },
        searchServer(){
             let data = {
                 Params:{
                    UserId:this.formData.UserId,
                    Cycle:this.formData.Cycle,
                 },
                 Page:this.pageIndex,
                 Limit:this.pageSize
            }
            this.loading = true
            User.ForbiddonList(data).then(res=>{
                if(res.Code == 0){
                    //数据处理
                     this.tableData = res.Data.Data.map(v=>{
                         v.EndDate = common.formatDate(v.EndDate,true)
                         v.StartDate = common.formatDate(v.StartDate,true)
                         if(v.Cycle == 1) {v.CycleText = '永久'; v.EndDate = "--"}
                         if(v.Cycle == 2) v.CycleText = '自定义'
                         return v
                     });
                     this.total = res.Data.Count
                }else{ 
                    this.$Message.error(res.Message)
                }
            }).finally(()=>{
                this.loading = false
            })
        }
    }
}
</script>
<style lang="less" scoped>
/deep/ .ivu-page{
    margin: 10px auto;
    display: flex;
    justify-content: center;
}
</style>