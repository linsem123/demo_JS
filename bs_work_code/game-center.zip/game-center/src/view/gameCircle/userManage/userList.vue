<template>
    <div>
        <Card>
            <Form ref="formValidate"
                :model="formData"
                :rules="ruleValidate"
                :inline="true"
               >
                <FormItem  prop="UserId">
                    <UserIdSelect v-model="formData.UserId" :width="200"/>
                </FormItem>
              
                <FormItem label="已设标签用户" prop="HasTag" :label-width="85">
                   <Checkbox v-model="formData.HasTag"/>
                </FormItem>
                <Button type="primary" @click="toSearch" style="margin-right:50px" >查询</Button>
            </Form>
            <Table
                border 
                highlight-row 
                ref="currentRowTable" 
                :columns="columns" 
                :data="tableData"
                :loading="loading"
                :max-height="600"
            >
                <template slot-scope="{ row }" slot="Image">
                    <img :src="row.HeadImg" v-if="row.HeadImg" style="width:30px;height:30px"/>
                </template>
                <template slot-scope="{ row }" slot="action">
                    <Button type="error" size="small" style="margin-right: 5px" @click="Forbidden(row)">禁言</Button>
                    <Button type="success" size="small" style="margin-right: 5px" @click="modifyInfo(row)">修改信息</Button>
                </template>
            </Table>
            <Page show-sizer 
            :total="total" sta
            show-total 
            :page-size="pageSize" 
            :current="pageIndex" 
            @on-change="changePage"
            @on-page-size-change="changePageSize"/>
        </Card>
         <Modal
            v-model="showForbidden"
            title="禁言设置"
            :width="700"
            footer-hide
            :closable="false"
            >
            <setForbidden :checkedTable="checkedTable" @closeForbidden="showForbidden=false" :idModify="false"/>
        </Modal>
         <Modal
            v-model="showModify"
            title="修改用户信息"
            :width="500"
            footer-hide
            :closable="false"
            >
            <modifyInfo v-if='showModify' :checkedTable="checkedTable" :tagList="tagList"  @closeModifyUser="closeModifyUser"/>
        </Modal>
        <Modal title="图片" v-model="visibleImg" footer-hide>
            <img :src="imgName" v-if="visibleImg" style="width: 100%">
        </Modal>
    </div>
</template>
<script>
import User from "@/api/gameCircle/userManage";
import Tags from "@/api/gameCircle/tagsManage";
import UserIdSelect from '@/view/gameCircle/components/UserIdSelect'
import setForbidden from '@/view/gameCircle/components/setForbidden'
import modifyInfo from './modifyInfo'
import common from '@/view/gameCircle/pubFunc/common'
export default {
    name:"",
    data(){
        return{
            loading:false,
            showForbidden:false,//禁言Modal
            showModify:false,//修改用户信息Modal
            visibleImg:false,//图片预览Modal
            imgName:"",
            formData:{
                UserId:undefined,
                HasTag:undefined,
            },
            ruleValidate:{},
            columns: [
                {
                    title: '用户昵称',
                    key: 'NickName',
                    align: 'center',
                    minWidth:150
                },
                {
                    title: '头像',
                    slot: 'Image',
                    align: 'center',
                    minWidth:100,

                },
                 {
                    title: '签名',
                    key: 'Description',
                    align: 'center',
                    minWidth:150
                },
                 {
                    title: '标签',
                    key: 'tagName',
                    align: 'center',
                    minWidth:150
                },
                {
                    title: '操作',
                    slot:'action',
                    align: 'center',
                    minWidth:170
                },
            ],
            tableData: [],
            tagList:[],
            total:0,
            pageIndex:1,
            pageSize:10,
            checkedTable:{}
        }
    },
    components:{
        UserIdSelect,
        setForbidden,
        modifyInfo
    },
    mounted(){
        this.searchServer()
        Tags.getUserTag({}).then(res => {
            this.tagList = res.Data;
        })
    },
    methods:{
        //禁言
        Forbidden(row){
           this.checkedTable = row
           this.showForbidden = true
        },
        //修改用户信息
        modifyInfo(row){
            this.checkedTable = row
            this.showModify = true
        },
        closeModifyUser(idUpdate){
            if(idUpdate) this.searchServer()
            this.showModify=false
        },
        //改页数
        changePage(page){
            this.pageIndex = page
            this.searchServer()
        },
        //改分页条数
        changePageSize(pageSize){
            this.pageSize = pageSize
            this.pageIndex = 1
            this.searchServer()
        },
        //查询
        toSearch(){
           this.pageIndex = 1;
           this.searchServer();
        },
        searchServer(){
             let data = {
                 Params:{
                    UserId:this.formData.UserId,
                    HasTag:this.formData.HasTag?true:undefined,
                 },
                 Page:this.pageIndex,
                 Limit:this.pageSize
            }
            this.loading = true
            User.getUserList(data).then(res=>{
                if(res.Code == 0){
                    //数据处理
                     this.tableData = res.Data.Data.map(v=>{
                        v.tagName = v.Tag.Name
                         return v
                     })
                     this.total = res.Data.Count
                }else{ 
                    this.$Message.error(res.Message)
                }
            }).finally(()=>{
                this.loading = false
            })
        }
    }
}
</script>
<style lang="less" scoped>
/deep/ .ivu-page{
    margin: 10px auto;
    display: flex;
    justify-content: center;
}
</style>