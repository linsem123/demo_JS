<template>
  <div>
    <Card>
      <Form
        ref="formValidate"
        :model="formData"
        :rules="ruleValidate"
        :inline="true"
        style="position: relative"
      >
        <FormItem prop="PostId">
          <gameTitleSelect v-model="formData.PostId" :width="200" />
        </FormItem>
        <FormItem prop="Id">
          <contentSelect v-model="formData.Id" :width="200" :multiple="false" />
        </FormItem>
        <FormItem prop="UnionId">
          <gameUserSelect v-model="formData.UnionId" :width="200" />
        </FormItem>
        <FormItem prop="Time">
          <DatePicker
            v-model="formData.Time"
            type="daterange"
            :options="options"
            placeholder="选择日期"
            style="width: 200px"
            @on-change="changeDate"
          ></DatePicker>
        </FormItem>
        <FormItem label="帖子状态" prop="Status" :label-width="65">
          <Selection v-model="formData.Status" :dataList="statusList" />
        </FormItem>
        <Button type="primary" @click="toSearch" style="margin-right: 50px"
          >查询</Button
        >
      </Form>
      <div style="position: relative">
        <tree-table
          :expand-type="false"
          :selectable="false"
          border
          highlight-row
          ref="currentRowTable"
          :columns="columns"
          :data="tableData"
          :loading="loading"
          :max-height="600"
          :is-fold="false"
          :row-class-name="rowClassName"
        >
          <template slot="Image" slot-scope="{ row }">
            <img
              style="width: 30px; height: 30px"
              :src="row.ImageUrl"
              v-if="row.ImageUrl"
              @click="previewImg(row.ImageUrl)"
            />
          </template>
          <template slot-scope="{ row, index }" slot="Status">
            <span>{{ row.statusText }}</span>
            <Button
              type="primary"
              v-if="row.Status == 1 || row.Status == 2"
              size="small"
              style="margin-left: 10px"
              @click.stop="statusChange(row, index)"
              :loading="statusLoading"
            >
              {{ row.Status | btnText }}
            </Button>
          </template>
          <template slot-scope="{ row, index }" slot="action">
            <Button
              type="primary"
              size="small"
              style="margin-right: 5px"
              @click.stop="discussEvent(row, index)"
              >回复</Button
            >
            <Button
              type="primary"
              size="small"
              style="margin-right: 5px"
              @click.stop="showChild(row)"
              v-show="row.ReplyNum > 0"
              >查看回复</Button
            >
            <Button
              type="success"
              size="small"
              @click.stop="overhead(row, 2)"
              v-show="row.IsTop == 1"
              >置顶</Button
            >

            <Button
              type="primary"
              size="small"
              v-show="row.IsTop == 2"
              @click.stop="overhead(row, 1)"
              >取消置顶</Button
            >
          </template>
        </tree-table>
        <PageLoading v-show="loading" />
      </div>
      <Page
        show-sizer
        :total="total"
        sta
        show-total
        :page-size="pageSize"
        :current="pageIndex"
        @on-change="changePage"
        @on-page-size-change="changePageSize"
      />
    </Card>
    <Modal v-model="showDiscuss" title="评论" :width="700" footer-hide>
      <discussPage
        :checkedTable="checkedTable"
        @closeDiscuss="closeDiscuss"
        :menus="menus"
        :discusstype="false"
        :canAt="false"
      />
    </Modal>
    <Modal title="图片" v-model="visibleImg" footer-hide>
      <img :src="imgName" v-if="visibleImg" style="width: 100%" />
    </Modal>
  </div>
</template>
<script>
import Discuss from "@/api/gameCircle/discussManage";
import gameUserSelect from "@/view/gameCircle/components/gameUserSelect";
import gameTitleSelect from "@/view/gameCircle/components/gameTitleSelect";
import contentSelect from "@/view/gameCircle/components/contentSelect";
import discussPage from "@/view/gameCircle/components/discussPage";
import Selection from "_c/Selection.vue";
import PageLoading from "@/view/gameCircle/components/PageLoading";
import common from "@/view/gameCircle/pubFunc/common";
import TreeTable from "tree-table-vue";
export default {
  name: "discussManage",
  data() {
    return {
      loading: false,
      statusLoading: false,
      showDiscuss: false, //回复Modal
      visibleImg: false, //图片预览Modal
      imgName: "", //图片src
      menus: [], //菜单
      formData: {
        Time: "",
        PostId: undefined,
        Id: undefined,
        PostId: undefined,
        UnionId: undefined,
        status: undefined,
        StartAt: undefined,
        EndAt: undefined,
      },
      ruleValidate: {},
      options: {
        disabledDate(date) {
          return date && date.valueOf() > Date.now();
        },
      },
      columns: [
        {
          title: "帖子标题",
          key: "PostTitle",
          minWidth: 200,
        },
        {
          title: "用户",
          key: "UserName",
          minWidth: 150,
          align: "center",
        },
        {
          title: "IMEI",
          key: "IMEI",
          minWidth: 150,
          align: "center",
        },
        {
          title: "评论内容",
          key: "Content",
          minWidth: 200,
          // tree:true
        },
        {
          title: "楼层",
          key: "Position",
          minWidth: 80,
          align: "center",
          tree: true,
        },
        {
          title: "评论时间",
          key: "creatTime",
          minWidth: 150,
          align: "center",
        },
        {
          title: "图片",
          type: "template",
          template: "Image",
          minWidth: 50,
          align: "center",
        },
        {
          title: "状态",
          type: "template",
          template: "Status",
          minWidth: 150,
          align: "center",
        },
        {
          title: "操作",
          type: "template",
          template: "action",
          minWidth: 220,
          fixed: "right",
          align: "center",
        },
      ],
      tableData: [],
      total: 0,
      pageIndex: 1,
      pageSize: 10,
      statusList: [
        {
          Id: 1,
          Name: "展示",
        },
        {
          Id: 2,
          Name: "隐藏",
        },
        {
          Id: 3,
          Name: "删除",
        },
      ],
      checkedTable: {},
    };
  },
  components: {
    // gameNameSelect,
    gameUserSelect,
    contentSelect,
    Selection,
    discussPage,
    PageLoading,
    TreeTable,
    gameTitleSelect,
  },
  filters: {
    btnText(Status) {
      //状态显示-按钮为隐藏
      //状态隐藏-按钮为显示
      //状态删除 -不展示按钮
      if (Status == 1) return "隐藏";
      if (Status == 2) return "显示";
    },
  },
  mounted() {
    this.searchServer();
  },
  methods: {
    rowClassName(row) {
      //二级加背景色
      if (!row.root) {
        return "demo-table-info-row";
      }
    },
    //查询子级
    showChild(row) {
      this.searchDisply(row.Id, row._normalIndex - 1);
    },
    //预览图片
    previewImg(url) {
      this.visibleImg = true; //图片预览Modal
      this.imgName = url; //图片src
    },
    //状态
    statusChange(row, index) {
      this.statusLoading = true;
      let Status;
      if (row.Status == 1) {
        Status = 2;
      }
      if (row.Status == 2) {
        Status = 1;
      }
      let server = row.root ? "updateDiscussStatus" : "updateReplyStatus";
      Discuss[server](row.Id, Status)
        .then((res) => {
          if (res.Code == 0) {
            this.$Message.success("更改状态成功");
            row.root
              ? this.searchServer()
              : this.searchDisply(row.CommentId, row.parentIndex);
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.statusLoading = false;
        });
    },
    //评论
    discussEvent(row, index) {
      this.checkedTable = row;
      this.showDiscuss = true;
    },
    //选择日期
    changeDate(value) {
      this.formData.StartAt = value[0];
      this.formData.EndAt = value[1];
    },
    //顶置
    overhead(row, type) {
      let Id = row.Id;
      let server = row.root ? "headoverDiscuss" : "headoverReply";
      Discuss[server](Id, type).then((res) => {
        if (res.Code == 0) {
          this.$Message.success("顶置成功");
          row.root
            ? this.searchServer()
            : this.searchDisply(row.CommentId, row.parentIndex);
        } else {
          this.$Message.error(res.Message);
        }
      });
    },
    //评论成功/取消
    closeDiscuss(value) {
      this.showDiscuss = false;
      if (!value.isClose) {
        value.row.root
          ? this.searchDisply(value.row.Id, value.row._normalIndex - 1)
          : this.searchDisply(value.row.CommentId, value.row.parentIndex);
      }
    },
    //改页数
    changePage(page) {
      this.pageIndex = page;
      this.searchServer();
    },
    //改分页条数
    changePageSize(pageSize) {
      this.pageSize = pageSize;
      this.pageIndex = 1;
      this.searchServer();
    },
    //查询
    toSearch() {
      this.pageIndex = 1;
      this.searchServer();
    },
    searchServer() {
      let StartAt = this.formData.StartAt
        ? common.toDate(this.formData.StartAt)
        : undefined;
      let EndAt = this.formData.EndAt
        ? common.toDate(this.formData.EndAt)
        : undefined;
      let { PostId, Id, UnionId, Status, Page, Limit } = {
        ...this.formData,
        Page: this.pageIndex,
        Limit: this.pageSize,
      };
      this.loading = true;
      Discuss.getDiscussList({
        PostId,
        Id,
        UnionId,
        Status,
        StartAt,
        EndAt,
        Page,
        Limit,
      })
        .then((res) => {
          if (res.Code == 0) {
            //数据处理
            this.tableData = res.Data.Data.map((v) => {
              v.statusText = this.statusList.filter(
                (item) => item.Id == v.Status
              )[0].Name;
              v.creatTime = common.formatDate(v.CreatedAt, true);
              v.root = true;
              v.showReplay = true;
              v.children = []; //初始化children
              return v;
            });
            this.total = res.Data.Count;
          } else {
            this.$Message.error(res.Message);
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
    searchDisply(CommentId, parentIndex) {
      this.loading = true;
      Discuss.getReplayList(CommentId)
        .then((res) => {
          if (res.Code == 0) {
            this.tableData[parentIndex].children = [];
            res.Data.forEach((v) => {
              v.statusText = this.statusList.filter(
                (item) => item.Id == v.Status
              )[0].Name;
              v.creatTime = common.formatDate(v.CreatedAt, true);
              v.parentIndex = parentIndex;
              v.CommentId = CommentId;
              v.root = false;
              this.tableData[parentIndex].children.push(v);
            });
            this.tableData[parentIndex].showReplay = false;
          }
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
<style lang="less" scoped>
/deep/ .ivu-page {
  margin: 10px auto;
  display: flex;
  justify-content: center;
}
/deep/ .zk-table__body .demo-table-info-row {
  background: #deeecb;
  &:hover {
    background: #ebf7ff;
  }
}
</style>