<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.title.loading"
              clearable
              filterable
              remote
              :remote-method="handleTitleSearch"
              placeholder="请输入壁纸标题"
            >
              <Option
                v-for="item in searchform.title.data"
                :value="item.ID"
                :key="item.ID"
              >{{ item.Title }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Select
              v-model="searchform.params.group_id"
              :loading="searchform.game_title.loading"
              clearable
              filterable
              remote
              :remote-method="handleGroupTitleSearch"
              placeholder="请输入游戏组"
            >
              <Option
                v-for="item in searchform.game_title.data"
                :value="item.ID"
                :key="item.ID"
              >{{ item.Title }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Select v-model="searchform.params.status" multiple placeholder="请选择状态">
              <Option
                v-for="item in statusList"
                :value="item.value"
                :key="item.value"
              >{{ item.label }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
        </Row>
      </div>
      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      ></Table>
      <div style="margin: 10px;overflow: hidden">
        <div style="float: left">
          <Button type="info" shape="circle" icon="plus-round" @click="openAdd">新增</Button>
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
      <Modal title="预览" v-model="preview_visible" size="small" width='250px'>
        <video
          id="preview_video"
          v-if="preview_type=='video'"
          style="width: 100%;height:100%;"
          controls
          :src="preview_url"
        />
        <img
          id="preview_img"
          v-if="preview_type=='img'"
          style="height:100%;width:100%"
          :src="preview_url"
        >
      </Modal>
    </Card>
    <check-status ref="checkstatus" @onClose="closeCheckStatus"/>
  </div>
</template>

<script>
import Tables from "_c/tables";
import CheckStatus from "_c/lockscreen/wallpaper/status";
import Lockscreen from "@/api/lockscreen";
import { formatDate, AssertVideo } from "@/libs/tools";
export default {
  components: {
    CheckStatus
  },
  name: "wallpaper",
  data() {
    return {
      preview_visible: false,
      preview_type: "",
      preview_url: "",
      statusList: [
        { value: 0, label: "未审核" },
        { value: 1, label: "审核成功" },
        { value: -1, label: "审核失败" }
      ],
      searchform: {
        params: { id: undefined, group_id: undefined, status: [] },
        page: {
          total: 100,
          current: 1,
          size: 10
        },
        title: {
          loading: false,
          data: []
        },
        game_title: {
          loading: false,
          data: []
        }
      },
      table: {
        loading: false,
        data: [],
        columns: [
          { title: "游戏组名", width: 150, key: "GroupTitle" },
          //  { title: "游戏是否启用", key: "GameEnable", enable: true },
          {
            title: "壁纸",
            key: "Title",
            width: 150,
            render: (h, params) => {
              return h(
                "Button",
                {
                  props: { type: "dashed" },
                  on: {
                    click: () => {
                      this.handleView(params);
                    }
                  }
                },
                params.row.Title
              );
            }
          },
          { title: "是否启用", width: 100, key: "Enable", enable: true },
          {
            title: "当前状态",
            width: 100,
            key: "Status",
            render: (h, params) => {
              let color = "";
              let txt = "";
              if (params.row.Status == 0) {
                color = "warning";
                txt = "未审核";
              }
              if (params.row.Status == 1) {
                color = "success";
                txt = "审核成功";
              }
              if (params.row.Status == -1) {
                color = "error";
                txt = "审核失败";
              }
              return h(
                "Button",
                {
                  props: { color: color, size: "small" },
                  on: {
                    click: () => {
                      this.$refs.checkstatus.show(
                        params.row.ID,
                        params.row.Status,
                        params.row.Opinion
                      );
                    }
                  }
                },
                txt
              );
            }
          },
          {
            title: "壁纸按钮",
            width: 200,
            render: (h, params) => {
              const div = [];
              if (params.row.IconURL != "") {
                let icon = h("Avatar", {
                  props: {
                    shape: "square",
                    src: params.row.IconURL,
                    size: "small"
                  },
                  style: {
                    marginRight: "5px"
                  }
                });
                div.push(icon);
              }
              if (params.row.ButtonText != "") {
                let tag = h("Tag", { props: {} }, params.row.ButtonText);
                div.push(tag);
              }
              return h("div", div);
            }
          },
          {
            title: "生效时间",
            key: "Status",
            width: 150,
            render: (h, params) => {
              return h("div", [
                h(
                  "Tag",
                  { props: { color: "default" } },
                  formatDate(params.row.ExpiredStart)
                ),
                h(
                  "Tag",
                  { props: { color: "default" } },
                  formatDate(params.row.ExpiredEnd)
                )
              ]);
            }
          },
          // { title: "创建时间", key: "CreatedAt", width: 150, timeformat: true },
          {
            title: "操作",
            key: "handle",
            options: ["edit"],
            button: [
              (h, param, vm) => {
                return h(
                  "Poptip",
                  {
                    props: {
                      confirm: true,
                      title: "你确定要置顶吗?"
                    },
                    on: {
                      "on-ok": () => {
                        this.rank(param);
                      }
                    }
                  },
                  [
                    h(
                      "Button",
                      {
                        props: {
                          type: "warning",
                          size: "small",
                          disabled: !param.row.Enable || !param.row.GameEnable
                          // ghost: true
                        },
                        style: {
                          marginRight: "5px"
                        }
                      },
                      "置顶"
                    )
                  ]
                );
              }
            ]
          }
        ]
      }
    };
  },
  methods: {
    handleTitleSearch(value) {
      Lockscreen.Wallpaper.LikeTitle({ value }).then(res => {
        this.searchform.title.data = res.Data;
      });
    },
    handleGroupTitleSearch(value) {
      Lockscreen.GameGroup.LikeTitle({ value }).then(res => {
        this.searchform.game_title.data = res.Data;
      });
    },
    handleView(params) {
      const t = AssertVideo(params.row.URL);
      this.preview_type = t;
      const url = params.row.URL;
      this.preview_url = url;
      this.preview_visible = true;
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    edit(params) {
      this.$router.push({
        name: "wallpaper_edit",
        params: { id: params.row.ID }
      });
    },
    enable(param) {
      Lockscreen.Wallpaper.Enable(param.row.ID, !param.row.Enable).then(res => {
        this.init();
      });
    },
    rank(param) {
      Lockscreen.Wallpaper.Rank(param.row.ID).then(res => {
        this.init();
      });
    },
    closeCheckStatus() {
      this.init();
    },
    init() {
      Lockscreen.Wallpaper.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then(res => {
        this.table.data = res.Data.Data;
        this.searchform.page.total = res.Data.Count;
      });
    },
    openAdd() {
      this.$router.push({
        name: "wallpaper_add"
      });
    }
  },
  mounted() {
    this.table.columns = Tables.RenderColumns(this.table.columns, this);
    this.$on("on-enable", this.enable);
    this.$on("on-edit", this.edit);
    this.init();
  },
  activated() {
    
     this.init();
  }
};
</script>