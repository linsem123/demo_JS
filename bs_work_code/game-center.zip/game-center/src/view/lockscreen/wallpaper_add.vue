<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>添加壁纸
    </p>
    <wallpaper-form @on-form-submit="handleSubmit"></wallpaper-form>
  </Card>
</template>
<script>
import Wallpaper from "@/api/lockscreen/wallpaper";
import WallpaperForm from "_c/lockscreen/wallpaper/form";
import { mapMutations} from 'vuex'
export default {
  name: "AddWallpaper",
  components: {
    WallpaperForm
  },
  data() {
    return {

    }
  },
  methods: {
    ...mapMutations([
      'closeTag'
    ]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      Wallpaper.Add(formScope).then(res => {
        this.$Loading.finish();
        this.loading = false;
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "添加壁纸成功"
        });
        this.closeTag(this.$route);
        // this.$emit("on-close", undefined, undefined, this.$route);
        this.$router.push({
          name: "wallpaper"
        });
      });
    }
  }
};
</script>