<template>
  <div>
    <Card>
      <div style="margin: 10px">
        <Row :gutter="10">
          <Col span="6">
            <Select
              v-model="searchform.params.id"
              :loading="searchform.title.loading"
              clearable
              filterable
              remote
              :remote-method="handleTitleSearch"
              placeholder="请输入游戏组"
            >
              <Option
                v-for="item in searchform.title.data"
                :value="item.ID"
                :key="item.ID"
              >{{ item.Title }}</Option>
            </Select>
          </Col>
          <Col span="6">
            <Button type="success" shape="circle" icon="ios-search" @click="init">搜索</Button>
          </Col>
        </Row>
      </div>
      <Table
        :loading="table.loading"
        border
        ref="selection"
        :columns="table.columns"
        :data="table.data"
      ></Table>
      <div style="margin: 10px;overflow: hidden">
        <div style="float: left">
          <Button type="info" shape="circle" icon="plus-round" @click="openAdd">新增</Button>
        </div>
        <div style="float: right">
          <Page
            :total="searchform.page.total"
            :current="searchform.page.current"
            :page-size="searchform.page.size"
            @on-change="onPageChange"
            @on-page-size-change="onPageSizechange"
            show-sizer
            show-total
          ></Page>
        </div>
      </div>
    </Card>
    <add ref="add" @onClose="closeAdd"/>
    <edit ref="edit" @onClose="closeAdd"/>
  </div>
</template>

<script>
import Tables from "_c/tables";
import lockscreen from "_c/lockscreen/gamegroup";
import GameGroup from "@/api/lockscreen/gamegroup";
export default {
  components: {
    Add: lockscreen.Add,
    Edit: lockscreen.Edit
  },
  name: "gamegroup",
  data() {
    return {
      searchform: {
        params: { id: undefined },
        page: {
          total: 100,
          current: 1,
          size: 10
        },
        title: {
          loading: false,
          data: []
        }
      },
      table: {
        loading: false,
        data: [],
        columns: [
          { title: "游戏组名", key: "Title" },
          { title: "是否启用", key: "Enable", enable: true },
          {
            title: "创建时间",
            key: "CreatedAt",
            timeformat: true
            // render: Tables.Renders.formatTime
          },
          {
            title: "操作",
            key: "handle",
            options: ["edit", ["enable"]]
            // render:Tables.Renders.handleBtn
          }
        ]
      }
    };
  },
  methods: {
    handleTitleSearch(value) {
      GameGroup.LikeTitle({ value }).then(res => {
        this.searchform.title.data = res.Data;
      });
    },
    onPageChange(value) {
      this.searchform.page.current = value;
      this.init();
    },
    onPageSizechange(value) {
      this.searchform.page.size = value;
      this.init();
    },
    edit(param) {
      this.$refs.edit.show(param.row.ID, param.row.Title);
    },
    enable(param) {
      GameGroup.Enable(param.row.ID, !param.row.Enable).then(res => {
        this.init();
      });
    },
    delete(param) {
      console.log(param);
    },
    init() {
      GameGroup.FindByPage(
        this.searchform.page.size,
        this.searchform.page.current,
        this.searchform.params
      ).then(res => {
        this.table.data = res.Data.Data;
        this.searchform.page.total = res.Data.Count;
      });
    },
    openAdd() {
      console.log("openadd");
      this.$refs.add.show();
    },
    closeAdd() {
      this.init();
    }
  },
  mounted() {
    this.table.columns = Tables.RenderColumns(this.table.columns, this);
    this.$on("on-enable", this.enable);
    this.$on("on-delete", this.delete);
    this.$on("on-edit", this.edit);
    this.init();
    //注册监听事件
  },activated() {
     this.init();
  }
};
</script>