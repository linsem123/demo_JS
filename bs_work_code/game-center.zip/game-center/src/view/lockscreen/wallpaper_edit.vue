<template>
  <Card>
    <p slot="title">
      <Icon type="information-circled"></Icon>编辑壁纸-{{Title}}
    </p>
    <wallpaper-form @on-form-submit="handleSubmit" :formScope="formScope"></wallpaper-form>
  </Card>
</template>
<script>
import Wallpaper from "@/api/lockscreen/wallpaper";
import WallpaperForm from "_c/lockscreen/wallpaper/form";
import { mapMutations } from "vuex";
export default {
  name: "EditWallpaper",
  components: {
    WallpaperForm
  },
  data() {
    return {
      Title:"",
      formScope: {
        type: Object
      }
    };
  },
  methods: {
    ...mapMutations(["closeTag"]),
    handleSubmit(formScope) {
      this.$Loading.start();
      this.loading = true;
      Wallpaper.Edit(formScope).then(res => {
        this.$Loading.finish();
        this.loading = false;
        if (res.error > 0) {
          this.$Message.warning(res.Message);
          return;
        }
        this.$Notice.success({
          title: "更新壁纸成功"
        });
        this.close();
      });
    },
    close() {
      this.closeTag(this.$route);
      // this.$emit("on-close", undefined, undefined, this.$route);
      this.$router.push({
        name: "wallpaper"
      });
    }
  },
  mounted() {
    Wallpaper.Get(this.$route.params.id).then(res => {
      if (res.error > 0) {
        this.$Message.warning(res.Message);
        return;
      }
      this.formScope = res.Data;
      this.Title=res.Data.Title;
    });
  }
};
</script>