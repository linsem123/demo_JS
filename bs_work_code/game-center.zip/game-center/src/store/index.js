import Vue from 'vue'
import Vuex from 'vuex'

import user from './module/user'
import app from './module/app'
import permission from './module/permission'
import tagsView from './module/tagsView'
import getters from './getters'
import config from './module/config'

Vue.use(Vuex)

export default new Vuex.Store({
    state: {
        //
    },
    getters,
    mutations: {
        //
    },
    actions: {
        //
    },
    modules: {
        user,
        app,
        permission,
        tagsView,
        config
    }
})