import API from '@/api/common'

export default {
    state: {
        CDNConfig: {}
    },
    mutations: {
        setConfig(state, config) {
            if (Object.keys(config).length > 0) {
                state.CDNConfig.bucket = config.Bucket
                state.CDNConfig.region = config.Region
                state.CDNConfig.exporturl = config.ExportURL
                state.CDNConfig.tencentExporturl = config.TencentExporturl
            }
        },
    },
    actions: {
        getConfig({ commit }) {
            API.getCDNConfig().then(res => {
                if (res.Code == 0) {
                    let Data = res.Data || {}
                    commit('setConfig', Data)
                }
            })
        },
    }
}