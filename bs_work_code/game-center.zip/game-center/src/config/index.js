export default {
    /**
     * @description 配置显示在浏览器标签的title
     */
    title: '黑鲨游戏中心运营平台',
    /**
     * @description token在Cookie中存储的天数，默认1天
     */

    cookieExpires: 1,
    /**
     * @description 是否使用国际化，默认为false
     *              如果不使用，则需要在路由中给需要在菜单中展示的路由设置meta: {title: 'xxx'}
     *              用来在菜单中显示文字
     */
    // useI18n: true,
    /**
     * @description api请求基础路径
     */
    baseUrl: {
        // dev: "http://10.0.12.220:8888",
        dev: 'https://dcms.blackshark.com',
        pro: ''
    },
    //授权地址
    authUrl: {
        // dev: "http://10.0.67.40:8888",
        dev: 'http://203.195.162.233:4399',
        pro: 'http://203.195.162.233:4444'
    },
    cos: {
        dev: {
            region: "ap-guangzhou",
            bucket: "activity-1256119282",
            exporturl: "https://cdn-activity.blackshark.com",//金山
            tencentExporturl: 'https://activity-1256119282.file.myqcloud.com'//腾讯
        },
        pro: {
            region: "ap-shanghai",
            bucket: "marketing-1256119282",
            exporturl: "https://cdn-market.blackshark.com",
            tencentExporturl: 'https://marketing-1256119282.file.myqcloud.com'
        }
    },
    /**
     * @description 默认打开的首页的路由name值，默认为home
     */
    homeName: 'developer_manage',
    /**
     * @description 需要加载的插件
     */
    plugin: {
        'error-store': {
            showInHeader: true, // 设为false后不会在顶部显示错误日志徽标
            developmentOff: true // 设为true后在开发环境不会收集错误信息，方便开发中排查错误
        }
    },
    fileBaseUrl: window.location.origin + '/v1/api/gamecenter' //下载文件baseurl
}