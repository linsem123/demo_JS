<template>
  <div id="app">
    <router-view v-if="isRouterAlive" />
  </div>
</template>

<script>
import api from "./api";
import config from "@/config";
import {
  setTagNavListInLocalstorage,
  getTagNavListFromLocalstorage,
} from "./libs/util";
const authUrl =
  process.env.NODE_ENV === "development"
    ? config.authUrl.dev
    : config.authUrl.pro;
var qs = require("qs");
export default {
  name: "App",
  provide() {
    return {
      reload: this.reload,
    };
  },
  data() {
    return {
      isRouterAlive: true, //控制视图是否显示的变量
    };
  },
  mounted() {
    this.$store.dispatch("getConfig");
  },
  methods: {
    reload() {
      this.isRouterAlive = false; //先关闭，
      this.$nextTick(function () {
        this.isRouterAlive = true; //再打开
      });
    },
    //获取
  },
};
</script>

<style lang="less">
.size {
  width: 100%;
  height: 100%;
}
html,
body {
  .size;
  overflow: hidden;
  margin: 0;
  padding: 0;
}
#app {
  .size;
}
</style>
