import {
    constantRoutes,
    routes,
    asyncRoutes
} from './routers'
import store from '@/store'
import iView from 'iview'
import { setToken, getToken, setTitle, getMenu } from '@/libs/util'
import config from '@/config'
const { homeName } = config
import { getAppMenuAuthority } from "@/api/user"
import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)
// Vue.use(Router)
// const router = new Router({
//     routes,
//     // mode: 'history'
// })
const createRouter = () => new Router({
    // mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: [...constantRoutes]
})

const router = createRouter()
// export function resetRouter() {
//     const newRouter = createRouter()
//     router.matcher = newRouter.matcher // reset router
// }

// 解决跳转同一个路由报错
const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err)
}
const LOGIN_PAGE_NAME = 'login'
// const token = getToken()
const whiteList = [] // 无需权限路由集合
router.beforeEach(async (to, from, next) => {
    // 开始加载进度条
    iView.LoadingBar.start()

    // 设置页面title
    document.title = to.meta.title + ' -' + config.title
    // 确定用户是否已登录

    const isLogin = store.getters.isLogin
    let token = getToken()
    if (token && isLogin) { // 判断是否有token

        if (to.name === 'login') {
            // 如果已登录，重定向到主页
            next({ name: homeName })
            // next({ name: gamespace_game })
            // 停止加载进度条
            iView.LoadingBar.finish()
        } else {
            const newAddRoutes = store.state.permission.addRoutes && store.state.permission.addRoutes.length > 0
            const hasRoles = store.state.user.menus && store.state.user.menus.length > 0 ? true : false
            if (hasRoles && newAddRoutes) {
                let item = {
                    fullPath: to.fullPath,
                    meta: to.meta,
                    name: to.name,
                    path: to.path
                }
                // 增加tab多页签数据
                store.dispatch('tagsView/pushRouter', item)
                next()
            } else {
                try {
                    // 获取用户信息 这里可以进行一些操作
                    let menus = null
                    // if (process.env.NODE_ENV === 'development') {
                    // menus = asyncRoutes.map(item => {
                    //     return item.name
                    // })
                    // console.log(0)
                    // sessionStorage.setItem('userMenus', JSON.stringify(menuList))
                    // store.commit('permission/setUserMenus', JSON.stringify(menuList))
                    // } else {
                    menus = await getMenu()
                    if (menus.length == 0) {
                        iView.LoadingBar.finish()
                        iView.Modal.warning({
                            title: "提示",
                            content: "权限不足，请联系管理员",
                            onOk: () => {
                                window.open("/", "Main")
                            },
                        });
                        return;
                    }

                    // }

                    const addrouters = await store.dispatch('permission/generateRoutes', menus)

                    // console.log(addrouters.length)
                    // if (addrouters.length == 0) {
                    //     next({ name: homeName })
                    //     iView.LoadingBar.finish()
                    // }
                    // 增加异步路由

                    router.options.routes = []
                    router.addRoutes(store.state.permission.routes)
                    router.options.routes = store.state.permission.routes
                    router.addRoutes(routes)
                    // hack方法，以确保addRoutes是完整的
                    // 设置replace：true，导航不会留下历史记录
                    next({ ...to, replace: true })
                    // iView.LoadingBar.finish()


                } catch (error) {
                    // 删除token并进入登录页面以重新登录
                    // await store.dispatch('user/resetToken')
                    iView.Message.error(error || 'Has Error')
                    // next({ name: LOGIN_PAGE_NAME })
                    // 停止加载进度条
                    iView.LoadingBar.finish()
                }

            }

            // 确定用户是否已通过getInfo获得其权限角色
        }


    } else {
        /* 没有 token*/

        if (whiteList.indexOf(to.path) !== -1) {
            // console.log(555)
            // 免权限直接进入
            next()
        } else {
            console.log(222)
            // 其他无权访问的页面将重定向到登录页面
            window.open("/#/login", "_parent")
            // next({
            //         path: '' + LOGIN_PAGE_NAME
            //     })
            // 停止加载进度条
            iView.LoadingBar.finish()
        }
    }

})

router.afterEach(to => {
    setTitle(to, router.app)
    iView.LoadingBar.finish()
    window.scrollTo(0, 0)

})



export default router