import Main from '@/components/main'
import parentView from '@/components/parent-view'
export default {
    router: [
        /*福利管理*/
        {
            path: 'gamespace_fulimanage',
            name: 'gamespace_fulimanage',
            meta: {
                icon: 'ios-pricetags-outline',
                title: '福利管理',
            },
            component: Main,
            children: [{
                path: '/gamespace/gamepaper/list',
                name: 'gamespace_gamepaper_list',
                meta: {
                    icon: 'ios-book',
                    title: '文章列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/gamepaper/list')
            },
            {
                path: '/gamespace/awardspool/list',
                name: 'gamespace_awardspool_list',
                meta: {
                    icon: 'logo-bitcoin',
                    title: '奖池列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/awardspool/list')
            },
            {
                path: '/gamespace/newawards',
                name: 'gamespace_newawards',
                meta: {
                    icon: 'logo-bitcoin',
                    title: '奖池列表(new)',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/newawards/index')
            },
            {
                path: '/gamespace/activity/list',
                name: 'gamespace_activity_list',
                meta: {
                    icon: 'ios-paper-outline',
                    title: '活动榜单',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/activity/activity-list')
            },
            {
                path: '/gamespace/activity/data',
                name: 'gamespace_activity_data',
                meta: {
                    icon: 'ios-paper-outline',
                    title: '活动列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/activity/activity-data')
            },
            {
                path: '/gamespace/public/activity',
                name: 'gamespace_public_activity',
                meta: {
                    icon: 'ios-document-outline',
                    title: '宣传活动列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/public-activity/index')
            },
            {
                path: '/gamespace/key/games',
                name: 'gamespace_key_games',
                meta: {
                    icon: 'ios-document-outline',
                    title: '重点游戏宣传列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/key-games/index')
            },
            {
                path: '/gamespace/gamespace_gift',
                name: 'gamespace_gift',
                meta: {
                    icon: 'ios-photos',
                    title: '礼包管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/gift/list')
            },
            {
                path: '/gamespace/gift_rank',
                name: 'gamespace_giftrank',
                meta: {
                    icon: 'md-list',
                    title: '礼包榜单',
                },
                component: () =>
                    import('@/view/gamespace/gift/rank')
            },
            // {
            //     path: '/gamespace/coupon/manage',
            //     name: 'gamespace_coupon_lmanage',
            //     meta: {
            //         icon: 'md-cash',
            //         title: '优惠券管理',
            //     },
            //     component: parentView,
            //     children: [
            {
                path: '/gamespace/coupon/list',
                name: 'gamespace_coupon_list',
                meta: {
                    icon: 'md-cash',
                    title: '优惠券列表',
                },
                component: () =>
                    import('@/view/gamespace/coupon/coupon-list')
            },
            {
                path: '/gamespace/coupon/autoCouponList',
                name: 'gamespace_autocoupon_list',
                meta: {
                    icon: 'md-cash',
                    title: '自动创建优惠券列表',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/coupon/auto-coupon-list')
            },
            {
                path: '/gamespace/cashback',
                name: 'gamespace_cashback',
                meta: {
                    icon: 'md-cash',
                    title: '消费返利',
                },
                component: () =>
                    import('@/view/gamespace/cashBack/index')
            },
            {
                path: '/gamespace/coupon/task',
                name: 'gamespace_coupon_task',
                meta: {
                    icon: 'md-cash',
                    title: '优惠券任务',
                },
                component: () =>
                    import('@/view/gamespace/coupon/coupon-task')
            },
            {
                path: '/gamespace/coupon/new_task',
                name: 'gamespace_coupon_new_task',
                meta: {
                    icon: 'md-cash',
                    title: '优惠券任务(new)',
                },
                component: () =>
                    import('@/view/gamespace/coupon/coupon-task/index')
            },
            {
                path: '/gamespace/coupon/new_task/edit',
                name: 'coupon_new_task_edit',
                meta: {
                    icon: 'md-cash',
                    title: '编辑优惠券任务(new)',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/coupon/coupon-task/form')
            },
            {
                path: '/gamespace/coupon/rank',
                name: 'gamespace_coupon_rank',
                meta: {
                    icon: 'ios-paper',
                    title: '优惠券榜单',
                },
                component: () =>
                    import('@/view/gamespace/coupon/coupon-rank')
            },
            {
                path: '/gamespace/coupon/shark_rank',
                name: 'gamespace_shark_coupon_rank',
                meta: {
                    icon: 'ios-paper',
                    title: '鲨享券榜单',
                },
                component: () =>
                    import('@/view/gamespace/coupon/coupon-shark-rank')
            },
            {
                path: '/gamespace/limits/rank',
                name: 'gamespace_limits_rank',
                meta: {
                    icon: 'ios-document-outline',
                    title: '黑白榜单',
                },
                component: () =>
                    import('@/view/gamespace/coupon/limits-rank')
            },

            {
                path: '/gamepromotion/sdk/daily_sign_in',
                name: 'daily_sign_in',
                meta: {
                    icon: 'ios-keypad-outline',
                    title: '每日签到管理',
                    hideInMenu: false
                },
                component: () =>
                    import('@/view/gamespace/daily-sign-in/index')
            },


            {
                path: '/gamespace/limits/game/:id',
                name: 'gamespace_limits_game',
                meta: {
                    icon: 'ios-paper',
                    title: '黑白榜单游戏管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/coupon/limits-game')
            },

            //     ]
            // },

            {
                path: '/gamespace/gamepaper/add',
                name: 'gamespace_gamepaper_add',
                meta: {
                    icon: 'md-trending-up',
                    title: '添加文章',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gamepaper/add')
            }, {
                path: '/gamespace/gamepaper/edit/:id',
                name: 'gamespace_gamepaper_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '文章编辑',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gamepaper/edit')
            },

            {
                path: '/gamespace/edittemplate/:id/:title',
                name: 'gamespace_edittemplate_list',
                meta: {
                    icon: 'md-trending-up',
                    title: '编辑模板',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/awardspool/edit-template')
            },
            {
                path: '/gamespace/downtemplate/:id/:title',
                name: 'gamespace_downtemplate_list',
                meta: {
                    icon: 'md-trending-up',
                    title: '编辑模板',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/public-activity/down-template')
            },
            {
                path: '/gamespace/keygames/:id/:title',
                name: 'gamespace_keygames_list',
                meta: {
                    icon: 'md-trending-up',
                    title: '编辑模板',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/key-games/page-template')
            },
            {
                path: '/gamespace/awardstemplate/:id/:title',
                name: 'newawards_template',
                meta: {
                    icon: 'md-trending-up',
                    title: '编辑模板',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/newawards/edit-template')
            },



            ]
        }
    ]
}
