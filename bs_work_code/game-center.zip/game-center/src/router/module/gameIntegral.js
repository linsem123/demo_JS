import Main from '@/components/main'
import noCacheView from '@/view/gameCircle/components/noCacheView'
// import postManage from '@/view/gameCircle/postManage/index'
const gameIntegral = {
    path: '/gameIntegral',
    name: 'gameIntegral',
    component: Main,
    meta: {
        icon: 'md-people',
        title: '积分系统'
    },
    children: [
        {
            path: '/taskConfig',
            name: 'taskConfig',
            meta: {
                icon: 'ios-aperture-outline',
                title: '积分任务配置',
                notCache: true
            },
            component: () =>
                import('@/view/gameIntegral/taskConfig/index')
        },
    ]
}

export default {
    router: [
        gameIntegral
    ]
}