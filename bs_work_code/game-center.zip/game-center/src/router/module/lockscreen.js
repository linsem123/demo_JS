import Main from '@/components/main'
import parentView from '@/components/parent-view'

const lockscreen = {
    path: '/lockscreen',
    name: 'lockscreen',
    component: Main,
    meta: {
        icon: 'logo-buffer',
        title: '游戏画报'
    },
    children: [{
        path: 'gamegroup',
        name: 'gamegroup',
        meta: {
            icon: 'md-apps',
            title: '游戏组管理',
        },
        component: () =>
            import('@/view/lockscreen/gamegroup')
    }, {
        path: 'wallpaper',
        name: 'wallpaper',
        meta: {
            icon: 'md-image',
            title: '壁纸管理',
        },
        component: () =>
            import('@/view/lockscreen/wallpaper')
    }, {
        path: 'wallpaper_add',
        name: 'wallpaper_add',
        meta: {
            hideInMenu: true,
            title: '添加壁纸',
            notCache: true,
            icon: 'md-trending-u'
        },
        component: () =>
            import('@/view/lockscreen/wallpaper_add')
    }, {
        path: 'wallpaper_edit/:id',
        name: 'wallpaper_edit',
        meta: {
            hideInMenu: true,
            title: '编辑壁纸',
            notCache: true,
            icon: 'md-trending-u'
        },
        component: () =>
            import('@/view/lockscreen/wallpaper_edit')
    }]
};

export default {
    router: [
        lockscreen
    ]
}