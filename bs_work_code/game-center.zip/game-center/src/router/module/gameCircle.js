import Main from '@/components/main'

export default {
    router: [
        {
            path: '/gameCircle',
            name: "gameCircle",
            component: Main,
            meta: {
                icon: 'md-people',
                title: '游戏圈'
            },
            children: [{
                path: 'postManage',
                name: 'postManage',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '论坛帖管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/postManage/index')
            },
            {
                path: '/gameCircle/createpost',
                name: 'gameCircle_createpost',
                meta: {
                    icon: 'ios-game-controller-b-outline',
                    title: '发帖',
                    hideInMenu: true,
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/postManage/createPost'),
            }, {
                path: '/gameCircle/editpost/:id',
                name: 'gameCircle_editpost',
                meta: {
                    icon: 'ios-game-controller-b-outline',
                    title: '编辑帖子',
                    hideInMenu: true,
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/postManage/editPost'),
            },
            {
                path: '/gameCircle/recommend',
                name: 'gameCircle_recommend',
                meta: {
                    icon: 'ios-game-controller-b-outline',
                    title: '推荐帖管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/recommendPost/index.vue'),
            },
            {
                path: '/discussManage',
                name: 'discussManage',
                meta: {
                    icon: 'ios-chatboxes-outline',
                    title: '论坛帖评论管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/discussManage/index')
            },
            {
                path: '/userManage/userList',
                name: 'userList',
                meta: {
                    icon: 'md-settings',
                    title: '用户列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/userManage/userList')
            },
            {
                path: '/userManage/forbiddonList',
                name: 'forbiddonList',
                meta: {
                    icon: 'md-settings',
                    title: '禁言列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/userManage/forbiddonList')
            },
            {
                path: '/tagsManage',
                name: 'tagsManage',
                meta: {
                    icon: 'ios-game-controller-b-outline',
                    title: '游戏圈管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/tagsManage/index')
            },
            {
                path: '/senstiveManage',
                name: 'senstiveManage',
                meta: {
                    icon: 'ios-alert-outline',
                    title: '敏感词管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/senstiveManage/index')
            },
            {
                path: '/whiteList',
                name: 'whiteList',
                meta: {
                    icon: 'ios-alert-outline',
                    title: '供应商白名单管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/whiteList/index')
            },
            {
                path: '/coverManage',
                name: 'coverManage',
                meta: {
                    icon: 'ios-alert-outline',
                    title: '圈子封面管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/coverManage/index')
            },
            {
                path: '/strategyStation',
                name: 'strategyStation',
                meta: {
                    icon: 'ios-alert-outline',
                    title: '游戏攻略站管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gameCircle/strategyStation/index')
            },
            ]
        }
    ]
}