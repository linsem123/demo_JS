import Main from '@/components/main'
import parentView from '@/components/parent-view'
export default {
    router: [
        /*游戏管理*/
        {
            path: 'gamespace_gamemanage',
            name: 'gamespace_gamemanage',
            meta: {
                icon: 'ios-game-controller-b-outline',
                title: '游戏管理',
            },
            component: Main,
            children: [{
                path: '/gamespace/game',
                name: 'gamespace_game',
                meta: {
                    icon: 'ios-game-controller-a',
                    title: '游戏管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/game/list')
            },
            {
                path: '/gamespace/gameversion',
                name: 'gamespace_gameversion',
                meta: {
                    icon: 'ios-send',
                    title: '游戏发布',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/gameversion/list')
            },
            {
                path: '/gamespace/gametime',
                name: 'gamespace_gametime',
                meta: {
                    icon: 'ios-send',
                    title: '上报游戏时长',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/gametime/list')
            },
            {
                path: '/gamespace/detailPage',
                name: 'detailPage_manage',
                meta: {
                    icon: 'ios-send',
                    title: '详情页管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/detailPage/list')
            },
            {
                path: '/gamespace/channel',
                name: 'gamespace_channel',
                meta: {
                    icon: 'ios-send',
                    title: '渠道规则',
                },
                component: () =>
                    import('@/view/gamespace/channel/list')
            },
            {
                path: '/gamespace/comment/list',
                name: 'gamespace_comment_list',
                meta: {
                    icon: 'md-text',
                    title: '评论管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/comment/list')
            },
            {
                path: '/gamespace/comment/ban',
                name: 'gamespace_comment_ban',
                meta: {
                    icon: 'md-mic-off',
                    title: '禁言管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/comment/ban-list')
            },

            {
                path: '/gamespace/game/add',
                name: 'gamespace_game_add',
                meta: {
                    icon: 'md-trending-up',
                    title: '添加游戏应用',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/game/add')
            }, {
                path: 'game/edit/:id',
                name: 'gamespace_game_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '更新游戏应用',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/game/edit')
            }, {
                path: 'gameversion/add/:id',
                name: 'gamespace_gameversion_add',
                meta: {
                    icon: 'md-trending-up',
                    title: '版本添加',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gameversion/add')
            }, {
                path: 'gameversion/childApk/:id',
                name: 'gamespace_gameversion_childApk',
                meta: {
                    icon: 'md-trending-up',
                    title: '子包管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gameversion/childApk')
            }, {
                path: '/gamespace/gameversion/edit/:id',
                name: 'gamespace_gameversion_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '版本更新',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gameversion/edit')
            }, {
                path: '/gamespace/developer',
                name: 'gamespace_developer',
                meta: {
                    icon: 'md-trending-up',
                    title: '开发者管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/developer/list')
            }, {
                path: '/gamespace/developer/add',
                name: 'gamespace_developer_add',
                meta: {
                    icon: 'md-trending-up',
                    title: '添加开发者',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/developer/add')
            }, {
                path: '/gamespace/developer/edit/:id',
                name: 'gamespace_developer_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '更新开发者信息',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/developer/edit')
            }, {
                path: '/gamespace/gamecategory',
                name: 'gamespace_gamecategory',
                meta: {
                    icon: 'md-trending-up',
                    hideInMenu: true,
                    title: '游戏分类',
                },
                component: () =>
                    import('@/view/gamespace/gamecategory/list')
            }, {
                path: '/gamespace/gamecategory/add',
                name: 'gamespace_gamecategory_add',
                meta: {
                    icon: 'md-trending-up',
                    title: '添加游戏分类',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gamecategory/add')
            }, {
                path: '/gamespace/gamecategory/edit/:id',
                name: 'gamespace_gamecategory_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '更新游戏分类',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gamecategory/edit')
            }, {
                path: '/gamespace/gametag',
                name: 'gamespace_gametag',
                meta: {
                    icon: 'md-trending-up',
                    hideInMenu: true,
                    title: '标签列表',
                },
                component: () =>
                    import('@/view/gamespace/gametag/list')
            }, {
                path: '/gamespace/gametag/add',
                name: 'gamespace_gametag_add',
                meta: {
                    icon: 'md-trending-up',
                    title: '添加游戏标签',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gametag/add')
            }, {
                path: '/gamespace/gametag/edit/:id',
                name: 'gamespace_gametag_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '更新游戏标签',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/gametag/edit')
            }, {
                path: '/game/classify_tag',
                name: 'game_classify_tag',
                meta: {
                    icon: 'md-trending-up',
                    title: '游戏分类标签管理',
                },
                component: () =>
                    import('@/view/gamespace/classifyTag/index')
            },]
        }
    ]
}