import Main from '@/components/main'
import parentView from '@/components/parent-view'
export default {
    router: [
        /*推广管理*/
        {
            path: 'gamespace_tuiguang',
            name: 'gamespace_tuiguang',
            meta: {
                icon: 'md-trending-up',
                title: '推广管理',
            },
            component: Main,
            children: [{
                path: '/gamespace/activity/homemodule',
                name: 'gamespace_activity_homemodule',
                meta: {
                    icon: 'ios-list-box-outline',
                    title: '首页模块管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/home-module/index')
            },
            {
                path: '/gamespace/activity/home/list',
                name: 'gamespace_activity_home_list',
                meta: {
                    icon: 'ios-apps-outline',
                    title: '合辑列表',
                },
                component: () =>
                    import('@/view/gamespace/home/list')
            },
            {
                path: '/gamespace/appmodelconfig/list',
                name: 'gamespace_appmodelconfig_list',
                meta: {
                    icon: 'ios-apps-outline',
                    title: '装机必备配置',
                },
                component: () =>
                    import('@/view/gamespace/appmodelconfig/index')
            },
            {
                path: '/gamespace/activity/home/index/:id',
                name: 'gamespace_activity_home_index',
                meta: {
                    icon: 'md-trending-up',
                    title: '首页布局配置',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/home/index')
            },
            {
                path: '/gamespace/activity/search/index',
                name: 'gamespace_activity_search_index',
                meta: {
                    icon: 'ios-search',
                    title: '搜索页配置',
                },
                component: () =>
                    import('@/view/gamespace/search-config/index')
            },
            // {
            //     path: '/gamespace/activity/setting',
            //     name: 'gamespace_activity_setting',
            //     meta: {
            //         icon: 'md-checkmark-circle-outline',
            //         title: '游戏精选设置',
            //     },
            //     component: parentView,
            //     children: [
            {
                path: '/gamespace/activity/setting/list',
                name: 'activity_setting_list',
                meta: {
                    icon: 'md-checkmark-circle-outline',
                    title: '游戏精选设置',
                },
                component: () =>
                    import('@/view/gamespace/setting'),
            },
            {
                path: '/gamespace/activity/setting/multiple',
                name: 'multiple_activity_setting',
                meta: {
                    icon: 'md-checkmark-circle-outline',
                    title: '游戏精选',
                },
                component: () =>
                    import('@/view/gamespace/setting/game-multiple'),
            },
            {
                path: '/gamespace/activity/setting/recommend',
                name: 'multiple_activity_recommend',
                meta: {
                    icon: 'md-checkmark-circle-outline',
                    title: '游戏推荐',
                },
                component: () =>
                    import('@/view/gamespace/setting/recommend'),
            },
            // ]
            // },
            {
                path: '/gamespace/announce/list',
                name: 'gamespace_announce',
                meta: {
                    icon: 'ios-notifications',
                    title: '公告管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/announce/list')
            },
            {
                path: '/gamespace/new-announce',
                name: 'new_announce',
                meta: {
                    icon: 'ios-notifications',
                    title: '游戏中心公告管理',
                    notCache: true
                },
                component: () =>
                    import('@/view/gamespace/new-announce/list')
            },
            {
                path: '/gamespace/new-announce/edit/:id',
                name: 'new_announce_edit',
                meta: {
                    icon: 'ios-notifications',
                    title: '公告管理编辑(游戏中心)',
                    notCache: true,
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/new-announce/edit')
            },
            {
                path: '/gamespace/rankmanage',
                name: 'gamespace_rankmanage',
                meta: {
                    icon: 'md-list-box',
                    title: '榜单管理',
                },
                component: () =>
                    import('@/view/gamespace/rank/rank-manage')
            },
            {
                path: '/gamespace/gamespace_rankgamelist/:id',
                name: 'gamespace_rank',
                meta: {
                    icon: 'md-trending-up',
                    title: '榜单游戏管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/rank/list')
            },
            {
                path: '/gamespace/gamespace_ranktag/:id',
                name: 'gamespace_ranktag',
                meta: {
                    icon: 'md-trending-up',
                    title: '榜单标签管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/rank/tags')
            },
            {
                path: '/gamespace/gamespace_taggames/:CategoryID/:TagID',
                name: 'gamespace_taggames',
                meta: {
                    icon: 'md-trending-up',
                    title: '标签游戏管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/rank/tag-gamelist')
            },
            {
                path: '/gamespace/thematic/list',
                name: 'gamespace_thematic',
                meta: {
                    icon: 'md-bookmark',
                    title: '专题管理',
                },
                component: () =>
                    import('@/view/gamespace/thematic/list')
            },


            {
                path: '/gamespace/gamespace_rank/add',
                name: 'gamespace_rank_add',
                meta: {
                    icon: 'md-trending-up',
                    title: '榜单绑定游戏',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/rank/add')
            },


            {
                path: '/gamespace/activity/homemodule/edit/:id',
                name: 'gamespace_activity_homemodule_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '首页模块编辑',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/home-module/edit')
            },
            {
                path: '/gamespace/activity/homemodule/elemanage/:modelType/:modelId',
                name: 'gamespace_activity_homemodule_elemanage',
                meta: {
                    icon: 'md-trending-up',
                    title: '模块元素管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/home-module/ele-manage/index')
            },

            {
                path: '/thematic/manage',
                name: 'gamespace_thematic_rank_manage',
                meta: {
                    icon: 'md-trending-up',
                    title: '专题元素管理',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/thematic/manage')
            },

            {
                path: '/announce/edit',
                name: 'gamespace_announce_edit',
                meta: {
                    icon: 'md-trending-up',
                    title: '公告编辑',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/announce/edit')
            },
            {
                path: '/gamespace/setting/game-recommend-manage',
                name: 'game-recommend-manager',
                meta: {
                    icon: 'ios-paper',
                    title: '游戏推荐',
                },
                component: () =>
                    import('@/view/gamespace/setting/game-recommend-manage')
            },
            {
                path: '/gamespace/post_rank_manage',
                name: 'post_rank_manage',
                meta: {
                    icon: 'ios-paper',
                    title: '帖子榜单管理',
                },
                component: () =>
                    import('@/view/gamespace/postRank')
            },
            {
                path: '/gamespace/post_rank_list/:id',
                name: 'post_rank_list',
                meta: {
                    icon: 'ios-paper',
                    title: '帖子榜单列表',
                    hideInMenu: true
                },
                component: () =>
                    import('@/view/gamespace/postRank/child-list')
            },
            {
                path: '/promotion/blacklist',
                name: 'promotion_blacklist',
                meta: {
                    icon: 'md-trending-up',
                    title: '推广黑名单',
                },
                component: () =>
                    import('@/view/gamespace/promotionBlack/index')
            },{
                path: '/promotion/whitelist',
                name: 'promotion_whitelist',
                meta: {
                    icon: 'md-trending-up',
                    title: '重点游戏白名单',
                },
                component: () =>
                    import('@/view/gamespace/promotionWhite/index')
            },
            {
                path: '/promotion/messageManage',
                name: 'promotion_messageManage',
                meta: {
                    icon: 'md-trending-up',
                    title: '短信管理',
                },
                component: () =>
                    import('@/view/gamespace/messageManage/list')
            },
            ]
        },
    ]
}
