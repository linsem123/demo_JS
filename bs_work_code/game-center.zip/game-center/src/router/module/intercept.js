import Main from '@/components/main'

export default {
    router: [
        {
            path: '/intercept',
            name: "intercept",
            component: Main,
            meta: {
                icon: 'md-people',
                title: '拦截器管理'
            },
            children: [{
                path: 'cityManage',
                name: 'cityManage',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '城市列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/intercept/cityManage/index')
            }, {
                path: 'cityGroup',
                name: 'cityGroup',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '分组列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/intercept/cityGroup/index')
            }, {
                path: 'platformList',
                name: 'platformList',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '平台列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/intercept/platformList/index')
            }, {
                path: 'appBinding',
                name: 'appBinding',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '应用绑定',
                    notCache: true
                },
                component: () =>
                    import('@/view/intercept/appBinding/index')
            }, {
                path: 'ruleList',
                name: 'ruleList',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '规则列表',
                    notCache: true
                },
                component: () =>
                    import('@/view/intercept/ruleList/index')
            }, {
                path: 'ruleBinding',
                name: 'ruleBinding',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '规则绑定',
                    notCache: true
                },
                component: () =>
                    import('@/view/intercept/ruleBinding/index')
            }, {
                path: 'ruleSearch',
                name: 'ruleSearch',
                meta: {
                    icon: 'ios-aperture-outline',
                    title: '规则查询',
                    notCache: true
                },
                component: () =>
                    import('@/view/intercept/ruleSearch/index')
            }]
        }
    ]
}