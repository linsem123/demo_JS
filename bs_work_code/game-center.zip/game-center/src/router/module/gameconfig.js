import Main from '@/components/main'
import parentView from '@/components/parent-view'
export default {
    router: [
        /*基础管理*/
        {
            path: 'gamespace_base',
            name: 'gamespace_base',
            meta: {
                icon: 'ios-settings-outline',
                title: '基础管理',
            },
            component: Main,
            children: [
                {
                    path: '/gamespace/cloudbackup/manage',
                    name: 'gamespace_cloud_backup_manage',
                    meta: {
                        icon: 'ios-folder-outline',
                        title: '云备份管理',
                    },
                    component: () =>
                        import('@/view/gamespace/cloud-backup/manage')
                },
                {
                    path: '/gamespace/rankapplist/:id',
                    name: 'gamespace_rank_app_list',
                    meta: {
                        icon: 'md-trending-up',
                        title: '榜单应用管理',
                        hideInMenu: true
                    },
                    component: () =>
                        import('@/view/gamespace/cloud-backup/rankAppList')
                },
                {
                    path: '/gamespace/cloudfolder/manage',
                    name: 'gamespace_cloud_folder_manage',
                    meta: {
                        icon: 'ios-folder-outline',
                        title: '云文件夹管理',
                    },
                    component: () =>
                        import('@/view/gamespace/cloud-folder/manage')
                },
                {
                    path: '/gamespace/comment/info',
                    name: 'gamespace_comment_info',
                    meta: {
                        icon: 'md-person',
                        title: '管理员信息配置',
                    },
                    component: () =>
                        import('@/view/gamespace/comment/admin-info')
                },
                {
                    path: '/gamespace/warning/person',
                    name: 'gamespace_warning_person',
                    meta: {
                        icon: 'md-person',
                        title: '预警负责人管理',
                    },
                    component: () =>
                        import('@/view/gamespace/warning/person')
                },
                {
                    path: '/gamespace/activity/findgame/config',
                    name: 'gamespace_activity_find_game_config',
                    meta: {
                        icon: 'md-copy',
                        title: '发现好游戏版本管理',
                    },
                    component: () =>
                        import('@/view/gamespace/find-game-config/version-config')
                },
                {
                    path: 'activity/push/config',
                    name: 'gamespace_activity_push_config',
                    meta: {
                        icon: 'md-settings',
                        title: '全局配置',
                    },
                    component: () =>
                        import('@/view/gamespace/push/push-config')
                },
                {
                    path: 'gamespace/kanban/find-game-version',
                    name: 'gamespace_kanban_version',
                    meta: {
                        icon: 'md-settings',
                        title: '发现好游戏版本信息看板',
                    },
                    component: () =>
                        import('@/view/gamespace/kanban/find-game-version')
                },
                {
                    path: 'gamespace/kanban/sub-count',
                    name: 'gamespace_kanban_sub',
                    meta: {
                        icon: 'ios-clipboard-outline',
                        title: '真实预约人数看板',
                    },
                    component: () =>
                        import('@/view/gamespace/kanban/sub-count')
                },
                {
                    path: 'gamespace/kanban/download-info',
                    name: 'gamespace_kanban_download',
                    meta: {
                        icon: 'md-settings',
                        title: '游戏下载人数看板',
                    },
                    component: () =>
                        import('@/view/gamespace/kanban/download-info')
                },
                {
                    path: 'gamespace/directive/search',
                    name: 'gamespace_directive_search',
                    meta: {
                        icon: 'md-settings',
                        title: '预约指令查询',
                    },
                    component: () =>
                        import('@/view/gamespace/directive/index')
                },
                {
                    path: 'gamespace/appointment/record',
                    name: 'gamespace_appointment_record',
                    meta: {
                        icon: 'ios-search',
                        title: '预约记录查询',
                    },
                    component: () =>
                        import('@/view/gamespace/appointment/index')
                },
                {
                    path: 'gamespace/pre_report',
                    name: 'gamespace_pre_report',
                    meta: {
                        icon: 'ios-cloud-download-outline',
                        title: '预约数据报表',
                    },
                    component: () =>
                        import('@/view/gamespace/dataReport/appointment')
                },
                {
                    path: 'gamespace/data_report',
                    name: 'gamespace_data_report',
                    meta: {
                        icon: 'ios-cloud-download-outline',
                        title: '数据报表',
                    },
                    component: () =>
                        import('@/view/gamespace/dataReport/index')
                },
                {
                    path: 'gamespace/phone_model',
                    name: 'gamespace_phone_model',
                    meta: {
                        icon: 'ios-phone-portrait',
                        title: '机型配置',
                    },
                    component: () =>
                        import('@/view/gamespace/phoneModel')
                },
            ]
        },
    ]
}