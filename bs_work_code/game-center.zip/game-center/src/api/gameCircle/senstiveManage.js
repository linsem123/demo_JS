import axios from '@/libs/api.request';
import baseurl from './base';
//添加屏蔽词
const addWord = (data) => {
    return axios.request({
        url: baseurl + 'dirty_word/add',
        data,
        method: 'post'
    })
}
//删除屏蔽词
const deleteWord = (id) => {
    return axios.request({
        url: baseurl + 'dirty_word/del/' + id,
        data: {},
        method: 'post'
    })
}
//查询屏蔽词列表
const getWordList = (data) => {
    return axios.request({
        url: baseurl + 'dirty_word/find_by_page',
        data,
        method: 'post'
    })
}
//屏蔽词模糊查询
const getWordLike = (title) => {
    return axios.request({
        url: baseurl + 'dirty_word/like/' + title,
        data: {},
        method: 'post'
    })
}
export default {
    addWord,
    deleteWord,
    getWordList,
    getWordLike
}