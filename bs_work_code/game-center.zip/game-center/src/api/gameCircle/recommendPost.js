import axios from '@/libs/api.request';
import baseurl from './base';

const getList = (data) => {
    return axios.request({
        url: baseurl + 'forum/post/feed/find_by_page',
        data,
        method: 'post'
    })
}

const Top = (id) => {
    return axios.request({
        url: baseurl + 'forum/post/feed/sort?id=' + id,
        method: 'post'
    })
}
const Update = (id, status) => {
    return axios.request({
        url: baseurl + 'forum/post/feed/change_status?id=' + id + '&status=' + status,
        method: 'post'
    })
}


const Add = (id) => {
    return axios.request({
        url: baseurl + 'forum/post/feed/add?postId=' + id,
        method: 'post'
    })
}

//用户列表
export default {
    getList,
    Add,
    Top,
    Update
}