import axios from '@/libs/api.request';
import baseurl from './base';
//添加
const Add = (data) => {
    return axios.request({
        url: baseurl + 'raiders/add',
        data,
        method: 'post'
    })
}
//删除
const changeState = (id, status) => {
    return axios.request({
        url: baseurl + 'raiders/update_state/' + id + '/' + status,
        data: {},
        method: 'post'
    })
}
//查询列表
const getList = (data) => {
    return axios.request({
        url: baseurl + 'raiders/list',
        data,
        method: 'post'
    })
}
//编辑
const Edit = (data) => {
    return axios.request({
        url: baseurl + 'raiders/edit/' + data.ID,
        data,
        method: 'post'
    })
}
export default {
    Add,
    changeState,
    getList,
    Edit
}