import axios from '@/libs/api.request';
import baseurl from './base';
//添加帖子标签
const addPostTag = (data) => {
    return axios.request({
        url: baseurl + 'forum/tag/add',
        data,
        method: 'post'
    })
}
//删除帖子标签
const deletePostTag = (id) => {
    return axios.request({
        url: baseurl + 'forum/tag/del/' + id,
        data: {},
        method: 'post'
    })
}
//用户标签
const getUserTag = (data) => {
    return axios.request({
        url: baseurl + 'user/tag',
        data,
        method: 'post'
    })
}
//删除用户标签
const deleteUserTag = (id) => {
    return axios.request({
        url: baseurl + 'user/tag/del/' + id,
        data: {},
        method: 'post'
    })
}
//添加用户标签
const addUserTag = (data) => {
    return axios.request({
        url: baseurl + 'user/tag/add',
        data,
        method: 'post'
    })
}
//删除管理员
const deleteAdminTag = (id) => {
    return axios.request({
        url: baseurl + 'user/admin/del/' + id,
        data: {},
        method: 'post'
    })
}
//添加管理员
const addAdminTag = (data) => {
    return axios.request({
        url: baseurl + 'user/admin/add',
        data,
        method: 'post'
    })
}
//全局禁言
const configStatus = (type) => {
    return axios.request({
        url: baseurl + 'config/get/' + type,
        data: {},
        method: 'post'
    })
}

//全局禁言
const setStatus = (type, status) => {
    return axios.request({
        url: baseurl + 'config/set/' + type + "/" + status,
        data: {},
        method: 'post'
    })
}
//查询消息中心管理员配置
const configFetch = () => {
    return axios.request({
        url: baseurl + 'message/icon/fetch',
        data: {},
        method: 'post'
    })
}
//消息中心管理员配置修改
const configModify = (data) => {
    return axios.request({
        url: baseurl + 'message/icon/edit',
        data,
        method: 'post'
    })
}
//添加帖子分类标签
const addPostType = (data) => {
    return axios.request({
        url: baseurl + 'forum/category/add',
        data,
        method: 'post'
    })
}
//删除帖子分类标签
const deletePostType = (id) => {
    return axios.request({
        url: baseurl + 'forum/category/del/' + id,
        data: {},
        method: 'post'
    })
}
//获取帖子分类标签
const getPostType = (id) => {
    return axios.request({
        url: baseurl + 'forum/category/list',
        data: {},
        method: 'post'
    })
}
export default {
    addPostTag,
    deletePostTag,
    getUserTag,
    addUserTag,
    deleteUserTag,
    deleteAdminTag,
    addAdminTag,
    configStatus,
    setStatus,
    configFetch,
    configModify,
    addPostType,
    deletePostType,
    getPostType
}