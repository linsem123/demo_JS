import axios from '@/libs/api.request';
import baseurl from './base';

const getList = (data) => {
    return axios.request({
        url: baseurl + 'forum/sub/background/find_by_page',
        data,
        method: 'post'
    })
}

const Edit = (data) => {
    return axios.request({
        url: baseurl + 'forum/sub/background/edit',
        method: 'post',
        data
    })
}

const Add = (data) => {
    return axios.request({
        url: baseurl + 'forum/sub/background/add',
        method: 'post',
        data
    })
}
const Delete = (id) => {
    return axios.request({
        url: baseurl + 'forum/sub/background/del?id=' + id,
        method: 'post',

    })
}
//帖子置顶
const Top = (id) => {
    return axios.request({
        url: baseurl + 'forum/sub/top?id=' + id,
        method: 'post',
    })
}

//帖子排序
const Sort = (data) => {
    return axios.request({
        url: baseurl + 'forum/sub/sort',
        method: 'post',
        data
    })
}

//用户列表
export default {
    getList,
    Add,
    Edit,
    Delete,
    Top,
    Sort
}