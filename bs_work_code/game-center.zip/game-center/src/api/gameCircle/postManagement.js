import axios from '@/libs/api.request';
import baseurl from './base';
//管理员类表
const getAccount = (data) => {
  return axios.request({
    url: baseurl + 'user/admin',
    data,
    method: 'post'
  })
}
//帖子标签列表
const getTagList = (data) => {
  return axios.request({
    url: baseurl + 'forum/tag',
    data,
    method: 'post'
  })
}
//发布
const publish = (data) => {
  return axios.request({
    url: baseurl + 'forum/post/add',
    data,
    method: 'post'
  })
}
//论坛帖列表
const getPostList = (data) => {
  return axios.request({
    url: baseurl + 'forum/post/find_by_page',
    data,
    method: 'post'
  })
}

//搜索用户
const userLikeByNickName = (value) => {
  return axios.request({
    url: baseurl + 'user/like/' + value,
    data: {},
    method: 'post'
  })
}
//搜索标题
const titleLike = (value) => {
  return axios.request({
    url: baseurl + 'forum/post/like/' + value,
    data: {},
    method: 'post'
  })
}
//顶置
const overheadPost = (value) => {
  return axios.request({
    url: baseurl + 'forum/post/top/' + value,
    data: {},
    method: 'post'
  })
}
//取消置顶
const unOverheadPost = (value) => {
  return axios.request({
    url: baseurl + 'forum/post/cancel_top/' + value,
    data: {},
    method: 'post'
  })
}
const overheadPostChild = (id, appId) => {
  return axios.request({
    url: baseurl + 'forum/post/sub/top/' + id + "/" + appId,
    data: {},
    method: 'post'
  })
}
const cancelOverheadChild = (id, appId) => {
  return axios.request({
    url: baseurl + 'forum/post/sub/cancel_top/' + id + "/" + appId,
    data: {},
    method: 'post'
  })
}

//编辑数据
const editPost = (value, data) => {
  return axios.request({
    url: baseurl + 'forum/post/edit/' + value,
    data,
    method: 'post'
  })
}
//详情
const postDetails = (value) => {
  return axios.request({
    url: baseurl + 'forum/post/' + value,
    data: {},
    method: 'post'
  })
}
//更新帖子状态
const postStatus = (data) => {
  return axios.request({
    url: baseurl + 'forum/post/change_status',
    data,
    method: 'post'
  })
}
//投放
const feedPost = (data) => {
  return axios.request({
    url: baseurl + 'forum/post/feed',
    data,
    method: 'post'
  })
}

//屏蔽评论
const ShowComment = (id, status) => {
  return axios.request({
    url: baseurl + 'forum/post/change/show_comment_status/' + id + '/' + status,
    data: {},
    method: 'post'
  })
}
//禁止评论
const AllowComment = (id, status) => {
  return axios.request({
    url: baseurl + 'forum/post/change/allow_comment_status/' + id + '/' + status,
    data: {},
    method: 'post'
  })
}
//帖子分类标签
const getPostType = (id) => {
  return axios.request({
    url: baseurl + 'forum/post/category/list/' + id,
    data: {},
    method: 'post'
  })
}
//帖子分类标签
const setPostType = (id, data) => {
  return axios.request({
    url: baseurl + 'forum/post/category/edit/' + id,
    data,
    method: 'post'
  })
}

//用户模糊查询
const likeAccount = (name) => {
  return axios.request({
    url: baseurl + 'user/admin/like/' + name,
    method: 'post'
  })
}

export default {
  getAccount,
  getTagList,
  publish,
  getPostList,
  userLikeByNickName,
  titleLike,
  overheadPost,
  unOverheadPost,
  overheadPostChild,
  editPost,
  postDetails,
  postStatus,
  feedPost,
  ShowComment,
  AllowComment,
  getPostType,
  setPostType,
  cancelOverheadChild,
  likeAccount
}