import axios from '@/libs/api.request';
import baseurl from './base';
//用户列表
const getUserList = (data) => {
    return axios.request({
        url: baseurl + 'user/find_by_page',
        data,
        method: 'post'
    })
}
//修改用户信息
const saveUserModify = (data) => {
    return axios.request({
        url: baseurl + 'user/edit',
        data,
        method: 'post'
    })
}
//禁言
const setForbiddon = (data) => {
    return axios.request({
        url: baseurl + 'user/ban/add',
        data,
        method: 'post'
    })
}
//禁言列表
const ForbiddonList = (data) => {
    return axios.request({
        url: baseurl + 'user/ban/find_by_page',
        data,
        method: 'post'
    })
}
//修改禁言 
const modifyForbiddon = (data, id) => {
    return axios.request({
        url: baseurl + 'user/ban/edit/' + id,
        data,
        method: 'post'
    })
}
//解除禁言
const delForbiddon = (id) => {
    return axios.request({
        url: baseurl + 'user/ban/del/' + id,
        data: {},
        method: 'post'
    })
}
export default {
    getUserList,
    saveUserModify,
    setForbiddon,
    ForbiddonList,
    modifyForbiddon,
    delForbiddon
}