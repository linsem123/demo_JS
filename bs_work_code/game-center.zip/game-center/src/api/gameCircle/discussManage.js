import axios from "@/libs/api.request";
import baseurl from "./base";
//评论
const addDiscuss = (data) => {
  return axios.request({
    url: baseurl + "forum/comment/add",
    data,
    method: "post",
  });
};
//评论列表
const getDiscussList = (data) => {
  return axios.request({
    url: baseurl + "forum/comment/find_by_page",
    data,
    method: "post",
  });
};
//评论状态
const updateDiscussStatus = (id, status) => {
  return axios.request({
    url: baseurl + "forum/comment/" + id + "/" + status,
    data: {},
    method: "post",
  });
};
//评论置顶
const headoverDiscuss = (id, type) => {
  return axios.request({
    url: baseurl + "forum/comment/top/" + id + "?isTop=" + type,
    data: {},
    method: "post",
  });
};
//回复
const addReplay = (data) => {
  return axios.request({
    url: baseurl + "forum/reply/add",
    data,
    method: "post",
  });
};
//回复列表
const getReplayList = (data) => {
  return axios.request({
    url: baseurl + "forum/reply/fetch/" + data,
    data: {},
    method: "post",
  });
};
//更新回复状态
const updateReplyStatus = (id, status) => {
  return axios.request({
    url: baseurl + "forum/reply/" + id + "/" + status,
    data: {},
    method: "post",
  });
};
//回复置顶
const headoverReply = (id,type) => {
  return axios.request({
    url: baseurl + "forum/reply/top/" + id+ "?isTop=" + type,
    data: {},
    method: "post",
  });
};
//模糊查找评论内容
const contentLike = (content) => {
  return axios.request({
    url: baseurl + "forum/comment/like/" + content,
    data: {},
    method: "post",
  });
};
export default {
  addDiscuss,
  getDiscussList,
  updateDiscussStatus,
  headoverDiscuss,
  addReplay,
  getReplayList,
  updateReplyStatus,
  headoverReply,
  contentLike,
};
