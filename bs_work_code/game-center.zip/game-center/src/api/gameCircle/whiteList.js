import axios from '@/libs/api.request';
import baseurl from './base';
//查询列表
const getWhiteList = (data) => {
    return axios.request({
        url: baseurl + 'post_white/fetch',
        data,
        method: 'post'
    })
}
//删除
const Delete = (id) => {
    return axios.request({
        url: baseurl + 'post_white/delete/' + id,
        data: {},
        method: 'post'
    })
}
const Create = (data) => {
    return axios.request({
        url: baseurl + 'post_white',
        data,
        method: 'post'
    })
}
//黑鲨ID模糊查询
const LikeHsID = (val) => {
    return axios.request({
        url: baseurl + 'user/like_by_hs_id/' + val,
        data: {},
        method: 'post'
    })
}

export default {
    getWhiteList,
    Delete,
    Create,
    LikeHsID
}