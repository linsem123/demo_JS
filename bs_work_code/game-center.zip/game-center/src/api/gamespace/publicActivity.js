import axios from '@/libs/api.request'
import baseurl from './base'
const GetList = (data) => {
    return axios.request({
        url: baseurl + 'propaganda/fetch',
        data,
        method: 'post'
    })
}
//新增
const Add = (data) => {
    return axios.request({
        url: baseurl + 'propaganda/create',
        data,
        method: 'post'
    })
}
//编辑
const Edit = (id, data) => {
    return axios.request({
        url: baseurl + 'propaganda/edit/' + id,
        data,
        method: 'post'
    })
}
const Check = (id, status) => {
    return axios.request({
        url: baseurl + 'propaganda/check/' + id + '/' + status,
        data: {},
        method: 'post'
    })
}
//查询模版
const GetTemplate = (id) => {
    return axios.request({
        url: baseurl + 'propaganda/one/' + id,
        data: {},
        method: 'post'
    })
}

// 4.11
// 编辑模板
const EditTemplate = (id, data) => {
    return axios.request({
        url: baseurl + 'propaganda/model/config/' + id,
        data,
        method: 'post'
    })
}

//活动标题模糊查询
const Like = (data) => {
    return axios.request({
        url: baseurl + 'propaganda/like/' + data,
        data: {},
        method: 'post'
    })
}
//重点游戏
const KeyGameList = (data) => {
    return axios.request({
        url: baseurl + 'important/fetch',
        data,
        method: 'post'
    })
}
const AddKeyGame = (data) => {
    return axios.request({
        url: baseurl + 'important/create',
        data,
        method: 'post'
    })
}
//编辑
const EditKeyGame = (id, data) => {
    return axios.request({
        url: baseurl + 'important/edit/' + id,
        data,
        method: 'post'
    })
}
//编辑
const KeyGameTemplate = (id) => {
    return axios.request({
        url: baseurl + 'important/one/' + id,
        data: {},
        method: 'post'
    })
}
//榜单名次
const GetRankNo = (id) => {
    return axios.request({
        url: baseurl + 'subscribe/rank/' + id,
        data: {},
        method: 'post'
    })
}
//榜单名次
const KeyGameLike = (value) => {
    return axios.request({
        url: baseurl + 'important/like/' + value,
        data: {},
        method: 'post'
    })
}
//更改活动状态
const SetStatus = (id, status) => {
    return axios.request({
        url: baseurl + 'important/change/status/' + id + '/' + status,
        data: {},
        method: 'post'
    })
}

export default {
    GetList,
    Add,
    Edit,
    Check,
    GetTemplate,
    EditTemplate,
    Like,
    KeyGameList,
    AddKeyGame,
    EditKeyGame,
    KeyGameTemplate,
    GetRankNo,
    KeyGameLike,
    SetStatus
}