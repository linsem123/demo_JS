/*优惠券相关*/
import axios from '@/libs/api.request'
import baseurl from './base'
const List = (params) => {
    return axios.request({
        url: baseurl + 'actrebate/list',
        data: params,
        method: 'post'
    })
}
const Edit = (params) => {
    return axios.request({
        url: baseurl + 'actrebate/edit/',
        data: params,
        method: 'post'
    })
}
const Add = (params) => {
    return axios.request({
        url: baseurl + 'actrebate/add',
        data: params,
        method: 'post'
    })
}
const Delete = (params) => {
    return axios.request({
        url: baseurl + 'actrebate/del/' + params.id,
        data: params,
        method: 'post'
    })
}

export default {
    List,
    Add,
    Edit,
    Delete,
}
