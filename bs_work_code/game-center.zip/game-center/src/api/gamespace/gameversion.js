import axios from '@/libs/api.request';
import baseurl from './base';
import config from '@/config';
const baseUrl = process.env.NODE_ENV === 'development' ? config.baseUrl.dev : config.baseUrl.pro
const FindByPage = (
    Limit,
    Page,
    Params
) => {
    const data = {
        Limit,
        Page,
        Params,
    }
    return axios.request({
        url: baseurl + 'gameversion/list',
        data,
        method: 'post'
    })
}

const Like = ({
    value
}) => {
    return axios.request({
        url: baseurl + 'gameversion/like/' + value,
        method: 'get'
    })
}

const Enable = (
    id,
    enable
) => {
    return axios.request({
        url: baseurl + 'gameversion/enable/' + id + '/' + enable,
        method: 'post'
    })
}


const Add = (data) => {
    return axios.request({
        url: baseurl + 'gameversion',
        data,
        method: 'post'
    })
}

const Edit = (data) => {
    return axios.request({
        url: baseurl + 'gameversion/edit/' + data.ID,
        data,
        method: 'post'
    })
}

const Get = (id) => {
    return axios.request({
        url: baseurl + 'gameversion/' + id,
        method: 'get'
    })
}

const CheckStatus = (id, data) => {
    console.log(id, data);
    return axios.request({
        url: baseurl + 'gameversion/check/' + id,
        data,
        method: 'post'
    })
}

const FindGameVersionList = () => {
    return axios.request({
        url: baseurl + 'gameversion/findgamelist',
        method: 'post'
    })
}

const getChildrenlist = (appId, version) => {
    return axios.request({
        url: baseurl + 'gameversion/channel/getminors/' + appId + "/" + version,
        method: 'post'
    })
}
const getChannelId = (params) => {
    return axios.request({
        url: baseurl + 'gameversion/channel/getchannelid/',
        method: 'post',
        data: params,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }

    })
}
const saveChannelMinor = (params) => {
    return axios.request({
        url: baseurl + 'gameversion/channel/saveminor/',
        method: 'post',
        data: params,
    })
}

const VersionCount = (params) => {
    return axios.request({
        url: baseurl + 'gameversion/versionusercount',
        data: params,
        method: 'post'
    })
}
const SubCount = (params) => {
    return axios.request({
        url: baseurl + 'game/sub_count',
        data: params,
        method: 'post'
    })
}

const DownloadInfo = (params) => {
    return axios.request({
        url: baseurl + 'game/download_info',
        data: params,
        method: 'post'
    })
}

const exportList = (data) => {
    return axios.request({
        url: baseurl + 'game/sub/export',
        method: 'post',
        data: data
    })
}

const exportDownloadList = (data) => {
    return axios.request({
        url: baseurl + 'game/download/export',
        method: 'post',
        data: data
    })
}
//更新提示弹窗
const getUpdateConfig = (data) => {
    return axios.request({
        url: baseurl + 'app_self_update/fetch',
        method: 'post',
        data: data
    })
}
//更新提示弹窗
const setUpdateConfig = (data) => {
    return axios.request({
        url: baseurl + 'app_self_update/edit/' + data.ID,
        method: 'post',
        data: data
    })
}

//根据链接下载apk包-新增版本日志
const upByUrlAct = (data) => {
    return axios.request({
        url: baseurl + 'gameversion/act',
        method: 'post',
        data: data
    })
}
//根据链接下载apk包-删除任务
const delActProgress = (data) => {
    return axios.request({
        url: baseurl + 'gameversion/act/del?logId=' + data,
        method: 'post',
    })
}
//获取任务状态
const getActProgress = (data) => {
    return axios.request({
        url: baseurl + 'gameversion/act/one?logId=' + data,
        method: 'post',
    })
}

export default {
    VersionCount,
    SubCount,
    DownloadInfo,
    FindByPage,
    Like,
    Enable,
    Add,
    Edit,
    Get,
    CheckStatus,
    FindGameVersionList,
    exportList,
    exportDownloadList,
    getChildrenlist,
    getChannelId,
    saveChannelMinor,
    getUpdateConfig,
    setUpdateConfig,
    upByUrlAct,
    getActProgress,
    delActProgress
}