import axios from '@/libs/api.request'
import baseurl from './base'

const SetConfig = (id, status) => {
  return axios.request({
    url: baseurl + 'config/set_config' + '/' + id + '/' + status,
    method: 'post'
  })
}

const GetConfig = () => {
  return axios.request({
    url: baseurl + 'config/get_config',
    method: 'post'
  })
}
const getIntegral = () => {
  return axios.request({
    url: baseurl + 'config/getintegral',
    method: 'post'
  })
}
const setIntegral = (id) => {
  return axios.request({
    url: baseurl + 'config/updateintegral/' + id,
    method: 'post'
  })
}
const setMiStatus = (id) => {
  return axios.request({
    url: baseurl + 'config/mi_sync/change/' + id,
    method: 'post'
  })
}
const getMiStatus = () => {
  return axios.request({
    url: baseurl + 'config/mi_sync/list',
    method: 'post'
  })
}
export default {
  GetConfig,
  SetConfig,
  getIntegral,
  setIntegral,
  setMiStatus,
  getMiStatus
}
