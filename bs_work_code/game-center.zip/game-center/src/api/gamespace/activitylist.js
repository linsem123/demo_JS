import axios from '@/libs/api.request'
import baseurl from './base'

const GetList = (category) => {
  return axios.request({
    url: baseurl + 'gamefeed/list/' + category,
    method: 'post'
  })
}

const QueryByFeedType = (title) => {
  return axios.request({
    url: baseurl + 'gamefeed/like/' + title,
    method: 'get'
  })
}

const SaveBind = (category, id, data) => {
  return axios.request({
    url: baseurl + 'gamefeed/bind/' + category + '/' + id,
    data: data,
    method: 'post'
  })
}

const UnBind = (id, category) => {
  return axios.request({
    url: baseurl + 'gamefeed/unbind/' + id + '/' + category,
    method: 'post'
  })
}

const SetTop = (id, category) => {
  return axios.request({
    url: baseurl + 'gamefeed/up/' + id + '/' + category,
    method: 'post'
  })
}

const LikeActivity = (title, type) => {
  return axios.request({
    url: baseurl + 'gamefeed/feedlike/' + title + '/' + type,
    method: 'get'
  })
}

const Feeds = (feedType, feedId) => {
  return axios.request({
    url: baseurl + 'gamefeed/feeds/' + feedType + '/' + feedId,
    method: 'get'
  })
}

const FeedsInfo = (Id) => {
  return axios.request({
    url: baseurl + 'gamefeed/feedinfo/' + Id,
    method: 'get'
  })
}

const LikeAward = (name, poolType) => {
  return axios.request({
    url: baseurl + 'gameaward/like/' + poolType + '/' + name,
    method: 'post'
  })
}

const awardInfo = (id) => {
  return axios.request({
    url: baseurl + 'gameaward/info/' + id,
    method: 'post'
  })
}
//获取信息流列表
const GetDataList = (data) => {
  return axios.request({
    url: baseurl + 'gamefeed/find_by_page',
    method: 'post',
    data
  })
}

//编辑榜单
const editRank = (data) => {
  return axios.request({
    url: baseurl + 'gamefeed/edit/' + data.ID + "/" + data.Category,
    method: 'post',
    data
  })
}

export default {
  GetList,
  QueryByFeedType,
  SaveBind,
  UnBind,
  SetTop,
  LikeActivity,
  Feeds,
  FeedsInfo,
  LikeAward,
  awardInfo,
  GetDataList,
  editRank
}
