import axios from '@/libs/api.request'
import baseurl from './base'

const GetList = (data) => {
  return axios.request({
    url: baseurl + 'app_shield/fetch',
    method: 'post',
    data,
  })
}

const Add = (data) => {
  return axios.request({
    url: baseurl + 'app_shield/create',
    data: data,
    method: 'post'
  })
}

const changeStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'app_shield/check/' + id + '/' + status,
    method: 'post'
  })
}

export default {
  GetList,
  Add,
  changeStatus,
}
