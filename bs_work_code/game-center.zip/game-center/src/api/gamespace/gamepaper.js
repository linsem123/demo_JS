import axios from '@/libs/api.request'
import baseurl from './base'

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params
  }
  return axios.request({
    url: baseurl + 'gamepaper/list',
    data,
    method: 'post'
  })
}

const Add = (data) => {
  return axios.request({
    url: baseurl + 'gamepaper/add',
    data,
    method: 'post'
  })
}

const Edit = (data) => {
  return axios.request({
    url: baseurl + 'gamepaper/edit',
    data,
    method: 'post'
  })
}
const CheckStatus=(id,status)=>{
  console.log(id,status);
  return axios.request({
    url: baseurl + 'gamepaper/check/' + id+"/"+status,
    method: 'post'
  })
}
const Get = (id) => {
  return axios.request({
    url: baseurl + 'gamepaper/' + id,
    method: 'get'
  })
}

export default{
  FindByPage,
  Add,
  Edit,
  CheckStatus,
  Get
}
