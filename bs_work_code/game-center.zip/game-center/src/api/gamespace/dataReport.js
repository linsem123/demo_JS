/*优惠券相关*/
import axios from '@/libs/api.request'
import baseurl from './base'

// 查询列表
const GetList = (params) => {
    return axios.request({
        url: baseurl + 'game/download_info_search',
        data: params,
        method: 'post'
    })
}

// 导出
const ExportExel = (formData) => {
    return axios.request({
        url: baseurl + 'game/download_info/exportInstallInfo',
        data: formData,
        method: 'post'
    })
}
// 查询列表
const GetAppointment = (params) => {
    return axios.request({
        url: baseurl + 'subscribe/fetch',
        data: params,
        method: 'post'
    })
}

// 导出
const ExportAppointment = (formData) => {
    return axios.request({
        url: baseurl + 'subscribe/export',
        data: formData,
        method: 'post'
    })
}
// 聚合导出
const AggregationExport = (formData) => {
    return axios.request({
        url: baseurl + 'subscribe/aggregation_export',
        data: formData,
        method: 'post'
    })
}

export default {
    GetList,
    ExportExel,
    GetAppointment,
    ExportAppointment,
    AggregationExport
}
