import GameApi from './game.js';

export default {
  GameApi,
}
