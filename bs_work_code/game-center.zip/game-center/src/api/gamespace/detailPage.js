/*优惠券相关*/
import axios from '@/libs/api.request'
import baseurl from './base'

// 查询列表
const GetList = (params) => {
    return axios.request({
        url: baseurl + 'game_detail/fetch',
        data: params,
        method: 'post'
    })
}
const Add = (params) => {
    return axios.request({
        url: baseurl + 'game_detail',
        data: params,
        method: 'post'
    })
}
const Edit = (id, params) => {
    return axios.request({
        url: baseurl + 'game_detail/edit/' + id,
        data: params,
        method: 'post'
    })
}
const KeyGameLike = (value) => {
    return axios.request({
        url: baseurl + 'important/like_title/' + value,
        method: 'post'
    })
}
const SetStatus = (id, status) => {
    return axios.request({
        url: baseurl + 'game_detail/change/status/' + id + '/' + status,
        method: 'post'
    })

}
export default {
    GetList,
    Add,
    Edit,
    KeyGameLike, SetStatus

}