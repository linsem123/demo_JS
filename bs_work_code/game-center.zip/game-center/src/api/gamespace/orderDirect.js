import axios from '@/libs/api.request'
import baseurl from './base'
const orderDirectData = (id) => {
  return axios.request({
    url: baseurl + 'game/sub/instruction/' + id,
    data: {},
    method: 'post'
  })
}
const getList = (data) => {
  return axios.request({
    url: baseurl + 'gameversion/push/list',
    data: data,
    method: 'post'
  })
}
export default {
  orderDirectData,
  getList
}