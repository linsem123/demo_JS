import axios from "@/libs/api.request";
import baseurl from "./base";
import config from "@/config";
const baseUrl =
  process.env.NODE_ENV === "development"
    ? config.baseUrl.dev
    : config.baseUrl.pro;
const FindByPage = (Limit, Page, Params) => {
  const data = {
    Limit,
    Page,
    Params,
  };
  return axios.request({
    url: baseurl + "game/list",
    data,
    method: "post",
  });
};

const updateParamStatusByType = (id, status, type) => {
  return axios.request({
    url: baseurl + "game/param/status/" + type + "/" + id + "/" + status,
    method: "post",
  });
};

const LikeApp = ({ value }) => {
  return axios.request({
    url: baseurl + "game/like/" + value,
    method: "get",
  });
};

const LikeAppByParams = (data) => {
  return axios.request({
    url: baseurl + "game/like",
    data: data,
    method: "post",
  });
};

const LikeGameVersion = (data) => {
  return axios.request({
    url: baseurl + "game/version/like",
    data: data,
    method: "post",
  });
};

const LikeAppByReport = ({ value }) => {
  return axios.request({
    url: baseurl + "game/like/report/" + value + "/" + 1,
    method: "get",
  });
};

const Enable = (id, enable) => {
  return axios.request({
    url: baseurl + "game/enable/" + id + "/" + enable,
    method: "post",
  });
};

const GameTakeDown = (id) => {
  return axios.request({
    url: baseurl + "game/offLine/" + id,
    method: "post",
  });
};

const BusinessCheck = (id, status) => {
  return axios.request({
    url: baseurl + "game/businessCheck/" + id + "/" + status,
    method: "post",
  });
};

const Add = (data) => {
  return axios.request({
    url: baseurl + "game",
    data,
    method: "post",
  });
};

const Edit = (data) => {
  return axios.request({
    url: baseurl + "game/edit/" + data.ID,
    data,
    method: "post",
  });
};
const UploadURL = () => {
  return baseUrl + baseurl + "game/upload";
};

const Get = (id) => {
  return axios.request({
    url: baseurl + "game/" + id,
    method: "get",
  });
};

const GetGames = (appIDs) => {
  const data = {
    AppIDs: appIDs,
  };
  return axios.request({
    url: baseurl + "game/gamelist",
    data,
    method: "post",
  });
};

const GetSts = () => {
  return axios.request({
    url: baseurl + "game/sts",
    method: "get",
  });
};

const GetCosAuth = (options, callback) => {
  GetSts().then((data) => {
    console.log(data);
    callback({
      TmpSecretId: data.Data.credentials.tmpSecretId,
      TmpSecretKey: data.Data.credentials.tmpSecretKey,
      XCosSecurityToken: data.Data.credentials.sessionToken,
      ExpiredTime: data.Data.expiredTime,
    });
  });
};

const PushStatus = () => {
  return axios.request({
    url: baseurl + "config/pushstatus",
    method: "get",
  });
};

const ChangePushStatus = (status) => {
  return axios.request({
    url: baseurl + "config/pushconfig/" + status,
    method: "post",
  });
};

const AppInfo = () => {
  return axios.request({
    url: baseurl + "game/appinfo",
    method: "post",
  });
};

const AppMiInfo = () => {
  return axios.request({
    url: baseurl + "game/appmiinfo",
    method: "post",
  });
};
const UpdateForum = (id, status) => {
  return axios.request({
    url: baseurl + "game/forum/" + id + "/" + status,
    method: "post",
  });
};
//修改包名
const EditPkgName = (id, data) => {
  return axios.request({
    url: baseurl + "game/edit_pkg_name/" + id,
    method: "post",
    data,
  });
};
const Edit_down = (ID, status) => {
  return axios.request({
    url: baseurl + "game/change/auto_download/" + ID + "/" + status,
    data: {},
    method: "post",
  });
};

//机型查询
const getPhoneModel = () => {
  return axios.request({
    url: baseurl + "game/model/list",
    method: "post",
    data: {},
  });
};
//批量导入小米数据
const uploadMiData = (params) => {
  return axios.request({
    url: baseurl + "mi_batch/upload",
    method: "post",
    data: params,
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
};
//批量导出小米数据
const exportMiData = () => {
  return axios.request({
    url: baseurl + "mi_batch/export",
    method: "post",
  });
};

//导入小米标签映射表
const uploadMiTag = (params) => {
  return axios.request({
    url: baseurl + "category_tag/import",
    method: "post",
    data: params,
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
};
//小米标签映射查询
const getMiTagList = (data) => {
  return axios.request({
    url: baseurl + "category_tag/fetch",
    method: "post",
    data,
  });
};
//上传游戏时长
const getGameTimeList = (data) => {
  return axios.request({
    url: baseurl + "gameversion/act/list",
    method: "post",
    data,
  });
};
//修改包名
const editPkgName = (data) => {
  return axios.request({
    url:
      baseurl +
      "game/edit_package_name?id=" +
      data.id +
      "&pkgName=" +
      data.pkgName,
    method: "post",
  });
};
//数据迁移
const subMergeData = (data) => {
  return axios.request({
    url: baseurl + "game/sub_merge",
    method: "post",
    data,
  });
};
//获取非预约内侧版本
const checkReleaseVersion = (data) => {
  return axios.request({
    url: baseurl + "game/sub_or_release_version?id=" + data,
    method: "post",
  });
};
//获取非预约版本
const checkSubVersion = (data) => {
  return axios.request({
    url: baseurl + "game/sub_version?id=" + data,
    method: "post",
  });
};
export default {
  getGameTimeList,
  updateParamStatusByType,
  FindByPage,
  LikeApp,
  LikeAppByParams,
  LikeGameVersion,
  LikeAppByReport,
  Enable,
  Add,
  Edit,
  UploadURL,
  Get,
  GetGames,
  GetSts,
  GetCosAuth,
  PushStatus,
  ChangePushStatus,
  GameTakeDown,
  AppInfo,
  AppMiInfo,
  BusinessCheck,
  UpdateForum,
  EditPkgName,
  Edit_down,
  getPhoneModel,
  uploadMiData,
  exportMiData,
  uploadMiTag,
  getMiTagList,
  editPkgName,
  subMergeData,
  checkReleaseVersion,
  checkSubVersion,
};
