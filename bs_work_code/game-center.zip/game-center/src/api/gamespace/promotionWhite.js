import axios from '@/libs/api.request'
import baseurl from './base'

const GetList = () => {
  return axios.request({
    url: baseurl + 'game/important/fetch',
    method: 'post',
  })
}

const Add = (data) => {
  return axios.request({
    url: baseurl + 'game/important/create',
    data: data,
    method: 'post'
  })
}

const changeStatus = (id) => {
  return axios.request({
    url: baseurl + 'game/important/delete?Id='+id,
    method: 'post',
  })
}

export default {
  GetList,
  Add,
  changeStatus,
}
