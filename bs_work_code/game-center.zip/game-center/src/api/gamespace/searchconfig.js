import axios from '@/libs/api.request'
import baseurl from './base'

// 查询榜单列表
const GetRankList = (data) => {
  return axios.request({
    url: baseurl + 'gamerank/ranklist',
    data,
    method: 'post'
  })
}

// 查询搜索模块列表
const GetSearchModels = (params) => {
  return axios.request({
    url: baseurl + 'home/searchmodel/list',
    method: 'post',
    data: params
  })
}


// 模块上下架
const UpdateStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'home/searchmodel/changestatus/' + id + '/' + status,
    method: 'post'
  })
}

const AddSearchModels = (params) => {
  return axios.request({
    url: baseurl + 'home/searchmodel/add',
    method: 'post',
    data: params
  })
}

const EditSearchModels = (params) => {
  return axios.request({
    url: baseurl + 'home/searchmodel/edit',
    method: 'post',
    data: params
  })
}

const GetHotList = (params) => {
  return axios.request({
    url: baseurl + 'home/hotword/list',
    method: 'post',
    data: params
  })
}

const AddHotWord = (params) => {
  return axios.request({
    url: baseurl + 'home/hotword/add',
    method: 'post',
    data: params
  })
}

const deleteHotWord = (params) => {
  return axios.request({
    url: baseurl + 'home/hotword/changestatus',
    method: 'post',
    data: params
  })
}

//搜索词查询
const getSearchList = (params) => {
  return axios.request({
    url: baseurl + 'keyword/fetch',
    method: 'post',
    data: params
  })
}
//新增搜索词
const addSearchWord = (params) => {
  return axios.request({
    url: baseurl + 'keyword/create',
    method: 'post',
    data: params
  })
}
//编辑搜索词
const editSearchWord = (id, params) => {
  return axios.request({
    url: baseurl + 'keyword/edit/' + id,
    method: 'post',
    data: params
  })
}
//编辑搜索词
const delSearchWord = (id) => {
  return axios.request({
    url: baseurl + 'keyword/delete/' + id,
    method: 'post',
    data: {}
  })
}
//校验搜索词
const validateSearchWord = (data) => {
  return axios.request({
    url: baseurl + 'keyword/validate',
    method: 'post',
    data
  })
}
export default {
  GetRankList,
  GetSearchModels,
  UpdateStatus,
  AddSearchModels,
  EditSearchModels,
  GetHotList,
  AddHotWord,
  deleteHotWord,
  getSearchList,
  addSearchWord,
  editSearchWord,
  delSearchWord,
  validateSearchWord
}
