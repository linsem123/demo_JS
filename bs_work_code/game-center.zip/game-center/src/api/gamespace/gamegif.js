import axios from '@/libs/api.request'
import baseurl from './base'

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params
  }
  return axios.request({
    url: baseurl + 'gamegift/list',
    data,
    method: 'post'
  })
}

const Add = (data) => {
  return axios.request({
    url: baseurl + 'gamegift/add',
    data,
    method: 'post'
  })
}

const Edit = (data) => {
  return axios.request({
    url: baseurl + 'gamegift/edit',
    data,
    method: 'post'
  })
}

const CheckStatus = (id, data) => {
  console.log(id, data);
  return axios.request({
    url: baseurl + 'gamegift/check/' + id,
    data,
    method: 'post'
  })
}

const LikeGift = ({
  value
}) => {
  return axios.request({
    url: baseurl + 'gamegift/like/' + value,
    method: 'get'
  })
}

const GiftsByType = (giftType) => {
  return axios.request({
    url: baseurl + 'gamegift/gifts/' + giftType,
    method: 'get'
  })
}
/*投放*/
const BindToRank = (id) => {
  return axios.request({
    url: baseurl + 'gamegift/bind/' + id,
    method: 'post'
  })
}

const UnbindFromRank = (id) => {
  return axios.request({
    url: baseurl + 'gamegift/unbind/' + id,
    method: 'post'
  })
}


const GiftRankList = (data) => {
  return axios.request({
    url: baseurl + 'gamegift/ranklist',
    data,
    method: 'post'
  })
}


const TopRank = (id) => {
  return axios.request({
    url: baseurl + 'gamegift/sort/' + id,
    method: 'post'
  })
}
//编辑
const EditGift = (data) => {
  return axios.request({
    url: baseurl + 'gamegift/info/edit?id=' + data.ID,
    data,
    method: 'post'
  })
}
//补码
const SupplyGift = (data, id) => {
  return axios.request({
    url: baseurl + 'gamegift/add/key?id=' + id,
    data,
    method: 'post'
  })
}

export default {
  FindByPage,
  Add,
  CheckStatus,
  Edit,
  LikeGift,
  GiftsByType,
  BindToRank,
  UnbindFromRank,
  GiftRankList,
  TopRank,
  EditGift,
  SupplyGift
}
