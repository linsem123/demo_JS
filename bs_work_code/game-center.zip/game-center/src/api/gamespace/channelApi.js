import axios from '@/libs/api.request'
import baseurl from './base'
const List = (params) => {
    return axios.request({
        url: baseurl + 'gameversion/channel/rule/get',
        method: 'post',
        data: params,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    })
}
const Edit = (params) => {
    return axios.request({
        url: baseurl + 'gameversion/channel/rule/update',
        method: 'post',
        data: params,
    })
}
const add = (params) => {
    console.log(params)
    return axios.request({
        url: baseurl + 'gameversion/channel/rule/create',
        method: 'post',
        data: params,
    })
}

const deletes = (id) => {
    return axios.request({
        url: baseurl + 'gameversion/channel/rule/delete/' + id,
        method: 'post',
        data: {}
    })
}
const getconfig = () => {
    return axios.request({
        url: baseurl + 'gameversion/channel/rule/getconfig',
        method: 'post',
        data: {}
    })
}

export default {
    List,
    deletes,
    Edit,
    add,
    getconfig
}