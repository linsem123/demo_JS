import axios from '@/libs/api.request'
import baseurl from './base'

// 获取任务列表
const GetList = (Page, Limit, Params) => {
    const data = {
        Limit,
        Page,
        Params,
    };
    return axios.request({
        url: baseurl + 'sms/getTaskList',
        method: 'post',
        data
    })
}

// 创建任务
const CreateTask = (data) => {
    return axios.request({
      url: baseurl + "sms/createTask",
      data,
      method: "post",
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
};

// 测试短信发送
const TestSmsSend = (data) => {
    return axios.request({
      url: baseurl + "sms/test",
      data,
      method: "post",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    });
};

export default {
  GetList,
  CreateTask,
  TestSmsSend
}
