import axios from '@/libs/api.request'
import baseurl from './base'

const GetCloudFolderList = (params) => {
  return axios.request({
    url: baseurl + 'bootstrap/cloudfolderlist',
    method: 'post',
    data: params
  })
}

const AddCloudFolder = (form) => {
  return axios.request({
    url: baseurl + 'bootstrap/addcloudfolder',
    method: 'post',
    data: form
  })
}

const EditCloudFolder = (form, id) => {
  return axios.request({
    url: baseurl + 'bootstrap/editcloudfolder/' + id,
    method: 'post',
    data: form
  })
}

const UpdateStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'bootstrap/updatecloudfolderstatus/' + id + '/' + status,
    method: 'post'
  })
}

export default {
  GetCloudFolderList,
  AddCloudFolder,
  EditCloudFolder,
  UpdateStatus,
}
