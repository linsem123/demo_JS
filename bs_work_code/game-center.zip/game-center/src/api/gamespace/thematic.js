import axios from '@/libs/api.request'
import baseurl from './base'

const AddThematic = (form) => {
  return axios.request({
    url: baseurl + 'thematic/add',
    method: 'post',
    data: form
  })
}

const EditThematic = (form, id) => {
  return axios.request({
    url: baseurl + 'thematic/edit/' + id,
    method: 'post',
    data: form
  })
}

const UpdateStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'thematic/updatestatus/' + id + '/' + status,
    method: 'post'
  })
}

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'thematic/listbypage',
    data: data,
    method: 'post'
  })
}

const Like = (name) => {
  return axios.request({
    url: baseurl + 'thematic/like/' + name,
    method: 'post'
  })
}

const ThematicRankList = (id) => {
  return axios.request({
    url: baseurl + 'thematic/ranklist/' + id,
    method: 'post'
  })
}

const UnBind = (id) => {
  return axios.request({
    url: baseurl + 'thematic/unbind/' + id,
    method: 'post',
  })
}

const Bind = (form) => {
  return axios.request({
    url: baseurl + 'thematic/bind',
    method: 'post',
    data: form
  })
}

const Sort = (id) => {
  return axios.request({
    url: baseurl + 'thematic/sort/' + id,
    method: 'post',
  })
}

const GetThematicList = (status) => {
  return axios.request({
    url: baseurl + 'thematic/list/' + status,
    method: 'post',
  })
}

const ThematicOne = (id) => {
  return axios.request({
    url: baseurl + 'thematic/one/' + id,
    method: 'post',
  })
}

export default {
  AddThematic,
  EditThematic,
  UpdateStatus,
  FindByPage,
  Like,
  ThematicRankList,
  UnBind,
  Bind,
  Sort,
  GetThematicList,
  ThematicOne,
}
