import axios from '@/libs/api.request';
import baseurl from './base';

const FindByPage = (
    Limit,
    Page,
    Params
) => {
    const data = {
        Limit,
        Page,
        Params,
    }
    return axios.request({
        url: baseurl + 'comment/list',
        data,
        method: 'post'
    })
}

const UpdateStatus = (id, status) => {
    return axios.request({
        url: baseurl + 'comment/updatestatus/' + id + '/' + status,
        method: 'post'
    })
}

const Up = (id) => {
    return axios.request({
        url: baseurl + 'comment/up/' + id,
        method: 'post'
    })
}

const Lift = (id) => {
    return axios.request({
        url: baseurl + 'comment/lift/' + id,
        method: 'post'
    })
}

const Reply = (id, params) => {
    const data = {
        CommentID: id,
        Content: params.Content
    }
    return axios.request({
        url: baseurl + 'comment/reply/' + id,
        method: 'post',
        data: data
    })
}
const One = (type, id) => {
    return axios.request({
        url: baseurl + 'comment/one/' + type + '/' + id,
        method: 'post',
    })
}

const Ban = (data) => {
    return axios.request({
        url: baseurl + 'comment/ban',
        method: 'post',
        data: data,
    })
}

const ReplyList = (id) => {
    return axios.request({
        url: baseurl + 'comment/replylist/' + id,
        method: 'post',
    })
}


const LiftBan = (id) => {
    return axios.request({
        url: baseurl + 'comment/liftban/' + id,
        method: 'post',
    })
}


const BanList = (
    Limit,
    Page,
    Params
) => {
    const data = {
        Limit,
        Page,
        Params,
    }
    return axios.request({
        url: baseurl + 'comment/banlist',
        data,
        method: 'post'
    })
}

const EditBan = (data) => {
    return axios.request({
        url: baseurl + 'comment/edit',
        method: 'post',
        data: data,
    })
}

const SetAdminInfo = (data) => {
    const admin = {
        NickName: data.NickName,
        HeaderImg: data.HeaderImg
    }
    return axios.request({
        url: baseurl + 'comment/updateadmin',
        method: 'post',
        data: admin
    })
}

const GetAdminInfo = () => {
    return axios.request({
        url: baseurl + 'comment/admininfo',
        method: 'post'
    })
}

// 提醒人列表
const GetPersonList = (data) => {
    return axios.request({
        url: baseurl + 'bs_conf_person/list',
        method: 'post',
        data
    })
}
// 添加提醒人
const AddPerson = (data) => {
    return axios.request({
        url: baseurl + 'bs_conf_person/save',
        method: 'post',
        data
    })
}
// 删除提醒人
const DelPerson = (data) => {
    return axios.request({
        url: baseurl + 'bs_conf_person/del',
        method: 'post',
        data
    })
}

export default {
    FindByPage,
    UpdateStatus,
    Up,
    Lift,
    Reply,
    One,
    Ban,
    ReplyList,
    LiftBan,
    BanList,
    EditBan,
    SetAdminInfo,
    GetAdminInfo,
    GetPersonList,
    AddPerson,
    DelPerson
}
