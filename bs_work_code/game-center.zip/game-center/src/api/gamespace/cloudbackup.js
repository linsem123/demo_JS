import axios from '@/libs/api.request';
const baseurl = '/v1/api/cloudbackup/';

// 查询云备份榜单列表
const GetCloudBackupList = (data) => {
    return axios.request({
        url: baseurl + 'rank/getRankList',
        data,
        method: 'post'
    })
}
// 新增云备份榜单
const AddCloudBackup = (form) => {
    return axios.request({
        url: baseurl + 'rank/addRank',
        method: 'post',
        data: form
    })
}
// 修改榜单状态
const UpdateStatus = (id, status) => {
    return axios.request({
        url: baseurl + 'rank/updateStatus?id=' + id + '&status=' + status,
        method: 'put'
    })
}

// 查询榜单应用列表
const GetRankAppList = (data) => {
    return axios.request({
        url: baseurl + 'rank/getAppList',
        data,
        method: 'post'
    })
}
// 修改应用是否支持高版本下载
const UpdateApp = (id, isHighVersionDownload) => {
    return axios.request({
        url: baseurl + 'rank/updateApp?id=' + id + '&isHighVersionDownload=' + isHighVersionDownload,
        method: 'put'
    })
}
// 榜单解绑应用
const UnbindApp = (id) => {
    return axios.request({
        url: baseurl + 'rank/unbindApp?id=' + id,
        method: 'delete'
    })
}
// 榜单绑定应用
const BindApp = (form) => {
    return axios.request({
        url: baseurl + 'rank/bindApp',
        method: 'post',
        data: form
    })
}

export default {
    GetCloudBackupList,
    AddCloudBackup,
    UpdateStatus,
    GetRankAppList,
    UpdateApp,
    UnbindApp,
    BindApp
}
