import axios from '@/libs/api.request';
import baseurl from './base';

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'comment/list',
    data,
    method: 'post'
  })
}


const LikeUser = ({
                   value
                 }) => {
  return axios.request({
    url: baseurl + 'comment/user/like/' + value,
    method: 'get'
  })
}


export default {
  FindByPage,
  LikeUser
}
