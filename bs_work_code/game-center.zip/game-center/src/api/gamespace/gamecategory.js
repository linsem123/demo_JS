import axios from '@/libs/api.request';
import baseurl from './base';
import app from "../../store/module/app";

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'gamecateory/list',
    data,
    method: 'post'
  })
}

 const Like = (value, appType) => {
  return axios.request({
    url: baseurl + 'gamecateory/like/' + appType + '/'+ value,
    method: 'get'
  })
}

 const Add = (data) => {
  return axios.request({
    url: baseurl + 'gamecateory',
    data,
    method: 'post'
  })
}

 const Edit = (id, data) => {
  return axios.request({
    url: baseurl + 'gamecateory/edit/' + id,
    data,
    method: 'post'
  })
}

const Get = (id) => {
  return axios.request({
    url: baseurl + 'gamecateory/' + id,
    method: 'get'
  })
}
export default{
  FindByPage,
  Like,
  Add,
  Edit,
  Get,
}
