import axios from '@/libs/api.request';
import baseurl from './base';

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'developer/list',
    data,
    method: 'post'
  })
}

 const Like = ({
  value
}) => {
  return axios.request({
    url: baseurl + 'developer/like/' + value,
    method: 'get'
  })
}

 const Enable = (
  id,
  enable
) => {
  return axios.request({
    url: baseurl + 'developer/enable/' + id + '/' + enable,
    method: 'post'
  })
}


 const Add = (data) => {
  return axios.request({
    url: baseurl + 'developer',
    data,
    method: 'post'
  })
}

 const Edit = (id, data) => {
  return axios.request({
    url: baseurl + 'developer/edit/' + id,
    data,
    method: 'post'
  })
}

const Get = (id) => {
  return axios.request({
    url: baseurl + 'developer/' + id,
    method: 'get'
  })
}
export default{
  FindByPage,
  Enable,
  Like,
  Add,
  Edit,
  Get,
}