import axios from '@/libs/api.request';
import baseurl from './base';
// import config from '@/config';
// const baseUrl = process.env.NODE_ENV === 'development' ? config.baseUrl.dev : config.baseUrl.pro
const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'gamerank/gamelist/',
    data,
    method: 'post'
  })
};

const Bind=(
  rankType,
  appID
)=>{
  return axios.request({
    url: baseurl + 'gamerank/bind/'+rankType+"/"+appID,
    method: 'post'
  })
}
const UnBind=( poolid,id)=>{
  return axios.request({
    url: baseurl + 'gamerank/unbind/'+poolid+'/'+id,
    method: 'post'
  })
}
const Up=(poolid,
  id
)=>{
  return axios.request({
    url: baseurl + 'gamerank/up/'+poolid+'/'+id,
    method: 'post'
  })
}

const Upswitch=(id,categoryType)=>{
  return axios.request({
    url: baseurl + 'gamecateory/sort/'+id + '/' + categoryType,
    method: 'post'
  })
}

const AddRank = (params) => {
  return axios.request({
    url: baseurl + 'gamerank/addrank',
    method: 'post',
    data: params
  })
}

const EditRank = (params) => {
  return axios.request({
    url: baseurl + 'gamerank/editrank',
    method: 'post',
    data: params
  })
}

const UpdateRankStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'gamerank/changestatus/' + id + '/' + status,
    method: 'post',
  })
}

const GetRankTags = (categoryId) => {
  return axios.request({
    url: baseurl + 'gamecateory/taglist/' + categoryId,
    method: 'post',
  })
}

const GetRankTagsGames = (data) => {
  return axios.request({
    url: baseurl + 'gamecateory/gamelist',
    data,
    method: 'post',
  })
}


const TagsStatus = (gameid, status) => {
  return axios.request({
    url: baseurl + 'gamecateory/tag/changestatus/' + gameid + '/' + status,
    method: 'post',
  })
}


const SwitchGamesStatus = (CategoryID, categoryType, status) => {
  return axios.request({
    url: baseurl + 'gamecateory/changestatus/' + CategoryID + '/' + categoryType+ '/' + status,
    method: 'post',
  })
}

const TagsUp = (tagid) => {
  return axios.request({
    url: baseurl + 'gamecateory/tag/sort/' + tagid,
    method: 'post',
  })
}



export default {
  FindByPage,
  Bind,
  UnBind,
  Up,
  AddRank,
  EditRank,
  UpdateRankStatus,
  GetRankTags,
  GetRankTagsGames,
  TagsStatus,
  SwitchGamesStatus,
  TagsUp,
  Upswitch,
}
