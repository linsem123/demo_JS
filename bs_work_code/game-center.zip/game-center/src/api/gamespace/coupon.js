/*优惠券相关*/
import axios from '@/libs/api.request'
import baseurl from './base'

const gamesdk = '/v1/api/gamesdk/'


// 优惠券列表
const GetList = (params) => {
    return axios.request({
        url: baseurl + 'coupon/list',
        data: params,
        method: 'post'
    })
}

// 编辑优惠券
const EditCoupon = (formData) => {
    return axios.request({
        url: baseurl + 'coupon/edit/' + formData.ID,
        data: formData,
        method: 'post'
    })
}

// 新增优惠券
const AddCoupon = (formData) => {
    return axios.request({
        url: baseurl + 'coupon/add',
        data: formData,
        method: 'post'
    })
}

// 更新状态，审核
const UpdateState = (formData) => {
    return axios.request({
        url: baseurl + 'coupon/updatestatus/' + formData.ID + '/' + formData.ApproveState,
        // data: formData,
        method: 'post'
    })
}


// 导出
const ExportCoupon = (id) => {
    return axios.request({
        url: baseurl + 'coupon/export/' + id,
        method: 'post'
    })
}

// 导出
const ExportCouponUsedData = (id) => {
    return axios.request({
        url: baseurl + 'coupon/used_data/' + id,
        method: 'get'
    })
}

// 投放
const SendCoupon = (data) => {
    return axios.request({
        url: baseurl + 'coupon/rank/add',
        data,
        method: 'post'
    })
}


// 根据游戏IDS获取游戏数据
const GamesByIds = (ids) => {
    return axios.request({
        url: baseurl + 'game/gamelist',
        data: { AppIDs: ids },
        method: 'post'
    })
}


// 榜单列表
const RankList = (params) => {
    return axios.request({
        url: baseurl + 'coupon/rank/list',
        data: params,
        method: 'post'
    })
}

// 鲨享券列表
const SharkRankList = (params) => {
  return axios.request({
      url: baseurl + 'coupon/rank/shark/list',
      data: params,
      method: 'post'
  })
}

// 移除从榜单列表
const RemoveFromRank = (id) => {
    return axios.request({
        url: baseurl + 'coupon/rank/remove/' + id,
        method: 'post'
    })
}
// 置顶从榜单列表
const TopRank = (id) => {
    return axios.request({
        url: baseurl + 'coupon/rank/sort/' + id,
        method: 'post'
    })
}

const CouponConfigStatus = () => {
    return axios.request({
        url: baseurl + 'config/couponconfig',
        method: 'post'
    })
}
// 优惠券任务列表
const CouponTaskList = (params) => {
    return axios.request({
        url: baseurl + 'couponactivity/list',
        method: 'post',
        data: params,
    })
}
// 优惠券任务新增
const CouponTaskAdd = (params) => {
    return axios.request({
        url: baseurl + 'couponactivity/add',
        method: 'post',
        data: params,
    })
}
// 优惠券任务礼包获取
const CouponTaskGamegiftOne = (id) => {
    return axios.request({
        url: baseurl + 'gamegift/one/' + id,
        method: 'post',

    })
}
// 优惠券任务优惠券获取
const CouponTaskCouponOne = (id) => {
    return axios.request({
        url: baseurl + 'coupon/one/' + id,
        method: 'post',

    })
}
const ChangeCouponConfigStatus = (status, id) => {
    return axios.request({
        url: baseurl + 'config/couponstatus/' + id + '/' + status,
        method: 'post'
    })
}

// 黑白榜单查询
const LimitsRank = (params) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank_pool/find_by_page',
        method: 'post',
        data: params,
    })
}
// 黑白榜单新增
const AddLimitsRank = (params) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank_pool/add',
        method: 'post',
        data: params,
    })
}
// 黑白榜单编辑
const EditLimitsRank = (params) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank_pool/edit',
        method: 'post',
        data: params,
    })
}
// 黑白榜单模糊查询
const LikeLimitRank = (value) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank_pool/like?Name=' + value,
        method: 'post',
        data: {},
    })
}
// 黑白榜单状态
const UpdateLimitStatus = (id, status) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank_pool/update_status?PoolId=' + id + '&Status=' + status,
        method: 'post',
        data: {},
    })
}
// 黑白榜单游戏
const RankAppList = (PoolId, params) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank/find_by_page?PoolId=' + PoolId,
        method: 'post',
        data: params,
    })
}
// 黑白榜单绑定游戏
const RankAppBind = (params) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank/bind',
        method: 'post',
        data: params,
    })
}
// 黑白榜单绑定游戏
const RankAppUnbind = (id, appId) => {
    return axios.request({
        url: baseurl + 'coupon/app/rank/unbind?PoolId=' + id + '&AppId=' + appId,
        method: 'post',
        data: {},
    })
}
//新版优惠券任务-查询list
const NewTaskList = (data) => {
    return axios.request({
        url: baseurl + 'task/find_by_page',
        method: 'post',
        data,
    })
}
//新版优惠券任务-新增
const AddNewTask = (data) => {
    return axios.request({
        url: baseurl + 'task/add',
        method: 'post',
        data,
    })
}
//新版优惠券任务-修改
const EditNewTask = (data) => {
    return axios.request({
        url: baseurl + 'task/edit?id=' + data.Id,
        method: 'post',
        data,
    })
}
//新版优惠券任务-更新状态
const UpdateNewTask = (status, ID) => {
    return axios.request({
        url: baseurl + 'task/update_status?id=' + ID + '&status=' + status,
        method: 'post',
        data: {},
    })
}
//新版优惠券任务-单条数据
const NewTaskOne = (ID) => {
    return axios.request({
        url: baseurl + 'task/one?id=' + ID,
        method: 'post',
        data: {},
    })
}
//游戏模糊查询
const LikeApp = (name) => {
    return axios.request({
        url: baseurl + 'task/app/like?name=' + name,
        method: 'post',
        data: {},
    })
}
//游戏初始化
const GetApp = (data) => {
    return axios.request({
        url: baseurl + 'task/app/list',
        method: 'post',
        data,
    })
}
//任务名称模糊查询
const LikeTask = (name) => {
    return axios.request({
        url: baseurl + 'task/like?name=' + name,
        method: 'post',
        data: {},
    })
}
//优惠券模糊查询

const couponLike = (name, type) => {
    return axios.request({
        url: baseurl + 'coupon/like?name=' + name + '&type=' + type,
        method: 'post',
        data: {},
    })
}
const couponDetail = (id) => {
    return axios.request({
        url: baseurl + 'coupon/detail?id=' + id,
        method: 'post',
        data: {},
    })
}

//复制优惠券
const CouponCopy = (id) => {
    return axios.request({
        url: baseurl + 'coupon/copy/' + id,
        method: 'post',
        data: {},
    })
}
//复制自动任务
const TaskCopy = (id) => {
    return axios.request({
        url: baseurl + 'task/copy/' + id,
        method: 'post',
        data: {},
    })
}
/* ***** 自动创建优惠券列表 sdk5.5.0新增 ***** */
const getAutoCouponList = (params) => {
    return axios.request({
        url: gamesdk + 'coupon_replication_task/list',
        data: params,
        method: 'post'
    })
}

// 保存优惠券
const saveAutoCoupon = (params) => {
    return axios.request({
        url: gamesdk + 'coupon_replication_task/save',
        data: params,
        method: 'post'
    })
}

// 删除自动优惠券
const delAutoCoupon = (id) => {
    return axios.request({
        url: gamesdk + 'coupon_replication_task/del/' + id,
        method: 'post'
    })
}

// 修改状态
const updateAutoCoupon = (id, status) => {
    return axios.request({
        url: gamesdk + 'coupon_replication_task/status/update/' + id + '/' + status,
        method: 'post'
    })
}

export default {
    GetList,
    AddCoupon,
    EditCoupon,
    UpdateState,
    ExportCoupon,
    SendCoupon,
    GamesByIds,

    SharkRankList,
    RankList,
    RemoveFromRank,
    TopRank,

    CouponConfigStatus,
    ChangeCouponConfigStatus,

    CouponTaskList,
    CouponTaskAdd,
    CouponTaskGamegiftOne,
    CouponTaskCouponOne,
    ExportCouponUsedData,

    LimitsRank,
    AddLimitsRank,
    EditLimitsRank,
    LikeLimitRank,
    UpdateLimitStatus,
    RankAppList,
    RankAppBind,
    RankAppUnbind,

    NewTaskList,
    AddNewTask,
    EditNewTask,
    UpdateNewTask,
    NewTaskOne,
    LikeApp,
    GetApp,
    LikeTask,
    couponLike,
    couponDetail,
    CouponCopy,
    TaskCopy,

    getAutoCouponList,
    saveAutoCoupon,
    delAutoCoupon,
    updateAutoCoupon
}
