/*每日签到相关*/
import axios from '@/libs/api.request'
import baseurl from './base'

// 每日签到列表
const DailySignActivityList = (params) =>{
    return axios.request({
        url: baseurl + 'bs_activity/list',
        method: 'post',
        data:params
    })
}

// 每日签到增加 or 更新
const DailySignAddOrUpdate = (params) =>{
    return axios.request({
        url: baseurl + 'bs_activity/save',
        method: 'post',
        data:params
    })
}

//每日签到删除
const DailySignDelete = (params) =>{
    return axios.request({
        url: baseurl + 'bs_activity/del/'+params.id,
        method: 'post',
        data:params
    })
}


export default {
    DailySignActivityList,
    DailySignAddOrUpdate,
    DailySignDelete

}
