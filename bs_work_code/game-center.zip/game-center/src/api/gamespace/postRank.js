import axios from "@/libs/api.request";
import baseurl from "./base";
//获取榜单列表
const GetRankList = (data) => {
  return axios.request({
    url: baseurl + "post/rank/find_by_page",
    method: "post",
    data,
  });
};
//新增榜单
const addRank = (data) => {
  return axios.request({
    url: baseurl + "post/rank/add",
    method: "post",
    data,
  });
};
//编辑榜单
const editRank = (data) => {
  return axios.request({
    url: baseurl + "post/rank/edit?id=" + data.Id,
    method: "post",
    data,
  });
};
//更新状态
const updateStatus = (id, status) => {
  return axios.request({
    url: baseurl + "post/rank/status/update?id=" + id + "&status=" + status,
    method: "post",
  });
};
//绑定帖子
const bindPost = (data) => {
  return axios.request({
    url: baseurl + "post/rank/bind",
    method: "post",
    data,
  });
};
//解绑帖子
const unbindPost = (id) => {
  return axios.request({
    url: baseurl + "post/rank/unbind?id=" + id,
    method: "post",
  });
};
//启用/禁用
const changeSheild = (id, status) => {
  return axios.request({
    url:
      baseurl + "post/rank/post_status/update?id=" + id + "&status=" + status,
    method: "post",
  });
};
//获取榜单帖子列表
const GetPostRankList = (data) => {
  return axios.request({
    url: baseurl + "post/rank/post_find_by_page",
    method: "post",
    data,
  });
};
//帖子置顶
const Top = (id, Sort) => {
  return axios.request({
    url: baseurl + "post/rank/top?id=" + id + "&Sort=" + Sort,
    method: "post",
  });
};

//帖子排序
const Sort = (data) => {
  return axios.request({
    url: baseurl + "post/rank/sort",
    method: "post",
    data,
  });
};

export default {
  GetRankList,
  addRank,
  editRank,
  updateStatus,
  bindPost,
  unbindPost,
  changeSheild,
  GetPostRankList,
  Top,
  Sort,
};
