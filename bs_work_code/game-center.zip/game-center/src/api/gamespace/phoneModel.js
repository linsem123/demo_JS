import axios from '@/libs/api.request';
import baseurl from './base';
//机型查询
const getPhoneModel = (data) => {
    return axios.request({
        url: baseurl + 'game/model/fetch',
        method: 'post',
        data
    })
}
//机型新增
const AddPhone = (data) => {
    return axios.request({
        url: baseurl + 'game/model/create',
        method: 'post',
        data
    })
}
//机型编辑
const EditPhone = (id, data) => {
    return axios.request({
        url: baseurl + 'game/model/edit/' + id,
        method: 'post',
        data
    })
}
// 获取机型列表
const fetchPhoneModelList = () => {
    return axios.request({
        url: baseurl + 'game/model/list',
        method: 'post',
    })
}

export default {
    getPhoneModel,
    AddPhone,
    EditPhone,
    fetchPhoneModelList
}
