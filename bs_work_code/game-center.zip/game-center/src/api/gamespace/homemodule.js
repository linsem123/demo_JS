import axios from '@/libs/api.request'
import baseurl from './base'

// 上传人群包
const GetSts = (params) => {
  return axios.request({
    url: '/v1/api/gamesdk/crowd/upload/' + params.crowdId,
    method: 'post',
    data: params.formData,
    headers: {
      'content-type': false
    },
  })
}

// 查询投放榜单列表
const GetRankList = () => {
  return axios.request({
    url: baseurl + 'gamerank/ranklist',
    method: 'post'
  })
}

const AddModel = (params) => {
  return axios.request({
    url: baseurl + 'home/model/add',
    method: 'post',
    data: params
  })
}

const EditModel = (params) => {
  return axios.request({
    url: baseurl + 'home/model/edit',
    method: 'post',
    data: params
  })
}

const GetModelList = (params) => {
  return axios.request({
    url: baseurl + 'home/model/list',
    method: 'post',
    data: params
  })
}

const ModelLike = (name) => {
  return axios.request({
    url: baseurl + 'home/model/like/' + name,
    method: 'post'
  })
}
const ModelById = (id) => {
  return axios.request({
    url: baseurl + 'home/model/one/' + id,
    method: 'post'
  })
}
//
const GetModelByStatus = (id) => {
  return axios.request({
    url: baseurl + 'home/model/list/' + id,
    method: 'post',
  })
}

// 模块编辑预检查
const ModelPreEdit = (params) => {
  return axios.request({
    url: baseurl + 'home/model/pre_edit',
    method: 'post',
    data: params
  })
}


// 模块上下架
const UpdateStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'home/model/changestatus/' + id + '/' + status,
    method: 'post'
  })
}

// 查询模块内元素列表
const GetModuleEles = (modelId) => {
  return axios.request({
    url: baseurl + 'home/banner/list/' + modelId,
    method: 'post'
  })
}

// 模块添加元素
const AddBanner = (params) => {
  return axios.request({
    url: baseurl + 'home/banner/add',
    method: 'post',
    data: params
  })
}

const EditBanner = (params) => {
  return axios.request({
    url: baseurl + 'home/banner/edit',
    method: 'post',
    data: params
  })
}

const UpdateBannerStatus = (id, modelId, status) => {
  return axios.request({
    url: baseurl + 'home/banner/changestatus/' + id + '/' + modelId + '/' + status,
    method: 'post',
  })
}

// 查询首页模板配置
const GetHomeConfig = (id) => {
  return axios.request({
    url: baseurl + 'home/model/resource/' + id,
    method: 'post'
  })
}
// 保存首页模板配置
const SaveHomeConfig = (params) => {
  return axios.request({
    url: baseurl + 'home/model/sort',
    method: 'post',
    data: params
  })
}

// 模块内元素批量排序
const SortEles = (modelId, params) => {
  return axios.request({
    url: baseurl + 'home/banner/sort/' + modelId,
    method: 'post',
    data: params
  })
}

const GetRankById = (id) => {
  return axios.request({
    url: baseurl + 'gamerank/one/' + id,
    method: 'post'
  })
}

const LikeRank = (val, rankType) => {
  return axios.request({
    url: baseurl + 'gamerank/like/' + val + '/' + rankType,
    method: 'post'
  })
}


const CollectionList = (data) => {
  return axios.request({
    url: baseurl + 'home/collection/list',
    data,
    method: 'post'
  })
}


const AddCollection = (data) => {
  return axios.request({
    url: baseurl + 'home/collection/add',
    data,
    method: 'post'
  })
}

const EditCollection = (data) => {
  return axios.request({
    url: baseurl + 'home/collection/edit/' + data.ID,
    data,
    method: 'post'
  })
}

const CollectionStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'home/collection/changestatus/' + id + '/' + status,
    method: 'post'
  })
}
const moduleTypes = (name, type) => {
  return axios.request({
    url: baseurl + 'home/collection/like/' + name + "/" + type,
    method: 'post'
  })
}
const collectionInfo = (id) => {
  return axios.request({
    url: baseurl + 'home/collection/info/' + id,
    method: 'post'
  })
}
//锚定元素模糊查询
const getElementLike = (like, modelId, id) => {
  return axios.request({
    url: baseurl + 'home/banner/allocate/like/' + like + "/" + modelId + "/" + id,
    method: 'post'
  })
}



export default {
  GetSts,
  LikeRank,
  GetRankById,
  GetRankList,
  AddModel,
  EditModel,
  GetModelList,
  ModelLike,
  ModelById,
  GetModelByStatus,
  ModelPreEdit,
  UpdateStatus,
  GetModuleEles,
  AddBanner,
  EditBanner,
  UpdateBannerStatus,
  GetHomeConfig,
  SaveHomeConfig,
  SortEles,
  CollectionList,
  AddCollection,
  EditCollection,
  CollectionStatus,
  moduleTypes,
  collectionInfo,
  getElementLike
}
