import axios from '@/libs/api.request'
import baseurl from './base'

const List = (params) => {
  return axios.request({
    url: baseurl + 'announce/list',
    method: 'post',
    data: params
  })
}

const AddAnnounce = (params) => {
  return axios.request({
    url: baseurl + 'announce/add',
    method: 'post',
    data: params
  })
}

const EditAnnounce = (id, params) => {
  return axios.request({
    url: baseurl + 'announce/edit/' + id,
    method: 'post',
    data: params
  })
}

const UpdateStatus = (id, status) => {
  return axios.request({
    url: baseurl + 'announce/updatestatus/' + id + '/' + status,
    method: 'post',
  })
}
//游戏中心分页拉取
const getAnnounce = (data) => {
  return axios.request({
    url: baseurl + 'announce/find_by_page',
    method: 'post',
    data
  })
}
//根据ID查询数据
const getInitData = (id) => {
  return axios.request({
    url: baseurl + 'announce/detail?id=' + id,
    method: 'post',
  })
}

//公告管理根据ID或标题查询
const GetAnnounce = (data) => {
  return axios.request({
      url: baseurl + 'announce/like/query' ,
      method: 'post',
      data
  })
}
export default {
  List,
  AddAnnounce,
  EditAnnounce,
  UpdateStatus,
  getInitData,
  getAnnounce,
  GetAnnounce
}
