import axios from '@/libs/api.request';
import baseurl from './base';

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'gametag/list',
    data,
    method: 'post'
  })
}

 const Like = ({
  value
}) => {
  return axios.request({
    url: baseurl + 'gametag/like/' + value,
    method: 'get'
  })
}

 const Add = (data) => {
  return axios.request({
    url: baseurl + 'gametag',
    data,
    method: 'post'
  })
}

 const Edit = (id, data) => {
  return axios.request({
    url: baseurl + 'gametag/edit/' + id,
    data,
    method: 'post'
  })
}

const Get = (id) => {
  return axios.request({
    url: baseurl + 'gametag/' + id,
    method: 'get'
  })
}
export default{
  FindByPage,
  Like,
  Add,
  Edit,
  Get,
}