import axios from '@/libs/api.request'
import baseurl from './base'
import config from '@/config';
const baseUrl = process.env.NODE_ENV === 'development' ? config.baseUrl.dev : config.baseUrl.pro

const GetSettingData = () => {
  return axios.request({
    url: baseurl + 'daily',
    method: 'get'
  })
}


const GetFeedIds = (type, title) => {
  return axios.request({
    url: baseurl + 'daily/' + type + '/' + title || '',
    method: 'get'
  })
}

const EditSettingData = (data) => {
  return axios.request({
    url: baseurl + 'daily',
    data: data,
    method: 'post'
  })
}


const GetStartData = () => {
  return axios.request({
    url: baseurl + 'bootstrap/getLink',
    method: 'get'
  })
}

const EditStartData = (data) => {
  return axios.request({
    url: baseurl + 'bootstrap/setLink',
    data: data,
    method: 'post'
  })
}

const GetGameRecommendData = () => {
  return axios.request({
    url: baseurl + 'gamerank/game_recommend',
    method: 'post'
  })
}

const ChangeRank = (id, type, rankType) => {
  return axios.request({
    url: baseurl + 'gamerank/change/game_recommend/' + id + '/' + type + '/' + rankType,
    method: 'post'
  })
}
//游戏精选查询list
const getMulGame = (data) => {
  return axios.request({
    url: baseurl + 'daily/list',
    method: 'post',
    data
  })
}
//游戏精选新增
const addMulGame = (data) => {
  return axios.request({
    url: baseurl + 'daily/add',
    method: 'post',
    data
  })
}
//游戏精选编辑
const editMulGame = (id, data) => {
  return axios.request({
    url: baseurl + 'daily/edit?id=' + id,
    method: 'post',
    data
  })
}
//游戏精选置顶
const topMulGame = (id) => {
  return axios.request({
    url: baseurl + 'daily/sort?id=' + id,
    method: 'post',
  })
}
//游戏精选上架
const updateMulGame = (id, status) => {
  return axios.request({
    url: baseurl + 'daily/update_status?id=' + id + "&status=" + status,
    method: 'post',
  })
}
//游戏精选查询list
const getActGame = (data) => {
  return axios.request({
    url: baseurl + 'daily/activity/list',
    method: 'post',
    data
  })
}
//游戏精选新增
const addActGame = (data) => {
  return axios.request({
    url: baseurl + 'daily/activity/add',
    method: 'post',
    data
  })
}
//游戏精选编辑
const editActGame = (id, data) => {
  return axios.request({
    url: baseurl + 'daily/activity/edit?id=' + id,
    method: 'post',
    data
  })
}
//游戏精选置顶
const topActGame = (id) => {
  return axios.request({
    url: baseurl + 'daily/activity/sort?id=' + id,
    method: 'post',
  })
}
//游戏精选上架
const updateActGame = (id, status) => {
  return axios.request({
    url: baseurl + 'daily/activity/update_status?id=' + id + "&status=" + status,
    method: 'post',
  })
}
//游戏精选上架
const ActGameLick = (type, name) => {
  return axios.request({
    url: baseurl + 'daily/activity/like?jumpType=' + type + "&name=" + name,
    method: 'post',
  })
}

export default {
  GetSettingData,
  GetFeedIds,
  EditSettingData,
  GetStartData,
  EditStartData,
  GetGameRecommendData,
  ChangeRank,
  getMulGame,
  addMulGame,
  editMulGame,
  topMulGame,
  updateMulGame,
  getActGame,
  addActGame,
  editActGame,
  topActGame,
  updateActGame,
  ActGameLick
}
