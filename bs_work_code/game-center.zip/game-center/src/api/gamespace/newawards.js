import axios from '@/libs/api.request'
let baseurl = "/v1/api/draw/"
//活动列表
const FindByPage = (data) => {
    return axios.request({
        url: baseurl + 'pool/list',
        data,
        method: 'post'
    })
}
//新增活动
const AddPool = (data) => {
    return axios.request({
        url: baseurl + 'pool/add',
        data,
        method: 'post'
    })
}
//编辑活动
const EditPool = (data) => {
    return axios.request({
        url: baseurl + 'pool/edit',
        data,
        method: 'post'
    })
}
//奖品列表
const AwardList = (poolId) => {
    return axios.request({
        url: baseurl + 'item/list?poolId=' + poolId,
        data: {},
        method: 'post'
    })
}
//新增奖品
const AddAward = (data) => {
    return axios.request({
        url: baseurl + 'item/add',
        data,
        method: 'post'
    })
}
//编辑奖品
const EditAward = (data) => {
    return axios.request({
        url: baseurl + 'item/edit',
        data,
        method: 'post'
    })
}
//单个奖品信息
const getAward = (data) => {
    return axios.request({
        url: baseurl + 'gameaward/2',
        data,
        method: 'post'
    })
}
//配置模版
const SaveTemplate = (data) => {
    return axios.request({
        url: baseurl + 'single/add',
        data,
        method: 'post'
    })
}

//拉取模版信息
const getSingle = (id) => {
    return axios.request({
        url: baseurl + 'single/one?id=' + id,
        data: {},
        method: 'post'
    })
}
//配置概率
const SetRate = (data) => {
    return axios.request({
        url: baseurl + 'item/rate',
        data,
        method: 'post'
    })
}
//配置兜底
const SetDefault = (data) => {
    return axios.request({
        url: baseurl + 'item/default',
        data,
        method: 'post'
    })
}
//配置必中
const SetMustWin = (data) => {
    return axios.request({
        url: baseurl + 'item/must_win',
        data,
        method: 'post'
    })
}
//更新状态
const Upstate = (id, status) => {
    return axios.request({
        url: baseurl + 'pool/update_status?id=' + id + '&status=' + status,
        data: {},
        method: 'post'
    })
}
//模糊查询
const getTitle = (value) => {
    return axios.request({
        url: baseurl + 'pool/like/' + value,
        data: {},
        method: 'post'
    })
}
//复制奖池
const copyAward = (data) => {
    return axios.request({
        url: '/bs-basement-admin/awardPool/copy',
        data,
        method: 'post'
    })
}

export default {
    FindByPage,
    AddPool,
    EditPool,

    AwardList,
    AddAward,
    EditAward,
    getAward,
    SaveTemplate,
    getSingle,
    SetRate,
    SetDefault,
    SetMustWin,
    Upstate,
    getTitle,

    copyAward
}