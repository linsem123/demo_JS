import axios from '@/libs/api.request'
import baseurl from './base'

const GetList = (data) => {
    return axios.request({
        url: baseurl + 'appmodelconfig/fetch',
        method: 'post',
        data
    })
}
const Add = (data) => {
    return axios.request({
        url: baseurl + 'appmodelconfig/create',
        method: 'post',
        data
    })
}
const Edit = (id, data) => {
    return axios.request({
        url: baseurl + 'appmodelconfig/edit/' + id,
        method: 'post',
        data
    })
}
const One = (id, data) => {
    return axios.request({
        url: baseurl + 'appmodelconfig/one/' + id,
        method: 'post',
        data
    })
}
export default {
    GetList,
    Add,
    Edit,
    One
}