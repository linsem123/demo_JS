import axios from '@/libs/api.request'
import baseurl from './base'
import config from '@/config';
const baseUrl = process.env.NODE_ENV === 'development' ? config.baseUrl.dev : config.baseUrl.pro

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params
  }
  return axios.request({
    url: baseurl + 'gameaward/list',
    data,
    method: 'post'
  })
}

const Add = (data) => {
  return axios.request({
    url: baseurl + 'gameaward/addpool',
    data,
    method: 'post'
  })
}

const Edit = (data) => {
  return axios.request({
    url: baseurl + 'gameaward/editpool',
    data,
    method: 'post'
  })
}

const Check = (id, status) => {
  return axios.request({
    url: baseurl + 'gameaward/check/' + id + '/' + status,
    method: 'post'
  })
}

const GetAwards = (id) => {
  return axios.request({
    url: baseurl + 'gameaward/itemlist/' + id,
    method: 'post'
  })
}

const newAwards = (data) => {
  return axios.request({
    url: baseurl + 'gameaward/additem/',
    method: 'post',
    data: data
  })
}

const editAwards = (data) => {
  return axios.request({
    url: baseurl + 'gameaward/edititem/',
    method: 'post',
    data: data
  })
}

const GetTemplate = (poolid) => {
  return axios.request({
    url: baseurl + 'gameaward/' + poolid,
    method: 'get',
  })
}

const SaveTemplate = (data) => {
  return axios.request({
    url: baseurl + 'gameaward/editsingle',
    method: 'post',
    data: data
  })
}

const exportList = (data) => {
  return axios.request({
    url: baseurl + 'gameaward/export',
    method: 'post',
    data: data
  })
}

export default {
  FindByPage,
  Add,
  Edit,
  Check,
  GetAwards,
  newAwards,
  editAwards,
  GetTemplate,
  SaveTemplate,
  exportList
}
