const baseurl = '/v1/api/gamecenter/';
export default baseurl;