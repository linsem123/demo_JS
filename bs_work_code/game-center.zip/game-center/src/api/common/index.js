import axios from '@/libs/api.request';
import baseurl from './base';

const getMenu = () => {
    return axios.request({
        url: '/sys/menu/getMenu',
        method: 'post',
        data: {
            appId: 4
        }
    })
}
const getUserInfo = () => {
    return axios.request({
        url: '/sys/user/getLoginInfo',
        method: 'get'
    })
}
const getCDNConfig = () => {
    return axios.request({
        url: baseurl + 'game/cos_config',
        method: 'post'
    })
}

export default {
    getMenu,
    getUserInfo,
    getCDNConfig
}