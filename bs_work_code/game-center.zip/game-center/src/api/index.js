import Common from './common/index';

export default {

    Common
}