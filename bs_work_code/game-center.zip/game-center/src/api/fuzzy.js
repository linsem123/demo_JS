import axios from "@/libs/api.request";
// import baseurl from './finance/base';
import gamespaceUrl from "./gamespace/base";
import gameCircleUrl from "./gameCircle/base";

//合辑
const ModelLike = (data) => {
  return axios.request({
    url: gamespaceUrl + "home/collection/like/" + data.like + "/" + data.type,
    method: "post",
  });
};
const ModelById = (data) => {
  return axios.request({
    url: gamespaceUrl + "home/collection/info/" + data.id,
    method: "post",
  });
};
//论坛帖
const PostLike = (data) => {
  return axios.request({
    url: gameCircleUrl + "forum/post/like/" + data.like,
    data: {},
    method: "post",
  });
};
const getPostList = (data) => {
  return axios.request({
    url: gameCircleUrl + "forum/post/find_by_page",
    data: {
      PostId: data.id,
      IsTop: data.IsTop,
      Limit: data.Limit,
      Page: data.Page,
    },
    method: "post",
  });
};
//帖子榜单
const PostRankLike = (data) => {
  let url = "post/rank/like?name=" + data.like + "&ForumType=" + data.type;
  if (data.status) {
    url += "&status=" + data.status;
  }
  return axios.request({
    url: gameCircleUrl + url,
    data: {},
    method: "post",
  });
};
//帖子榜单
const getPostRank = (data) => {
  return axios.request({
    url: gamespaceUrl + "post/rank/one?id=" + data.id,
    data: {},
    method: "post",
  });
};
//拦截器-分组列表-城市名模糊查询
const cityLike = (data) => {
  return axios.request({
    url: gamespaceUrl + "city/like/" + data.like,
    data: {},
    method: "post",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });
};
//拦截器-平台列表-平台名模糊查询
const platformLike = (data) => {
  return axios.request({
    url: gamespaceUrl + "platform/like/" + data.like,
    data: {},
    method: "post",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });
};
//拦截器-城市分组模糊查询
const cityGropLike = (data) => {
  return axios.request({
    url: gamespaceUrl + "group_city/like/" + data.like,
    data: {},
    method: "post",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });
};
//拦截器-规则名模糊查询
const ruleLike = (data) => {
  return axios.request({
    url: gamespaceUrl + "rule/like/" + data.like,
    data: {},
    method: "post",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });
};

//游戏名称模糊搜索
const gameLike = (data) => {
  return axios.request({
    url: gamespaceUrl + "game/like/" + data.like,
    method: "get",
  });
};
//游戏ID 查询对应游戏
const getGameList = (data) => {
  return axios.request({
    url: gamespaceUrl + "game/" + data.id,
    method: "get",
  });
};
//重点游戏活动名称模糊搜索
const KeyGameLike = (data) => {
  return axios.request({
    url: gamespaceUrl + "important/like/" + data.like,
    method: "post",
  });
};
//重点游戏活动根据id查询
const getKeyGameList = (data) => {
  return axios.request({
    url: gamespaceUrl + "important/one/" + data.id,
    method: "post",
  });
};
//h5活动模糊查询（抽奖/宣传活动）
const LikeActivity = (data) => {
  return axios.request({
    url: gamespaceUrl + "gamefeed/feedlike/" + data.like + "/" + data.type,
    method: "get",
  });
};
//h5活动根据id查询
const getActivityByID = (data) => {
  return axios.request({
    url: gamespaceUrl + "gamefeed/feedinfo/" + data.id,
    method: "get",
  });
};
//榜单名称模糊查询
const LikeRank = (data) => {
  return axios.request({
    url: gamespaceUrl + "gamerank/like/" + data.like + "/" + data.type,
    method: "post",
  });
};
//榜单根据id查询
const GetRankById = (data) => {
  return axios.request({
    url: gamespaceUrl + "gamerank/one/" + data.id,
    method: "post",
  });
};

//首页模块名称模糊查询
const LikeModel = (data) => {
  return axios.request({
    url: gamespaceUrl + "home/model/father_like/" + data.like,
    method: "post",
  });
};
//首页模块根据id查询
const GetModelById = (data) => {
  return axios.request({
    url: gamespaceUrl + "home/model/father_one/" + data.id,
    method: "post",
  });
};
//模糊查询包名
const LikeAppByParams = (data) => {
  return axios.request({
    url: gamespaceUrl + "game/like",
    data: {
      params: { PkgName: data.like },
    },
    method: "post",
  });
};
//开发者模糊查询
const LikeDeveloper = (data) => {
  return axios.request({
    url: gamespaceUrl + "developer/like/" + data.like,
    method: "get",
  });
};
//公告管理根据ID或标题查询
const GetAnnounce = (data) => {
  return axios.request({
    url: gamespaceUrl + "announce/like/query",
    method: "post",
    data: {
      Title: data.like || "",
      ...data,
    },
  });
};

// 4.11迭代新增，绑定跳转类型为论坛帖时，查询无已投放校验的活动列表接口
const LikeActivityFree = (data) => {
    return axios.request({
      url: gamespaceUrl + 'forum/post/like/' + data.like,
      method: 'post'
    })
}
// 4.11迭代新增，针对"无已投放校验的列表"，查询绑定跳转活动的帖子详情
const FeedsInfoFree = (data) => {
    return axios.request({
      url: gamespaceUrl + 'forum/post/' + data.id,
      method: 'post'
    })
}

export default {
  ModelLike,
  ModelById,
  PostLike,
  getPostList,
  PostRankLike,
  getPostRank,
  cityLike,
  platformLike,
  cityGropLike,
  ruleLike,
  gameLike,
  getGameList,
  KeyGameLike,
  getKeyGameList,
  LikeActivity,
  getActivityByID,
  LikeRank,
  GetRankById,
  LikeModel,
  GetModelById,
  LikeAppByParams,
  LikeDeveloper,
  GetAnnounce,
  LikeActivityFree,
  FeedsInfoFree
};
