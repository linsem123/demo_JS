import axios from '@/libs/api.request';
import baseurl from './base';
//获取所有的省市
const cityList = () => {
    return axios.request({
        url: baseurl + 'city/all',
        method: 'post',
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    })
}

export default {
    cityList,
}