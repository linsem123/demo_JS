import axios from '@/libs/api.request';
import baseurl from './base';

const getList = (data) => {
    return axios.request({
        url: baseurl + 'platform/fetch',
        data,
        method: 'post'
    })
}

const Edit = (data, id) => {
    return axios.request({
        url: baseurl + 'platform/edit/' + id,
        method: 'post',
        data
    })
}

const Add = (data) => {
    return axios.request({
        url: baseurl + 'platform/add',
        method: 'post',
        data
    })
}
const Update = (data, id) => {
    return axios.request({
        url: baseurl + 'platform/check/' + id,
        method: 'post',
        data
    })
}

export default {
    getList,
    Add,
    Edit,
    Update
}