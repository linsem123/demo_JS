import axios from '@/libs/api.request';
import baseurl from './base';

const getList = (data) => {
    return axios.request({
        url: baseurl + 'group_city/fetch',
        data,
        method: 'post'
    })
}
//获取所有的市
const cityList = () => {
    return axios.request({
        url: baseurl + 'city/fetch',
        method: 'post',
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    })
}
//获取分组下面的城市
const groupCityList = (data) => {
    return axios.request({
        url: baseurl + 'group_city/cities',
        method: 'post',
        data: data,
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    })
}

const Edit = (data, id) => {
    return axios.request({
        url: baseurl + 'group_city/edit/' + id,
        method: 'post',
        data
    })
}

const Add = (data) => {
    return axios.request({
        url: baseurl + 'group_city/add',
        method: 'post',
        data
    })
}
const Update = (data, id) => {
    return axios.request({
        url: baseurl + 'group_city/check/' + id,
        method: 'post',
        data
    })
}

export default {
    getList,
    cityList,
    Add,
    Edit,
    groupCityList,
    Update
}