// const baseurl = '/v2/forum/';
const baseurl = '/v1/api/gamecenter/';


export default baseurl;