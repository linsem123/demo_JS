import axios from '@/libs/api.request';
import baseurl from './base';
const getList = (data) => {
    return axios.request({
        url: baseurl + 'rule_bind/fetch',
        data,
        method: 'post'
    })
}

const Edit = (data, id) => {
    return axios.request({
        url: baseurl + 'rule_bind/edit/' + id,
        method: 'post',
        data
    })
}

const Add = (data) => {
    return axios.request({
        url: baseurl + 'rule_bind/add',
        method: 'post',
        data
    })
}
const Update = (data, id) => {
    return axios.request({
        url: baseurl + 'rule_bind/check/' + id,
        method: 'post',
        data
    })
}
const getBindList = (data) => {
    return axios.request({
        url: baseurl + 'rule_bind/standard/fetch',
        method: 'post',
        data
    })
}

export default {
    getList,
    Add,
    Edit,
    Update,
    getBindList
}