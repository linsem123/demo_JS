import axios from '@/libs/api.request';
import baseurl from './base';

const getList = (data) => {
    return axios.request({
        url: baseurl + 'rule/fetch',
        data,
        method: 'post'
    })
}

const Edit = (data, id) => {
    return axios.request({
        url: baseurl + 'rule/edit/' + id,
        method: 'post',
        data
    })
}

const Add = (data) => {
    return axios.request({
        url: baseurl + 'rule/add',
        method: 'post',
        data
    })
}
const Update = (data, id) => {
    return axios.request({
        url: baseurl + 'rule/check/' + id,
        method: 'post',
        data
    })
}

export default {
    getList,
    Add,
    Edit,
    Update
}