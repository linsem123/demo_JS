import axios from '@/libs/api.request';
import baseurl from './base';
const getList = (data) => {
    return axios.request({
        url: baseurl + 'standard_app/fetch',
        data,
        method: 'post'
    })
}

const Edit = (data, id) => {
    return axios.request({
        url: baseurl + 'standard_app/edit/' + id,
        method: 'post',
        data
    })
}

const Add = (data) => {
    return axios.request({
        url: baseurl + 'standard_app/add',
        method: 'post',
        data
    })
}
const Update = (data, id) => {
    return axios.request({
        url: baseurl + 'standard_app/check/' + id,
        method: 'post',
        data
    })
}
const getBindList = (data) => {
    return axios.request({
        url: baseurl + 'standard_app/bind_app/fetch',
        method: 'post',
        data
    })
}
//拦截器-应用绑定-应用名模糊查询
const appBindingLike = (data) => {
    return axios.request({
        url: baseurl + 'standard_app/like_app_name/' + data,
        data: {},
        method: 'post',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
}
//拦截器-应用绑定-标准包名模糊查询
const pkgNameLike = (data) => {
    return axios.request({
        url: baseurl + 'standard_app/like_pkgname/' + data,
        data: {},
        method: 'post',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    })
}
export default {
    getList,
    Add,
    Edit,
    Update,
    appBindingLike,
    pkgNameLike,
    getBindList
}