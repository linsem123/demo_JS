import axios from '@/libs/api.request'
import baseurl from './base'
//积分任务配置
const GetList = (data) => {
    return axios.request({
        url: baseurl + 'integral/fetch',
        method: 'post',
        data,
    })
}
const AddConfig = (data) => {
    return axios.request({
        url: baseurl + 'integral/create',
        method: 'post',
        data,
    })
}
const EditConfig = (id, data) => {
    return axios.request({
        url: baseurl + 'integral/edit/' + id,
        method: 'post',
        data,
    })
}
const BindConfig = (id, status) => {
    return axios.request({
        url: baseurl + 'integral/status/' + id + "/" + status,
        method: 'post',
        data: {},
    })
}
export default {
    GetList,
    AddConfig,
    EditConfig,
    BindConfig
}
