import axios from '@/libs/api.request';
import baseurl from './base';

const FindByPage = (
  Limit,
  Page,
  Params
) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'gamegroup/list',
    data,
    method: 'post'
  })
}

 const LikeTitle = ({
  value
}) => {
  return axios.request({
    url: baseurl + 'gamegroup/title_like/' + value,
    method: 'get'
  })
}

 const Enable = (
  id,
  enable
) => {
  return axios.request({
    url: baseurl + 'gamegroup/enable/' + id + '/' + enable,
    method: 'post'
  })
}


 const Add = (data) => {
  return axios.request({
    url: baseurl + 'gamegroup',
    data,
    method: 'post'
  })
}

 const Edit = (id, data) => {
  return axios.request({
    url: baseurl + 'gamegroup/edit/' + id,
    data,
    method: 'post'
  })
}

export default{
  FindByPage,
  LikeTitle,
  Enable,
  Add,
  Edit,
}