import Wallpaper from './wallpaper.js';
import GameGroup from './gamegroup.js';

export default {
  Wallpaper,
  GameGroup,
}
