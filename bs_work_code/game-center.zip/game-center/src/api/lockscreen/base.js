const baseurl = '/v1/api/lockscreen/';

export default baseurl;