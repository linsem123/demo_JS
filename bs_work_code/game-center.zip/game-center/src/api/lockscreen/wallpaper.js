import axios from '@/libs/api.request';
import baseurl from './base';
import config from '@/config'
const baseUrl = process.env.NODE_ENV === 'development' ? config.baseUrl.dev : config.baseUrl.pro

const FindByPage = (
  Limit,
  Page,
  Params) => {
  const data = {
    Limit,
    Page,
    Params,
  }
  return axios.request({
    url: baseurl + 'wallpaper/list',
    data,
    method: 'post'
  })
}

const Add = (data) => {
  return axios.request({
    url: baseurl + 'wallpaper',
    data,
    method: 'post'
  })
}

const Enable = (
  id,
  enable
) => {
  return axios.request({
    url: baseurl + 'wallpaper/enable/' + id + '/' + enable,
    method: 'post'
  })
}

const LikeTitle = ({
  value
}) => {
  return axios.request({
    url: baseurl + 'wallpaper/title_like/' + value,
    method: 'get'
  })
}

const Get = (id) => {
  return axios.request({
    url: baseurl + 'wallpaper/' + id,
    method: 'get'
  })
}
const Edit = (data) => {
  return axios.request({
    url: baseurl + 'wallpaper/edit/' + data.ID,
    data,
    method: 'post'
  })
}

const UploadURL = () => {
  return baseUrl + baseurl + 'wallpaper/upload';
}

const Rank = (id) => {
  return axios.request({
    url: baseurl + 'wallpaper/rank/' + id,
    method: 'post'
  })
}

const CheckStatus=(id,data)=>{
  console.log(id,data);
  return axios.request({
    url: baseurl + 'wallpaper/check/' + id,
    data,
    method: 'post'
  })
}
export default {
  FindByPage,
  Add,
  Enable,
  LikeTitle,
  UploadURL,
  Get,
  Edit,
  Rank,
  CheckStatus,
}
