<template>
  <el-drawer :model-value="visible" title="我的应用" direction="ltr" size="50%">
    <div class="apps-menu-content">
      <div class="apps-menu-history" v-if="historyMenus.length > 0">
        <h3>最近访问</h3>
        <span
          class="adminui-apps-menu-item"
          v-for="(item, index) of historyMenus"
          :key="index"
          @click="doJumpTo(item)"
          >
          <span>{{ item.appName }}</span>
          <addr-icon style="position:absolute;left:-18px;" v-if="appId && item.appId == appId"></addr-icon>
        </span>
      </div>
      <div class="apps-menu-all">
        <h3>所有应用</h3>
          <span
            class="adminui-apps-menu-item"
            @click="doJumpTo(item)"
            v-for="(item, index) of menus"
            :key="index"
            >
            <span>{{ item.appName }}</span>
             <addr-icon style="position:absolute;left:-18px;" v-if="appId && item.appId == appId"></addr-icon>
             </span>
      </div>
    </div>
  </el-drawer>
</template>
<script>
import AddrIcon from './AddrIcon.vue'
export default {
  name:'MainAppsMenu',
  components:{AddrIcon},
  props:{
    appId:{
      type:String,
      default:''
    }
  },
  data() {
    return {
      visible: false,
      menus: [], 
      historyMenus: [], 
      iconColor:''
    };
  },
  watch: {
    value(val) {
      if (this.visible != val) {
        this.visible = val;
      }
    },
  },
  mounted() {
    this.menus = this.$TOOL.data.get("ENTER_MENU") || [];
    this.historyMenus = this.$TOOL.data.get("HISTORY_MENU") || [];
  },
  methods: {
    doJumpTo(menu) {
      if(this.appId && this.appId == menu.appId){
        return
      }
      window.location.replace(menu.baseRouter + "/"); //跳转页面
    },
  },
};
</script>
<style lang="scss" >
.apps-menu-content {
  padding-bottom:50px;
  width: 100%;
  h3 {
    padding-bottom: 10px;
  }
}
.apps-menu-history,
.apps-menu-all {
  margin: 10px 10px 10px 30px;
  width: 100%;
}
.adminui-apps-menu-item{
  position: relative;
	$bgColor:var(--el-color-primary);
	margin: 10px 30px 10px 0;
	padding: 6px 10px;
	width: 120px;
	border: 1px solid var(--el-color-primary);
	color: var(--el-color-primary);
	border-radius: 4px;
	display: inline-block;
	cursor: pointer;
	box-sizing: border-box;
	&:hover {
	  border: 1px solid var(--el-color-primary);
	  background-color: var(--el-color-primary) !important;
	  color: #fff;
	}
}
</style>
