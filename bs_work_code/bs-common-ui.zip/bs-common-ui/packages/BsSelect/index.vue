<template>
    <el-select
        v-model="value"
        class="bs-select"
        :style="style"
        :tag-type="tagType"
        :placeholder="placeholder"
        :size="size"
        :loading-text="loadingText"
        :no-match-text="noMatchText"
        :no-data-text="noDataText"
        :loading="isLoading"
        :remote="isRemote"
        :multiple="isMultiple"
        :filterable="isFilterable"
        :disabled="isDisabled"
        :clearable="isClearable"
        :collapse-tags="isCollapseTags"
        :collapse-tags-tooltip="isCollapseTagsTooltip"
        :multiple-limit="multipleLimit"
        :remote-method="handelRemote"
        @clear="handleClear"
        @change="handleChange"
    >
        <el-option
            v-for="item in selectList"
            :key="item.value"
            :label="isShowValue ? `(${item.value || ''})${item.label}` : item.label"
            :value="item.value"
        />
    </el-select>
</template>
<script>
export default {
    name: "BsSelect",
    props: {
        selecetValue: { type: [Number, String, Object, Array], default: "" },
        apiObj: { type: [Function, String], default: "" },
        params: { type: [Number, String, Object, Array], default: "" },
        echoApi: { type: [Function, String], default: "" },
        echoParams: { type: [Number, String, Object, Array], default: "" },
        style: {
            type: Object,
            default: () => {}
        },
        tagType: {
            type: String,
            default: "info"
        },
        dataArray: {
            type: Array,
            default: () => []
        }, // 下拉框数据
        placeholder: {
            type: String,
            default: "请选择"
        }, // 占位文字
        loadingText: {
            type: String,
            default: "Loading"
        }, // 从服务器加载内容时显示的文本
        noMatchText: {
            type: String,
            default: "No matching data"
        }, // 搜索条件无匹配时显示的文字
        noDataText: {
            type: String,
            default: "No data"
        }, // 无选项时显示的文字
        size: {
            type: String,
            default: "default"
        },
        isRemote: {
            type: Boolean,
            default: false
        }, // 是否从服务器远程加载
        isFilterable: {
            type: Boolean,
            default: false
        },
        isMultiple: {
            type: Boolean,
            default: false
        }, // 是否可以多选
        isDisabled: {
            type: Boolean,
            default: false
        }, // 是否可以禁用
        isShowValue: {
            type: Boolean,
            default: false
        }, // label是否显示value值
        isClearable: {
            type: Boolean,
            default: true
        }, // 是否可以清空选项
        isCollapseTags: {
            type: Boolean,
            default: false
        }, // 多选时是否将选中值按文字的形式展示
        isCollapseTagsTooltip: {
            type: Boolean,
            default: false
        }, // 当鼠标悬停于折叠标签的文本时，是否显示所有选中的标签。 要使用此属性，collapse-tags属性必须设定为 true
        isCanShowAll: {
            type: Boolean,
            default: false
        },
        multipleLimit: {
            type: Number,
            default: 0
        }
    },
    data() {
        return {
            value: "",
            isLoading: false,
            list: [],
            selectList: []
        };
    },
    watch: {
        selecetValue: {
            deep: true,
            immediate: true,
            handler: function (newVal) {
                // console.log(newVal, "selecetValue", this.selectList.length);
                if (this.isMultiple && this.isCanShowAll && this.selectList.length == newVal.length + 1) {
                    this.value = ["all"];
                } else {
                    this.value = newVal;
                }
            }
        },
        dataArray: {
            deep: true,
            immediate: true,
            handler: function (val) {
                if (this.dataArray && val.length && !this.isRemote) {
                    this.selectList = this.handleList(val);
                }
                if (this.apiObj && this.isRemote && !this.dataArray.length) this.handelRemote();

                if (this.isMultiple && this.isCanShowAll && this.selectList.length == this.selecetValue.length + 1) {
                    this.value = ["all"];
                }
            }
        }
    },
    mounted() {
        try {
            if (this.isRemote && this.value && this.echoApi) this.handleEcho(this.value);
        } catch (error) {
            console.log(error);
        }
    },
    methods: {
        handleClear() {
            this.$emit("update:selecetValue", "");
        },
        handleChange(value) {
            if (
                this.isMultiple &&
                this.isCanShowAll &&
                (value == "all" || value.includes("all") || this.selectList.length == value.length + 1)
            ) {
                this.value = ["all"];
                let list = JSON.parse(JSON.stringify(this.selectList));
                let selectValue = list.splice(1).map(item => {
                    return item.value;
                });
                this.$emit("update:selecetValue", selectValue);
            } else {
                this.$emit("update:selecetValue", value);
            }
        },
        handelRemote(value) {
            let str = value || this.value;
            if (!str || this.isLoading || !str.length) {
                return;
            }
            if (this.selectList && this.selectList.length === 1 && (this.selectList[0].Title === value || this.selecetValue[0] == value)) {
                return;
            }
            this.isLoading = true;
            if (this.isFilterable) {
                this.apiObj(value, this.params ? this.params : "").then(res => {
                    if (res.Code === 0) {
                        this.list = res.Data || [];
                        this.selectList = this.handleList(this.list);
                        this.selectList = this.selectList.filter(item => item.label.toLowerCase().indexOf(value.toLowerCase()) > -1);
                        // console.log(this.selectList);
                    }
                });
            } else {
                this.apiObj(this.params ? this.params : "").then(res => {
                    if (res.Code === 0) {
                        this.list = res.Data || [];
                        this.selectList = this.handleList(this.list);
                        if (this.isMultiple && this.isCanShowAll && this.selectList.length == this.value.length + 1) {
                            this.value = ["all"];
                        }
                    }
                });
            }
            this.isLoading = false;
        },
        handleEcho(value) {
            if (this.selectList && this.selectList.length === 1 && this.selectList[0].value == this.value) {
                return;
            }
            if (!value || value == null) {
                return;
            }
            this.echoApi(this.echoParams).then(res => {
                if (res.Code === 0) {
                    this.list = res.Data || [];
                    this.selectList = this.handleList(this.list);
                }
            });
        },
        handleList(list) {
            let formatList = list.map(item => {
                return {
                    value: item.ID || item.Id || item.id || item.AppId || item.appId || "",
                    label: item.title || item.Title || item.label || item.Label || item.name || item.Name || item.appName || item.AppName,
                    ...item
                };
            });
            if (this.isCanShowAll) {
                formatList.unshift({
                    value: "all",
                    label: "全部"
                });
            }
            return formatList;
        }
    }
};
</script>
<style lang="sass" scoped>
</style>