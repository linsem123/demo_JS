<template>
    <div>测试npm组件</div>
</template>
<script>
export default {
    name: "BsButton"
};
</script>