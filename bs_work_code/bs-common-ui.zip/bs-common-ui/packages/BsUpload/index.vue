<template>
    <div>
        <div class="row-wrap">
            <div class="demo-upload-list" v-for="(item, index) in uploadList" :key="index">
                <template v-if="['img','video','pdf'].includes(getfileType(item.url))">
                    <img :src="item.url" v-if="getfileType(item.url) == 'img'" class="img-prev" />

                    <div class="video-prev" v-if="getfileType(item.url) == 'video'">
                        <video :src="item.url" width="60" height="60"></video>
                        <!-- <el-icon color="rgba(0,0,0,0.2)" :size="30" class="play-icon"><video-play /></el-icon> -->
                    </div>

                    <img src="./assets/img/pdf.jpeg" v-if="getfileType(item.url) == 'pdf'" class="img-prev" />
                </template>
                <!-- 兼容无法判断类型的链接（由服务器解析返回） -->
                <template v-else>
                    <img :src="item.url" v-if="type.indexOf('img')>=0" class="img-prev" />

                    <div class="video-prev" v-if="type.indexOf('video')>=0">
                        <video :src="item.url" width="60" height="60"></video>
                        <!-- <el-icon color="rgba(0,0,0,0.2)" :size="30"><video-play /></el-icon> -->
                    </div>
                </template>

                <div class="demo-upload-list-cover">
                    <el-icon @click="handleView(item)">
                        <eye />
                    </el-icon>
                    <el-icon v-if="!readOnly" @click="handleRemove(item, index)">
                        <delete />
                    </el-icon>
                </div>
            </div>

            <el-upload v-show="uploadList.length < maxNum" class="avatar-uploader" ref="upload" :show-file-list="false"
                :file-list="uploadList" :multiple="multiple" :action="action" :before-upload="handleBeforeUpload">
                <el-icon class="avatar-uploader-icon">
                    <CameraFilled />
                </el-icon>
            </el-upload>
        </div>

        <el-image-viewer v-if="showViewer" @close="showViewer=false" :url-list="[previewUrl]" />
    </div>
</template>

<script>
    // import axios from "@/libs/api.request";
    import { View as Eye, Delete, CameraFilled } from "@element-plus/icons-vue";
    // import http from "@/utils/request"
    import { getSuffix, AssertVideo, readImg, compressImg } from "./assets/js/tools";
    import COS from "cos-js-sdk-v5";

    export default {
        name: "BsUpload",
        components: {
            Eye,
            Delete,
            CameraFilled
        },
        // model: {
        //     prop: "initUpload",
        //     event: "uploadSuccess"
        // },
        props: {
            initUpload: null, // maxNum为1时，传url字符串值，大于1时传文件列表
            readOnly: {
                type: Boolean,
                default: false
            },
            cosconfig: {},
            // 上传地址
            action: {
                type: String,
                default: "https://jsonplaceholder.typicode.com/posts/"
            },
            format: {
                type: Array,
                default: function () {
                    return ["jpg", "png", "jpeg"];
                }
            },
            module: {
                type: String,
                default: "game"
            },
            // 最大上传数量
            maxNum: {
                type: Number,
                default: 1
            },
            // 文件大小限制
            maxSize: null,
            // onSuccess: {
            //     type: Function,
            //     default: function () { },
            // },
            // onRemove: {
            //     type: Function,
            //     default: function () { },
            // },
            type: {
                type: String,
                default: "img" // 默认为img，可选，img video,pdf，可能为多类型，由","隔开，如（img,pdf）
            },
            poster: {},
            towebp: {
                // 是否要压缩转换为webp格式，默认不转
                type: Boolean,
                default: false
            },
            // 是否压缩上传，默认原图
            compress: {
                type: Boolean,
                default: false
            },
            // 是否支持多选
            multiple: {
                type: Boolean,
                default: false
            },
            getSts: {
                type: Function,
                default: () => { }
            }
        },
        data() {
            return {
                uploadList: [],
                previewUrl: "",
                showViewer: false,
            };
        },
        mounted() {
            // 初始化上传列表
            this.uploadList = (() => {
                if (this.maxNum === 1) {
                    if (this.initUpload) {
                        return [{ url: this.initUpload }];
                    } else {
                        return [];
                    }
                }
                if (this.initUpload && this.initUpload.length > this.maxNum) {
                    return this.initUpload.slice(0, this.maxNum) || [];
                }
                return this.initUpload || [];
            })();

        },
        watch: {
            initUpload() {
                if (this.maxNum === 1) {
                    if (this.initUpload) {
                        this.uploadList = [{ url: this.initUpload }];
                    } else {
                        this.uploadList = [];
                    }
                } else {
                    if (this.initUpload && this.initUpload.length > this.maxNum) {
                        this.uploadList = this.initUpload.slice(0, this.maxNum) || [];
                    } else {
                        this.uploadList = this.initUpload || [];
                    }
                }
            }
        },
        computed: {
            formatInside() {
                let formatRes = [];
                if (this.format.length > 0) {
                    formatRes = this.format;
                } else {
                    if (this.type.indexOf("video") >= 0) {
                        formatRes = formatRes.concat(["wmv", "avi", "mpeg", "mpg", "rm", "rmvb", "flv", "mp4"]);
                    }
                    if (this.type.indexOf("img") >= 0) {
                        formatRes = formatRes.concat(["jpg", "JPG", "jpeg", "JPEG", "png", "PNG", "gif", "GIF", "webp", "WebP", "mp3"]);
                    }
                    if (this.type.indexOf("pdf") >= 0) {
                        formatRes = formatRes.concat(["pdf"]);
                    }
                }
                return formatRes;
            }
        },
        methods: {
            // handleSuccess(res, file, fileList) {
            //   console.log("handleSuccess", fileList);
            //   this.uploadList = fileList;
            //   this.onSuccess(res, file, fileList);
            // },
            handleRemove(file, index) {
                this.uploadList.splice(index, 1);

                // this.onRemove(file, this.uploadList);
                if (this.maxNum == 1) {
                    this.$emit("update:initUpload", (this.uploadList[0] && this.uploadList[0].url) || "");
                } else {
                    this.$emit("update:initUpload", this.uploadList);
                }
            },
            // 预览
            handleView(file) {
                if (this.getfileType(file.url) == "img") {
                    this.previewUrl = file.url;
                    this.showViewer = true;
                } else if (this.getfileType(file.url) == "video" || this.getfileType(file.url) == "pdf") {
                    window.open(file.url, "_blank");
                } else {
                    if (this.type.indexOf("img") >= 0) {
                        this.previewUrl = file.url;
                        this.showViewer = true;
                    } else {
                        window.open(file.url, "_blank");
                    }
                }
            },
            getfileType(url) {
                return AssertVideo(url);
            },
            handleCos(filename, blob) {
                let that = this;
                let cos = new COS({
                    getAuthorization: function (options, callback) {
                        that.getSts().then(data => {
                            callback({
                                TmpSecretId: data.Data.credentials.tmpSecretId,
                                TmpSecretKey: data.Data.credentials.tmpSecretKey,
                                XCosSecurityToken: data.Data.credentials.sessionToken,
                                ExpiredTime: data.Data.expiredTime
                            });
                        });
                    }
                });

                cos.sliceUploadFile(
                    {
                        Bucket: that.cosconfig.Bucket || '' /* 必须 */,
                        Region: that.cosconfig.Region || '' /* 必须 *key"pkg"+"/"+parser.file.name /* 必须 */,
                        Key: filename,
                        Body: blob /* 必须 */
                    },
                    function (err, data) {
                        if (err) {
                            // console.error(err);
                            that.$message.error("上传失败");
                            return;
                        }
                        that.uploadList.push({
                            url: that.cosconfig.ExportURL + "/" + filename
                        });
                        // that.onSuccess(that.uploadList);
                        if (that.maxNum == 1) {
                            that.$emit("update:initUpload", (that.uploadList[0] && that.uploadList[0].url) || "");
                        } else {
                            that.$emit("update:initUpload", that.uploadList);
                        }
                    }
                );
            },
            handleBeforeUpload(file) {
                // console.log('------->', this.uploadList, this.maxNum);
                // 校验最大上传数量
                if (this.uploadList.length > this.maxNum) {
                    this.$message.warning(`文件数量不超过${this.maxNum}个`);
                    return false;
                }

                // 校验上传文件格式
                let nameSuffix = getSuffix(file.name);
                // console.log('suffix--->', nameSuffix);
                let format = [
                    ...new Set(
                        this.formatInside.map(item => {
                            return item.toLowerCase();
                        })
                    )
                ];
                if (!format.includes(nameSuffix)) {
                    this.$message.warning("文件格式有误，仅支持：" + format.join("，") + "文件");
                    return false;
                }

                // 校验文件大小
                if (this.maxSize) {
                    const maxSize = file.size / 1024 / 1024 < this.maxSize;
                    if (!this.compress && !maxSize) {
                        this.$message.warning(`上传文件大小不能超过 ${this.maxSize}MB!`);
                        return false;
                    }
                }

                let key = this.module + "/" + new Date().getTime() + "." + nameSuffix;

                if (this.type.indexOf("img") >= 0 && AssertVideo(key) === "img") {
                    if (this.compress) {
                        let filename = "";
                        let suffix = getSuffix(file.name);
                        let comType = "image/" + suffix;
                        if (this.towebp) {
                            comType = "image/webp";
                        }
                        readImg(file)
                            .then(img => {
                                compressImg(img, comType).then(({ blob }) => {
                                    let dotidx = key.lastIndexOf(".");
                                    filename = key.substr(0, dotidx) + "." + comType.replace("image/", "");

                                    this.handleCos(filename, blob);
                                });
                            })
                            .catch(err => {
                                this.$message.error("压缩失败！");
                            });
                    } else {
                        this.handleCos(key, file);
                    }
                } else {
                    this.handleCos(key, file);
                }

                return false;
            }
        }
    };
</script>

<style scoped lang="css">
    .row-wrap {
        display: flex;
        flex-direction: row;
    }

    .demo-upload-list {
        display: inline-block;
        width: 60px;
        height: 60px;
        text-align: center;
        line-height: 60px;
        border: 1px solid transparent;
        border-radius: 4px;
        overflow: hidden;
        background: #fff;
        position: relative;
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
        margin-right: 4px;
    }

    .demo-upload-list .video-prev {
        display: inline-block;
        text-align: center;
        line-height: 60px;
        position: relative;
    }

    .demo-upload-list .play-icon {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: (-50%, -50%);
    }

    .demo-upload-list img {
        width: 100%;
        height: 100%;
    }

    .demo-upload-list-cover {
        display: none;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, 0.6);
    }

    .demo-upload-list:hover .demo-upload-list-cover {
        display: block;
    }

    .demo-upload-list-cover i {
        color: #fff;
        font-size: 20px;
        cursor: pointer;
        margin: 0 2px;
    }

    .plus-img {
        width: 60px;
        height: 60px;
    }

    :deep() .avatar-uploader .el-upload {
        width: 60px;
        height: 60px;
        line-height: 60px;
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        font-size: 16px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        transition: var(--el-transition-duration-fast);
    }

    :deep() .avatar-uploader .el-upload:hover {
        border-color: var(--el-color-primary);
    }

    :deep() .el-icon .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        text-align: center;
    }
</style>