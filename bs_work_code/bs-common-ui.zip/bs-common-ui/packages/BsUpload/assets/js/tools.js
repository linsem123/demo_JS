export const AssertVideo = (name) => {
    const ft = getSuffix(name);
    if (ft == "gif" || ft == "jpeg" || ft == "png" || ft == "jpg" || ft == "webp") {
        return "img";
    }
    if (ft == "mp4" || ft == "avi" || ft == "wmv" || ft == "rmvb" || ft == "flv") {
        return "video";
    }
    return ft;
}
export const compressImg = (img, type) => {
    return new Promise((resolve, reject) => {
        const canvas = document.createElement('canvas')
        const context = canvas.getContext('2d')
        const { width: originWidth, height: originHeight } = img
        // 最大尺寸限制
        const maxWidth = 1920
        const maxHeight = originHeight
        // 目标尺寸
        let targetWidth = originWidth
        let targetHeight = originHeight
        if (originWidth > maxWidth || originHeight > maxHeight) {
            if (originWidth / originHeight > 1) {
                // 宽图片
                targetWidth = maxWidth
                targetHeight = Math.round(maxWidth * (originHeight / originWidth))
            } else {
                // 高图片
                targetHeight = maxHeight
                targetWidth = Math.round(maxHeight * (originWidth / originHeight))
            }
        }
        canvas.width = targetWidth
        canvas.height = targetHeight
        context.clearRect(0, 0, targetWidth, targetHeight)
        // 图片绘制
        context.drawImage(img, 0, 0, targetWidth, targetHeight)
        canvas.toBlob(function (blob) {
            resolve({ blob, width: targetWidth, height: targetHeight })
        }, type || 'image/webp')
    })
}
// 获取文件后缀
export const getSuffix = (name = "") => {
    var startIndex = name.lastIndexOf(".");
    if (startIndex == -1) return "";
    return name.substring(startIndex + 1, name.length).toLowerCase();
}
export const readImg = (file) => {
    return new Promise((resolve, reject) => {
        const img = new Image()
        const reader = new FileReader(); // 读取文件内容
        reader.onload = function (e) { // 文件读取完成
            img.src = e.target.result
        }
        reader.onerror = function (e) {
            reject(e)
        }
        reader.readAsDataURL(file); // 将读取到的文件编码成DataURL
        img.onload = function () {
            resolve(img)
        }
        img.onerror = function (e) {
            reject(e)
        }
    })
}
