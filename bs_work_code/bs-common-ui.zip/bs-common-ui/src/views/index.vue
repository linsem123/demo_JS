<template>
    <el-button @click="show = true">打开菜单</el-button>
    <main-apps-menu v-model="show" appId="20210001"></main-apps-menu>
    <bs-button></bs-button>

    <bs-upload v-model:initUpload="imgUrl" :cosconfig="cosconfig" :getSts="GetSts">
    </bs-upload>
    <br />

    <bs-table ref="table" :data="tableData" :dataTotal="total" height="auto" stripe remoteSort remoteFilter
        @updateList="updateList">
        <el-table-column label="ID" prop="Id" width="100" sortable>
            <template #default="scope">
                {{scope.row.Id}}
            </template>
        </el-table-column>
        <el-table-column label="游戏名" width="280" prop="Name">
            <template #default="scope">
                {{scope.row.Name}}
            </template>
        </el-table-column>
        <el-table-column label="游戏包名" width="120" prop="PkgName">
            <template #default="scope">
                {{scope.row.PkgName}}
            </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right" width="140">
            <template #default="scope">
                <el-button type="text" size="small" @click="table_event(scope.row, scope.$index)">查看</el-button>
                <el-button type="text" size="small" @click="table_event(scope.row, scope.$index)">编辑</el-button>
                <el-popconfirm title="确定删除吗？" @confirm="table_event(scope.row, scope.$index)">
                    <template #reference>
                        <el-button type="text" size="small">删除</el-button>
                    </template>
                </el-popconfirm>
            </template>
        </el-table-column>
    </bs-table>

</template>
<script>
    import { fetchList, GetSts } from '../api/model/demo.js';
    export default {
        name: "Demo",
        data() {
            return {
                show: false,
                imgUrl: '',
                uploadList: [{ url: 'https://cdn-activity.blackshark.com/game/1650336257127-bar.png' }],
                apiObj: null,
                fetchList,
                GetSts,
                cosconfig: {
                    Region: "ap-guangzhou",
                    Bucket: "activity-1256119282",
                    ExportURL: "https://cdn-activity.blackshark.com",//金山
                    TencentExportUrl: 'https://activity-1256119282.file.myqcloud.com'//腾讯
                },
                params: {
                    filter: '',
                    status: 1
                },

                tableData: [
                    {
                        Id: 11,
                        Name: '勇者征途（啦啦啦啦啦啦啦啦）',
                        PkgName: 'fhihfuwbfui.kojfihi.ifhfih.apk',
                        Status: 0,
                        Date: '2022-04-19 14:41'
                    }, {
                        Id: 22,
                        Name: '随便起个名字好了',
                        PkgName: 'iiiiiiiii-kojfihi-ifhfih.apk',
                        Status: 1,
                        Date: '2022-04-19 15:00'
                    }, {
                        Id: 33,
                        Name: '随便',
                        PkgName: 'iiiiiiiii-kojfihi-ifhfih.apk',
                        Status: 1,
                        Date: '2022-04-19 15:00'
                    }
                ],
                tableColumn: [
                    {
                        label: 'ID',
                        prop: 'Id',
                        width: 80,
                        sortable: true,
                        fixed: true,
                        // filters: '',
                        // showOverflowTooltip: true,
                    }, {
                        label: '游戏名',
                        prop: 'Name',
                        width: 120,
                        sortable: false,
                        fixed: true,
                        showOverflowTooltip: true,
                    }, {
                        label: '游戏包名称',
                        prop: 'PkgName',
                        width: 150,
                        sortable: false,
                        fixed: false,
                        showOverflowTooltip: true,
                    }, {
                        label: '状态',
                        prop: 'Status',
                        width: 100,
                    }, {
                        label: '操作时间',
                        prop: 'Date',
                    }
                ],

                successList: [],
            };
        },
        watch: {
            imgUrl() {
                console.log('v-model--->', this.imgUrl);
            },
        },
        mounted() {
            console.log('type==', typeof this.fetchList)
        },
        methods: {
            //表格选择后回调事件
            selectionChange(selection) {
                console.log('selection---->', selection);
                this.selection = selection;
            },
            table_event(row, index) {
                console.log('row--->', row, index);
            },
        },
    };
</script>