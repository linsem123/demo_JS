import config from "@/config"
import http from "@/utils/request"
import { reject } from "any-promise";

export default {
    ver: {
        url: `${config.API_URL}/demo/ver`,
        name: "获取最新版本号",
        get: async function () {
            return await http.get(this.url);
        }
    },
    post: {
        url: `${config.API_URL}/demo/post`,
        name: "分页列表",
        post: async function (data) {
            return await http.post(this.url, data, {
                headers: {
                    //'response-status': 401
                }
            });
        }
    },
    page: {
        url: `${config.API_URL}/demo/page`,
        name: "分页列表",
        get: async function (params) {
            return await http.get(this.url, params);
        }
    },
    menu: {
        url: `${config.API_URL}/demo/menu`,
        name: "普通用户菜单",
        get: async function () {
            return await http.get(this.url);
        }
    },
}

export const fetchList = function (params) {
    let data = [
        {
            no: 1,
            name: '张三'
        }, {
            no: 2,
            name: '李四'
        }
    ];
    if (params.filter == 'mine' || params.status == 2) {
        data = [
            {
                no: 2,
                name: '李四'
            }
        ];
    }
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(data);
        }, 500);
    });
}

export const GetSts = function (baseurl) {
    let data = {
        expiredTime: 1651148257,
        credentials: {
            sessionToken: "97619a1c3bfd39f65ff4abc32d32effbaede8afa30001",
            tmpSecretId: "AKIDNi5Z1oI6nGK7RjRCRabuZld0JsZbP3ii",
            tmpSecretKey: "I4J6YBn1bqDZOMs1G8wUbQdsKxSzIOqU"
        }
    }
    return new Promise((resolve, reject) => {
        resolve({ Data: data });
    })
}