import demo from './module/demoRouter'
const asyncRoutes = [...demo]
// 需做校验的异步路由
export default asyncRoutes