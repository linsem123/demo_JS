//示例
const routes = [
    {
        path: "/demo",
        name: "demo",
        meta: {
            icon: "el-icon-eleme-filled",
            title: "演示页面",
            type: "menu"
        },
        component: "index"
    
    },
]
export default routes