(function () {
  let fontSize = document.documentElement.style.fontSize.replace("px", "");
  let pageHeight = document.getElementById("editPage").offsetHeight;
  __resize(); //根据屏幕尺寸动态设置根节点font-size

  window.addEventListener("resize", __resize, false);

  function __resize() {
    var nowH = document.getElementById("editPage").offsetHeight;
    if (nowH < pageHeight) {
      document.getElementById("editPage").style.height =
        pageHeight / fontSize + "rem";
    }
  }
})();
// let url = window.location.href;
// console.log(url);
// let $QRCode = new QRCode(document.getElementById("qrcode"), {
//     text: url,
//     width: 50,
//     height: 50,
//     // colorDark: "#000000",
//     colorDark: "#000000",
//     colorLight: "#ffffff",
//     correctLevel: QRCode.CorrectLevel.H
// });

//生成邀请函图片
document
  .getElementsByClassName("init_btn")[0]
  .addEventListener("click", function () {
    clickAndInit();
  });
document
  .getElementsByClassName("act_btn")[0]
  .addEventListener("click", function () {
    document.getElementsByClassName("group1")[0].className = "group1";
    document.getElementsByClassName("group2")[0].className =
      "group2  page-show";
    document.getElementsByClassName("group2")[1].className =
      "group2  page-show";
    // document.getElementById('qrcode').className = 'page-show'
    document.getElementById("user_name").innerHTML =
      document.getElementById("input_text").value;
    document.getElementById("user_name1").innerHTML =
      document.getElementById("input_text").value;
  });
function clickAndInit() {
  document.getElementsByClassName("init_btn")[0].style.display = "none";
  // document.getElementsByClassName('group2')[0].className = 'group2  page-show';
  document.getElementsByClassName("init_page")[0].style.visibility = "visible";
  //   document.getElementsByClassName("qrcode_box")[0].className =
  //     "qrcode_box page-show";
  let dom = document.getElementById("initContent");
  getCanvasImg(dom);
  document.getElementsByClassName("model")[0].style.display = "block";
}
function getCanvasImg(dom) {
  var width = dom.offsetWidth; //dom宽
  var height = dom.offsetHeight; //dom高
  console.log(window.devicePixelRatio);
  let scale = 4;
  new html2canvas(dom, {
    dpi: window.devicePixelRatio * 4,
    scale: scale,
    width: width,
    heigth: height,
    allowTaint: true,
    useCORS: true,
  }).then((canvas) => {
    // canvas为转换后的Canvas对象
    let oImg = new Image();
    oImg.style.width = "100%";
    oImg.src = canvas.toDataURL("image/png", 1); // 导出图片
    let footer = document.getElementsByClassName("footer")[0];
    footer.parentNode.insertBefore(oImg, footer);
    document.getElementsByClassName("footer")[0].className = "footer page-show";
  });
}
function handleInpChange(event) {
  if (event.target.value) {
    document.getElementById("user_name").innerHTML = event.target.value;
    document.getElementsByClassName("unable_act")[0].style.display = "none";
    document.getElementsByClassName("act_btn")[0].style.display = "block";
  } else {
    document.getElementsByClassName("unable_act")[0].style.display = "block";
    document.getElementsByClassName("act_btn")[0].style.display = "none";
  }
}
